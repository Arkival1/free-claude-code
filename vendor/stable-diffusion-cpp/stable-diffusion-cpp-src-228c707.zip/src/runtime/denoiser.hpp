#ifndef __SD_RUNTIME_DENOISER_HPP__
#define __SD_RUNTIME_DENOISER_HPP__

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <functional>
#include <limits>
#include <map>
#include <string>
#include <utility>

#include "core/rng.hpp"
#include "core/rng_mt19937.hpp"
#include "core/rng_philox.hpp"
#include "core/tensor.hpp"
#include "core/util.h"
#include "model.h"
#include "runtime/gits_noise.h"
#include "runtime/guidance.h"

/*================================================= CompVisDenoiser ==================================================*/

// Ref: https://github.com/crowsonkb/k-diffusion/blob/master/k_diffusion/external.py

#define TIMESTEPS 1000
#define FLUX_TIMESTEPS 1000

struct SigmaScheduler {
    typedef std::function<float(float)> t_to_sigma_t;

    virtual std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) = 0;
};

struct DiscreteScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        std::vector<float> result;

        int t_max = TIMESTEPS - 1;

        if (n == 0) {
            return result;
        } else if (n == 1) {
            result.push_back(t_to_sigma((float)t_max));
            result.push_back(0);
            return result;
        }

        float step = static_cast<float>(t_max) / static_cast<float>(n - 1);
        for (uint32_t i = 0; i < n; ++i) {
            float t = t_max - step * i;
            result.push_back(t_to_sigma(t));
        }
        result.push_back(0);
        return result;
    }
};

struct ExponentialScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        std::vector<float> sigmas;

        // Calculate step size
        float log_sigma_min = std::log(sigma_min);
        float log_sigma_max = std::log(sigma_max);
        float step          = (log_sigma_max - log_sigma_min) / (n - 1);

        // Fill sigmas with exponential values
        for (uint32_t i = 0; i < n; ++i) {
            float sigma = std::exp(log_sigma_max - step * i);
            sigmas.push_back(sigma);
        }

        sigmas.push_back(0.0f);

        return sigmas;
    }
};

/* interp and linear_interp adapted from dpilger26's NumCpp library:
 * https://github.com/dpilger26/NumCpp/tree/5e40aab74d14e257d65d3dc385c9ff9e2120c60e */
constexpr double interp(double left, double right, double perc) noexcept {
    return (left * (1. - perc)) + (right * perc);
}

/* This will make the assumption that the reference x and y values are
 * already sorted in ascending order because they are being generated as
 * such in the calling function */
inline std::vector<double> linear_interp(std::vector<float> new_x,
                                         const std::vector<float> ref_x,
                                         const std::vector<float> ref_y) {
    const size_t len_x = new_x.size();
    size_t i           = 0;
    size_t j           = 0;
    std::vector<double> new_y(len_x);

    if (ref_x.size() != ref_y.size()) {
        LOG_ERROR("Linear Interpolation Failed: length mismatch");
        return new_y;
    }

    /* Adjusted bounds checking to ensure new_x is within ref_x range */
    if (new_x[0] < ref_x[0]) {
        new_x[0] = ref_x[0];
    }
    if (new_x.back() > ref_x.back()) {
        new_x.back() = ref_x.back();
    }

    while (i < len_x) {
        if ((ref_x[j] > new_x[i]) || (new_x[i] > ref_x[j + 1])) {
            j++;
            continue;
        }

        const double perc = static_cast<double>(new_x[i] - ref_x[j]) / static_cast<double>(ref_x[j + 1] - ref_x[j]);

        new_y[i] = interp(ref_y[j], ref_y[j + 1], perc);
        i++;
    }

    return new_y;
}

inline std::vector<float> linear_space(const float start, const float end, const size_t num_points) {
    std::vector<float> result(num_points);
    const float inc = (end - start) / (static_cast<float>(num_points - 1));

    if (num_points > 0) {
        result[0] = start;

        for (size_t i = 1; i < num_points; i++) {
            result[i] = result[i - 1] + inc;
        }
    }

    return result;
}

inline std::vector<float> log_linear_interpolation(std::vector<float> sigma_in,
                                                   const size_t new_len) {
    const size_t s_len        = sigma_in.size();
    std::vector<float> x_vals = linear_space(0.f, 1.f, s_len);
    std::vector<float> y_vals(s_len);

    /* Reverses the input array to be ascending instead of descending,
     * also hits it with a log, it is log-linear interpolation after all */
    for (size_t i = 0; i < s_len; i++) {
        y_vals[i] = std::log(sigma_in[s_len - i - 1]);
    }

    std::vector<float> new_x_vals  = linear_space(0.f, 1.f, new_len);
    std::vector<double> new_y_vals = linear_interp(new_x_vals, x_vals, y_vals);
    std::vector<float> results(new_len);

    for (size_t i = 0; i < new_len; i++) {
        results[i] = static_cast<float>(std::exp(new_y_vals[new_len - i - 1]));
    }

    return results;
}

/*
https://research.nvidia.com/labs/toronto-ai/AlignYourSteps/howto.html
*/
struct AYSScheduler : SigmaScheduler {
    SDVersion version;
    explicit AYSScheduler(SDVersion version)
        : version(version) {}
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        const std::vector<float> noise_levels[] = {
            /* SD1.5 */
            {14.6146412293f, 6.4745760956f, 3.8636745985f, 2.6946151520f,
             1.8841921177f, 1.3943805092f, 0.9642583904f, 0.6523686016f,
             0.3977456272f, 0.1515232662f, 0.0291671582f},
            /* SDXL */
            {14.6146412293f, 6.3184485287f, 3.7681790315f, 2.1811480769f,
             1.3405244945f, 0.8620721141f, 0.5550693289f, 0.3798540708f,
             0.2332364134f, 0.1114188177f, 0.0291671582f},
            /* SVD */
            {700.00f, 54.5f, 15.886f, 7.977f, 4.248f, 1.789f, 0.981f, 0.403f,
             0.173f, 0.034f, 0.002f},
        };

        std::vector<float> inputs;
        std::vector<float> results(n + 1);

        if (sd_version_is_sd2((SDVersion)version)) {
            LOG_WARN("AYS_SCHEDULER not designed for SD2.X models");
        } /* fallthrough */
        else if (sd_version_is_sd1((SDVersion)version)) {
            LOG_INFO("AYS_SCHEDULER using SD1.5 noise levels");
            inputs = noise_levels[0];
        } else if (sd_version_is_sdxl((SDVersion)version)) {
            LOG_INFO("AYS_SCHEDULER using SDXL noise levels");
            inputs = noise_levels[1];
        } else if (version == VERSION_SVD) {
            LOG_INFO("AYS_SCHEDULER using SVD noise levels");
            inputs = noise_levels[2];
        } else {
            LOG_ERROR("Version not compatible with AYS_SCHEDULER scheduler");
            return results;
        }

        /* Stretches those pre-calculated reference levels out to the desired
         * size using log-linear interpolation */
        if ((n + 1) != inputs.size()) {
            results = log_linear_interpolation(inputs, n + 1);
        } else {
            results = inputs;
        }

        /* Not sure if this is strictly neccessary */
        results[n] = 0.0f;

        return results;
    }
};

/*
 * GITS Scheduler: https://github.com/zju-pi/diff-sampler/tree/main/gits-main
 */
struct GITSScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        if (sigma_max <= 0.0f) {
            return std::vector<float>{};
        }

        std::vector<float> sigmas;

        // Assume coeff is provided (replace 1.20 with your dynamic coeff)
        float coeff = 1.20f;  // Default coefficient
        // Normalize coeff to the closest value in the array (0.80 to 1.50)
        coeff = std::round(coeff * 20.0f) / 20.0f;  // Round to the nearest 0.05
        // Calculate the index based on the coefficient
        int index = static_cast<int>((coeff - 0.80f) / 0.05f);
        // Ensure the index is within bounds
        index                                                 = std::max(0, std::min(index, static_cast<int>(GITS_NOISE.size() - 1)));
        const std::vector<std::vector<float>>& selected_noise = *GITS_NOISE[index];

        if (n <= 20) {
            sigmas = (selected_noise)[n - 2];
        } else {
            sigmas = log_linear_interpolation(selected_noise.back(), n + 1);
        }

        sigmas[n] = 0.0f;
        return sigmas;
    }
};

struct SGMUniformScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min_in, float sigma_max_in, t_to_sigma_t t_to_sigma_func) override {
        std::vector<float> result;
        if (n == 0) {
            result.push_back(0.0f);
            return result;
        }
        result.reserve(n + 1);
        int t_max                    = TIMESTEPS - 1;
        int t_min                    = 0;
        std::vector<float> timesteps = linear_space(static_cast<float>(t_max), static_cast<float>(t_min), n + 1);
        for (uint32_t i = 0; i < n; i++) {
            result.push_back(t_to_sigma_func(timesteps[i]));
        }
        result.push_back(0.0f);
        return result;
    }
};

struct LCMScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        std::vector<float> result;
        result.reserve(n + 1);
        const int original_steps = 50;
        const int k              = TIMESTEPS / original_steps;
        for (uint32_t i = 0; i < n; i++) {
            // the rounding ensures we match the training schedule of the LCM model
            int index    = (i * original_steps) / n;
            int timestep = (original_steps - index) * k - 1;
            result.push_back(t_to_sigma(static_cast<float>(timestep)));
        }
        result.push_back(0.0f);
        return result;
    }
};

struct KarrasScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        // These *COULD* be function arguments here,
        // but does anybody ever bother to touch them?
        float rho = 7.f;

        if (sigma_min <= 1e-6f) {
            sigma_min = 1e-6f;
        }

        std::vector<float> result(n + 1);

        float min_inv_rho = pow(sigma_min, (1.f / rho));
        float max_inv_rho = pow(sigma_max, (1.f / rho));
        for (uint32_t i = 0; i < n; i++) {
            // Eq. (5) from Karras et al 2022
            result[i] = pow(max_inv_rho + (float)i / ((float)n - 1.f) * (min_inv_rho - max_inv_rho), rho);
        }
        result[n] = 0.;
        return result;
    }
};

struct BetaScheduler : SigmaScheduler {
    double alpha = 0.6;
    double beta  = 0.6;

    explicit BetaScheduler(const char* extra_sample_args = nullptr) {
        parse_extra_sample_args(extra_sample_args);
        LOG_VERBOSE("Beta scheduler: alpha=%.4f, beta=%.4f", alpha, beta);
    }

    void parse_extra_sample_args(const char* extra_sample_args) {
        for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "beta scheduler arg")) {
            if (key == "alpha") {
                float parsed;
                if (!parse_strict_float(value, parsed) || parsed <= 0.0) {
                    LOG_WARN("ignoring invalid beta scheduler arg '%s=%s'", key.c_str(), value.c_str());
                } else {
                    alpha = static_cast<double>(parsed);
                }
            } else if (key == "beta") {
                float parsed;
                if (!parse_strict_float(value, parsed) || parsed <= 0.0) {
                    LOG_WARN("ignoring invalid beta scheduler arg '%s=%s'", key.c_str(), value.c_str());
                } else {
                    beta = static_cast<double>(parsed);
                }
            }
        }
    }

    static double log_beta(double a, double b) {
        return std::lgamma(a) + std::lgamma(b) - std::lgamma(a + b);
    }

    static double incbeta(double x, double a, double b) {
        if (x <= 0.0) {
            return 0.0;
        }
        if (x >= 1.0) {
            return 1.0;
        }

        // Continued fraction approximation using Lentz's method.
        const int max_iter   = 200;
        const double epsilon = 3.0e-7;
        const double tiny    = 1e-30;

        const double qab = a + b;
        const double qap = a + 1.0;
        const double qam = a - 1.0;

        double c = 1.0;
        double d = 1.0 - qab * x / qap;
        if (std::abs(d) < tiny) {
            d = tiny;
        }
        d        = 1.0 / d;
        double h = d;

        for (int m = 1; m <= max_iter; m++) {
            const int m2 = 2 * m;

            double aa = m * (b - m) * x / ((qam + m2) * (a + m2));
            d         = 1.0 + aa * d;
            if (std::abs(d) < tiny) {
                d = tiny;
            }
            c = 1.0 + aa / c;
            if (std::abs(c) < tiny) {
                c = tiny;
            }
            d = 1.0 / d;
            h *= d * c;

            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
            d  = 1.0 + aa * d;
            if (std::abs(d) < tiny) {
                d = tiny;
            }
            c = 1.0 + aa / c;
            if (std::abs(c) < tiny) {
                c = tiny;
            }
            d                = 1.0 / d;
            const double del = d * c;
            h *= del;

            if (std::abs(del - 1.0) < epsilon) {
                break;
            }
        }

        return std::exp(a * std::log(x) + b * std::log(1.0 - x) - log_beta(a, b)) / a * h;
    }

    static double beta_cdf(double x, double a, double b) {
        if (x == 0.0) {
            return 0.0;
        }
        if (x == 1.0) {
            return 1.0;
        }
        if (x < (a + 1.0) / (a + b + 2.0)) {
            return incbeta(x, a, b);
        }
        return 1.0 - incbeta(1.0 - x, b, a);
    }

    static double beta_ppf(double u, double a, double b, int max_iter = 30) {
        double x = 0.5;
        for (int i = 0; i < max_iter; i++) {
            const double f = beta_cdf(x, a, b) - u;
            if (std::abs(f) < 1e-10) {
                break;
            }
            const double df = std::exp((a - 1.0) * std::log(x) + (b - 1.0) * std::log(1.0 - x) - log_beta(a, b));
            x -= f / df;
            if (x <= 0.0) {
                x = 1e-10;
            }
            if (x >= 1.0) {
                x = 1.0 - 1e-10;
            }
        }
        return x;
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t t_to_sigma) override {
        std::vector<float> result;
        result.reserve(n + 1);

        const int t_max = TIMESTEPS - 1;
        if (n == 0) {
            return result;
        } else if (n == 1) {
            result.push_back(t_to_sigma(static_cast<float>(t_max)));
            result.push_back(0.f);
            return result;
        }

        int last_t = -1;
        for (uint32_t i = 0; i < n; i++) {
            const double u      = 1.0 - static_cast<double>(i) / static_cast<double>(n);
            const double t_cont = beta_ppf(u, alpha, beta) * t_max;
            const int t         = static_cast<int>(std::lround(t_cont));

            if (t != last_t) {
                result.push_back(t_to_sigma(static_cast<float>(t)));
                last_t = t;
            }
        }

        result.push_back(0.f);
        return result;
    }
};

struct SimpleScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        std::vector<float> result_sigmas;

        if (n == 0) {
            return result_sigmas;
        }

        result_sigmas.reserve(n + 1);

        int model_sigmas_len = TIMESTEPS;

        float step_factor = static_cast<float>(model_sigmas_len) / static_cast<float>(n);

        for (uint32_t i = 0; i < n; ++i) {
            int offset_from_start_of_py_array = static_cast<int>(static_cast<float>(i) * step_factor);
            int timestep_index                = model_sigmas_len - 1 - offset_from_start_of_py_array;

            if (timestep_index < 0) {
                timestep_index = 0;
            }

            result_sigmas.push_back(t_to_sigma(static_cast<float>(timestep_index)));
        }
        result_sigmas.push_back(0.0f);
        return result_sigmas;
    }
};

// Close to Beta Scheduler, but increadably simple in code.
struct SmoothStepScheduler : SigmaScheduler {
    static constexpr float smoothstep(float x) {
        return x * x * (3.0f - 2.0f * x);
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t t_to_sigma) override {
        std::vector<float> result;
        result.reserve(n + 1);

        const int t_max = TIMESTEPS - 1;
        if (n == 0) {
            return result;
        } else if (n == 1) {
            result.push_back(t_to_sigma((float)t_max));
            result.push_back(0.f);
            return result;
        }

        for (uint32_t i = 0; i < n; i++) {
            float u = 1.f - float(i) / float(n);
            result.push_back(t_to_sigma(std::round(smoothstep(u) * t_max)));
        }

        result.push_back(0.f);
        return result;
    }
};

struct BongTangentScheduler : SigmaScheduler {
    static constexpr float kPi = 3.14159265358979323846f;

    static std::vector<float> get_bong_tangent_sigmas(int steps, float slope, float pivot, float start, float end) {
        std::vector<float> sigmas;
        if (steps <= 0) {
            return sigmas;
        }

        float smax   = ((2.0f / kPi) * atanf(-slope * (0.0f - pivot)) + 1.0f) * 0.5f;
        float smin   = ((2.0f / kPi) * atanf(-slope * ((float)(steps - 1) - pivot)) + 1.0f) * 0.5f;
        float srange = smax - smin;
        float sscale = start - end;

        sigmas.reserve(steps);

        if (fabsf(srange) < 1e-8f) {
            if (steps == 1) {
                sigmas.push_back(start);
                return sigmas;
            }
            for (int i = 0; i < steps; ++i) {
                float t = (float)i / (float)(steps - 1);
                sigmas.push_back(start + (end - start) * t);
            }
            return sigmas;
        }

        float inv_srange = 1.0f / srange;
        for (int x = 0; x < steps; ++x) {
            float v     = ((2.0f / kPi) * atanf(-slope * ((float)x - pivot)) + 1.0f) * 0.5f;
            float sigma = ((v - smin) * inv_srange) * sscale + end;
            sigmas.push_back(sigma);
        }

        return sigmas;
    }

    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> result;
        if (n == 0) {
            return result;
        }

        float start  = sigma_max;
        float end    = sigma_min;
        float middle = sigma_min + (sigma_max - sigma_min) * 0.5f;

        float pivot_1 = 0.6f;
        float pivot_2 = 0.6f;
        float slope_1 = 0.2f;
        float slope_2 = 0.2f;

        int steps     = static_cast<int>(n) + 2;
        int midpoint  = static_cast<int>(((float)steps * pivot_1 + (float)steps * pivot_2) * 0.5f);
        int pivot_1_i = static_cast<int>((float)steps * pivot_1);
        int pivot_2_i = static_cast<int>((float)steps * pivot_2);

        float slope_scale = (float)steps / 40.0f;
        slope_1           = slope_1 / slope_scale;
        slope_2           = slope_2 / slope_scale;

        int stage_2_len = steps - midpoint;
        int stage_1_len = steps - stage_2_len;

        std::vector<float> sigmas_1 = get_bong_tangent_sigmas(stage_1_len, slope_1, (float)pivot_1_i, start, middle);
        std::vector<float> sigmas_2 = get_bong_tangent_sigmas(stage_2_len, slope_2, (float)(pivot_2_i - stage_1_len), middle, end);

        if (!sigmas_1.empty()) {
            sigmas_1.pop_back();
        }

        result.reserve(n + 1);
        result.insert(result.end(), sigmas_1.begin(), sigmas_1.end());
        result.insert(result.end(), sigmas_2.begin(), sigmas_2.end());

        if (result.size() < n + 1) {
            while (result.size() < n + 1) {
                result.push_back(end);
            }
        } else if (result.size() > n + 1) {
            result.resize(n + 1);
        }

        result[n] = 0.0f;
        return result;
    }
};

struct KLOptimalScheduler : SigmaScheduler {
    std::vector<float> get_sigmas(uint32_t n, float sigma_min, float sigma_max, t_to_sigma_t t_to_sigma) override {
        std::vector<float> sigmas;

        if (n == 0) {
            return sigmas;
        }

        if (n == 1) {
            sigmas.push_back(sigma_max);
            sigmas.push_back(0.0f);
            return sigmas;
        }

        if (sigma_min <= 1e-6f) {
            sigma_min = 1e-6f;
        }

        sigmas.reserve(n + 1);

        float alpha_min = std::atan(sigma_min);
        float alpha_max = std::atan(sigma_max);

        for (uint32_t i = 0; i < n; ++i) {
            float t     = static_cast<float>(i) / static_cast<float>(n - 1);
            float angle = t * alpha_min + (1.0f - t) * alpha_max;
            sigmas.push_back(std::tan(angle));
        }

        sigmas.push_back(0.0f);

        return sigmas;
    }
};

struct LTX2Scheduler : SigmaScheduler {
    int token_count  = 4096;
    float max_shift  = 2.05f;
    float base_shift = 0.95f;
    bool stretch     = true;
    float terminal   = 0.1f;

    explicit LTX2Scheduler(int token_count, const char* extra_sample_args = nullptr)
        : token_count(token_count > 0 ? token_count : 4096) {
        parse_extra_sample_args(extra_sample_args);
    }

    void parse_extra_sample_args(const char* extra_sample_args) {
        for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "ltx2 scheduler arg")) {
            if (key == "max_shift") {
                if (!parse_strict_float(value, max_shift)) {
                    LOG_WARN("ignoring invalid ltx2 scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            } else if (key == "base_shift") {
                if (!parse_strict_float(value, base_shift)) {
                    LOG_WARN("ignoring invalid ltx2 scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            } else if (key == "terminal") {
                if (!parse_strict_float(value, terminal)) {
                    LOG_WARN("ignoring invalid ltx2 scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            } else if (key == "stretch") {
                if (!parse_strict_bool(value, stretch)) {
                    LOG_WARN("ignoring invalid ltx2 scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            }
        }
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> sigmas;
        if (n == 0) {
            sigmas.push_back(0.0f);
            return sigmas;
        }

        constexpr float base_shift_anchor = 1024.0f;
        constexpr float max_shift_anchor  = 4096.0f;
        float m                           = (max_shift - base_shift) / (max_shift_anchor - base_shift_anchor);
        float b                           = base_shift - m * base_shift_anchor;
        float sigma_shift                 = static_cast<float>(token_count) * m + b;
        float exp_shift                   = std::exp(sigma_shift);
        float target_terminal             = std::clamp(terminal, 0.0f, 0.99f);

        LOG_VERBOSE("LTX2 scheduler: tokens=%d, shift=%.4f, stretch=%d, terminal=%.4f", token_count, sigma_shift, stretch ? 1 : 0, target_terminal);

        sigmas.reserve(n + 1);
        for (uint32_t i = 0; i <= n; ++i) {
            float sigma = 1.0f - static_cast<float>(i) / static_cast<float>(n);
            if (sigma != 0.0f) {
                sigma = exp_shift / (exp_shift + (1.0f / sigma - 1.0f));
            }
            sigmas.push_back(sigma);
        }

        if (stretch && sigmas.size() > 2) {
            float one_minus_last = 1.0f - sigmas[n - 1];
            float scale_factor   = one_minus_last / (1.0f - target_terminal);
            if (scale_factor > 1e-8f) {
                for (uint32_t i = 0; i < n; ++i) {
                    sigmas[i] = 1.0f - (1.0f - sigmas[i]) / scale_factor;
                }
            }
        }

        sigmas[n] = 0.0f;
        return sigmas;
    }
};

inline float flux_time_shift(float mu, float sigma, float t) {
    return ::expf(mu) / (::expf(mu) + ::powf((1.0f / t - 1.0f), sigma));
}

// https://github.com/black-forest-labs/flux/blob/main/src/flux/sampling.py#L289
struct FluxScheduler : SigmaScheduler {
    int image_seq_len      = 0;
    int base_image_seq_len = 256;
    int max_image_seq_len  = 4096;
    float base_shift       = 0.5f;
    float max_shift        = 1.15f;
    float shift_terminal   = 0.0f;

    FluxScheduler(int image_seq_len, SDVersion version, const char* extra_sample_args = nullptr)
        : image_seq_len(image_seq_len) {
        if (version == VERSION_QWEN_IMAGE_2_1) {
            max_image_seq_len = 8192;
            max_shift         = 0.9f;
            shift_terminal    = 0.02f;
        }
        parse_extra_sample_args(extra_sample_args);
    }

    void parse_extra_sample_args(const char* extra_sample_args) {
        for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "flux scheduler arg")) {
            if (key == "base_shift") {
                if (!parse_strict_float(value, base_shift)) {
                    LOG_WARN("ignoring invalid flux scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            } else if (key == "max_shift") {
                if (!parse_strict_float(value, max_shift)) {
                    LOG_WARN("ignoring invalid flux scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            }
        }
    }

    float compute_mu() const {
        float m = (max_shift - base_shift) / static_cast<float>(max_image_seq_len - base_image_seq_len);
        float b = base_shift - m * static_cast<float>(base_image_seq_len);
        return static_cast<float>(image_seq_len) * m + b;
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);

        float mu = compute_mu();
        LOG_VERBOSE("Flux scheduler: image_seq_len=%d, steps=%u, mu=%.3f, shift_terminal=%.3f", image_seq_len, n, mu, shift_terminal);

        if (n == 0) {
            sigmas.push_back(1.0f);
            return sigmas;
        }

        for (uint32_t i = 0; i <= n; ++i) {
            float t = 1.0f - static_cast<float>(i) / static_cast<float>(n);
            if (t <= 0.0f) {
                sigmas.push_back(0.0f);
            } else {
                sigmas.push_back(flux_time_shift(mu, 1.0f, t));
            }
        }

        if (shift_terminal > 0.0f && n > 1) {
            // The terminal shift applies to the last model evaluation, not the final zero sigma.
            float scale_factor = (1.0f - sigmas[n - 1]) / (1.0f - shift_terminal);
            if (std::isfinite(scale_factor) && scale_factor > 0.0f) {
                for (uint32_t i = 0; i < n; ++i) {
                    sigmas[i] = 1.0f - (1.0f - sigmas[i]) / scale_factor;
                }
            }
        }

        sigmas[n] = 0.0f;
        return sigmas;
    }
};

// https://github.com/black-forest-labs/flux2/blob/main/src/flux2/sampling.py#L244
// LLaDA-Image does not use a shift-based flow schedule. The reference pipeline builds a
// Kumaraswamy-shaped grid over t = linspace(0.001, 1, n + 1)[:-1]:
//     schedule = (1 - (1 - t^1.17)^0.8)^1.1
//     sigma    = 1 - schedule
// Its scheduler config can also set use_uniform_sigmas, which replaces the whole curve with a
// plain linspace(1, 0, n + 1)[:-1] pre-shift grid.
struct LLaDAImageScheduler : SigmaScheduler {
    bool uniform_sigmas = false;

    explicit LLaDAImageScheduler(const char* extra_sample_args = nullptr) {
        parse_extra_sample_args(extra_sample_args);
    }

    void parse_extra_sample_args(const char* extra_sample_args) {
        for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "llada_image scheduler arg")) {
            if (key == "uniform") {
                if (!parse_strict_bool(value, uniform_sigmas)) {
                    LOG_WARN("ignoring invalid llada_image scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            }
        }
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);

        if (n == 0) {
            sigmas.push_back(1.0f);
            return sigmas;
        }

        for (uint32_t i = 0; i < n; ++i) {
            float progress = static_cast<float>(i) / static_cast<float>(n);
            if (uniform_sigmas) {
                sigmas.push_back(1.0f - progress);
            } else {
                float t        = 0.001f + progress * (1.0f - 0.001f);
                float schedule = powf(1.0f - powf(1.0f - powf(t, 1.17f), 0.8f), 1.1f);
                sigmas.push_back(1.0f - schedule);
            }
        }

        sigmas.push_back(0.0f);
        return sigmas;
    }
};

struct Flux2Scheduler : SigmaScheduler {
    int image_seq_len = 0;

    explicit Flux2Scheduler(int image_seq_len)
        : image_seq_len(image_seq_len) {}

    static float compute_empirical_mu(int image_seq_len, uint32_t num_steps) {
        const float a1 = 8.73809524e-05f;
        const float b1 = 1.89833333f;
        const float a2 = 0.00016927f;
        const float b2 = 0.45666666f;

        if (image_seq_len > 4300) {
            return a2 * image_seq_len + b2;
        }

        float m_200 = a2 * image_seq_len + b2;
        float m_10  = a1 * image_seq_len + b1;

        float a = (m_200 - m_10) / 190.0f;
        float b = m_200 - 200.0f * a;
        return a * num_steps + b;
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);

        float mu = compute_empirical_mu(image_seq_len, n);
        LOG_VERBOSE("Flux2 scheduler: image_seq_len=%d, steps=%u, mu=%.3f", image_seq_len, n, mu);

        if (n == 0) {
            sigmas.push_back(1.0f);
            return sigmas;
        }

        for (uint32_t i = 0; i <= n; ++i) {
            float t = 1.0f - static_cast<float>(i) / static_cast<float>(n);
            if (t <= 0.0f) {
                sigmas.push_back(0.0f);
            } else if (t >= 1.0f) {
                sigmas.push_back(1.0f);
            } else {
                sigmas.push_back(flux_time_shift(mu, 1.0f, t));
            }
        }

        sigmas[n] = 0.0f;
        return sigmas;
    }
};

/*
 * Logit-Normal Scheduler
 * Based on: https://github.com/ideogram-oss/ideogram4/blob/main/src/ideogram4/scheduler.py
 */
struct LogitNormalScheduler : SigmaScheduler {
    float mean       = 0.0f;
    float std        = 1.75f;
    float logsnr_min = -15.0f;
    float logsnr_max = 18.0f;

    bool resolution_aware = true;

    float one_minus_t_min, one_minus_t_max;

    void parse_extra_sample_args(int image_seq_len = 0, const char* extra_sample_args = nullptr) {
        const int known_seq_len = (512 * 512) / (16 * 16);
        if (extra_sample_args) {
            for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "logit-normal scheduler arg")) {
                if (key == "mu") {
                    if (!parse_strict_float(value, mean)) {
                        LOG_WARN("ignoring invalid logit-normal scheduler arg '%s=%s'", key.c_str(), value.c_str());
                    }
                } else if (key == "std") {
                    if (!parse_strict_float(value, std)) {
                        LOG_WARN("ignoring invalid logit-normal scheduler arg '%s=%s'", key.c_str(), value.c_str());
                    }
                }
                if (key == "logsnr_min") {
                    if (!parse_strict_float(value, logsnr_min)) {
                        LOG_WARN("ignoring invalid logit-normal scheduler arg '%s=%s'", key.c_str(), value.c_str());
                    }
                } else if (key == "logsnr_max") {
                    if (!parse_strict_float(value, logsnr_max)) {
                        LOG_WARN("ignoring invalid logit-normal scheduler arg '%s=%s'", key.c_str(), value.c_str());
                    }
                } else if (key == "resolution_aware") {
                    if (!parse_strict_bool(value, resolution_aware)) {
                        LOG_WARN("ignoring invalid logit-normal scheduler arg '%s=%s'", key.c_str(), value.c_str());
                    }
                }
            }
        }
        if (image_seq_len > 0 && resolution_aware) {
            mean += 0.5f * std::log(static_cast<float>(image_seq_len) / static_cast<float>(known_seq_len));
        }
    }

    float sigmoid(float x) {
        return 1.0f / (1.0f + std::exp(-x));
    }

    LogitNormalScheduler(float mean = 0.0f, float std = 1.75f, float logsnr_min = -18.0f, float logsnr_max = 15.0f)
        : mean(mean), std(std), logsnr_min(logsnr_min), logsnr_max(logsnr_max) {
        // t_min = 1.0f / (1.0f + std::exp(0.5f * logsnr_max));
        one_minus_t_min = sigmoid(0.5f * logsnr_max);
        // t_max = 1.0f / (1.0f + std::exp(0.5f * logsnr_min));
        one_minus_t_max = sigmoid(0.5f * logsnr_min);
    }

    LogitNormalScheduler(int image_seq_len = 0, const char* extra_sample_args = nullptr) {
        mean       = 0.0f;
        std        = 1.75f;
        logsnr_min = -15.0f;
        logsnr_max = 18.0f;

        parse_extra_sample_args(image_seq_len, extra_sample_args);
        // t_min = 1.0f / (1.0f + std::exp(0.5f * logsnr_max));
        one_minus_t_min = sigmoid(0.5f * logsnr_max);
        // t_max = 1.0f / (1.0f + std::exp(0.5f * logsnr_min));
        one_minus_t_max = sigmoid(0.5f * logsnr_min);
    }

    // https://stackedboxes.org/2017/05/01/acklams-normal-quantile-function/
    double ndtri(double p) {
        if (p <= 0.0) {
            return -std::numeric_limits<double>::infinity();
        } else if (p >= 1.0) {
            return std::numeric_limits<double>::infinity();
        }

        static const double p_low  = 0.02425;
        static const double p_high = 1.0 - p_low;

        static const double c[6] = {-7.784894002430293e-03,
                                    -3.223964580411365e-01,
                                    -2.400758277161838e+00,
                                    -2.549732539343734e+00,
                                    4.374664141464968e+00,
                                    2.938163982698783e+00};

        static const double d[5] = {7.784695709041462e-03,
                                    3.224671290700398e-01,
                                    2.445134137142996e+00,
                                    3.754408661907416e+00,
                                    1.0};

        // Coefficients for the central region
        static const double a[6] = {-3.969683028665376e+01,
                                    2.209460984245205e+02,
                                    -2.759285104469687e+02,
                                    1.383577518672690e+02,
                                    -3.066479806614716e+01,
                                    2.506628277459239e+00};

        static const double b[6] = {-5.447609879822406e+01,
                                    1.615858368580409e+02,
                                    -1.556989798598866e+02,
                                    6.680131188771972e+01,
                                    -1.328068155288572e+01,
                                    1.0};

        double x = 0.0;

        if (p < p_low) {
            // Lower region
            double q = std::sqrt(-2.0 * std::log(p));

            // Numerator: c[0]*q^5 + c[1]*q^4 + ... + c[5]
            double numerator = c[0];
            for (int i = 1; i < 6; ++i) {
                numerator = numerator * q + c[i];
            }

            // Denominator: d[0]*q^4 + d[1]*q^3 + ... + d[3]*q + 1
            double denominator = d[0];
            for (int i = 1; i < 5; ++i) {
                denominator = denominator * q + d[i];
            }

            x = numerator / denominator;
        } else if (p > p_high) {
            // Upper region
            double q = std::sqrt(-2.0 * std::log(1.0 - p));

            double numerator = c[0];
            for (int i = 1; i < 6; ++i) {
                numerator = numerator * q + c[i];
            }

            double denominator = d[0];
            for (int i = 1; i < 5; ++i) {
                denominator = denominator * q + d[i];
            }

            x = -(numerator / denominator);
        } else {
            // Central region
            double q = p - 0.5;
            double r = q * q;

            // Numerator: (a[0]*r^5 + a[1]*r^4 + ... + a[5])*q
            double numerator = a[0];
            for (int i = 1; i < 6; ++i) {
                numerator = numerator * r + a[i];
            }
            numerator *= q;

            // Denominator: b[0]*r^4 + b[1]*r^3 + ... + b[4]*r + 1
            double denominator = b[0];
            for (int i = 1; i < 6; ++i) {
                denominator = denominator * r + b[i];
            }

            x = numerator / denominator;
        }
        return x;
    }

    std::vector<float> get_sigmas(uint32_t n, float /*sigma_min*/, float /*sigma_max*/, t_to_sigma_t /*t_to_sigma*/) override {
        std::vector<float> sigmas;
        LOG_INFO("LOGIT_NORMAL_SCHEDULER using mean=%.4f, std=%.4f, logsnr_min=%.4f, logsnr_max=%.4f", mean, std, logsnr_min, logsnr_max);
        sigmas.reserve(n + 1);
        for (uint32_t i = 0; i <= n; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(n);

            // ndtri(1-t) == -ndtri(t)
            float z = static_cast<float>(-ndtri(t));

            float y = mean + std * z;

            float timestep = sigmoid(y);

            if (timestep > one_minus_t_min)
                timestep = one_minus_t_min;
            if (timestep < one_minus_t_max)
                timestep = one_minus_t_max;

            float sigma = timestep;

            sigmas.push_back(sigma);
        }
        sigmas[n] = 0.0f;
        return sigmas;
    }
};

struct Denoiser {
    virtual float sigma_min()                                                        = 0;
    virtual float sigma_max()                                                        = 0;
    virtual float sigma_to_t(float sigma)                                            = 0;
    virtual float t_to_sigma(float t)                                                = 0;
    virtual std::vector<float> get_scalings(float sigma)                             = 0;
    virtual sd::Tensor<float> noise_scaling(float sigma,
                                            const sd::Tensor<float>& noise,
                                            const sd::Tensor<float>& latent)         = 0;
    virtual sd::Tensor<float> inverse_noise_scaling(float sigma,
                                                    const sd::Tensor<float>& latent) = 0;
    virtual float noise_level_to_sigma(float noise_level)                            = 0;

    virtual sd::Tensor<float> process_latent_in(const sd::Tensor<float>& latent) {
        // An empty result means the original latent can be used unchanged.
        SD_UNUSED(latent);
        return {};
    }

    virtual sd::Tensor<float> process_latent_out(sd::Tensor<float> latent) {
        return latent;
    }

    virtual std::vector<float> get_sigmas(uint32_t n, int image_seq_len, scheduler_t scheduler_type, SDVersion version, const char* extra_sample_args = nullptr) {
        auto bound_t_to_sigma = std::bind(&Denoiser::t_to_sigma, this, std::placeholders::_1);
        std::shared_ptr<SigmaScheduler> scheduler;
        switch (scheduler_type) {
            case DISCRETE_SCHEDULER:
                LOG_INFO("get_sigmas with discrete scheduler");
                scheduler = std::make_shared<DiscreteScheduler>();
                break;
            case KARRAS_SCHEDULER:
                LOG_INFO("get_sigmas with Karras scheduler");
                scheduler = std::make_shared<KarrasScheduler>();
                break;
            case BETA_SCHEDULER:
                LOG_INFO("get_sigmas with Beta scheduler");
                scheduler = std::make_shared<BetaScheduler>(extra_sample_args);
                break;
            case EXPONENTIAL_SCHEDULER:
                LOG_INFO("get_sigmas exponential scheduler");
                scheduler = std::make_shared<ExponentialScheduler>();
                break;
            case AYS_SCHEDULER:
                LOG_INFO("get_sigmas with Align-Your-Steps scheduler");
                scheduler = std::make_shared<AYSScheduler>(version);
                break;
            case GITS_SCHEDULER:
                LOG_INFO("get_sigmas with GITS scheduler");
                scheduler = std::make_shared<GITSScheduler>();
                break;
            case SGM_UNIFORM_SCHEDULER:
                LOG_INFO("get_sigmas with SGM Uniform scheduler");
                scheduler = std::make_shared<SGMUniformScheduler>();
                break;
            case SIMPLE_SCHEDULER:
                LOG_INFO("get_sigmas with Simple scheduler");
                scheduler = std::make_shared<SimpleScheduler>();
                break;
            case SMOOTHSTEP_SCHEDULER:
                LOG_INFO("get_sigmas with SmoothStep scheduler");
                scheduler = std::make_shared<SmoothStepScheduler>();
                break;
            case BONG_TANGENT_SCHEDULER:
                LOG_INFO("get_sigmas with bong_tangent scheduler");
                scheduler = std::make_shared<BongTangentScheduler>();
                break;
            case KL_OPTIMAL_SCHEDULER:
                LOG_INFO("get_sigmas with KL Optimal scheduler");
                scheduler = std::make_shared<KLOptimalScheduler>();
                break;
            case LCM_SCHEDULER:
                LOG_INFO("get_sigmas with LCM scheduler");
                scheduler = std::make_shared<LCMScheduler>();
                break;
            case LTX2_SCHEDULER:
                LOG_INFO("get_sigmas with LTX2 scheduler");
                scheduler = std::make_shared<LTX2Scheduler>(image_seq_len, extra_sample_args);
                break;
            case LOGIT_NORMAL_SCHEDULER: {
                LOG_INFO("get_sigmas with Logit-Normal scheduler");
                scheduler = std::make_shared<LogitNormalScheduler>(image_seq_len, extra_sample_args);
                break;
            }
            case FLUX2_SCHEDULER: {
                LOG_INFO("get_sigmas with Flux2 scheduler");
                scheduler = std::make_shared<Flux2Scheduler>(image_seq_len);
                break;
            }
            case LLADA_IMAGE_SCHEDULER: {
                LOG_INFO("get_sigmas with LLaDA-Image scheduler");
                scheduler = std::make_shared<LLaDAImageScheduler>(extra_sample_args);
                break;
            }
            case FLUX_SCHEDULER: {
                LOG_INFO("get_sigmas with Flux scheduler");
                scheduler = std::make_shared<FluxScheduler>(image_seq_len, version, extra_sample_args);
                break;
            }
            default:
                LOG_INFO("get_sigmas with discrete scheduler (default)");
                scheduler = std::make_shared<DiscreteScheduler>();
                break;
        }
        return scheduler->get_sigmas(n, sigma_min(), sigma_max(), bound_t_to_sigma);
    }
};

struct CompVisDenoiser : public Denoiser {
    float sigmas[TIMESTEPS];
    float log_sigmas[TIMESTEPS];

    float sigma_data = 1.0f;

    float sigma_min() override {
        return sigmas[0];
    }

    float sigma_max() override {
        return sigmas[TIMESTEPS - 1];
    }

    float sigma_to_t(float sigma) override {
        float log_sigma = std::log(sigma);
        std::vector<float> dists;
        dists.reserve(TIMESTEPS);
        for (float log_sigma_val : log_sigmas) {
            dists.push_back(log_sigma - log_sigma_val);
        }

        int low_idx = 0;
        for (size_t i = 0; i < TIMESTEPS; i++) {
            if (dists[i] >= 0) {
                low_idx++;
            }
        }
        low_idx      = std::min(std::max(low_idx - 1, 0), TIMESTEPS - 2);
        int high_idx = low_idx + 1;

        float low  = log_sigmas[low_idx];
        float high = log_sigmas[high_idx];
        float w    = (low - log_sigma) / (low - high);
        w          = std::max(0.f, std::min(1.f, w));
        float t    = (1.0f - w) * low_idx + w * high_idx;

        return t;
    }

    float t_to_sigma(float t) override {
        int low_idx     = static_cast<int>(std::floor(t));
        int high_idx    = static_cast<int>(std::ceil(t));
        float w         = t - static_cast<float>(low_idx);
        float log_sigma = (1.0f - w) * log_sigmas[low_idx] + w * log_sigmas[high_idx];
        return std::exp(log_sigma);
    }

    std::vector<float> get_scalings(float sigma) override {
        float c_skip = 1.0f;
        float c_out  = -sigma;
        float c_in   = 1.0f / std::sqrt(sigma * sigma + sigma_data * sigma_data);
        return {c_skip, c_out, c_in};
    }

    sd::Tensor<float> noise_scaling(float sigma,
                                    const sd::Tensor<float>& noise,
                                    const sd::Tensor<float>& latent) override {
        GGML_ASSERT(noise.numel() == latent.numel());
        return latent + noise * sigma;
    }

    sd::Tensor<float> inverse_noise_scaling(float sigma, const sd::Tensor<float>& latent) override {
        SD_UNUSED(sigma);
        return latent;
    }

    float noise_level_to_sigma(float noise_level) override {
        return noise_level / (1.0f - noise_level);
    }
};

struct CompVisVDenoiser : public CompVisDenoiser {
    std::vector<float> get_scalings(float sigma) override {
        float c_skip = sigma_data * sigma_data / (sigma * sigma + sigma_data * sigma_data);
        float c_out  = -sigma * sigma_data / std::sqrt(sigma * sigma + sigma_data * sigma_data);
        float c_in   = 1.0f / std::sqrt(sigma * sigma + sigma_data * sigma_data);
        return {c_skip, c_out, c_in};
    }
};

struct EDMVDenoiser : public CompVisVDenoiser {
    float min_sigma = 0.002f;
    float max_sigma = 120.0f;

    EDMVDenoiser(float min_sigma = 0.002, float max_sigma = 120.0)
        : min_sigma(min_sigma), max_sigma(max_sigma) {
    }

    float t_to_sigma(float t) override {
        return std::exp(t * 4 / (float)TIMESTEPS);
    }

    float sigma_to_t(float s) override {
        return 0.25f * std::log(s);
    }

    float sigma_min() override {
        return min_sigma;
    }

    float sigma_max() override {
        return max_sigma;
    }
};

inline float time_snr_shift(float alpha, float t) {
    if (alpha == 1.0f) {
        return t;
    }
    return alpha * t / (1 + (alpha - 1) * t);
}

struct DiscreteFlowDenoiser : public Denoiser {
    float shift = 3.0f;

    DiscreteFlowDenoiser(float shift = 3.0f) {
        set_shift(shift);
    }

    void set_shift(float shift) {
        this->shift = shift;
    }

    float sigma_min() override {
        return t_to_sigma(0);
    }

    float sigma_max() override {
        return t_to_sigma(TIMESTEPS - 1);
    }

    float sigma_to_t(float sigma) override {
        return sigma * 1000.f;
    }

    float t_to_sigma(float t) override {
        t = t + 1;
        return time_snr_shift(shift, t / 1000.f);
    }

    std::vector<float> get_scalings(float sigma) override {
        float c_skip = 1.0f;
        float c_out  = -sigma;
        float c_in   = 1.0f;
        return {c_skip, c_out, c_in};
    }

    sd::Tensor<float> noise_scaling(float sigma,
                                    const sd::Tensor<float>& noise,
                                    const sd::Tensor<float>& latent) override {
        GGML_ASSERT(noise.numel() == latent.numel());
        return latent * (1.0f - sigma) + noise * sigma;
    }
    sd::Tensor<float> inverse_noise_scaling(float sigma, const sd::Tensor<float>& latent) override {
        return latent * (1.0f / (1.0f - sigma));
    }

    float noise_level_to_sigma(float noise_level) override {
        return noise_level;
    }
};

struct MingImageFlowDenoiser : DiscreteFlowDenoiser {
    float resolution_shift = std::exp(1.35f);

    MingImageFlowDenoiser()
        : DiscreteFlowDenoiser(INFINITY) {}

    float sigma_min() override { return 0.f; }
    float sigma_max() override { return 1.f; }

    float t_to_sigma(float t) override {
        return time_snr_shift(std::isfinite(shift) ? shift : resolution_shift, (t + 1.f) / 1000.f);
    }

    std::vector<float> get_sigmas(uint32_t n, int image_seq_len, scheduler_t scheduler, SDVersion version, const char* extra_sample_args = nullptr) override {
        const float tokens = static_cast<float>(image_seq_len) / 4.f;
        const float mu     = tokens >= 4096.f ? 1.35f : 0.5f + (tokens - 256.f) * (1.15f - 0.5f) / (4096.f - 256.f);
        resolution_shift   = std::exp(mu);
        if (scheduler != DISCRETE_SCHEDULER) {
            return DiscreteFlowDenoiser::get_sigmas(n, image_seq_len, scheduler, version, extra_sample_args);
        }
        if (n == 0) {
            return {};
        }
        const float factor = std::isfinite(shift) ? shift : resolution_shift;
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);
        for (uint32_t i = 0; i < n; ++i) {
            const float t = n == 1 ? 1.f : 1.f - static_cast<float>(i) / static_cast<float>(n - 1);
            sigmas.push_back(time_snr_shift(factor, t));
        }
        // Upstream sets sigma_min to zero before linspace, then appends the terminal zero.
        sigmas.push_back(0.f);
        return sigmas;
    }
};

struct H3AVFlowDenoiser : public DiscreteFlowDenoiser {
    int64_t video_channels;
    float audio_shift;

    H3AVFlowDenoiser(float shift, float audio_shift, int64_t video_channels)
        : DiscreteFlowDenoiser(shift),
          video_channels(video_channels),
          audio_shift(audio_shift) {
        GGML_ASSERT(shift > 0.f && audio_shift > 0.f && video_channels > 0);
    }

    sd::Tensor<float> process_latent_in(const sd::Tensor<float>& latent) override {
        return scale_audio(latent, shift / audio_shift);
    }

    sd::Tensor<float> process_latent_out(sd::Tensor<float> latent) override {
        auto transformed = scale_audio(latent, audio_shift / shift);
        if (transformed.empty()) {
            return latent;
        }
        return transformed;
    }

private:
    sd::Tensor<float> scale_audio(const sd::Tensor<float>& latent, float scale) const {
        if (scale == 1.f || latent.dim() < 4 || latent.shape()[3] <= video_channels) {
            return {};
        }
        auto video = sd::ops::slice(latent, 3, 0, video_channels);
        auto audio = sd::ops::slice(latent, 3, video_channels, latent.shape()[3]) * scale;
        return sd::ops::concat(video, audio, 3);
    }
};

struct FluxFlowDenoiser : public DiscreteFlowDenoiser {
    FluxFlowDenoiser() = default;

    float sigma_to_t(float sigma) override {
        return sigma;
    }

    float t_to_sigma(float t) override {
        t = t + 1;
        return flux_time_shift(shift, 1.0f, t / TIMESTEPS);
    }
};

struct SefiFlowDenoiser;

struct SefiFlowDenoiser : public FluxFlowDenoiser {
    static constexpr int kNumTrainTimesteps = 1000;
    static constexpr int kSemChannels       = 16;
    static constexpr int kTotalChannels     = 144;

    float delta_t              = 0.1f;
    float timestep_shift_alpha = 1.0f;

    std::vector<float> sem_sigmas;
    std::vector<float> tex_sigmas;
    std::vector<float> sem_timesteps;
    std::vector<float> tex_timesteps;

    SefiFlowDenoiser() = default;

    static float apply_alpha_shift(float u_unit, float alpha) {
        if (alpha == 1.0f) {
            return u_unit;
        }
        float denom = 1.0f + (alpha - 1.0f) * u_unit;
        return (alpha * u_unit) / denom;
    }

    std::vector<float> get_sigmas(uint32_t n,
                                  int image_seq_len,
                                  scheduler_t scheduler_type,
                                  SDVersion version,
                                  const char* extra_sample_args = nullptr) override {
        sem_sigmas.clear();
        tex_sigmas.clear();
        sem_timesteps.clear();
        tex_timesteps.clear();

        for (const auto& [key, value] : parse_key_value_args(extra_sample_args, "sefi scheduler arg")) {
            if (key == "sefi_alpha") {
                if (!parse_strict_float(value, timestep_shift_alpha)) {
                    LOG_WARN("ignoring invalid sefi scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            } else if (key == "sefi_delta_t") {
                if (!parse_strict_float(value, delta_t)) {
                    LOG_WARN("ignoring invalid sefi scheduler arg '%s=%s'", key.c_str(), value.c_str());
                }
            }
        }

        for (uint32_t i = 0; i <= n; ++i) {
            float u_base    = static_cast<float>(i) / static_cast<float>(n);
            float u_shifted = apply_alpha_shift(u_base, timestep_shift_alpha);
            float u_sem_raw = u_shifted * (1.0f + delta_t);

            float u_sem = std::min(u_sem_raw, 1.0f);
            float u_tex = std::max(0.0f, std::min(u_sem_raw - delta_t, 1.0f));

            int idx_sem = std::min(kNumTrainTimesteps - 1,
                                   std::max(0, static_cast<int>(u_sem * (kNumTrainTimesteps - 1))));
            int idx_tex = std::min(kNumTrainTimesteps - 1,
                                   std::max(0, static_cast<int>(u_tex * (kNumTrainTimesteps - 1))));

            float t_sem     = static_cast<float>(kNumTrainTimesteps - idx_sem);
            float t_tex     = static_cast<float>(kNumTrainTimesteps - idx_tex);
            float sigma_sem = t_sem / static_cast<float>(kNumTrainTimesteps);
            float sigma_tex = t_tex / static_cast<float>(kNumTrainTimesteps);

            sem_timesteps.push_back(t_sem);
            tex_timesteps.push_back(t_tex);
            sem_sigmas.push_back(sigma_sem);
            tex_sigmas.push_back(sigma_tex);
        }
        LOG_VERBOSE("SefiFlowDenoiser: built %u-step dual schedule (alpha=%.2f delta_t=%.2f)",
                    n, timestep_shift_alpha, delta_t);
        return tex_sigmas;
    }
};

// MiniT2I predicts x0 directly and integrates a linear flow ODE:
//   x_{t+dt} = x_t + (x0 - x_t)/(1 - t) * dt,  t in [0, 1), x0 = start = noise * 2.
// Mapping sigma = 1 - t makes the generic Euler update
//   x += (x - denoised)/sigma * (sigma_next - sigma)
// exactly reproduce that step when denoised == x0. To make the generic
// `denoised = pred * c_out + x * c_skip` yield x0 from the model's raw x0
// prediction we use c_skip = 0, c_out = 1, c_in = 1. Sigmas run linearly 1 -> 0.
struct MiniT2IFlowDenoiser : public Denoiser {
    float sigma_min() override {
        return 0.0f;
    }

    float sigma_max() override {
        return 1.0f;
    }

    float sigma_to_t(float sigma) override {
        return 1.0f - sigma;
    }

    float t_to_sigma(float t) override {
        return 1.0f - t;
    }

    std::vector<float> get_scalings(float sigma) override {
        SD_UNUSED(sigma);
        float c_skip = 0.0f;
        float c_out  = 1.0f;
        float c_in   = 1.0f;
        return {c_skip, c_out, c_in};
    }

    sd::Tensor<float> noise_scaling(float sigma,
                                    const sd::Tensor<float>& noise,
                                    const sd::Tensor<float>& latent) override {
        SD_UNUSED(sigma);
        SD_UNUSED(latent);
        // Sampling starts from x0_init = noise * 2 (see MiniT2I reference).
        return noise * 2.0f;
    }

    sd::Tensor<float> inverse_noise_scaling(float sigma, const sd::Tensor<float>& latent) override {
        SD_UNUSED(sigma);
        return latent;
    }

    float noise_level_to_sigma(float noise_level) override {
        SD_UNUSED(noise_level);
        return 1.0f;
    }

    std::vector<float> get_sigmas(uint32_t n, int image_seq_len, scheduler_t scheduler_type, SDVersion version, const char* extra_sample_args = nullptr) override {
        SD_UNUSED(image_seq_len);
        SD_UNUSED(scheduler_type);
        SD_UNUSED(version);
        SD_UNUSED(extra_sample_args);
        // Uniform t schedule 0 -> 1 => sigma 1 -> 0, matching the reference loop.
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);
        for (uint32_t i = 0; i < n; ++i) {
            sigmas.push_back(1.0f - static_cast<float>(i) / static_cast<float>(n));
        }
        sigmas.push_back(0.0f);
        return sigmas;
    }
};

// SenseNova U1.5 integrates velocity over t=0..1 while the generic sampler
// integrates over descending sigma. With sigma=1-t, returning
// denoised=x+sigma*v makes the generic Euler derivative exactly -v, so the
// descending-sigma update is identical to the official ascending-time update.
struct SenseNovaU1FlowDenoiser : public DiscreteFlowDenoiser {
    explicit SenseNovaU1FlowDenoiser(float shift = 3.f)
        : DiscreteFlowDenoiser(shift) {}

    float sigma_min() override {
        return 0.f;
    }

    float sigma_max() override {
        return 1.f;
    }

    float sigma_to_t(float sigma) override {
        return 1.f - sigma;
    }

    float t_to_sigma(float t) override {
        float sigma = 1.f - t;
        return shift * sigma / (1.f + (shift - 1.f) * sigma);
    }

    std::vector<float> get_scalings(float sigma) override {
        return {1.f, sigma, 1.f};
    }

    sd::Tensor<float> noise_scaling(float sigma,
                                    const sd::Tensor<float>& noise,
                                    const sd::Tensor<float>& latent) override {
        SD_UNUSED(sigma);
        SD_UNUSED(latent);
        GGML_ASSERT(noise.dim() >= 2);
        const float token_w     = static_cast<float>(noise.shape()[0]) / 32.f;
        const float token_h     = static_cast<float>(noise.shape()[1]) / 32.f;
        const float noise_scale = std::min(16.f, std::sqrt((token_w * token_h) / 64.f));
        return noise * noise_scale;
    }

    sd::Tensor<float> inverse_noise_scaling(float sigma,
                                            const sd::Tensor<float>& latent) override {
        SD_UNUSED(sigma);
        return latent;
    }

    float noise_level_to_sigma(float noise_level) override {
        SD_UNUSED(noise_level);
        return 1.f;
    }

    std::vector<float> get_sigmas(uint32_t n,
                                  int image_seq_len,
                                  scheduler_t scheduler_type,
                                  SDVersion version,
                                  const char* extra_sample_args = nullptr) override {
        SD_UNUSED(image_seq_len);
        SD_UNUSED(scheduler_type);
        SD_UNUSED(version);
        SD_UNUSED(extra_sample_args);
        std::vector<float> sigmas;
        sigmas.reserve(n + 1);
        if (n == 0) {
            sigmas.push_back(0.f);
            return sigmas;
        }
        for (uint32_t i = 0; i <= n; ++i) {
            const float t = static_cast<float>(i) / static_cast<float>(n);
            sigmas.push_back(t_to_sigma(t));
        }
        sigmas.back() = 0.f;
        return sigmas;
    }
};

typedef std::function<sd::guidance::GuiderOutput(const sd::Tensor<float>&, float, int)> denoise_cb_t;

static std::pair<float, float> get_ancestral_step(float sigma_from,
                                                  float sigma_to,
                                                  float eta = 1.0f) {
    float sigma_up   = 0.0f;
    float sigma_down = sigma_to;

    if (eta <= 0.0f) {
        return {sigma_down, sigma_up};
    }

    float sigma_from_sq = sigma_from * sigma_from;
    float sigma_to_sq   = sigma_to * sigma_to;
    if (sigma_from_sq > 0.0f) {
        float term = sigma_to_sq * (sigma_from_sq - sigma_to_sq) / sigma_from_sq;
        sigma_up   = std::min(sigma_to, eta * std::sqrt(std::max(term, 0.0f)));
    }

    float sigma_down_sq = sigma_to_sq - sigma_up * sigma_up;
    sigma_down          = sigma_down_sq > 0.0f ? std::sqrt(sigma_down_sq) : 0.0f;
    return {sigma_down, sigma_up};
}

static std::tuple<float, float, float> get_ancestral_step_flow(float sigma_from,
                                                               float sigma_to,
                                                               float eta = 1.0f) {
    float sigma_down  = sigma_to;
    float sigma_up    = 0.0f;
    float alpha_scale = 1.0f;

    if (eta <= 0.0f || sigma_from <= 0.0f || sigma_to <= 0.0f) {
        return {sigma_down, sigma_up, alpha_scale};
    }

    // Flow Euler ancestral sampling becomes numerically unstable for eta > 1, so
    // clamp to the valid maximum-noise regime instead of letting NaNs propagate.
    eta = std::min(eta, 1.0f);

    float sigma_ratio = sigma_to / sigma_from;
    sigma_down        = sigma_to * (1.0f + (sigma_ratio - 1.0f) * eta);
    sigma_down        = std::max(0.0f, std::min(sigma_to, sigma_down));

    float denom = 1.0f - sigma_down;
    if (denom <= 0.0f) {
        return {sigma_to, sigma_up, alpha_scale};
    }

    alpha_scale = (1.0f - sigma_to) / denom;

    float term = (sigma_down / sigma_to) * alpha_scale;
    term       = std::max(-1.0f, std::min(1.0f, term));
    sigma_up   = sigma_to * std::sqrt(std::max(1.0f - term * term, 0.0f));
    return {sigma_down, sigma_up, alpha_scale};
}

static std::tuple<float, float, float> get_ancestral_step(float sigma_from,
                                                          float sigma_to,
                                                          float eta,
                                                          bool is_flow_denoiser) {
    if (is_flow_denoiser) {
        return get_ancestral_step_flow(sigma_from, sigma_to, eta);
    } else {
        auto [sigma_down, sigma_up] = get_ancestral_step(sigma_from, sigma_to, eta);
        return {sigma_down, sigma_up, 1.0f};
    }
}

class NoiseSampler {
public:
    virtual sd::Tensor<float> operator()(double sigma_from, double sigma_to) = 0;
    virtual ~NoiseSampler()                                                  = default;
};

static sd::Tensor<float> sample_euler_ancestral(denoise_cb_t model,
                                                sd::Tensor<float> x,
                                                const std::vector<float>& sigmas,
                                                NoiseSampler& noise_sampler,
                                                bool is_flow_denoiser = false,
                                                float eta             = 0.f) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma       = sigmas[i];
        float sigma_to    = sigmas[i + 1];
        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        if (sigma_to == 0.f) {
            x = denoised;
        } else if (eta == 0.f) {
            float sigma_ratio = sigma_to / sigma;
            x                 = sigma_ratio * x + (1.0 - sigma_ratio) * denoised;
        } else {
            auto [sigma_down, sigma_up, alpha_scale] = get_ancestral_step(sigma, sigma_to, eta, is_flow_denoiser);
            float sigma_ratio                        = sigma_down / sigma;
            x                                        = sigma_ratio * x + (1.0f - sigma_ratio) * denoised;
            if (sigma_up > 0.f) {
                if (is_flow_denoiser) {
                    x *= alpha_scale;
                }
                x += noise_sampler(sigma, sigma_to) * sigma_up;
            }
        }
    }
    return x;
}

static sd::Tensor<float> sample_sefi_euler(SefiFlowDenoiser* sefi,
                                           denoise_cb_t model,
                                           sd::Tensor<float> x) {
    const std::vector<float>& sigma_tex_vec = sefi->tex_sigmas;
    const std::vector<float>& sigma_sem_vec = sefi->sem_sigmas;
    int steps                               = static_cast<int>(sigma_tex_vec.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma_tex_cur  = sigma_tex_vec[i];
        float sigma_tex_next = sigma_tex_vec[i + 1];
        float sigma_sem_cur  = sigma_sem_vec[i];
        float sigma_sem_next = sigma_sem_vec[i + 1];
        if (sigma_tex_cur <= 1e-9f) {
            continue;
        }
        auto denoised_opt = model(x, sigma_tex_cur, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        sd::Tensor<float> velocity = (x - denoised) / sigma_tex_cur;

        auto x_sem      = sd::ops::slice(x, 2, 0, SefiFlowDenoiser::kSemChannels);
        auto x_tex      = sd::ops::slice(x, 2, SefiFlowDenoiser::kSemChannels, SefiFlowDenoiser::kTotalChannels);
        auto vel_sem    = sd::ops::slice(velocity, 2, 0, SefiFlowDenoiser::kSemChannels);
        auto vel_tex    = sd::ops::slice(velocity, 2, SefiFlowDenoiser::kSemChannels, SefiFlowDenoiser::kTotalChannels);
        auto x_sem_next = x_sem + vel_sem * (sigma_sem_next - sigma_sem_cur);
        auto x_tex_next = x_tex + vel_tex * (sigma_tex_next - sigma_tex_cur);

        sd::ops::slice_assign(&x, 2, 0, SefiFlowDenoiser::kSemChannels, x_sem_next);
        sd::ops::slice_assign(&x, 2, SefiFlowDenoiser::kSemChannels, SefiFlowDenoiser::kTotalChannels, x_tex_next);
    }
    return x;
}

static sd::Tensor<float> sample_euler(denoise_cb_t model,
                                      sd::Tensor<float> x,
                                      const std::vector<float>& sigmas) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma = sigmas[i];
        if (sigma == sigmas[i + 1]) {
            continue;
        }
        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        sd::Tensor<float> d        = (x - denoised) / sigma;
        x += d * (sigmas[i + 1] - sigma);
    }
    return x;
}

static sd::Tensor<float> sample_heun(denoise_cb_t model,
                                     sd::Tensor<float> x,
                                     const std::vector<float>& sigmas) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], -(i + 1));
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        sd::Tensor<float> d        = (x - denoised) / sigmas[i];
        float dt                   = sigmas[i + 1] - sigmas[i];
        if (sigmas[i + 1] == 0) {
            x += d * dt;
        } else {
            sd::Tensor<float> x2 = x + d * dt;
            auto denoised2_opt   = model(x2, sigmas[i + 1], i + 1);
            if (denoised2_opt.pred.empty()) {
                return {};
            }
            sd::Tensor<float> denoised2 = std::move(denoised2_opt.pred);
            d                           = (d + (x2 - denoised2) / sigmas[i + 1]) / 2.0f;
            x += d * dt;
        }
    }
    return x;
}

static sd::Tensor<float> sample_dpm2(denoise_cb_t model,
                                     sd::Tensor<float> x,
                                     const std::vector<float>& sigmas) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], -(i + 1));
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        sd::Tensor<float> d        = (x - denoised) / sigmas[i];
        if (sigmas[i + 1] == 0) {
            x += d * (sigmas[i + 1] - sigmas[i]);
        } else {
            float sigma_mid      = exp(0.5f * (log(sigmas[i]) + log(sigmas[i + 1])));
            float dt_1           = sigma_mid - sigmas[i];
            float dt_2           = sigmas[i + 1] - sigmas[i];
            sd::Tensor<float> x2 = x + d * dt_1;
            auto denoised2_opt   = model(x2, sigma_mid, i + 1);
            if (denoised2_opt.pred.empty()) {
                return {};
            }
            sd::Tensor<float> denoised2 = std::move(denoised2_opt.pred);
            x += ((x2 - denoised2) / sigma_mid) * dt_2;
        }
    }
    return x;
}

static sd::Tensor<float> sample_dpmpp_2s_ancestral(denoise_cb_t model,
                                                   sd::Tensor<float> x,
                                                   const std::vector<float>& sigmas,
                                                   NoiseSampler& noise_sampler,
                                                   float eta) {
    auto t_fn     = [](float sigma) -> float { return -log(sigma); };
    auto sigma_fn = [](float t) -> float { return exp(-t); };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], -(i + 1));
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised  = std::move(denoised_opt.pred);
        auto [sigma_down, sigma_up] = get_ancestral_step(sigmas[i], sigmas[i + 1], eta);

        if (sigma_down == 0) {
            x = denoised;
        } else {
            float t              = t_fn(sigmas[i]);
            float t_next         = t_fn(sigma_down);
            float h              = t_next - t;
            float s              = t + 0.5f * h;
            float sigma_s        = sigma_fn(s);
            sd::Tensor<float> x2 = (sigma_s / sigma_fn(t)) * x - (exp(-h * 0.5f) - 1) * denoised;
            auto denoised2_opt   = model(x2, sigma_s, i + 1);
            if (denoised2_opt.pred.empty()) {
                return {};
            }
            sd::Tensor<float> denoised2 = std::move(denoised2_opt.pred);
            x                           = (sigma_fn(t_next) / sigma_fn(t)) * x - (exp(-h) - 1) * denoised2;
        }

        if (sigmas[i + 1] > 0) {
            x += noise_sampler(sigmas[i], sigmas[i + 1]) * sigma_up;
        }
    }
    return x;
}

static sd::Tensor<float> sample_dpmpp_2s_ancestral_flow(denoise_cb_t model,
                                                        sd::Tensor<float> x,
                                                        const std::vector<float>& sigmas,
                                                        NoiseSampler& noise_sampler,
                                                        float eta = 1.0f) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma    = sigmas[i];
        float sigma_to = sigmas[i + 1];

        bool opt_first_step = (1.0 - sigma < 1e-6);

        auto denoised_opt = model(x, sigma, (opt_first_step ? 1 : -1) * (i + 1));
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        if (sigma_to == 0.0f) {
            // Euler method (final step, no noise)
            // sigma_to == 0 --> sigma_down = 0, so:
            //   x +                       d  * (sigma_down - sigma)
            // = x + ((x - denoised) / sigma) * (sigma_down - sigma)
            // = x + ((x - denoised) / sigma) * (         0 - sigma)
            // = x + ((x - denoised)        ) * -1
            // = x    -x + denoised
            x = denoised;

        } else {
            auto [sigma_down, sigma_up, alpha_scale] = get_ancestral_step_flow(sigma, sigma_to, eta);
            sd::Tensor<float> D_i;

            if (opt_first_step) {
                // the reformulated exp_s calc already accounts for this, but we can avoid
                // a redundant model call for the typical sigma 1 at the first step:
                // exp_s = sqrt((1-sigma)/sigma * (1-sigma_down)/sigma_down)
                //       = sqrt((1-    1)/    1 * (1-sigma_down)/sigma_down)
                //       = 0
                // so sigma_s = 1 = sigma, and sigma_s_i_ratio = sigma_s / sigma = 1
                // u = (x*sigma_s_i_ratio)+(denoised*(1.0f-sigma_s_i_ratio))
                //   = (x*1)+(denoised*0) = x
                // so D_i = model(u, sigma_s, i + 1)
                //        = model(x, sigma,   i + 1)
                //        = denoised
                D_i = denoised;

            } else {
                float sigma_s;

                // ref implementation would be:
                // auto lambda_fn = [](float sigma) -> float {
                //     return std::log((1.0f - sigma) / sigma); };
                // auto sigma_fn = [](float lbda) -> float {
                //     return 1.0f / (std::exp(lbda) + 1.0f); };
                // t_i     = lambda_fn(sigma);
                // t_down  = lambda_fn(sigma_down);
                // float r = 0.5f;
                // h       = t_down - t_i;
                // s       = t_i + r * h;
                // sigma_s = sigma_fn(s);

                // assuming r is constant, we sidestep the singularity at sigma -> 1 by:
                // s   = 0.5 * (lambda_fn(sigma)     + lambda_fn(sigma_down))
                //     = 0.5 * (log((1-sigma)/sigma) + log((1-sigma_down)/sigma_down))
                //     = 0.5 * log(((1-sigma)/sigma) *    ((1-sigma_down)/sigma_down))
                //     = log(sqrt (((1-sigma)/sigma) *    ((1-sigma_down)/sigma_down)))
                // so exp(s) = sqrt((1-sigma)/sigma  *     (1-sigma_down)/sigma_down)
                // and sigma_s = sigma_fn(s) = 1.0f / (exp(s) + 1.0f)

                float exp_s = std::sqrt(((1 - sigma) / sigma) * ((1 - sigma_down) / sigma_down));
                sigma_s     = 1.0f / (exp_s + 1.0f);

                float sigma_s_i_ratio = sigma_s / sigma;
                sd::Tensor<float> u   = (x * sigma_s_i_ratio) + (denoised * (1.0f - sigma_s_i_ratio));

                auto denoised2_opt = model(u, sigma_s, i + 1);
                if (denoised2_opt.pred.empty()) {
                    return {};
                }
                D_i = std::move(denoised2_opt.pred);
            }

            float sigma_down_i_ratio = sigma_down / sigma;
            x                        = (x * sigma_down_i_ratio) + (D_i * (1.0f - sigma_down_i_ratio));

            if (sigma_to > 0.0f && eta > 0.0f) {
                x = alpha_scale * x + noise_sampler(sigma, sigma_to) * sigma_up;
            }
        }
    }

    return x;
}

static sd::Tensor<float> sample_dpmpp_2m(denoise_cb_t model,
                                         sd::Tensor<float> x,
                                         const std::vector<float>& sigmas) {
    sd::Tensor<float> old_denoised = x;
    auto t_fn                      = [](float sigma) -> float { return -log(sigma); };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        float t                    = t_fn(sigmas[i]);
        float t_next               = t_fn(sigmas[i + 1]);
        float h                    = t_next - t;
        float a                    = sigmas[i + 1] / sigmas[i];
        float b                    = exp(-h) - 1.f;

        if (i == 0 || sigmas[i + 1] == 0) {
            x = a * x - b * denoised;
        } else {
            float h_last                 = t - t_fn(sigmas[i - 1]);
            float r                      = h_last / h;
            sd::Tensor<float> denoised_d = (1.f + 1.f / (2.f * r)) * denoised - (1.f / (2.f * r)) * old_denoised;
            x                            = a * x - b * denoised_d;
        }
        old_denoised = denoised;
    }
    return x;
}

static sd::Tensor<float> sample_dpmpp_2m_v2(denoise_cb_t model,
                                            sd::Tensor<float> x,
                                            const std::vector<float>& sigmas) {
    sd::Tensor<float> old_denoised = x;
    auto t_fn                      = [](float sigma) -> float { return -log(sigma); };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        float t                    = t_fn(sigmas[i]);
        float t_next               = t_fn(sigmas[i + 1]);
        float h                    = t_next - t;
        float a                    = sigmas[i + 1] / sigmas[i];

        if (i == 0 || sigmas[i + 1] == 0) {
            float b = exp(-h) - 1.f;
            x       = a * x - b * denoised;
        } else {
            float h_last                 = t - t_fn(sigmas[i - 1]);
            float h_min                  = std::min(h_last, h);
            float h_max                  = std::max(h_last, h);
            float r                      = h_max / h_min;
            float h_d                    = (h_max + h_min) / 2.f;
            float b                      = exp(-h_d) - 1.f;
            sd::Tensor<float> denoised_d = (1.f + 1.f / (2.f * r)) * denoised - (1.f / (2.f * r)) * old_denoised;
            x                            = a * x - b * denoised_d;
        }
        old_denoised = denoised;
    }
    return x;
}

// DPM-Solver++(2M) SDE, midpoint variant.
// Ref: Lu et al. arXiv:2211.01095; k-diffusion sample_dpmpp_2m_sde
static sd::Tensor<float> sample_dpmpp_2m_sde(denoise_cb_t model,
                                             sd::Tensor<float> x,
                                             const std::vector<float>& sigmas,
                                             NoiseSampler& noise_sampler,
                                             float eta) {
    sd::Tensor<float> old_denoised;
    bool have_old_denoised = false;
    float h_last           = 0.f;

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        if (sigmas[i + 1] == 0.f) {
            x = denoised;
        } else {
            float t     = -std::log(sigmas[i]);
            float s     = -std::log(sigmas[i + 1]);
            float h     = s - t;
            float eta_h = eta * h;
            float a     = sigmas[i + 1] / sigmas[i] * std::exp(-eta_h);
            float b     = -std::expm1(-h - eta_h);

            x = a * x + b * denoised;

            if (have_old_denoised) {
                float r = h_last / h;
                x += (0.5f * b / r) * (denoised - old_denoised);
            }
            if (eta > 0.f) {
                x += noise_sampler(sigmas[i], sigmas[i + 1]) * (sigmas[i + 1] * std::sqrt(-std::expm1(-2.f * eta_h)));
            }
            h_last = h;
        }
        old_denoised      = denoised;
        have_old_denoised = true;
    }
    return x;
}

using SamplerExtraArgs = KeyValueArgs;

static sd::Tensor<float> sample_lcm(denoise_cb_t model,
                                    sd::Tensor<float> x,
                                    const std::vector<float>& sigmas,
                                    NoiseSampler& noise_sampler,
                                    bool is_flow_denoiser,
                                    const SamplerExtraArgs& extra_sample_args) {
    struct LCMSampleArgs {
        float noise_clip_std    = 0.0f;
        float noise_scale_start = 1.0f;
        float noise_scale_end   = 1.0f;
    };

    LCMSampleArgs args;
    bool noise_scale_end_was_set   = false;
    bool noise_scale_start_was_set = false;

    for (const auto& [key, value] : extra_sample_args) {
        float parsed = 0.0f;
        if (key == "noise_clip_std") {
            if (!parse_strict_float(value, parsed)) {
                LOG_WARN("ignoring invalid lcm extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            args.noise_clip_std = parsed;
        } else if (key == "noise_scale_start") {
            if (!parse_strict_float(value, parsed)) {
                LOG_WARN("ignoring invalid lcm extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            args.noise_scale_start    = parsed;
            noise_scale_start_was_set = true;
        } else if (key == "noise_scale_end") {
            if (!parse_strict_float(value, parsed)) {
                LOG_WARN("ignoring invalid lcm extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            args.noise_scale_end    = parsed;
            noise_scale_end_was_set = true;
        }
    }

    if (noise_scale_start_was_set && !noise_scale_end_was_set) {
        args.noise_scale_end = args.noise_scale_start;
    }

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        x = std::move(denoised_opt.pred);
        if (sigmas[i + 1] > 0) {
            if (is_flow_denoiser) {
                x *= (1 - sigmas[i + 1]);
            }
            auto noise = noise_sampler(sigmas[i], sigmas[i + 1]);
            if (args.noise_clip_std > 0.0f && noise.numel() > 0) {
                double mean = 0.0;
                for (int64_t j = 0; j < noise.numel(); ++j) {
                    mean += static_cast<double>(noise[j]);
                }
                mean /= static_cast<double>(noise.numel());

                double variance = 0.0;
                for (int64_t j = 0; j < noise.numel(); ++j) {
                    double centered = static_cast<double>(noise[j]) - mean;
                    variance += centered * centered;
                }
                variance /= static_cast<double>(noise.numel());

                float clip_val = args.noise_clip_std * static_cast<float>(std::sqrt(variance));
                noise          = sd::ops::clamp(noise, -clip_val, clip_val);
            }
            float t           = steps > 1 ? static_cast<float>(i) / static_cast<float>(steps - 1) : 0.0f;
            float noise_scale = args.noise_scale_start + (args.noise_scale_end - args.noise_scale_start) * t;
            x += noise * (sigmas[i + 1] * noise_scale);
        }
    }
    return x;
}

static sd::Tensor<float> sample_ipndm(denoise_cb_t model,
                                      sd::Tensor<float> x,
                                      const std::vector<float>& sigmas) {
    const int max_order                 = 4;
    std::vector<sd::Tensor<float>> hist = {};

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma      = sigmas[i];
        float sigma_next = sigmas[i + 1];

        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        sd::Tensor<float> d_cur = (x - denoised) / sigma;
        int order               = std::min(max_order, i + 1);
        float dt                = sigma_next - sigma;

        switch (order) {
            case 1:
                x += d_cur * dt;
                break;
            case 2:
                x += ((3.f * d_cur - hist.back()) / 2.f) * dt;
                break;
            case 3:
                x += ((23.f * d_cur - 16.f * hist[hist.size() - 1] + 5.f * hist[hist.size() - 2]) / 12.f) * dt;
                break;
            case 4:
                x += ((55.f * d_cur - 59.f * hist[hist.size() - 1] + 37.f * hist[hist.size() - 2] - 9.f * hist[hist.size() - 3]) / 24.f) * dt;
                break;
        }

        if (hist.size() == static_cast<size_t>(max_order - 1)) {
            hist.erase(hist.begin());
        }
        hist.push_back(std::move(d_cur));
    }
    return x;
}

static sd::Tensor<float> sample_ipndm_v(denoise_cb_t model,
                                        sd::Tensor<float> x,
                                        const std::vector<float>& sigmas) {
    const int max_order                 = 4;
    std::vector<sd::Tensor<float>> hist = {};

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma  = sigmas[i];
        float t_next = sigmas[i + 1];

        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        sd::Tensor<float> d_cur = (x - denoised) / sigma;
        int order               = std::min(max_order, i + 1);
        float h_n               = t_next - sigma;
        float h_n_1             = (i > 0) ? (sigma - sigmas[i - 1]) : h_n;

        switch (order) {
            case 1:
                x += d_cur * h_n;
                break;
            case 2:
                x += (((2.f + (h_n / h_n_1)) * d_cur - (h_n / h_n_1) * hist.back()) / 2.f) * h_n;
                break;
            case 3:
                x += ((23.f * d_cur - 16.f * hist[hist.size() - 1] + 5.f * hist[hist.size() - 2]) / 12.f) * h_n;
                break;
            case 4:
                x += ((55.f * d_cur - 59.f * hist[hist.size() - 1] + 37.f * hist[hist.size() - 2] - 9.f * hist[hist.size() - 3]) / 24.f) * h_n;
                break;
        }

        if (hist.size() == static_cast<size_t>(max_order - 1)) {
            hist.erase(hist.begin());
        }
        hist.push_back(std::move(d_cur));
    }
    return x;
}

static sd::Tensor<float> sample_res_multistep(denoise_cb_t model,
                                              sd::Tensor<float> x,
                                              const std::vector<float>& sigmas,
                                              NoiseSampler& noise_sampler,
                                              bool is_flow_denoiser,
                                              float eta) {
    sd::Tensor<float> old_denoised = x;
    bool have_old_sigma            = false;
    float old_sigma_down           = 0.0f;

    auto t_fn     = [](float sigma) -> float { return -logf(sigma); };
    auto sigma_fn = [](float t) -> float { return expf(-t); };
    auto phi1_fn  = [](float t) -> float {
        if (fabsf(t) < 1e-6f) {
            return 1.0f + t * 0.5f + (t * t) / 6.0f;
        }
        return (expf(t) - 1.0f) / t;
    };
    auto phi2_fn = [&](float t) -> float {
        if (fabsf(t) < 1e-6f) {
            return 0.5f + t / 6.0f + (t * t) / 24.0f;
        }
        float phi1_val = phi1_fn(t);
        return (phi1_val - 1.0f) / t;
    };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        float sigma_from = sigmas[i];
        float sigma_to   = sigmas[i + 1];

        auto [sigma_down, sigma_up, alpha_scale] = get_ancestral_step(sigma_from, sigma_to, eta, is_flow_denoiser);

        if (sigma_down == 0.0f || !have_old_sigma) {
            x += ((x - denoised) / sigma_from) * (sigma_down - sigma_from);
        } else {
            float t      = t_fn(sigma_from);
            float t_old  = t_fn(old_sigma_down);
            float t_next = t_fn(sigma_down);
            float t_prev = t_fn(sigmas[i - 1]);
            float h      = t_next - t;
            float c2     = (t_prev - t_old) / h;

            float phi1_val = phi1_fn(-h);
            float phi2_val = phi2_fn(-h);
            float b1       = phi1_val - phi2_val / c2;
            float b2       = phi2_val / c2;

            if (!std::isfinite(b1)) {
                b1 = 0.0f;
            }
            if (!std::isfinite(b2)) {
                b2 = 0.0f;
            }

            x = sigma_fn(h) * x + h * (b1 * denoised + b2 * old_denoised);
        }

        if (sigma_to > 0.0f && sigma_up > 0.0f) {
            if (is_flow_denoiser) {
                x *= alpha_scale;
            }
            x += noise_sampler(sigma_from, sigma_to) * sigma_up;
        }

        old_denoised   = denoised;
        old_sigma_down = sigma_down;
        have_old_sigma = true;
    }
    return x;
}

static sd::Tensor<float> sample_res_2s(denoise_cb_t model,
                                       sd::Tensor<float> x,
                                       const std::vector<float>& sigmas,
                                       NoiseSampler& noise_sampler,
                                       bool is_flow_denoiser,
                                       float eta) {
    const float c2 = 0.5f;
    auto t_fn      = [](float sigma) -> float { return -logf(sigma); };
    auto phi1_fn   = [](float t) -> float {
        if (fabsf(t) < 1e-6f) {
            return 1.0f + t * 0.5f + (t * t) / 6.0f;
        }
        return (expf(t) - 1.0f) / t;
    };
    auto phi2_fn = [&](float t) -> float {
        if (fabsf(t) < 1e-6f) {
            return 0.5f + t / 6.0f + (t * t) / 24.0f;
        }
        float phi1_val = phi1_fn(t);
        return (phi1_val - 1.0f) / t;
    };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma_from = sigmas[i];
        float sigma_to   = sigmas[i + 1];

        auto denoised_opt = model(x, sigma_from, -(i + 1));
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        auto [sigma_down, sigma_up, alpha_scale] = get_ancestral_step(sigma_from, sigma_to, eta, is_flow_denoiser);

        sd::Tensor<float> x0 = x;
        if (sigma_down == 0.0f || sigma_from == 0.0f) {
            x = denoised;
        } else {
            float t      = t_fn(sigma_from);
            float t_next = t_fn(sigma_down);
            float h      = t_next - t;

            float a21      = c2 * phi1_fn(-h * c2);
            float phi1_val = phi1_fn(-h);
            float phi2_val = phi2_fn(-h);
            float b2       = phi2_val / c2;
            float b1       = phi1_val - b2;

            float sigma_c2         = expf(-(t + h * c2));
            sd::Tensor<float> eps1 = denoised - x0;
            sd::Tensor<float> x2   = x0 + eps1 * (h * a21);

            auto denoised2_opt = model(x2, sigma_c2, i + 1);
            if (denoised2_opt.pred.empty()) {
                return {};
            }
            sd::Tensor<float> denoised2 = std::move(denoised2_opt.pred);
            sd::Tensor<float> eps2      = denoised2 - x0;
            x                           = x0 + h * (b1 * eps1 + b2 * eps2);
        }

        if (sigma_to > 0.0f && sigma_up > 0.0f) {
            if (is_flow_denoiser) {
                x *= alpha_scale;
            }
            x += noise_sampler(sigma_from, sigma_to) * sigma_up;
        }
    }
    return x;
}

static sd::Tensor<float> sample_er_sde(denoise_cb_t model,
                                       sd::Tensor<float> x,
                                       std::vector<float> sigmas,
                                       NoiseSampler& noise_sampler,
                                       bool is_flow_denoiser,
                                       float eta) {
    constexpr int max_stage                  = 3;
    constexpr int num_integration_points     = 200;
    constexpr float num_integration_points_f = 200.0f;
    float s_noise                            = eta;

    auto er_sde_flow_sigma = [](float sigma) -> float {
        sigma = std::max(sigma, 1e-6f);
        sigma = std::min(sigma, 1.0f - 1e-4f);
        return sigma;
    };

    auto sigma_to_er_sde_lambda = [&](float sigma, bool is_flow_denoiser) -> float {
        if (is_flow_denoiser) {
            sigma = er_sde_flow_sigma(sigma);
            return sigma / std::max(1.0f - sigma, 1e-6f);
        }
        return std::max(sigma, 1e-6f);
    };

    auto sigma_to_er_sde_alpha = [&](float sigma, bool is_flow_denoiser) -> float {
        if (is_flow_denoiser) {
            sigma = er_sde_flow_sigma(sigma);
            return 1.0f - sigma;
        }
        return 1.0f;
    };

    auto er_sde_noise_scaler = [](float x) -> float {
        x = std::max(x, 0.0f);
        return x * (std::exp(std::pow(x, 0.3f)) + 10.0f);
    };

    if (is_flow_denoiser) {
        for (size_t i = 0; i + 1 < sigmas.size(); ++i) {
            if (sigmas[i] > 1.0f) {
                sigmas[i] = er_sde_flow_sigma(sigmas[i]);
            }
        }
    }

    std::vector<float> er_lambdas(sigmas.size(), 0.0f);
    for (size_t i = 0; i < sigmas.size(); ++i) {
        er_lambdas[i] = sigma_to_er_sde_lambda(sigmas[i], is_flow_denoiser);
    }

    sd::Tensor<float> old_denoised   = x;
    sd::Tensor<float> old_denoised_d = x;
    bool have_old_denoised           = false;
    bool have_old_denoised_d         = false;

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        auto denoised_opt = model(x, sigmas[i], i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        int stage_used = std::min(max_stage, i + 1);

        if (sigmas[i + 1] == 0.0f) {
            x = denoised;
        } else {
            float er_lambda_s = er_lambdas[i];
            float er_lambda_t = er_lambdas[i + 1];
            float alpha_s     = sigma_to_er_sde_alpha(sigmas[i], is_flow_denoiser);
            float alpha_t     = sigma_to_er_sde_alpha(sigmas[i + 1], is_flow_denoiser);
            float scaled_s    = er_sde_noise_scaler(er_lambda_s);
            float scaled_t    = er_sde_noise_scaler(er_lambda_t);
            float r_alpha     = alpha_s > 0.0f ? alpha_t / alpha_s : 0.0f;
            float r           = scaled_s > 0.0f ? scaled_t / scaled_s : 0.0f;

            x = r_alpha * r * x + alpha_t * (1.0f - r) * denoised;

            if (stage_used >= 2 && have_old_denoised) {
                float dt               = er_lambda_t - er_lambda_s;
                float lambda_step_size = -dt / num_integration_points_f;
                float s                = 0.0f;
                float s_u              = 0.0f;

                for (int p = 0; p < num_integration_points; ++p) {
                    float lambda_pos = er_lambda_t + p * lambda_step_size;
                    float scaled_pos = er_sde_noise_scaler(lambda_pos);
                    if (scaled_pos <= 0.0f) {
                        continue;
                    }

                    s += 1.0f / scaled_pos;
                    if (stage_used >= 3 && have_old_denoised_d) {
                        s_u += (lambda_pos - er_lambda_s) / scaled_pos;
                    }
                }

                s *= lambda_step_size;

                float denom_d = er_lambda_s - er_lambdas[i - 1];
                if (std::fabs(denom_d) > 1e-12f) {
                    float coeff_d                = alpha_t * (dt + s * scaled_t);
                    sd::Tensor<float> denoised_d = (denoised - old_denoised) / denom_d;
                    x += coeff_d * denoised_d;

                    if (stage_used >= 3 && have_old_denoised_d) {
                        float denom_u = (er_lambda_s - er_lambdas[i - 2]) * 0.5f;
                        if (std::fabs(denom_u) > 1e-12f) {
                            s_u *= lambda_step_size;
                            float coeff_u                = alpha_t * (0.5f * dt * dt + s_u * scaled_t);
                            sd::Tensor<float> denoised_u = (denoised_d - old_denoised_d) / denom_u;
                            x += coeff_u * denoised_u;
                        }
                    }

                    old_denoised_d      = denoised_d;
                    have_old_denoised_d = true;
                }
            }

            float noise_scale_sq = er_lambda_t * er_lambda_t - er_lambda_s * er_lambda_s * r * r;
            if (s_noise > 0.0f && noise_scale_sq > 0.0f) {
                float noise_scale = alpha_t * std::sqrt(std::max(noise_scale_sq, 0.0f));
                x += noise_sampler(sigmas[i], sigmas[i + 1]) * noise_scale;
            }
        }

        old_denoised      = denoised;
        have_old_denoised = true;
    }
    return x;
}

static sd::Tensor<float> sample_tcd(denoise_cb_t model,
                                    sd::Tensor<float> x,
                                    const std::vector<float>& sigmas,
                                    NoiseSampler& noise_sampler,
                                    float eta) {
    float beta_start = 0.00085f;
    float beta_end   = 0.0120f;
    std::vector<double> alphas_cumprod(TIMESTEPS);
    std::vector<double> compvis_sigmas(TIMESTEPS);
    for (int i = 0; i < TIMESTEPS; i++) {
        alphas_cumprod[i] =
            (i == 0 ? 1.0f : alphas_cumprod[i - 1]) *
            (1.0f -
             std::pow(sqrtf(beta_start) +
                          (sqrtf(beta_end) - sqrtf(beta_start)) *
                              ((float)i / (TIMESTEPS - 1)),
                      2));
        compvis_sigmas[i] =
            std::sqrt((1 - alphas_cumprod[i]) / alphas_cumprod[i]);
    }

    auto get_timestep_from_sigma = [&](float s) -> int {
        auto it = std::lower_bound(compvis_sigmas.begin(), compvis_sigmas.end(), s);
        if (it == compvis_sigmas.begin())
            return 0;
        if (it == compvis_sigmas.end())
            return TIMESTEPS - 1;
        int idx_high = static_cast<int>(std::distance(compvis_sigmas.begin(), it));
        int idx_low  = idx_high - 1;
        if (std::abs(compvis_sigmas[idx_high] - s) < std::abs(compvis_sigmas[idx_low] - s)) {
            return idx_high;
        }
        return idx_low;
    };

    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma_to    = sigmas[i + 1];
        int prev_timestep = get_timestep_from_sigma(sigma_to);
        int timestep_s    = (int)floor((1 - eta) * prev_timestep);
        float sigma       = sigmas[i];

        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        sd::Tensor<float> d        = (x - denoised) / sigma;

        float alpha_prod_t      = 1.0f / (sigma * sigma + 1.0f);
        float beta_prod_t       = 1.0f - alpha_prod_t;
        float alpha_prod_t_prev = 1.0f / (sigma_to * sigma_to + 1.0f);
        float alpha_prod_s      = static_cast<float>(alphas_cumprod[timestep_s]);
        float beta_prod_s       = 1.0f - alpha_prod_s;

        x = std::sqrt(alpha_prod_s / alpha_prod_t_prev) * denoised +
            std::sqrt(beta_prod_s / alpha_prod_t_prev) * d;

        if (eta > 0 && sigma_to > 0.0f) {
            x = std::sqrt(alpha_prod_t_prev / alpha_prod_s) * x +
                std::sqrt(1.0f / alpha_prod_t_prev - 1.0f / alpha_prod_s) * noise_sampler(sigma, sigma_to);
        }
    }
    return x;
}

static sd::Tensor<float> sample_lms(denoise_cb_t model,
                                    sd::Tensor<float> x,
                                    const std::vector<float>& sigmas,
                                    const SamplerExtraArgs& extra_sample_args) {
    // Linear Multi-Step from https://github.com/crowsonkb/k-diffusion,
    // modified with "history shift" value, which seemingly needs less steps
    int divisions = 1000;
    int max_order = 4;
    int shift     = 1;  // 4, 0 - original; 4, 1 - PR #1843; 3, 1 - smoother image
    for (const auto& [key, value] : extra_sample_args) {
        int parsed = 0;
        if (key == "lms_max_order") {
            if (!parse_strict_int(value, parsed)) {
                LOG_WARN("ignoring invalid lms extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            max_order = std::max(1, parsed);
            // smaller values make the result softer, closer to Euler
            // higher values need more steps
            // values above 12 can produce NaNs, depending on steps and scheduler
        }
        if (key == "lms_shift") {
            if (!parse_strict_int(value, parsed)) {
                LOG_WARN("ignoring invalid lms extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            shift = std::max(0, parsed);
            // for a low number of steps, the value 1 works best
        }
        if (key == "lms_divisions") {
            if (!parse_strict_int(value, parsed)) {
                LOG_WARN("ignoring invalid lms extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            divisions = parsed;  // std::max(1, parsed);
            // values < 1 always produce noise
            // values above 30M require double precision in the integrator
            // (they are needless and just slow the integration down, but
            //  with single precision they softly produce noise
            //  near the 35M, it can be used for distorted generations)
        }
    }

    auto linear_multistep_coeff = [=](const int order, const int m, const int j) -> float {
        if (!divisions)
            return sigmas[m + 1] - sigmas[m];  // delta / 0 * 0
#define LMS_PRECISION float                    // when divisions > 30 millions, the double precision fixes noise
        const LMS_PRECISION a = sigmas[m], dx = (sigmas[m + 1] - a) / divisions, s = sigmas[m - j];
        const LMS_PRECISION b0 = a + 0.5f * dx;  // using Riemann middle integral
        LMS_PRECISION sum      = 0.0f;
        for (int h = 0; h < divisions; h++) {
            const LMS_PRECISION b = h * dx + b0;
            LMS_PRECISION prod    = 1.0f;
            for (int k = 0; k < j; k++) {
                const LMS_PRECISION t = sigmas[m - k];
                prod *= (b - t) / (s - t);
            }
            for (int k = j + 1; k < order; k++) {
                const LMS_PRECISION t = sigmas[m - k];
                prod *= (b - t) / (s - t);
            }
            sum += prod;
        }
        return sum * dx;
    };

    int steps = static_cast<int>(sigmas.size()) - 1;
    max_order = std::min(max_order, steps);  // history can not be larger than steps
    LOG_VERBOSE("linear multi-step sampler: lms_max_order = %i, lms_shift = %i, lms_divisions = %i", max_order, shift, divisions);
    std::vector<float> lms_coeff(max_order);
    std::vector<sd::Tensor<float>> hist = {};

    for (int i = 0; i < steps; i++) {
        const float sigma = sigmas[i];

        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);

        const int order = std::min(max_order, i + 1);

        for (int c = 0; c < order; c++)  // computing coefficients
            lms_coeff[c] = linear_multistep_coeff(order, i, c);

        sd::Tensor<float> d_cur = (x - denoised) / sigma;
        x += d_cur * lms_coeff[0];
        if (max_order > 1) {  // if max_order == 1, the history is not used (order always < 2)
            int hist_size_p1 = static_cast<int>(hist.size()) + 1;
            if (i) {  // history does not exist at 1st step
                int hist_max = static_cast<int>(hist.size()) - 1;
                for (int c = 2; c <= order; c++)
                    x += hist[std::min(hist_max, hist_size_p1 - c + shift)] * lms_coeff[c - 1];
                // max_order == 4  =>  hist[] index = 2, 1, 0
                // shift == 1      =>  hist[] index = 2, 2, 1
            }
            if (hist_size_p1 == max_order) {
                hist.erase(hist.begin());
            }
            hist.push_back(std::move(d_cur));
        }
    }
    return x;
}

static sd::Tensor<float> sample_euler_cfg_pp(denoise_cb_t model,
                                             sd::Tensor<float> x,
                                             const std::vector<float>& sigmas) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma       = sigmas[i];
        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty() || denoised_opt.pred_uncond.empty()) {
            return {};
        }

        sd::Tensor<float> denoised        = std::move(denoised_opt.pred);
        sd::Tensor<float> uncond_denoised = std::move(denoised_opt.pred_uncond);
        sd::Tensor<float> d               = (x - uncond_denoised) / sigma;

        x = denoised + d * sigmas[i + 1];
    }
    return x;
}

static sd::Tensor<float> sample_euler_ancestral_cfg_pp(denoise_cb_t model,
                                                       sd::Tensor<float> x,
                                                       const std::vector<float>& sigmas,
                                                       NoiseSampler& noise_sampler,
                                                       float eta) {
    int steps = static_cast<int>(sigmas.size()) - 1;
    for (int i = 0; i < steps; i++) {
        float sigma       = sigmas[i];
        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty() || denoised_opt.pred_uncond.empty()) {
            return {};
        }

        sd::Tensor<float> denoised        = std::move(denoised_opt.pred);
        sd::Tensor<float> uncond_denoised = std::move(denoised_opt.pred_uncond);
        sd::Tensor<float> d               = (x - uncond_denoised) / sigma;

        auto [sigma_down, sigma_up] = get_ancestral_step(sigmas[i], sigmas[i + 1], eta);

        x = denoised + d * sigma_down;

        if (sigmas[i + 1] > 0) {
            x += noise_sampler(sigmas[i], sigmas[i + 1]) * sigma_up;
        }
    }
    return x;
}

// https://github.com/ToyotaResearchInstitute/gradient-estimation-sampler
static sd::Tensor<float> sample_gradient_estimation(denoise_cb_t model,
                                                    sd::Tensor<float> x,
                                                    const std::vector<float>& sigmas,
                                                    NoiseSampler& noise_sampler,
                                                    bool is_flow_denoiser,
                                                    float eta,
                                                    const SamplerExtraArgs& extra_sample_args) {
    float ge_gamma = 2.0f;

    for (const auto& [key, value] : extra_sample_args) {
        if (key == "gamma") {
            float parsed = 0.0f;
            if (!parse_strict_float(value, parsed)) {
                LOG_WARN("ignoring invalid euler_ge extra sample arg '%s=%s'", key.c_str(), value.c_str());
                continue;
            }
            LOG_VERBOSE("setting euler_ge gamma to %.2f", parsed);
            ge_gamma = parsed;
        }
    }

    int steps = static_cast<int>(sigmas.size()) - 1;
    sd::Tensor<float> old_d;
    bool has_old_d = false;
    for (int i = 0; i < steps; i++) {
        float sigma       = sigmas[i];
        float sigma_to    = sigmas[i + 1];
        auto denoised_opt = model(x, sigma, i + 1);
        if (denoised_opt.pred.empty()) {
            return {};
        }
        sd::Tensor<float> denoised = std::move(denoised_opt.pred);
        if (sigma_to == 0.f) {
            x = denoised;
        } else {
            auto [sigma_down, sigma_up, alpha_scale] = get_ancestral_step(sigma, sigma_to, eta, is_flow_denoiser);
            sd::Tensor<float> d                      = (x - denoised) / sigma;
            float dt                                 = sigma_down - sigma;
            if (has_old_d) {
                sd::Tensor<float> d_bar = d * ge_gamma + old_d * (1.0f - ge_gamma);
                x += d_bar * dt;
            } else {
                x += d * dt;
            }
            old_d     = std::move(d);
            has_old_d = true;
            if (sigma_up > 0.f) {
                if (is_flow_denoiser) {
                    x *= alpha_scale;
                }
                x += noise_sampler(sigma, sigma_to) * sigma_up;
            }
        }
    }
    return x;
}

// independent and identically distributed Gaussian noise (default for most samplers)
class IIDGaussianNoiseSampler : public NoiseSampler {
public:
    IIDGaussianNoiseSampler(const sd::Tensor<float>& x_template, std::shared_ptr<RNG> r)
        : rng(std::move(r)), shape(x_template.shape()) {}
    sd::Tensor<float> operator()(double sigma_from, double sigma_to) override {
        (void)sigma_from;
        (void)sigma_to;
        return sd::Tensor<float>::randn(shape, rng);
    }

private:
    std::shared_ptr<RNG> rng;
    std::vector<int64_t> shape;
};

// A fixed tree seed, shape and sigma range give consistent increments across
// interval subdivisions. Each query returns normalized Gaussian noise.
// Reference: torchsde BrownianTree; k-diffusion BatchedBrownianTree.
class BrownianTreeNoiseSampler : public NoiseSampler {
public:
    BrownianTreeNoiseSampler(const sd::Tensor<float>& x_template,
                             double sigma_min,
                             double sigma_max,
                             std::shared_ptr<RNG> seed_rng,
                             std::shared_ptr<RNG> node_rng)
        : t_min_(sigma_min),
          t_max_(sigma_max),
          shape_(x_template.shape()),
          seed_rng_(std::move(seed_rng)),
          node_rng_(std::move(node_rng)) {}

    sd::Tensor<float> operator()(double sigma_a, double sigma_b) override {
        if (!initialized_) {
            uint64_t seed = 0;
            auto draw     = seed_rng_->randn(2);
            std::memcpy(&seed, draw.data(), sizeof(seed));
            root_seed_ = mix64(seed, 0x9E3779B97F4A7C15ULL);
            node_rng_->manual_seed(mix64(seed, 0xBF58476D1CE4E5B9ULL));
            w_at_tmax_   = sd::Tensor<float>::randn(shape_, node_rng_) * std::sqrt(static_cast<float>(t_max_ - t_min_));
            initialized_ = true;
        }
        double a   = clamp(std::min(sigma_a, sigma_b));
        double b   = clamp(std::max(sigma_a, sigma_b));
        auto dW    = w(b) - w(a);
        float span = static_cast<float>(std::max(std::abs(sigma_b - sigma_a), 1e-12));
        return dW * (1.0f / std::sqrt(span));
    }

private:
    static constexpr int kMaxDepth = 24;

    static uint64_t mix64(uint64_t v, uint64_t salt) {
        uint64_t z = v + salt;
        z          = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z          = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        return z ^ (z >> 31);
    }

    double clamp(double t) const {
        return std::min(std::max(t, t_min_), t_max_);
    }

    sd::Tensor<float> w(double t) {
        auto it = cache_.find(t);
        if (it != cache_.end()) {
            return it->second;
        }
        sd::Tensor<float> zero = sd::Tensor<float>::zeros(shape_);
        sd::Tensor<float> out  = bridge(t_min_, t_max_, zero, w_at_tmax_, t, root_seed_, kMaxDepth);
        cache_.emplace(t, out);
        return out;
    }

    sd::Tensor<float> bridge(double a,
                             double c,
                             const sd::Tensor<float>& w_a,
                             const sd::Tensor<float>& w_c,
                             double t,
                             uint64_t node_seed,
                             int depth) {
        if (depth <= 0 || c - a < 1e-9) {
            float alpha = (c > a) ? static_cast<float>((t - a) / (c - a)) : 0.5f;
            return (1.0f - alpha) * w_a + alpha * w_c;
        }
        double m       = 0.5 * (a + c);
        double std_dev = std::sqrt((c - m) * (m - a) / (c - a));
        node_rng_->manual_seed(node_seed);
        auto z   = sd::Tensor<float>::randn(shape_, node_rng_);
        auto w_m = 0.5f * (w_a + w_c) + static_cast<float>(std_dev) * z;
        if (t == m) {
            return w_m;
        }
        if (t < m) {
            return bridge(a, m, w_a, w_m, t, mix64(node_seed, 1), depth - 1);
        }
        return bridge(m, c, w_m, w_c, t, mix64(node_seed, 2), depth - 1);
    }

    double t_min_;
    double t_max_;
    std::vector<int64_t> shape_;
    std::shared_ptr<RNG> seed_rng_;
    std::shared_ptr<RNG> node_rng_;
    uint64_t root_seed_ = 0;
    bool initialized_   = false;
    sd::Tensor<float> w_at_tmax_;
    std::map<double, sd::Tensor<float>> cache_;
};

static std::unique_ptr<NoiseSampler> make_noise_sampler(const sd::Tensor<float>& x, std::shared_ptr<RNG> rng, sample_method_t method, const std::vector<float>& sigmas, const SamplerExtraArgs& extra_args) {
    bool brownian_tree            = (method == DPMPP2M_SDE_BT_SAMPLE_METHOD);
    bool def_brownian_tree        = brownian_tree;
    std::string brownian_tree_rng = "cpu";

    for (const auto& [key, value] : extra_args) {
        if (key == "noise_sampler") {
            if (value == "iid") {
                brownian_tree = false;
            } else if (value == "brownian_tree") {
                brownian_tree = true;
            } else {
                LOG_WARN("unknown noise_sampler value '%s'; using default", value.c_str());
            }
        } else if (key == "brownian_tree_rng") {
            if (value == "cpu" || value == "cuda" || value == "std_default" || value == "sampler_rng") {
                brownian_tree_rng = value;
            } else {
                LOG_WARN("ignoring invalid brownian_tree_rng value '%s'; expected cpu, cuda, std_default or sampler_rng", value.c_str());
            }
        }
    }

    if (brownian_tree) {
        double sigma_max = 0.0;
        double sigma_min = std::numeric_limits<double>::infinity();
        for (float s : sigmas) {
            if (s > 0.0f) {
                sigma_max = std::max(sigma_max, static_cast<double>(s));
                sigma_min = std::min(sigma_min, static_cast<double>(s));
            }
        }

        if (sigma_max > sigma_min) {
            std::shared_ptr<RNG> node_rng;
            if (brownian_tree_rng == "sampler_rng") {
                node_rng = rng->clone();
            } else if (brownian_tree_rng == "std_default") {
                node_rng = std::make_shared<STDDefaultRNG>();
            } else if (brownian_tree_rng == "cuda") {
                node_rng = std::make_shared<PhiloxRNG>();
            } else {
                node_rng = std::make_shared<MT19937RNG>();
            }
            if (!def_brownian_tree) {
                LOG_INFO("setting noise sampler to Brownian tree (%s RNG)", brownian_tree_rng.c_str());
            }
            return std::make_unique<BrownianTreeNoiseSampler>(x, sigma_min, sigma_max, rng, std::move(node_rng));
        }
    }

    if (def_brownian_tree) {
        LOG_INFO("setting noise sampler to independent and identically distributed (iid)");
    }
    return std::make_unique<IIDGaussianNoiseSampler>(x, rng);
}

// k diffusion reverse ODE: dx = (x - D(x;\sigma)) / \sigma dt; \sigma(t) = t
static sd::Tensor<float> sample_k_diffusion(sample_method_t method,
                                            denoise_cb_t model,
                                            sd::Tensor<float> x,
                                            std::vector<float> sigmas,
                                            std::shared_ptr<RNG> rng,
                                            float eta,
                                            bool is_flow_denoiser,
                                            const char* extra_sample_args,
                                            std::shared_ptr<Denoiser> denoiser_for_dispatch = nullptr) {
    if (denoiser_for_dispatch) {
        if (auto sefi = std::dynamic_pointer_cast<SefiFlowDenoiser>(denoiser_for_dispatch)) {
            return sample_sefi_euler(sefi.get(), model, std::move(x));
        }
    }
    SamplerExtraArgs extra_args = parse_key_value_args(extra_sample_args, "extra sample arg");

    std::unique_ptr<NoiseSampler> noise_sampler = make_noise_sampler(x, rng, method, sigmas, extra_args);

    switch (method) {
        case EULER_A_SAMPLE_METHOD:
            return sample_euler_ancestral(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta);
        case EULER_SAMPLE_METHOD:
            return sample_euler(model, std::move(x), sigmas);
        case HEUN_SAMPLE_METHOD:
            return sample_heun(model, std::move(x), sigmas);
        case DPM2_SAMPLE_METHOD:
            return sample_dpm2(model, std::move(x), sigmas);
        case DPMPP2S_A_SAMPLE_METHOD:
            if (is_flow_denoiser)
                return sample_dpmpp_2s_ancestral_flow(model, std::move(x), sigmas, *noise_sampler, eta);
            else
                return sample_dpmpp_2s_ancestral(model, std::move(x), sigmas, *noise_sampler, eta);
        case DPMPP2M_SAMPLE_METHOD:
            return sample_dpmpp_2m(model, std::move(x), sigmas);
        case DPMPP2Mv2_SAMPLE_METHOD:
            return sample_dpmpp_2m_v2(model, std::move(x), sigmas);
        case LCM_SAMPLE_METHOD:
            return sample_lcm(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, extra_args);
        case IPNDM_SAMPLE_METHOD:
            return sample_ipndm(model, std::move(x), sigmas);
        case IPNDM_V_SAMPLE_METHOD:
            return sample_ipndm_v(model, std::move(x), sigmas);
        case RES_MULTISTEP_SAMPLE_METHOD:
            return sample_res_multistep(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta);
        case RES_2S_SAMPLE_METHOD:
            return sample_res_2s(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta);
        case ER_SDE_SAMPLE_METHOD:
            return sample_er_sde(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta);
        case DPMPP2M_SDE_SAMPLE_METHOD:
        case DPMPP2M_SDE_BT_SAMPLE_METHOD:
            return sample_dpmpp_2m_sde(model, std::move(x), sigmas, *noise_sampler, eta);
        case DDIM_TRAILING_SAMPLE_METHOD:
            // DDIM is equivalent to Euler Ancestral with the Simple scheduler
            return sample_euler_ancestral(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta);
        case TCD_SAMPLE_METHOD:
            return sample_tcd(model, std::move(x), sigmas, *noise_sampler, eta);
        case LMS_SAMPLE_METHOD:
            return sample_lms(model, std::move(x), sigmas, extra_args);
        case EULER_CFG_PP_SAMPLE_METHOD:
            return sample_euler_cfg_pp(model, std::move(x), sigmas);
        case EULER_A_CFG_PP_SAMPLE_METHOD:
            return sample_euler_ancestral_cfg_pp(model, std::move(x), sigmas, *noise_sampler, eta);
        case EULER_GE_SAMPLE_METHOD:
            return sample_gradient_estimation(model, std::move(x), sigmas, *noise_sampler, is_flow_denoiser, eta, extra_args);
        default:
            return {};
    }
}

#endif  // __SD_RUNTIME_DENOISER_HPP__
