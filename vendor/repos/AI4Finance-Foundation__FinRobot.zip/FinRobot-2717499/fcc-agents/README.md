# FCC agent cards for FinRobot

FinRobot is from the AI4Finance Foundation, under the Apache License 2.0
(see LICENSE and NOTICE next to this folder). Its agents are instruction files
and Python profiles, not agent files, so FCC wrapped them in cards LCC Studio
can read:

- eight cards hold the instructions in
  `finrobot_desktop/finrobot/engine/agents/instructions/` unchanged;
- three hold the profiles of `Software_Developer`, `Data_Analyst` and
  `Financial_Analyst` from `finrobot_autogen/finrobot/agents/agent_library.py`
  unchanged.

What FCC changed: it added each card's name, description, tool list, and the
closing notes on how to work inside LCC Studio. The cards are a derivative
work built on FinRobot, not FinRobot itself, and are not endorsed by the
AI4Finance Foundation (see TRADEMARK_POLICY.md).
