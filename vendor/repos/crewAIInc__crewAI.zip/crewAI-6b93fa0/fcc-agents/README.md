# FCC agent cards for crewAI

crewAI defines its agents in YAML (a role, a goal, and a backstory). FCC
turned the agents of crewAI's two starter crews into cards LCC Studio can
read: the research crew (`templates/crew/config/agents.yaml`: Senior Data
Researcher, Reporting Analyst) and the content crew
(`templates/flow/crews/content_crew/config/agents.yaml`: Content Planner,
Writer, Editor). The role, goal and backstory are quoted unchanged from those
files at commit 6b93fa0, under crewAI's MIT licence; the rest is FCC's.
