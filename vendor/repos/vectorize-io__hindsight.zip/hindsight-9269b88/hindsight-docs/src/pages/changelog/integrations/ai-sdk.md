---
hide_table_of_contents: true
---

import PageHero from '@site/src/components/PageHero';

<PageHero title="Vercel AI SDK Changelog" subtitle="@vectorize-io/hindsight-ai-sdk — memory integration for Vercel AI SDK." />

[← Vercel AI SDK integration](/sdks/integrations/ai-sdk)

## [0.5.2](https://github.com/vectorize-io/hindsight/tree/integrations/ai-sdk/v0.5.2)

[Commits in this release →](https://github.com/vectorize-io/hindsight/commits/integrations/ai-sdk/v0.5.2)

**Bug Fixes**

- Recall results now preserve the source chunks requested by callers.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/rudycelekli" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/rudycelekli.png?size=40" alt="@rudycelekli" width="18" height="18" style={{borderRadius: "50%"}} />@rudycelekli</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/f3fa28166" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>f3fa28166</a>

## [0.5.1](https://github.com/vectorize-io/hindsight/tree/integrations/ai-sdk/v0.5.1)

**Bug Fixes**

- Fixed AI-SDK reflection tool type definitions to match the OpenAPI spec for more reliable integration behavior.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/nicoloboschi" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/nicoloboschi.png?size=40" alt="@nicoloboschi" width="18" height="18" style={{borderRadius: "50%"}} />@nicoloboschi</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/3d6b3805" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>3d6b3805</a>

## [0.5.0](https://github.com/vectorize-io/hindsight/tree/integrations/ai-sdk/v0.5.0)

**Bug Fixes**

- Improved compatibility with Hindsight Client v0.5.2 to prevent integration mismatches when using the AI SDK.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/nicoloboschi" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/nicoloboschi.png?size=40" alt="@nicoloboschi" width="18" height="18" style={{borderRadius: "50%"}} />@nicoloboschi</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/bca87412" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>bca87412</a>

## [0.4.20](https://github.com/vectorize-io/hindsight/tree/integrations/ai-sdk/v0.4.20)

**Features**

- Add AI SDK integration for Hindsight. ([`7e339e16`](https://github.com/vectorize-io/hindsight/commit/7e339e16))
- Add Deno compatibility for the TypeScript client. ([`72c25c97`](https://github.com/vectorize-io/hindsight/commit/72c25c97))

**Improvements**

- Improve AI SDK tool support to make integrations more capable and reliable. ([`d06a0259`](https://github.com/vectorize-io/hindsight/commit/d06a0259))

**Bug Fixes**

- Security fixes by resolving dependency vulnerabilities affecting the integration. ([`b6a4f17c`](https://github.com/vectorize-io/hindsight/commit/b6a4f17c))
