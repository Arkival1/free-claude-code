---
hide_table_of_contents: true
---

# Vapi Integration Changelog

Changelog for [`hindsight-vapi`](https://pypi.org/project/hindsight-vapi/).

For the source code, see [`hindsight-integrations/vapi`](https://github.com/vectorize-io/hindsight/tree/main/hindsight-integrations/vapi).

← [Back to main changelog](/changelog)

## [0.1.0](https://github.com/vectorize-io/hindsight/tree/integrations/vapi/v0.1.0)

**Features**

- Added Vapi voice AI webhook integration to capture and store call memories in Hindsight.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/benfrank241" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/benfrank241.png?size=40" alt="@benfrank241" width="18" height="18" style={{borderRadius: "50%"}} />@benfrank241</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/dde133da" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>dde133da</a>
