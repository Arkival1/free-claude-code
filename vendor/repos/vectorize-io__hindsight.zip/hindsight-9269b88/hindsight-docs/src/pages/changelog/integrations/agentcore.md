---
hide_table_of_contents: true
---

# Bedrock AgentCore Integration Changelog

Changelog for [`hindsight-agentcore`](https://pypi.org/project/hindsight-agentcore/).

For the source code, see [`hindsight-integrations/agentcore`](https://github.com/vectorize-io/hindsight/tree/main/hindsight-integrations/agentcore).

← [Back to main changelog](/changelog)

## [0.1.2](https://github.com/vectorize-io/hindsight/tree/integrations/agentcore/v0.1.2)

[Commits in this release →](https://github.com/vectorize-io/hindsight/commits/integrations/agentcore/v0.1.2)

**Bug Fixes**

- Reflect recall mode now returns the reflection text instead of an empty memory context.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/rudycelekli" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/rudycelekli.png?size=40" alt="@rudycelekli" width="18" height="18" style={{borderRadius: "50%"}} />@rudycelekli</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/071502981" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>071502981</a>

## [0.1.1](https://github.com/vectorize-io/hindsight/tree/integrations/agentcore/v0.1.1)

**Features**

- Added integration so Hindsight can use Bedrock AgentCore Runtime for memory operations.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/benfrank241" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/benfrank241.png?size=40" alt="@benfrank241" width="18" height="18" style={{borderRadius: "50%"}} />@benfrank241</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/c91696f5" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>c91696f5</a>

**Improvements**

- Improved the AgentCore integration with an async-native client and better task tracking for more reliable runtime behavior.<span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/nicoloboschi" target="_blank" rel="noopener noreferrer" style={{color: "var(--ifm-color-primary)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "4px", verticalAlign: "middle"}}><img src="https://github.com/nicoloboschi.png?size=40" alt="@nicoloboschi" width="18" height="18" style={{borderRadius: "50%"}} />@nicoloboschi</a><span style={{color: "var(--ifm-color-emphasis-500)", margin: "0 0.3em"}}>·</span><a href="https://github.com/vectorize-io/hindsight/commit/b153541e" target="_blank" rel="noopener noreferrer" style={{fontFamily: "var(--ifm-font-family-monospace, monospace)", fontSize: "0.85em", color: "var(--ifm-color-emphasis-600)"}}>b153541e</a>
