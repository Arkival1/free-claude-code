# FCC agent card for OpenHands

The OpenHands agent's system prompt now lives in the OpenHands
software-agent-sdk, as prompt sections in
`openhands-sdk/openhands/sdk/context/prompts/sections/static.py` (kept next to
this folder). FCC's card `openhands-engineer.md` opens with the agent's
default soul line and then quotes six of those sections unchanged (ROLE,
EFFICIENCY, FILE_SYSTEM_GUIDELINES, CODE_QUALITY, PROBLEM_SOLVING_WORKFLOW,
TROUBLESHOOTING) at commit 1cfba21, under the SDK's MIT licence. Sections about
git, pull requests, secrets and the OpenHands runtime are left out because LCC
Studio does those its own way.
