# Licence note (written by FCC)

vercel-labs/agent-skills has no licence file. It states its licence as MIT in its README (section "License") and in each SKILL.md header (`license: MIT`), both kept in this copy.
