# FCC agent cards for MetaGPT

MetaGPT's roles are Python classes, not agent files, so FCC wrote one card per
role of MetaGPT's software company (Product Manager, Architect, Project
Manager, Engineer, QA Engineer). Each card quotes the role's profile, goal and
constraints and its action's instructions from the files kept next to it
(`metagpt/roles/`, `metagpt/actions/`) at commit 11cdf46, under MetaGPT's MIT
licence. The rest of each card (how to work inside LCC Studio) is FCC's.
