# Token Optimization Checklist

Comprehensive checklist of ALL optimization techniques.

---

## Contents

- [QUICK WINS (< 30 minutes each)](#quick-wins--30-minutes-each)
- [MODEL ROUTING STRATEGY (Highest-ROI Behavioral Change)](#model-routing-strategy-highest-roi-behavioral-change)
- [MEDIUM EFFORT (1-3 hours, save 2,000-5,000 tokens)](#medium-effort-1-3-hours-save-2000-5000-tokens)
- [DEEP OPTIMIZATION (power users)](#deep-optimization-power-users)
- [BEHAVIORAL CHANGES (Free, highest cumulative impact)](#behavioral-changes-free-highest-cumulative-impact)
- [ADVANCED (Power Users)](#advanced-power-users)
- [MONITORING & MEASUREMENT](#monitoring--measurement)
- [TOKEN FLOW REFERENCE](#token-flow-reference)
- [WORKED EXAMPLE: Power User Optimization](#worked-example-power-user-optimization)
- [ENVIRONMENT VARIABLES & SETTINGS (Tune your setup)](#environment-variables--settings-tune-your-setup)
- [ANTI-PATTERNS](#anti-patterns)

---

## QUICK WINS (< 30 minutes each)

### 1. Check /cost and /context (0 minutes)
**Target**: Know your baseline before changing anything

**Actions**:
- [ ] Run `/cost` to see current session spending
- [ ] Run `/context` to see context fill level
- [ ] Note your per-message overhead (this IS your baseline)

**Why first**: You can't optimize what you don't measure. And these are built-in, zero effort.

---

### 2. Check Model Routing (5 minutes)
**Target**: Confirm you have model routing instructions in CLAUDE.md

**Quick check**: Does your CLAUDE.md tell Claude which model to use for subagents? If not, add the snippet from the Model Routing section below. One line, the largest per-token cut you can get on every multi-agent workflow.

**Expected savings**: The biggest single cut on automation costs (see full breakdown below)

---

### 3. CLAUDE.md Consolidation
**Target**: Under 200 lines per CLAUDE.md file — Anthropic's documented guidance (code.claude.com/docs/en/memory). The ~300 lines / ~4,500 tokens figure is an internal aggressive heuristic (derived at ~15 tokens/line for prose), not an Anthropic recommendation.

**Actions**:
- [ ] Remove content that belongs in skills/commands (workflows, detailed configs)
- [ ] Remove content that duplicates MEMORY.md (paths, gotchas, personality)
- [ ] Move reference content to on-demand files (coding standards, tool configs)
- [ ] Condense personality spec to 1-2 lines (full spec can live in MEMORY.md)
- [ ] Apply tiered architecture (see below)

**Tiered Architecture Pattern**:
- **Tier 1 (always loaded, ~300 lines / ~4,500 tokens — internal heuristic, not Anthropic's under-200-lines guidance)**: Identity, critical rules, key paths, personality ONE-LINER
- **Tier 2 (skill/command, loaded on-demand)**: Workflows, domain docs, tool configs
- **Tier 3 (file reference, explicit only)**: Full guides, templates, detailed standards

**Expected savings**: 1,000-3,000+ tokens/msg (depends on starting size)

---

### 4. MEMORY.md Deduplication
**Target**: Remove 100% overlap with CLAUDE.md

**Actions**:
- [ ] Remove Key Paths if already in CLAUDE.md (choose ONE source of truth)
- [ ] Remove personality spec if already in CLAUDE.md
- [ ] Condense verbose operational history to current rule only
- [ ] Keep only: Learnings, corrections, habit tracking

**Expected savings**: 400-800 tokens/msg

---

### 5. File Exclusion Rules
**Target**: Block unnecessary files from context via `permissions.deny`

See `examples/permissions-deny-template.json` for a ready-to-use template.

Add `permissions.deny` rules to `.claude/settings.json` (project-level) or `~/.claude/settings.json` (global):

```json
{
  "permissions": {
    "deny": [
      "Read(./.env)",
      "Read(./.env.*)",
      "Read(./node_modules/**)",
      "Read(./dist/**)",
      "Read(./**/*.log)"
    ]
  }
}
```

**Why**: Files matching deny patterns are excluded from file discovery, search, and read operations. This is the official approach (replaces deprecated `ignorePatterns`). The rules are enforced locally and are NOT injected into the prompt, so they cost zero tokens per turn.

**CAUTION**: Deny rules affect ALL tools in ALL sessions for the scope they're applied to.
- Apply at **project level** (`.claude/settings.json`) first, not global. Easier to debug when something breaks.
- **Never deny `*.sqlite` or `*.db` globally** unless you're certain no tools need database access. Many plugins (session memory, search indexes, WhatsApp) read SQLite files.
- **Credential denies** (`.env`, `*.key`) are usually safe and desired, but will break any skill that reads API keys from those files at runtime.

**TOKEN-COST CAUTION (counterintuitive)**: Deny rules save tokens only when Claude *never tries* the path. If you deny a path Claude actively wants, each blocked attempt returns feedback that accumulates in the conversation and is re-sent every turn, which **costs** tokens. Prefer narrow paths over broad globs (`Read(./logs/**)` over `Read(./**/*.log)`), only deny what Claude wouldn't read anyway, and if Claude keeps hitting "permission denied" on the same path, narrow or remove that rule.

**Expected savings**: Varies. Net positive when rules target files Claude never needs (secrets, `node_modules`, build output). Broad globs on actively-read paths can net negative.

---

### 6. Archive Unused Skills
**Target**: Reduce skill menu overhead

**Actions**:
- [ ] Identify duplicate skills (similar names/descriptions)
- [ ] Identify unused domain skills
- [ ] Create backup: `mkdir -p ~/.claude/_backups/skills-archived-$(date +%Y%m%d)`
- [ ] Move unused skills: `mv ~/.claude/skills/[skill-name] ~/.claude/_backups/skills-archived-*/`

A subfolder such as `_archived/` inside skills/ still loads as a namespace, so move archived skills outside skills/ entirely.

**Expected savings**: ~100 tokens per skill archived

---

### 7. Trim Commands
**Target**: Reduce command menu overhead

**Actions**:
- [ ] Identify rarely-used commands
- [ ] Merge similar commands if possible
- [ ] Archive to `~/.claude/_backups/commands-archived-$(date +%Y%m%d)/`

**Expected savings**: ~50 tokens per command archived

---

### 8. Cache Preservation (Reduce Compaction-Triggered Cache Rebuilds)
**Target**: Fewer full cache rebuilds per session

Every compaction event invalidates the prompt cache. Post-compaction, ALL context gets re-billed at full input price (not the 10% cached rate). In a heavy Opus session, a single cache rebuild can cost $2-5.

**Strategies**:
- [ ] Keep context lean (the optimizer's core job) to delay or prevent compaction
- [ ] Enable Smart Compaction (`setup-smart-compact`) to preserve state across compaction events
- [ ] For API users: Use Anthropic's Context Editing API (`clear_tool_uses_20250919` beta) to surgically evict old tool results WITHOUT triggering full compaction. This preserves the cache prefix.
- [ ] For API users: Use thinking block clearing (`clear_thinking_20251015`) to free context space without compaction
- [ ] Place strategic cache breakpoints before editable content (API users)

**Why it matters**: The LinkedIn poster's dashboard showed cache hit rates swinging from 88% to 17% after compaction. At $5/M tokens on Opus, that's the difference between $0.50/M and $5/M for the same context.

**Expected savings**: 1-3 cache rebuilds avoided per long session = $2-15 in API costs

**Compaction Timing Guide**:

Compaction timing matters as much as frequency. Compact at *phase boundaries*, not mid-task:

| When to compact | Why |
|-----------------|-----|
| After research/exploration, before execution | Bulky context served its purpose; the plan is the output |
| After debugging, before next feature | Debug traces and hypothesis state pollute unrelated work |
| After a failed approach, before retrying | Dead-end reasoning wastes context on the retry |
| After completing a milestone (commit/merge) | Natural checkpoint; fresh context for fresh work |

| When NOT to compact | Why |
|---------------------|-----|
| Mid-implementation | Losing file paths and partial state is costly to rebuild |
| Mid-debugging | Losing hypothesis state forces re-investigation |
| During multi-step operations | Breaks continuity across related steps |

Rule of thumb: if you just *produced* something (a plan, a commit, a diagnosis), compact. If you're *in the middle* of producing something, hold.

---

## MODEL ROUTING STRATEGY (Highest-ROI Behavioral Change)

Model routing is the single highest-ROI optimization for multi-agent workflows. It saves dollars (API users), rate limit quota (subscription users), and wall-clock time. One instruction in CLAUDE.md, 50-75% cost reduction on automation.

### Cost Math

Check anthropic.com/pricing for current rates; this file keeps no price table because it would go stale. The shape that holds: Sonnet and Opus bill more per token than Haiku, and Haiku 5.5 charges 5x more on the part of a prompt beyond 100K tokens ($0.10/MTok up to 100K, $0.50/MTok above, per the platform pricing page). For work that needs no judgment or deep reasoning, a larger model is overspend.

### Task-to-Model Mapping

| Task Type | Model | Examples | Why |
|-----------|-------|----------|-----|
| Data gathering | haiku | File reading, counting, scanning, listing, presence checks | No judgment needed, pattern matching only |
| Light analysis | haiku | Formatting, simple transforms, status checks, inventory | Structured output from structured input |
| Moderate reasoning | sonnet | Code review, writing, synthesis, moderate debugging, content analysis | Requires judgment + coherence |
| Complex reasoning | opus | Architecture decisions, novel problems, cross-cutting analysis, multi-file synthesis | Needs full capability, nuanced tradeoffs |

### CLAUDE.md Snippet (Ready to Copy-Paste)

```markdown
## Agent Model Selection
Default subagents to haiku. Upgrade only when task requires judgment:
- haiku: file reading, data gathering, counting, scanning, formatting
- sonnet: analysis, code review, writing, moderate reasoning
- opus: architecture decisions, novel debugging, cross-cutting synthesis
```

### Worked Example: 5-Agent Workflow

A typical audit workflow dispatches 5 agents to scan files, count items, analyze content, and synthesize findings, each using roughly 30K input and 5K output tokens.

- **Without routing (all on the largest model)**: all five agents bill at that model's input and output rates.
- **With routing (3 data-gathering agents on Haiku, 1 on Sonnet, 1 on Opus)**: the same tokens, but the three data-gathering agents bill at the cheapest rate.

The routed mix costs a fraction of the all-largest-model run. Work out exact dollars from the current pricing page and the measured token counts (`measure.py trends` shows them), not from memory.

For subscription users (Max plan): model routing affects rate limits, not dollars. Lighter models consume fewer quota units, so routing keeps your session under rate limits longer and agents return results faster.

### What Routing Does NOT Save

- **Context window space**: Subagents inherit the full system prompt regardless of model. A Haiku agent gets the same system prompt overhead as an Opus agent.
- **System prompt overhead**: CLAUDE.md, skills, MCP tools all load for every subagent at full size.

Routing saves **dollars** (API users), **rate limit quota** (subscription users), and **wall-clock time** (everyone). It does not reduce context window consumption. That's what the config optimizations (CLAUDE.md slimming, skill archival, etc.) address.

### Detection: Is Your Setup Routing Efficiently?

Signs of inefficient routing:
- No model routing instructions in CLAUDE.md or MEMORY.md
- `measure.py trends` shows >70% of tokens going to Opus/Sonnet
- Subagent types include data-gathering patterns (Explore, general-purpose for file reads) running on Opus, since Explore inherits the main model
- The Settings & Advanced auditor checks this automatically (see agent-prompts.md)

---

## MEDIUM EFFORT (1-3 hours, save 2,000-5,000 tokens)

### 8. MCP Server Audit
**Target**: Remove broken/unused MCP servers and their deferred tool listings

**First, check Tool Search status**:
- If ToolSearch is available in your session, Tool Search is active. Unset, Claude Code defers all MCP tools by default; it loads them upfront on some cloud-provider models and when `ANTHROPIC_BASE_URL` points to a non-first-party host
- Tool Search means definitions are deferred (~15 tokens per tool name in the menu, not 300-850 for full definitions)
- If Tool Search is NOT active, enabling it is the single biggest MCP optimization you can make

**How to audit**:
1. Check Claude Code config: `~/.claude/settings.json` (primary, mcpServers key)
2. Check Desktop config: `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS)
3. Check plugin configs: `~/.claude/plugins/` (plugins can bundle MCP servers)
4. Count deferred tools in current session (system prompt shows count)

**Identify**:
- [ ] Broken servers (auth failed, deprecated APIs)
- [ ] Duplicate tools across servers AND plugins (same tool from multiple sources)
- [ ] Rarely-used servers (domain-specific, >10 tools, used <1x/month)
- [ ] Plugin-bundled MCP that duplicates standalone servers

**Expected savings**: ~15 tokens per deferred tool removed (with Tool Search active). Larger savings from removing full server instructions (~50-100 tokens per server).

---

### 9. Install qmd for Local Search
**Target**: 60-95% reduction on code exploration tasks

**Install**:
```bash
# Option 1: npm
npm install -g qmd

# Option 2: bun
bun install -g github:tobi/qmd
```

**Index your codebase**:
```bash
qmd index /path/to/codebase
```

**Add to CLAUDE.md** (1 line):
```
Before reading files, always try `qmd search [query]` or `qmd query [question]` first.
```

**Why**: Pre-indexes your files with hybrid search (keyword + vector). Claude queries the index instead of reading every file.

**Expected savings**: 60-95% on exploration sessions

---

### 10. Migrate CLAUDE.md Content to Skills
**Target**: Move domain-specific content to on-demand loading

**Pattern**: Skills load ~100 tokens at startup (frontmatter only). Full content loads on-demand. Only the short frontmatter sits in every message; the body loads when the skill is used, whereas CLAUDE.md content loads every time.

**How**:
1. Create skill: `mkdir ~/.claude/skills/[name]`
2. Write SKILL.md with content
3. Remove from CLAUDE.md
4. Add 1-line reference in CLAUDE.md: "Full config: see /[name] skill"

**Expected savings**: ~500-1,000 tokens (depends on volume moved)

---

## DEEP OPTIMIZATION (power users)

### 11. Session Folder Pattern (Architecture Change)
**Target**: Prevent orchestrator context overflow

**Problem**: Multi-agent workflows load all agent outputs into main context. At 5-10K tokens per agent x 5 agents = 25-50K tokens in orchestrator.

**Solution**:
1. Orchestrator creates a project-local session folder: `./.agent-sessions/[task-name]-$(date +%Y%m%d-%H%M%S)/` (add `.agent-sessions/` to `.gitignore`)
2. Agents write findings to files in session folder
3. Orchestrator receives ONLY: "Agent X completed, output at {path}"
4. Synthesis agent reads files directly
5. Orchestrator does not read full agent outputs, which is what keeps its context small

**When to use**: Any task with 3+ subagents or agents producing >5K tokens output each.

---

### 12. Progressive Disclosure Pattern
**Target**: Load context incrementally, not all at once

**Pattern**:
- Phase 1: Load minimal context (identity, current state)
- Phase 2: Ask clarifying questions
- Phase 3: Load relevant context based on answers
- Phase 4: Execute

**Expected savings**: 30-50% on large context tasks

---

## BEHAVIORAL CHANGES (Free, highest cumulative impact)

These save more than config changes over a full day of usage.

### 13. Extended Thinking Awareness (Informational)
**Target**: Understand thinking token costs (no action needed for most users)

**What it is**: When extended thinking is enabled, Claude generates "thinking" tokens (output-priced, more expensive than input). Claude's built-in **adaptive thinking** automatically adjusts thinking depth based on task complexity, using more for hard problems and less for simple ones.

**Why this is informational, not prescriptive**: If you chose Opus, you chose it for deep reasoning. The optimizer respects that choice. "Deep reasoning" is subjective and task-dependent, so we don't recommend disabling or manually toggling thinking. Claude's adaptive system handles this better than manual rules.

**Actions**:
- [ ] Use `/cost` to see thinking token breakdown (awareness only)
- [ ] If `CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING` is set, understand it forces fixed thinking budget regardless of task complexity

**What the optimizer does**: Reports thinking token usage for cost awareness. Does NOT recommend disabling or reducing thinking. Your model choice is your intent.

---

### 14. /compact and /clear Hygiene
**Target**: Keep context lean, extend productive session length

**Rules**:
- [ ] Compact earlier than the default when sessions run long: on 1M models auto-compact fires at about 967K tokens, and on 200K models near the context limit. Set a lower window with `/autocompact <n>` (100K-1M, saved per model; `/autocompact auto` restores the tuned window) or the `autoCompactWindow` setting. `measure.py compact-advice` estimates from your own history whether an earlier window pays off
- [ ] Run `/compact` at natural breakpoints (after commit, after feature)
- [ ] Run `/clear` between unrelated topics (cheaper than compact, no summary overhead)
- [ ] Check `/context` periodically to know your fill level
- [ ] If `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` is set, confirm it is intentional: it is the percent of the compact window used when compaction fires, so a low value compacts early (doctor reports it and never removes it)

**Measured**: Community measurements show /compact can reduce conversation history from 77K to 4K tokens (18x reduction), freeing context from ~50% to 90%.

**Note**: /clear is often better than /compact when switching tasks. Compacting preserves conversation context as a summary. Clearing is cheaper and gives you a completely fresh window.

---

### 15. Batch Requests
**Target**: Reduce context re-sends

**DON'T**:
```
"Change button color" -> response -> "Make it bigger" -> response -> "Add shadow"
(3 messages = 3 full context sends)
```

**DO**:
```
"Change button color to navy, make it bigger (48px), add subtle shadow"
(1 message = 1 context send)
```

**Expected savings**: 2x-3x on multi-step tasks

---

### 16. Skip Confirmations
**Target**: Reduce message count

**DON'T**:
```
User: "Thanks!"
Claude: "You're welcome!"
(Claude just re-sent full context for a courtesy)
```

**Community stat**: One analysis showed 40% of tokens were confirmations and "looks good" messages.

---

### 17. Test Locally, Not Through Claude
**Target**: Avoid expensive test output in chat

**DON'T**: Let Claude run tests and dump 5,000 tokens of output.

**DO**: Run `pytest tests/` locally and paste any failures.

**Expected savings**: 5,000-50,000 tokens per test run

---

## ADVANCED (Power Users)

### 18. Prompt Caching Awareness
**Target**: Understand what caching does and doesn't fix

**Confirmed behavior**: Prompt caching is active by default in Claude Code. The status line input carries a `prompt_cache` object (TTL, hit ratio, expiry) so you can watch it.

**Pricing**:
- Cache reads: 0.1x base input, 90% cheaper than normal input
- Cache writes: 1.25x base input for the 5-minute cache, 2x for the 1-hour cache
- TTL: the main conversation gets 1 hour on subscription plans and 5 minutes on usage credits, an API key or a cloud provider; subagents get 5 minutes even on a subscription. The timer resets with each cache hit. `promptCacheTtl`, `subagentPromptCacheTtl` and per-agent `experimental.cacheTtl` (frontmatter, v2.1.248+) change this; see the cache controls table in `token-coach/references/quick-reference.md`

**What gets cached**: System prompt (including CLAUDE.md), tool definitions, conversation history prefix up to last cache breakpoint.

**What breaks the cache** (avoid these mid-session):
- Adding/removing an MCP tool
- Switching models
- Editing CLAUDE.md mid-session
- Putting timestamps in system prompt
- Any change to content before a cache breakpoint

**What caching does NOT fix**:
- Context window SIZE (cached tokens still occupy your window)
- Rate limit quotas (cache reads count toward subscription limits)
- Quality degradation as the window fills (lost-in-the-middle)
- Multi-agent amplification (each subagent inherits full overhead)

**Optimization**: Structure CLAUDE.md so stable sections come FIRST, volatile sections LAST. This maximizes cache prefix length.

See `examples/claude-md-optimized.md` for the pattern.

---

### 19. Multi-Project CLAUDE.md Strategy
**Target**: Different configs for different projects

**Pattern**:
- Global `~/.claude/CLAUDE.md`: Identity, personality, core rules (~2,000-3,000 tokens, under 200 lines)
- Project `[repo]/CLAUDE.md`: Project-specific context, tech stack, conventions (~1,000-1,500 tokens, under 100 lines)

**Why**: Global CLAUDE.md loads for ALL projects. Project CLAUDE.md loads only in that directory. Keep global minimal.

---

### 20. Hook-Based Optimizations
**Target**: Pre/post-session token management

See `examples/hooks-starter.json` for a ready-to-use template.

**Key hooks**:
- **PreCompact**: Guide compaction to preserve critical context
- **PostToolUse**: Trigger auto-formatters, save output tokens

---

### 21. Smart Compaction
**Target**: Preserve decisions, context, and state across compaction events

**What it does**: Captures structured session state before compaction fires, then restores the critical pieces after compaction completes. Decisions, error-fix sequences, agent state, and modified files survive the lossy compaction process.

**Actions**:
- [ ] Install Smart Compaction hooks: `python3 $MEASURE_PY setup-smart-compact --dry-run` (preview first)
- [ ] Run `python3 $MEASURE_PY setup-smart-compact` to install
- [ ] Generate project-specific Compact Instructions: `python3 $MEASURE_PY compact-instructions`
- [ ] Add the generated instructions to `.claude/settings.json` under `compactInstructions`

**What the hooks do**:
- **PreCompact**: Captures session state (decisions, files, errors, agent state) to a markdown checkpoint
- **SessionStart** (after compact): Injects the checkpoint back as context, filling gaps left by compaction
- **Stop/SessionEnd**: Saves a checkpoint when the session ends, enabling continuity in the next session

**Checkpoints stored in**: the `token-optimizer/checkpoints/` folder under the runtime's data directory, auto-cleaned (default: 5 newest per session, 7 days, 400 overall; tune with `TOKEN_OPTIMIZER_CHECKPOINT_PER_SESSION`, `TOKEN_OPTIMIZER_CHECKPOINT_RETENTION_DAYS`, `TOKEN_OPTIMIZER_CHECKPOINT_RETENTION_MAX`)

**Expected impact**: Preserves 3-10 key decisions per compaction. Prevents "what were we doing?" restart loops after compaction. Enables session continuity across /clear and session death.

---

### 22. Context Quality Monitoring
**Target**: Measure content quality, not just quantity

**What it does**: Analyzes your session JSONL and scores how useful your context content is. A session at 60% with clean, relevant content performs differently from 60% stuffed with stale reads and duplicate injections.

**Actions**:
- [ ] Run `python3 $MEASURE_PY quality` on your current or recent session
- [ ] Check your score: 85+ is excellent, 70-84 good, 50-69 degraded, <50 critical
- [ ] Act on specific issues: stale reads, bloated results, duplicate reminders

**Quality signals**:
- Stale read ratio (files read then later edited, making the read content outdated)
- Tool result bloat (large results never referenced again)
- Duplicate content (repeated system reminders)
- Compaction depth (each compaction = information loss)
- Decision density (ratio of substantive to overhead exchanges)
- Agent efficiency (dispatch cost vs useful result size)

**Expected impact**: Quantifies when to /compact (score dropping) and validates that smart compaction is working (score improves post-compact).

---

## MONITORING & MEASUREMENT

### 23. Baseline Your Usage

```bash
# Measure current state
python3 $MEASURE_PY report

# Save snapshot before optimizing
python3 $MEASURE_PY snapshot before

# After optimization
python3 $MEASURE_PY snapshot after

# Compare
python3 $MEASURE_PY compare
```

Also track with `/cost` at end of each session and `measure.py trends` for historical data. The SessionEnd hook auto-collects usage into a local SQLite database.

---

### 24. Regular Audits
**Quarterly** (every 3 months):
- [ ] Re-run `/token-optimizer` (skills accumulate, CLAUDE.md grows back)
- [ ] Re-check MCP servers (you add new ones)

**Why**: Optimization entropy. Without discipline, configs grow back to original size.

---

## TOKEN FLOW REFERENCE

**Every message loads this stack** (with Tool Search active, the default):
```
├─ Core system prompt:          ~3,000 tokens  (fixed)
├─ Built-in tools (18+):      ~12,000 tokens  (fixed)
├─ MCP (Tool Search + names):  ~500 + ~15 tokens per deferred tool
├─ MCP server instructions:    ~50-100 tokens per server
├─ Skills frontmatter:          ~100 tokens x skill count
├─ Commands frontmatter:        ~50 tokens x command count
├─ CLAUDE.md (global):          Variable (Anthropic guidance: under 200 lines; internal heuristic ~4,500 tokens / ~300 lines)
├─ Project CLAUDE.md:           Variable (target: <300 tokens)
├─ MEMORY.md:                   Variable (200-line auto-load cap, ~3,000 tokens)
├─ System reminders:            ~2,000 tokens (auto-injected, variable)
└─ Message + history:           Variable
```

**Irreducible floor**: ~15K tokens even with zero config (no CLAUDE.md, no skills, no MCP). This is core system + built-in tools alone.
**Baseline (well-optimized)**: ~21K tokens first message
**Power user (unoptimized)**: ~43K tokens first message

---

## WORKED EXAMPLE: Power User Optimization

**Before** (unaudited power user, 3+ months of use, Tool Search active; the percentages show both common window sizes because the same tokens matter far more on a 200K window):
- Core system + built-in tools: ~15,000 tokens (fixed)
- MCP tools: ~9,000 tokens (deferred tools + server instructions)
- Skills (~60): ~6,000 tokens
- Commands (~60): ~3,000 tokens
- CLAUDE.md: ~3,500 tokens (grown organically, never trimmed)
- MEMORY.md: ~3,500 tokens (duplicates CLAUDE.md content)
- System reminders: ~3,000 tokens (no permissions.deny rules)
- **Total consumed: ~43,000 tokens/msg (4% of a 1M window, 22% of a 200K window)**

**Config changes** (what the optimizer implements):
1. CLAUDE.md: 3,500 -> 2,500 tokens (progressive disclosure, under 300-line target)
2. MEMORY.md: 3,500 -> 2,000 tokens (dedup with CLAUDE.md, under 200-line cap)
3. Skills: 60 -> 30 (30 archived, ~3,000 tokens saved)
4. Commands: 60 -> 25 (35 archived, ~1,800 tokens saved)
5. MCP: pruned unused servers (~3,000 tokens saved)
6. permissions.deny rules added (~2,000 tokens saved from file exclusion)
- **Config savings: ~12,300 tokens/msg (29% reduction in consumed overhead)**
- **After consumed: ~30,700 tokens/msg (3% of a 1M window, 15% of a 200K window)**

**Behavioral changes** (what the optimizer teaches):
- Agent model selection (lighter tier for data gathering): a large share of automation cost
- /compact at natural breakpoints: replaces a long history with a short summary
- Extended thinking awareness: variable, potentially largest single factor
- Batching requests: 2-3x on multi-step tasks
- /clear between topics: prevents stale context accumulation
- **Behavioral savings: extend productive session length, reduce compaction cycles, improve output quality**

The config changes shrink your per-message overhead. The behavioral changes compound across every message, every session, every day. Together they are the full picture.

---

## ENVIRONMENT VARIABLES & SETTINGS (Tune your setup)

These are settings that affect token usage and context behavior. The optimizer audits current values and explains tradeoffs.

### 25. MAX_THINKING_TOKENS (default: unset)
**Target**: Understand thinking token budget

**What it is**: A fixed token budget for extended thinking, capped one token below the request's max output tokens and never below 1,024. When unset, models with adaptive reasoning (Sonnet 5 and later, Haiku 5.5, Opus 4.7 and later, Fable) choose their own thinking depth; other models use the cap. Thinking uses output-priced tokens.

**Actions**:
- [ ] Check current value: `CLAUDE_CODE_MAX_THINKING_TOKENS` in settings.json env block
- [ ] Observe thinking patterns in `/cost` output (thinking tokens are listed separately)
- [ ] Consider if thinking budget is being spent on simple tasks (file renames and quick edits do not need a large thinking budget)

**What the optimizer does**: Reports current value. Surfaces patterns where thinking budget was clearly wasted (e.g., thousands of thinking tokens on a file rename). Does NOT suggest reducing it for complex reasoning tasks.

---

### 26. CLAUDE_CODE_MAX_OUTPUT_TOKENS (default varies by model)
**Target**: Understand output token budget

**What it is**: Maximum tokens Claude generates per response. Defaults and caps vary by model, and Claude Code lowers a value above the model's cap to the cap. Raising it reduces the effective context window available before auto-compaction triggers.

**Actions**:
- [ ] Check current value in settings.json env block
- [ ] Note if you've seen truncation issues
- [ ] Default is fine for most users

**What the optimizer does**: Reports current value. Notes if user has hit truncation issues.

---

### 27. MAX_MCP_OUTPUT_TOKENS (default: 25,000)
**Target**: Understand MCP tool output limits

**What it is**: Maximum tokens a single MCP tool call can return. Tools returning max-length output may be sending more data than needed.

**Actions**:
- [ ] Check if any MCP tools consistently return very large outputs
- [ ] Consider if those tools have filtering options to reduce output size

**What the optimizer does**: Reports current value. Flags MCP tools that consistently return near-max output (potential tuning opportunity).

---

### 28. BASH_MAX_OUTPUT_LENGTH (default: 30,000 characters, max 150,000)
**Target**: Control bash output token consumption

**What it is**: Limits how much stdout/stderr from Bash tool calls gets captured into context. Verbose test runners or build logs can dump thousands of tokens.

**Actions**:
- [ ] Check if bash output is frequently truncated (might need raising)
- [ ] Check if verbose commands are filling context unnecessarily (might need lowering)

**What the optimizer does**: Reports current value. Flags if bash output appears frequently truncated.

---

### 29. ENABLE_TOOL_SEARCH (default: unset, MCP tools deferred)
**Target**: Verify Tool Search is active (the largest MCP saving)

**What it is**: Tool Search defers MCP tool definitions until actually needed. Instead of loading 300-850 tokens per tool upfront, only ~15 tokens per tool name is loaded. This is the single biggest MCP optimization.

**Actions**:
- [ ] Verify Tool Search is active in your session (look for ToolSearch in available tools)
- [ ] If not active, check the Claude Code version, the provider, and whether `ANTHROPIC_BASE_URL` points to a non-first-party host
- [ ] `true` always defers, `false` loads everything upfront, `auto` loads upfront only when tool definitions fit within 10% of context, and `auto:N` sets a custom percentage such as `auto:5`

**What the optimizer does**: Reports if Tool Search is active. If not, explains what enabling it saves. This is flagged as high priority if missing.

---

### 30. CLAUDE_CODE_DISABLE_AUTO_MEMORY (default: not set)
**Target**: Audit auto-memory content quality, not the feature itself

**What it is**: Auto-memory writes learnings to MEMORY.md automatically. This is a valuable feature. The optimization target is the CONTENT it produces, not the feature.

**Actions**:
- [ ] Check MEMORY.md for duplicate entries (auto-memory sometimes writes the same insight twice)
- [ ] Check for entries that duplicate CLAUDE.md content
- [ ] Check for stale entries (rules that no longer apply)
- [ ] Condense verbose entries to current rule only

**What the optimizer does**: Audits MEMORY.md for duplicates, stale entries, and redundancy with CLAUDE.md. Cleans up the CONTENT. Does NOT suggest disabling the feature.

---

### 31. CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING (default: not set)
**Target**: Understand what adaptive thinking does

**What it is**: Set to `1`, it turns off adaptive reasoning on Opus 4.6 and Sonnet 4.6 and falls back to the fixed budget in `MAX_THINKING_TOKENS`. It has no effect on Sonnet 5 and later, Haiku 5.5, Opus 4.7 and later, or Fable, which always use adaptive reasoning.

**Actions**:
- [ ] Check if set in settings.json env block
- [ ] Understand that disabling this means fixed thinking budget regardless of task

**What the optimizer does**: Reports if set. Explains what it does. No recommendation to disable.

---

### 32. CLAUDE_AUTOCOMPACT_PCT_OVERRIDE
**Documented, and never removed by Token Optimizer.** It is the percent of the compact window already used when auto-compaction fires: a lower value compacts earlier, and it cannot raise the threshold. Doctor explains the current value and flags one low enough to compact very early; the user decides.

---

## ANTI-PATTERNS

- Don't add content to CLAUDE.md without asking "Can this be a skill or reference file?"
- Don't duplicate rules between CLAUDE.md and MEMORY.md
- Don't archive skills to subfolder inside skills/ (still loads)
- Don't use the largest model for plain file reading (see the Model Routing section)
- Don't wait for auto-compact when a session is clearly past a natural breakpoint (compact manually, or set an earlier window with `/autocompact`)
- Don't paste full error logs (paste relevant lines only)
- Don't run tests through Claude (run locally, paste failures only)
- Don't dump everything in global CLAUDE.md (project-specific goes in project CLAUDE.md)
- Be aware that extended thinking uses output-priced tokens (Claude's adaptive thinking manages depth automatically)
- Don't assume MCP overhead is huge (Tool Search defers definitions by default)
- Don't quote dollar savings to subscription users (talk context budget, not money)
