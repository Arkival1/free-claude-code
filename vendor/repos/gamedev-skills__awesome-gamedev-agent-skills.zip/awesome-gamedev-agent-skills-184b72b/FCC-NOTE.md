# What FCC kept

FCC ships the 15 GDScript skills in `skills/godot/` (Godot 4.7, FCC's Godot
version) with this repo's LICENSE (Apache-2.0) and NOTICE, unchanged.
Left out: `godot-csharp` (FCC games use GDScript), every `scripts/` folder
(godot-nodes-scenes mentions `scripts/check_godot_project.py`: in FCC use the
`godot` tool's `check` action instead, which runs Godot itself), and the
repo's other engines, site tooling and tests.
