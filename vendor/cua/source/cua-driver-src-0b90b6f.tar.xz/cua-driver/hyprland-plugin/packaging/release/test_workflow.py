"""Focused contract for stable plugin source assets in Driver releases."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[5]


class WorkflowTest(unittest.TestCase):
    def setUp(self):
        self.workflow = (ROOT / ".github/workflows/cd-rust-cua-driver.yml").read_text()
        self.job = self.workflow.split("  build-hyprland-plugin-source:\n", 1)[1].split(
            "  verify-release-artifacts:\n", 1
        )[0]
        self.release = self.workflow.split("  release:\n", 1)[1]

    def test_stable_immutable_candidates_only_and_publication_dependency(self):
        self.assertIn("needs: release-attribution-preflight", self.job)
        self.assertIn(
            "    if: >-\n"
            "      github.event_name == 'push' &&\n"
            "      startsWith(github.ref, 'refs/tags/cua-driver-rs-v')\n",
            self.job,
        )
        # The stable tag push is the only publishing run and always runs the
        # source job. Manual build-only and nightly invocations skip both.
        needs, steps = self.release.split("    steps:\n", 1)
        self.assertIn("      - build-hyprland-plugin-source\n", needs)
        self.assertIn(
            "if: github.event_name == 'push' && "
            "startsWith(github.ref, 'refs/tags/cua-driver-rs-v')",
            needs,
        )
        self.assertNotIn("inputs.publish", self.workflow)
        self.assertNotIn("always()", needs)
        self.assertIn('if [[ "$SHA" != "$TAG_SHA" ]]; then', steps)
        self.assertIn("python3 .github/scripts/validate_release_versions.py --product driver", steps)

    def test_source_override_is_checked_and_assets_remain_namespaced(self):
        self.assertIn("fetch-depth: 0", self.job)
        self.assertIn("ref: ${{ inputs.source_ref || github.ref }}", self.job)
        self.assertIn('--repo . --revision "$(git rev-parse HEAD)"', self.job)
        self.assertIn('--driver-version "$VERSION" --release-assets', self.job)
        self.assertIn("path: plugin-release-assets/*.tar.gz", self.job)
        self.assertIn("if-no-files-found: error", self.job)
        self.assertIn("if: steps.source.outputs.available == 'true'", self.job)
        self.assertLess(self.job.index('test "$SHA" = "$TAG_SHA"'), self.job.index("if ! git cat-file"))
        self.assertLess(self.job.index('test "$VERSION" = "$SOURCE_VERSION"'), self.job.index("if ! git cat-file"))
        self.assertNotIn("apply-version", self.job)
        self.assertIn("cua-hyprland-plugin-*.tar.gz", self.release)
        self.assertNotIn("--clobber", self.release)

    def test_downloaded_plugin_assets_are_verified_before_checksums_and_publication(self):
        verify = self.release.index("- name: Verify staged plugin source assets")
        checksums = self.release.index("- name: Generate SHA256 checksums")
        self.assertLess(self.release.index("- name: Download candidate release artifacts"), verify)
        self.assertLess(verify, checksums)
        step = self.release[verify:checksums]
        self.assertIn('test "${#PLUGIN_ASSETS[@]}" -eq 2', step)
        self.assertIn('--release-assets --output plugin-release-expected', step)
        self.assertIn('cmp "$EXPECTED" "release-upload/$(basename "$EXPECTED")"', step)


if __name__ == "__main__":
    unittest.main()
