"""Portable failure-oracle tests only; never native lock certification."""
from concurrent.futures import Future
from contextlib import ExitStack
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import proofs_path  # noqa: F401  Puts ../proofs on sys.path.
import production_active_lock_proof as proof
import production_lock_refusal_proof as settled
from proof_fixtures import ACTIVE, CANCEL, PARTIAL, ink, inkscape_profile, lock_plan, motion_gate, retained_status, status, trace


def plan():
    return {**lock_plan(), 'purpose': 'active_lock',
            'recovery': {'pointer_stages': ['click_a1', 'click_b2']}}


def action():
    response = deepcopy(PARTIAL)
    response['structuredContent']['reason'] = 'desktop_changed'
    return {'outcome': 'response', 'replayed': False, 'response': response,
            'dispatch_ns': 500_000, 'observed_ns': 11_000_000}


def record():
    return {'result': 'acknowledged', 'before': status(1),
        'ready': {'event': 'ready', 'observed_ns': 1},
        'prefix': trace(ACTIVE), 'lane': 1, 'status_started_ns': 5_000_000,
        'requested_ns': 6_000_000, 'ack': {'event': 'locked', 'observed_ns': 7_000_000},
        'observed_ns': 12_000_000, 'deadline_ns': 20_000_000,
        'gate_status': status(1, held=True), 'after': status(2)}


def ready_fixture():
    """An armed lock helper that reported ready and has not been asked to lock."""
    fixture = object.__new__(proof.ActiveLockFixture)
    fixture.child = Mock(stdin=io.BytesIO(), poll=Mock(return_value=None))
    fixture.record = {'before': status(1), 'ready': {'event': 'ready', 'observed_ns': 1}}
    fixture.config = {}
    fixture.requested = False
    fixture.check_targets = Mock()
    fixture.check_binary = Mock()
    fixture.check_running_binary = Mock()
    fixture.locked = Mock()
    fixture.event = Mock(return_value={'event': 'locked', 'observed_ns': 7_000_000})
    return fixture


class OracleTests(unittest.TestCase):
    def test_inkscape_only_profile_reaches_the_shared_app_profile_gate(self):
        candidate = {**inkscape_profile(plan()), 'recovery': {'pointer_stages': ['scroll_down', 'scroll_up']}}
        proof.validate_plan(candidate)
        candidate['agents'][0]['document'] = '/synthetic/private.svg'
        with self.assertRaisesRegex(AssertionError, 'absolute synthetic SVG document'):
            proof.validate_plan(candidate)

    def test_scroll_recovery_uses_existing_pixel_and_semantic_oracle(self):
        before, pixels = ink()
        before.update(proof_image='synthetic.png', proof_observation_started_ns=1)
        spec = {'app': 'inkscape', 'name': 'recovery', 'target': {'pid': 20, 'window_id': 200},
                'pointer_stage': 'move_rectangle'}
        with patch.object(proof, 'grounded_snapshot', return_value=before), \
             patch.object(proof.pointer_grounding, 'read_pixels', return_value=pixels):
            prepared = proof.prepare_recovery(Mock(), spec, ['scroll_down', 'scroll_up'])
        self.assertIn(prepared['stage'], ('scroll_down', 'scroll_up'))
        self.assertEqual(prepared['prepared_ns'], 1)
        with self.assertRaises(AssertionError):
            proof.pointer_grounding.verify(before, pixels, prepared['oracle'])
        shift = -10 if prepared['stage'] == 'scroll_down' else 10
        after, moved = ink(scroll_y=shift)
        self.assertTrue(proof.pointer_grounding.verify(after, moved, prepared['oracle'])['verified'])

    def test_recovery_grounding_uses_original_snapshot_time_not_wrapper_clock(self):
        client = Mock()
        spec = plan()['agents'][0]
        snapshot = {'proof_observation_started_ns': 10, 'proof_image': 'synthetic.png'}
        with patch.object(proof, 'grounded_snapshot', return_value=snapshot) as observe, \
             patch.object(proof, 'recovery_stage', return_value='click_b2'), \
             patch.object(proof.time, 'monotonic_ns', return_value=50), \
             patch.object(proof.pointer_grounding, 'read_pixels', return_value='pixels'), \
             patch.object(proof.pointer_grounding, 'action', return_value=({'x': 1}, {'cell': 'B2'})):
            result = proof.prepare_recovery(client, spec, ['click_a1', 'click_b2'])
        observe.assert_called_once_with(client, spec['target'], spec)
        self.assertEqual(result, {'snapshot': snapshot, 'arguments': {'x': 1},
            'oracle': {'cell': 'B2'}, 'stage': 'click_b2', 'prepared_ns': 10})
        client.tool.assert_not_called()

    def test_recovery_grounding_rejects_missing_invalid_or_future_snapshot_time(self):
        for timestamp in (None, True, 0, -1, 51, 10.0):
            snapshot = {'proof_image': 'synthetic.png'}
            if timestamp is not None:
                snapshot['proof_observation_started_ns'] = timestamp
            with self.subTest(timestamp=timestamp), \
                 patch.object(proof, 'grounded_snapshot', return_value=snapshot), \
                 patch.object(proof.time, 'monotonic_ns', return_value=50), \
                 patch.object(proof.pointer_grounding, 'action') as action, \
                 self.assertRaises((AssertionError, KeyError)):
                proof.prepare_recovery(Mock(), plan()['agents'][0], ['click_a1', 'click_b2'])
            action.assert_not_called()

    def test_recovery_stage_is_chosen_from_new_selection_before_input(self):
        snapshot = {'snapshot_id': 'fresh-after-unlock'}
        for selected_b2, expected in ((True, 'click_a1'), (False, 'click_b2')):
            with patch.object(proof.pointer_grounding, 'rows', return_value=['fresh']) as rows, \
                 patch.object(proof.pointer_grounding, 'calc_formula_selection', return_value=selected_b2) as selection:
                self.assertEqual(proof.recovery_stage(snapshot), expected)
            rows.assert_called_once_with(snapshot)
            selection.assert_called_once_with(snapshot, ['fresh'], 'B2')

    def test_plan_requires_reviewed_disposable_calc_lock_and_fresh_recovery(self):
        proof.validate_plan(plan())
        for change in ({'purpose': 'lock_refusal'}, {'fault': {'kind': 'dpms'}},
                       {'disposable': False}, {'fault': {'kind': 'lock', 'kill': True}},
                       {'recovery': {'pointer_stage': 'select_range'}}):
            with self.subTest(change=change), self.assertRaises(AssertionError):
                proof.validate_plan({**plan(), **change})
        for field in ('path', 'sha256', 'source_sha256', 'uid', 'inode'):
            candidate = plan()
            candidate['lock_fixture'][field] = 'unreviewed'
            with self.subTest(field=field), self.assertRaises(AssertionError):
                proof.validate_plan(candidate)

    def test_held_gate_cancel_and_own_release_are_verified_without_isolation_claim(self):
        result = proof.verify_cancelled(trace(CANCEL), record(), action())
        self.assertEqual(result['result'], 'verified')
        self.assertEqual(result['reason'], 'desktop_changed')
        self.assertEqual(result['continuous_primary_isolation'], 'unproven')

    def test_primary_transition_violations_are_retained_never_filtered_to_pass(self):
        for kind in ('cursor', 'pointer_focus', 'keyboard_focus', 'pointer_button', 'keyboard_key'):
            page = trace(CANCEL + [(13, kind, 0, 0)])
            if kind == 'cursor':
                page['events'][-1][3] += 10
            original = deepcopy(page)
            result = proof.transition_evidence(page)
            self.assertEqual(result['raw_primary_analysis']['result'], 'failed')
            self.assertEqual(result['continuous_primary_isolation'], 'unproven')
            self.assertEqual(result['primary_transition_events'], [page['events'][-1]])
            self.assertEqual(page, original)
            # This oracle proves synthetic cancellation only, not the cause
            # or acceptability of any primary-seat transition event.
            self.assertEqual(proof.verify_cancelled(page, record(), action())['result'], 'verified')

    def test_primary_activity_before_lock_is_not_a_transition_exception(self):
        candidate = record()
        candidate['prefix'] = trace(ACTIVE + [(5, 'pointer_focus', 0, 0)])
        page = trace(ACTIVE + [(5, 'pointer_focus', 0, 0)] + CANCEL[len(ACTIVE):])
        with self.assertRaisesRegex(AssertionError, 'pre-LOCK isolation'):
            proof.verify_cancelled(page, candidate, action())

    def test_unrelated_input_before_lock_is_not_an_ordinary_drag(self):
        candidate = record()
        candidate['prefix'] = trace(ACTIVE + [(5, 'pointer_axis', 1, 0)])
        page = trace(ACTIVE + [(5, 'pointer_axis', 1, 0)] + CANCEL[len(ACTIVE):])
        with self.assertRaisesRegex(AssertionError, 'unexpected input before LOCK'):
            proof.verify_cancelled(page, candidate, action())

    def test_missing_release_extra_input_cross_lane_and_false_completion_fail(self):
        tails = [
            [(8, 'agent_cancel', 1, 0)],
            [(8, 'agent_cancel', 1, 0), (9, 'pointer_button', 2, 0)],
            [(8, 'pointer_button', 1, 0), (9, 'agent_cancel', 1, 0)],
            [(8, 'agent_cancel', 1, 0), (9, 'pointer_button', 1, 1)],
            [(8, 'agent_cancel', 2, 0), (9, 'pointer_button', 1, 0)],
            [(5, 'agent_cancel', 1, 0), (9, 'pointer_button', 1, 0)],
        ]
        tails += [CANCEL[len(ACTIVE):] + [(11, kind, 1, 0)] for kind in
                  ('agent_cancel', 'agent_admitted', 'agent_drag_start', 'agent_drag_end',
                   'agent_action_end', 'keyboard_key', 'pointer_axis', 'pointer_motion',
                   'pointer_enter', 'pointer_button')]
        for tail in tails:
            with self.subTest(tail=tail), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(ACTIVE + tail), record(), action())

    def test_incomplete_trace_rewritten_history_or_missing_held_prefix_fail(self):
        # Page validity is owned by trace_interval (realapp TraceIntervalTests); one case proves wiring.
        with self.assertRaisesRegex(AssertionError, 'dropped events'):
            proof.verify_cancelled({**trace(CANCEL), 'overflow': True}, record(), action())
        for mutation in ('history', 'press', 'admitted', 'start'):
            candidate, page = record(), trace(CANCEL)
            if mutation == 'history':
                page['events'][0][1] += 1
            else:
                index = {'press': 3, 'admitted': 1, 'start': 2}[mutation]
                candidate['prefix']['events'][index][2] = 'pointer_motion'
                page['events'][index][2] = 'pointer_motion'
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError):
                proof.verify_cancelled(page, candidate, action())

    def test_stale_or_unacknowledged_lock_and_bad_clocks_fail(self):
        for change in ({'result': 'unproven'}, {'requested_ns': 3_000_000},
                       {'requested_ns': 300_000_000}, {'status_started_ns': -300_000_000},
                       {'ready': {'event': 'ready', 'observed_ns': -3_000_000_000}},
                       {'ack': {'event': 'finished', 'observed_ns': 7_000_000}},
                       {'ack': {'event': 'locked', 'observed_ns': 5_000_000}},
                       {'deadline_ns': 10_000_000}):
            with self.subTest(change=change), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(CANCEL), {**record(), **change}, action())

    def test_unknown_refused_replayed_or_wrong_reason_cannot_certify_cancellation(self):
        for change in ({'outcome': 'unknown'}, {'replayed': True}, {'observed_ns': 30_000_000},
                       {'dispatch_ns': 5_000_000}):
            with self.subTest(change=change), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(CANCEL), record(), {**action(), **change})
        for field, value in (('reason', 'session_unavailable'), ('reason', 'primary_target_busy'),
                             ('effect', 'refused'), ('route', 'foreground')):
            candidate = action()
            candidate['response']['structuredContent'][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(CANCEL), record(), candidate)
        for delivery in ({'mode': 'unknown', 'delivered_count': 1},
                         {'mode': 'background', 'delivered_count': 0}):
            candidate = action()
            candidate['response']['structuredContent']['delivery'] = delivery
            with self.subTest(delivery=delivery), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(CANCEL), record(), candidate)

    def test_status_requires_held_owned_lane_then_cleared_authority_and_no_dispatch(self):
        for section, key, value, index in (
            ('gate_status', 'held_button', 0, 0), ('gate_status', 'held_keys', 1, 0),
            ('gate_status', 'drag_active', False, 0), ('gate_status', 'reserved', False, 0),
            ('gate_status', 'held_button', 272, 1), ('gate_status', 'reserved', True, 1),
            ('after', 'held_button', 272, 0), ('after', 'held_keys', 1, 0),
            ('after', 'drag_active', True, 0), ('after', 'lease_active', True, 0),
            ('after', 'pointer_focus', True, 0), ('after', 'keyboard_focus', True, 0),
            ('after', 'reserved', True, 0), ('after', 'desktop_generation', 1, 0),
            ('after', 'dispatches', 1, 0), ('after', 'epoch', 'replaced', 0)):
            candidate = record()
            candidate[section]['input']['lanes'][index][key] = value
            with self.subTest(section=section, key=key, index=index), self.assertRaises(AssertionError):
                proof.verify_cancelled(trace(CANCEL), candidate, action())

    def test_unlock_trace_keeps_primary_failures_but_rejects_any_new_synthetic_event(self):
        boundary = trace(CANCEL)
        stopped = proof.stopped_prefix(trace(CANCEL + [(14, 'keyboard_focus', 0, 0)]))
        result = proof.verify_transition_end(boundary, stopped)
        self.assertEqual(result['raw_primary_analysis']['result'], 'failed')
        self.assertFalse(result['analysis_uses_end_sentinel'])
        for kind in ('pointer_motion', 'pointer_button', 'agent_admitted', 'agent_cancel', 'pointer_leave'):
            with self.subTest(kind=kind), self.assertRaises(AssertionError):
                proof.verify_transition_end(boundary, proof.stopped_prefix(trace(CANCEL + [(14, kind, 1, 0)])))
        for field, value in (('overflow', True), ('active', True), ('count', 1)):
            malformed = {**stopped, field: value}
            with self.subTest(field=field), self.assertRaises(AssertionError):
                proof.verify_transition_end(boundary, malformed)
        rewritten = deepcopy(stopped)
        rewritten['events'][0][1] += 1
        with self.assertRaises(AssertionError):
            proof.verify_transition_end(boundary, rewritten)


class FixtureTests(unittest.TestCase):
    def test_active_fixture_reuses_the_settled_lock_restore_and_binary_checks(self):
        self.assertIs(proof.ActiveLockFixture.restore, settled.LockFixture.restore)
        self.assertIs(proof.ActiveLockFixture.check_running_binary, settled.LockFixture.check_running_binary)

    def test_injection_sends_one_lock_only_after_exact_identity_and_fresh_held_gate(self):
        fixture = ready_fixture()
        pending = Mock(done=Mock(return_value=False))
        with patch.object(proof, 'power'), \
             patch.object(proof, 'production_status', side_effect=[status(1, held=True), status(2)]), \
             patch.object(proof, 'poll_active', return_value=(trace(ACTIVE), {1: 2_000_000})), \
             patch.object(proof.time, 'monotonic_ns', side_effect=[5_000_000, 6_000_000, 12_000_000]):
            self.assertEqual(fixture.inject(Mock(), trace([ACTIVE[0]]), pending), 1)
        self.assertEqual(fixture.child.stdin.getvalue(), b'LOCK\n')
        fixture.check_targets.assert_called_once()
        fixture.check_binary.assert_called_once()
        fixture.check_running_binary.assert_called_once()
        fixture.event.assert_called_once_with('locked')
        fixture.child.kill.assert_not_called()
        fixture.child.terminate.assert_not_called()

    def test_finished_stale_changed_identity_or_nonheld_drag_never_sends_lock(self):
        for failure in ('finished', 'stale_trace', 'stale_status', 'ready_expired',
                        'not_held', 'target', 'binary', 'running_binary', 'generation'):
            fixture = ready_fixture()
            pending = Mock(done=Mock(return_value=failure == 'finished'))
            gate = status(1, held=failure != 'not_held')
            if failure == 'generation':
                gate['input']['lanes'][0]['desktop_generation'] = 2
            if failure in ('target', 'binary', 'running_binary'):
                getattr(fixture, {'target': 'check_targets', 'binary': 'check_binary',
                                  'running_binary': 'check_running_binary'}[failure]).side_effect = AssertionError('identity changed')
            if failure == 'ready_expired':
                fixture.record['ready']['observed_ns'] = -3_000_000_000
            page = trace(ACTIVE)
            now = [5_000_000, 6_000_000, 12_000_000]
            if failure == 'stale_trace':
                now = [299_000_000, 300_000_000]
            if failure == 'stale_status':
                now = [-300_000_000, 6_000_000]
            with self.subTest(failure=failure), patch.object(proof, 'power'), \
                 patch.object(proof, 'production_status', return_value=gate), \
                 patch.object(proof, 'poll_active', return_value=(page, {1: 2_000_000})), \
                 patch.object(proof.time, 'monotonic_ns', side_effect=now), self.assertRaises(AssertionError):
                fixture.inject(Mock(), trace([ACTIVE[0]]), pending)
            self.assertEqual(fixture.child.stdin.getvalue(), b'')
            self.assertFalse(fixture.requested)

    def test_lost_lock_ack_keeps_requested_state_for_graceful_cleanup(self):
        fixture = ready_fixture()
        fixture.event.side_effect = TimeoutError('lost acknowledgement')
        with patch.object(proof, 'power'), \
             patch.object(proof, 'production_status', return_value=status(1, held=True)), \
             patch.object(proof, 'poll_active', return_value=(trace(ACTIVE), {1: 2_000_000})), \
             patch.object(proof.time, 'monotonic_ns', side_effect=[5_000_000, 6_000_000]), \
             self.assertRaises(TimeoutError):
            fixture.inject(Mock(), trace([ACTIVE[0]]), Mock(done=Mock(return_value=False)))
        self.assertTrue(fixture.requested)
        self.assertEqual(fixture.child.stdin.getvalue(), b'LOCK\n')
        self.assertNotEqual(fixture.record.get('result'), 'acknowledged')

    def test_arm_does_not_lock_and_binds_running_helper_after_ready(self):
        fixture = ready_fixture()
        fixture.child = None
        child = Mock(pid=99)
        identity = {'pid': 99, 'uid': 1000, 'exe': '/test/session_lock_fixture', 'starttime': '1'}
        fixture.config = {'compositor': {'pid': 50, 'uid': 1000}}
        fixture.event.return_value = {'event': 'ready', 'observed_ns': 1}
        with tempfile.TemporaryDirectory() as directory:
            fixture.args = SimpleNamespace(evidence=Path(directory), lock_fixture=Path(identity['exe']))
            before = status()
            before['input']['lanes'][0]['pointer_focus'] = True
            with patch.object(proof, 'production_status', return_value=before), \
                 patch.object(proof.subprocess, 'Popen', return_value=child) as launch, \
                 patch.object(proof, '_identity', return_value=identity):
                fixture.arm()
            self.assertEqual(json.loads((fixture.args.evidence / 'pre-fault-status.json').read_text()), before)
        self.assertEqual(launch.call_args.args[0], ['/test/session_lock_fixture', '20000', '50'])
        child.stdin.write.assert_not_called()
        fixture.event.assert_called_once_with('ready')
        fixture.check_running_binary.assert_called_once()

    def test_drag_attempt_saved_before_transport_and_unknown_never_replayed(self):
        for outcome in ('partial', 'unknown', 'stale'):
            candidate = plan()['agents'][0]
            prepared = {'target': candidate['target'], 'session': candidate['name'],
                        'prepared_ns': 0, 'arguments': {'from_x': 1}}
            client = Mock()
            client.tool.return_value = action()['response']
            if outcome == 'unknown':
                client.tool.side_effect = TimeoutError('lost drag response')
            saved = []
            attempt = {'outcome': 'unknown', 'replayed': False}
            with patch.object(proof.time, 'monotonic_ns', return_value=proof.MAX_GROUNDING_AGE_NS + 1 if outcome == 'stale' else 1):
                result = proof.drag_once(client, candidate, prepared, attempt,
                    lambda name, value: saved.append((name, deepcopy(value))))
            self.assertEqual(saved[0][1]['outcome'], 'unknown')
            self.assertEqual(result['outcome'], 'response' if outcome == 'partial' else 'unknown')
            self.assertFalse(result['replayed'])
            self.assertEqual(client.tool.call_count, 0 if outcome == 'stale' else 1)
            self.assertEqual(saved[-1][1], result)


class RunTests(unittest.TestCase):
    def test_invalid_plan_retained_without_native_setup(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'plan.json'
            path.write_text(json.dumps({**plan(), 'disposable': False}))
            args = SimpleNamespace(plan=path, evidence=root / 'evidence')
            with patch.object(proof, 'ActiveLockFixture') as fixture, patch('builtins.print'):
                self.assertEqual(proof.run(args), 1)
            fixture.assert_not_called()
            report = json.loads((args.evidence / 'result.json').read_text())
            self.assertEqual(report['result'], 'failed')
            self.assertEqual(report['continuous_isolation_across_transitions'], 'unproven')

    def episode(self, failure=None, *, retained=False):
        """Synthetic run ordering only; all native/Driver boundaries are mocked."""
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            root = Path(directory)
            path = root / 'plan.json'
            selected_plan = plan()
            if retained:
                selected_plan['fault'].update(pointer_cleanup='retained_inert', min_motion_px=12)
            path.write_text(json.dumps(selected_plan))
            args = SimpleNamespace(plan=path, evidence=root / 'evidence', driver=root / 'driver',
                trace_socket=root / 'trace', foreground_journal=root / 'journal', primary_grab=root / 'grab')
            events = []
            clients = []
            def launch(*_args):
                client = Mock(process=Mock(pid=30 + len(clients) * 10, poll=Mock(return_value=None)), closed=False)
                client.tool.return_value = {'structuredContent': {'screen_width': 1280, 'screen_height': 800,
                    'effect': 'unverifiable', 'route': 'synthetic_events'}}
                clients.append(client)
                events.append('launch_' + str(client.process.pid))
                return client
            def close(client):
                events.append('close_' + str(client.process.pid))
                client.closed = True
                client.process.poll.return_value = 0
            fixture = Mock(config={}, record=record())
            fixture.inject.side_effect = lambda *_args: events.append('LOCK')
            def restore(*, cleanup=False):
                events.append('cleanup_unlock' if cleanup else 'explicit_unlock')
                if failure == 'restore' and not cleanup:
                    raise AssertionError('deadline unlock cannot pass')
                return {'result': 'restored', 'after': status(3)}
            fixture.restore.side_effect = restore
            initial, boundary = trace([ACTIVE[0]]), trace(CANCEL)
            if retained:
                fixture.config = {'pointer_cleanup': 'retained_inert', 'min_motion_px': 12}
                boundary = motion_gate(fixture.record)
                def retained_restore(*, cleanup=False):
                    result = restore(cleanup=cleanup)
                    result['after'] = retained_status(3)
                    return result
                fixture.restore.side_effect = retained_restore
            if failure == 'release':
                boundary = trace(ACTIVE + [(8, 'agent_cancel', 1, 0)])
            transition = proof.stopped_prefix(trace(CANCEL + [(14, 'keyboard_focus', 0, 0)]))
            if retained:
                transition_page = deepcopy(boundary)
                transition_page['events'].append([9, 14_000_000, 'keyboard_focus', 100, 100, 0, 0])
                if failure == 'unlock_leave':
                    transition_page['events'].append([10, 15_000_000, 'pointer_leave', 100, 100, 1, 0])
                transition_page['count'] = len(transition_page['events'])
                transition = proof.stopped_prefix(transition_page)
            recovery = trace([(0, 'start', 0, 0), (1, 'agent_admitted', 1, 0),
                (2, 'pointer_button', 1, 1), (3, 'pointer_button', 1, 0), (4, 'agent_action_end', 1, 0)])
            trace_client = Mock()
            trace_client.collect.side_effect = [initial, boundary, boundary, transition, initial,
                                                recovery, proof.stopped_prefix(recovery)]
            def exchange(command):
                events.append(command)
                if failure == 'start_ack' and command == 'TRACE_START':
                    trace_client.collect.side_effect = None
                    trace_client.collect.return_value = transition
                    raise TimeoutError('lost trace start acknowledgement')
            trace_client.exchange.side_effect = exchange
            def drag(_client, _spec, _prepared, attempt, save):
                events.append('drag')
                attempt.update(action())
                if failure == 'unknown':
                    attempt.update(outcome='unknown', error='lost response')
                save('drag-action.json', attempt)
                return attempt
            pool = Mock()
            def submit(fn, *args):
                future = Future()
                future.set_result(fn(*args))
                return future
            pool.submit.side_effect = submit
            primary = {'pid': 10, 'address': '0x64', 'cursor': {'x': 30, 'y': 40}}
            baseline = {'held': True, 'clicks': 0, 'keys': 0, 'scroll': 0}
            final = status(3)
            final['input']['lanes'][0]['dispatches'] = 1
            def status_read(*_args):
                if len(clients) == 3:
                    return final
                if retained:
                    value = retained_status(3 if 'explicit_unlock' in events else 2)
                    if failure == 'lost_presence':
                        value['input']['lanes'][0]['pointer_focus'] = False
                    return value
                return status(3 if 'explicit_unlock' in events else 2)
            snapshot = {'window_bounds': {'x': 10, 'y': 20, 'width': 800, 'height': 600},
                        'proof_image': 'fresh.png', 'proof_observation_started_ns': 10}
            mocks = {
                'ActiveLockFixture': Mock(return_value=fixture), 'provenance': Mock(return_value={'files': {}}),
                'DirectMCP': launch, 'connect_trace': Mock(return_value=trace_client),
                'close_owned': close, 'ThreadPoolExecutor': Mock(return_value=pool), 'drag_once': drag,
                'prepare_drag': Mock(return_value={'prepared_ns': 0}), 'settle_locked': Mock(),
                'grounded_snapshot': Mock(return_value=snapshot), 'wm': Mock(return_value=primary),
                'state': Mock(side_effect=lambda *_args: baseline if 'explicit_unlock' in events else {'held': False}),
                'production_status': status_read, 'power': Mock(), 'primary_acknowledgement': Mock(return_value='HELD\n'),
                'wait_for': Mock(), 'require_primary_active': Mock(), 'stop_process': Mock(),
            }
            for name, value in mocks.items():
                stack.enter_context(patch.object(proof, name, value))
            stack.enter_context(patch.object(proof.time, 'monotonic_ns',
                side_effect=lambda: 50 if len(clients) == 3 else 0))
            stack.enter_context(patch.object(proof.subprocess, 'Popen', return_value=Mock()))
            stack.enter_context(patch.object(proof.pointer_grounding, 'read_pixels'))
            stack.enter_context(patch.object(proof.pointer_grounding, 'rows', return_value=[]))
            stack.enter_context(patch.object(proof.pointer_grounding, 'calc_formula_selection', return_value=False))
            stack.enter_context(patch.object(proof.pointer_grounding, 'action', return_value=({'x': 1, 'y': 2}, {})))
            stack.enter_context(patch.object(proof.pointer_grounding, 'verify', return_value={'result': 'verified'}))
            stack.enter_context(patch('builtins.print'))
            result = proof.run(args)
            evidence = {file.name: json.loads(file.read_text()) for file in args.evidence.glob('*.json')}
            return result, evidence, events, clients

    def test_complete_synthetic_episode_restores_before_fresh_visible_recovery(self):
        result, evidence, events, clients = self.episode()
        self.assertEqual(result, 0, evidence.get('result.json'))
        report = evidence['result.json']
        self.assertEqual(report['runtime_pids'], [30, 40, 50])
        self.assertEqual(report['cancellation']['result'], 'verified')
        self.assertEqual(report['recovery']['result'], 'verified')
        self.assertEqual(evidence['recovery-grounding.json']['prepared_ns'], 10)
        self.assertEqual(evidence['recovery-action.json']['prepared_ns'], 10)
        self.assertEqual(report['transition']['raw_primary_analysis']['result'], 'failed')
        self.assertEqual(report['continuous_isolation_across_transitions'], 'unproven')
        self.assertLess(events.index('drag'), events.index('LOCK'))
        self.assertLess(events.index('LOCK'), events.index('close_40'))
        self.assertLess(events.index('close_40'), events.index('explicit_unlock'))
        self.assertLess(events.index('explicit_unlock'), events.index('launch_50'))
        self.assertEqual([c.args[0] for c in clients[-1].tool.call_args_list], ['start_session', 'click'])
        for name in ('transition-trace.json', 'transition-analysis.json', 'cancellation-boundary.json',
                     'recovery-grounding.json', 'recovery-after.json', 'recovery-trace.json', 'restoration.json'):
            self.assertIn(name, evidence)

    def test_unknown_attempt_or_failed_unlock_is_preserved_without_recovery_or_replay(self):
        for failure in ('unknown', 'restore', 'release'):
            result, evidence, events, clients = self.episode(failure)
            with self.subTest(failure=failure):
                self.assertEqual(result, 1)
                self.assertEqual(evidence['result.json']['recovery']['result'], 'unproven')
                self.assertEqual(len(clients), 2)
                self.assertEqual(events.count('drag'), 1)
                self.assertIn('cleanup_unlock', events)
                self.assertIn('drag-action.json', evidence)
                self.assertIn('failed-transition-trace.json', evidence)
                if failure == 'unknown':
                    self.assertEqual(evidence['drag-action.json']['outcome'], 'unknown')

    def test_lost_trace_start_ack_is_stopped_and_retained_without_dispatch(self):
        result, evidence, events, _clients = self.episode('start_ack')
        self.assertEqual(result, 1)
        self.assertNotIn('drag', events)
        self.assertNotIn('LOCK', events)
        self.assertIn('TRACE_STOP', events)
        self.assertIn('failed-transition-trace.json', evidence)


    def test_full_retained_episode_checks_unlock_and_pre_recovery_presence(self):
        result, evidence, events, clients = self.episode(retained=True)
        self.assertEqual(result, 0, evidence['result.json'])
        self.assertEqual(evidence['result.json']['continuous_isolation_across_transitions'], 'unproven')
        self.assertLess(events.index('explicit_unlock'), events.index('launch_50'))
        for failure in ('unlock_leave', 'lost_presence'):
            result, evidence, events, clients = self.episode(failure, retained=True)
            with self.subTest(failure=failure):
                self.assertEqual(result, 1)
                self.assertNotIn('launch_50', events)
                self.assertEqual(evidence['result.json']['recovery']['result'], 'unproven')


class RetainedPointerTests(unittest.TestCase):
    def test_active_lock_accepts_opt_in_motion_and_cleanup_only(self):
        value = plan()
        value['fault'].update(pointer_cleanup='retained_inert', min_motion_px=12.5)
        proof.validate_plan(value)
        # Policy and threshold validity are owned by desktop_fault; one case each proves wiring.
        for change, error in (({'pointer_cleanup': 'unknown'}, 'unknown pointer cleanup policy'),
                              ({'extra': True}, 'unsupported fault option'),
                              ({'min_motion_px': 0}, 'positive finite min_motion_px')):
            bad = deepcopy(value)
            bad['fault'].update(change)
            with self.subTest(change=change), self.assertRaisesRegex(AssertionError, error):
                proof.validate_plan(bad)

    def test_retained_cancellation_both_lanes_is_not_transition_isolation(self):
        for lane in (1, 2):
            value = record()
            boundary = motion_gate(value, lane)
            result = proof.verify_cancelled(boundary, value, action())
            self.assertEqual(result['result'], 'verified')
            self.assertEqual(result['continuous_primary_isolation'], 'unproven')
            with self.assertRaises(AssertionError):
                proof.cancelled_status(value['gate_status'], value['after'])
            for key, replacement in (('pointer_focus', False), ('reserved', True), ('held_keys', 1),
                                      ('held_button', 272), ('drag_active', True), ('lease_active', True),
                                      ('keyboard_focus', True), ('dispatches', 1)):
                bad = deepcopy(value)
                bad['after']['input']['lanes'][lane - 1][key] = replacement
                with self.subTest(lane=lane, key=key), self.assertRaises(AssertionError):
                    proof.verify_cancelled(boundary, bad, action())

    def test_motion_and_retention_cannot_accept_pointer_leave_reentry_or_stale_status(self):
        value = record()
        boundary = motion_gate(value)
        for kind in ('pointer_leave', 'pointer_enter', 'pointer_motion'):
            bad = deepcopy(boundary)
            bad['events'].append([9, 10_000_000, kind, 100, 100, 1, 0])
            bad['count'] += 1
            with self.subTest(kind=kind), self.assertRaises(AssertionError):
                proof.verify_cancelled(bad, value, action())
        for change in ({'min_motion_px': 14}, {'status_started_ns': -300_000_000}, {'lane': 2}):
            with self.subTest(change=change), self.assertRaises(AssertionError):
                proof.verify_cancelled(boundary, {**value, **change}, action())

    def test_motion_poll_preserves_short_ready_window_and_brackets_status(self):
        for failure in (None, 'insufficient', 'lane', 'stale'):
            fixture = ready_fixture()
            fixture.config.update(pointer_cleanup='retained_inert', min_motion_px=12)
            fixture.record.update(pointer_cleanup='retained_inert', min_motion_px=12)
            value = record()
            motion_gate(value)
            first, page = deepcopy(value['prefix']), deepcopy(value['prefix'])
            if failure == 'insufficient':
                first['events'][-1][7] = page['events'][-1][7] = 15
            if failure == 'lane':
                for row in page['events'][1:]:
                    row[5] = 2
            calls = []
            def poll(*args, **kwargs):
                calls.append(('trace', kwargs['timeout']))
                result = first if len(calls) == 1 else page
                return result, proof.active_drags(result)
            def read(*args):
                calls.append(('status', None))
                return value['gate_status'] if len(calls) == 2 else retained_status()
            with self.subTest(failure=failure), patch.object(proof, 'power'), \
                 patch.object(proof, 'poll_fault_active', side_effect=poll), \
                 patch.object(proof, 'production_status', side_effect=read), \
                 patch.object(proof.time, 'monotonic_ns', side_effect=[-300_000_000 if failure == 'stale' else 5_000_000, 6_000_000, 12_000_000]):
                if failure:
                    with self.assertRaises(AssertionError):
                        fixture.inject(Mock(), trace([ACTIVE[0]]), Mock(done=Mock(return_value=False)))
                    self.assertFalse(fixture.requested)
                    self.assertEqual(fixture.child.stdin.getvalue(), b'')
                else:
                    self.assertEqual(fixture.inject(Mock(), trace([ACTIVE[0]]), Mock(done=Mock(return_value=False))), 1)
                    self.assertEqual(fixture.child.stdin.getvalue(), b'LOCK\n')
                    self.assertEqual(calls[:3], [('trace', 1), ('status', None), ('trace', 0.25)])
                    self.assertEqual(fixture.deadline_ns - fixture.record['requested_ns'], 20_000_000_000)


if __name__ == '__main__':
    unittest.main()
