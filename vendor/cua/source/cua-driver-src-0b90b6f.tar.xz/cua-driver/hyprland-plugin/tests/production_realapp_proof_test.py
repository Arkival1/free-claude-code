import copy
from contextlib import ExitStack
import io
import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import zipfile

import proofs_path  # noqa: F401  Puts ../proofs on sys.path.
import production_pointer_grounding as pointer
from production_realapp_proof import (SMOKE_STEPS, app_process_identity, provenance,
                                    assert_no_dispatch, assert_primary_state, check_response,
                                    bound_drag_lanes, capacity_lane, verify_capacity, check_manifest_refusal,
                                    manifest_tool_messages, verify_policy_cache,
                                    passive_focus_evidence,
                                    expected_primary_motion, move_primary, primary_acknowledgement,
                                    parallel_actions, primary_trajectory, require_primary_active,
                                    PRIMARY_LIFETIME_MS, POINTER_EPISODES, run, trace_interval, validate_plan,
                                    verify_output)
from proof_fixtures import (INKSCAPE, INKSCAPE_SELECTED, START, STOP, assert_rejects, capacity_events, capacity_plan,
                            harness_args, ink, inkscape_plan, lane, lane_status, patch_module, plan,
                            policy_cache_plan, primary_trace as trace, run_replacements)
from production_app_smoke import OBSERVATION_TIMEOUT_MS


def focus_evidence(rows):
    """Passive-focus checkpoints around one lane-1 episode, then its stopped trace."""
    focus_page = {'hook': True, 'active': True, 'overflow': False, 'timed_out': False,
                  'count': len(rows), 'events': rows}
    before = {'status': lane_status(lane(0, reserved=True, pointer_focus=True), lane(1)), 'trace': focus_page}
    after = {'status': copy.deepcopy(before['status'])}
    after['status']['input']['lanes'][0]['reserved'] = False
    stopped = {**focus_page, 'active': False, 'count': len(rows) + 1,
               'events': rows + [[len(rows) + 1, len(rows), 'stop', 100, 100, 0, 0]]}
    return before, after, stopped


class PassiveFocusTests(unittest.TestCase):
    def test_only_initial_pre_admission_retirement_is_allowed(self):
        def evidence(kinds):
            rows = [[1, 0, 'start', 100, 100, 0, 0]]
            for index, kind in enumerate(kinds, 2):
                row = [index, index - 1, kind, 100, 100, 1, 0]
                if kind in ('pointer_enter', 'pointer_motion'):
                    row.extend((10, 20))
                rows.append(row)
            return focus_evidence(rows)

        accepted = [
            ['pointer_leave', 'agent_admitted', 'pointer_enter', 'pointer_motion', 'agent_action_end'],
            ['agent_admitted', 'pointer_motion', 'agent_action_end'],  # Reuse unchanged inert hover.
        ]
        rejected = [
            ['agent_admitted', 'pointer_leave', 'pointer_enter', 'pointer_motion'],
            ['pointer_leave', 'pointer_leave', 'agent_admitted', 'pointer_enter'],
            ['pointer_enter', 'pointer_leave', 'agent_admitted', 'pointer_enter'],
            ['pointer_leave', 'pointer_enter', 'agent_admitted', 'pointer_motion'],
            ['pointer_leave', 'pointer_enter', 'pointer_motion'],
            ['pointer_motion', 'pointer_leave', 'agent_admitted', 'pointer_motion'],
            ['agent_admitted', 'pointer_enter', 'pointer_leave', 'pointer_enter'],
            ['agent_admitted', 'agent_action_end'],
        ]
        for kinds in accepted:
            with self.subTest(kinds=kinds):
                self.assertEqual(passive_focus_evidence(*evidence(kinds))['lanes'], [1])
        for kinds in rejected:
            with self.subTest(kinds=kinds), self.assertRaises(AssertionError):
                passive_focus_evidence(*evidence(kinds))

    def test_passive_focus_retains_presence_without_authority_after_close(self):
        before, after, stopped = focus_evidence([[1, 0, 'start', 100, 100, 0, 0],
                                                 [2, 1, 'pointer_enter', 100, 100, 1, 0, 10, 20],
                                                 [3, 2, 'pointer_motion', 100, 100, 1, 0, 10, 20],
                                                 [4, 3, 'agent_action_end', 100, 100, 1, 0]])
        def append_synthetic(t, kind):
            t['events'].insert(-1, [5, 4, kind, 100, 100, 1, 0])
            t['events'][-1][0] = 6
            t['count'] += 1
        mutations = {
            'grant': lambda b, a, t: b['status']['input']['lanes'][0].update(lease_active=True),
            'held': lambda b, a, t: b['status']['input']['lanes'][0].update(held_button=272),
            'keyboard': lambda b, a, t: b['status']['input']['lanes'][0].update(keyboard_focus=True),
            'not_retained': lambda b, a, t: b['status']['input']['lanes'][0].update(pointer_focus=False),
            'reservation': lambda b, a, t: a['status']['input']['lanes'][0].update(reserved=True),
            'hover_lost': lambda b, a, t: a['status']['input']['lanes'][0].update(pointer_focus=False),
            'held_after_close': lambda b, a, t: a['status']['input']['lanes'][0].update(held_keys=1),
            'epoch': lambda b, a, t: a['status']['input']['lanes'][0].update(epoch='replaced'),
            'unexpected_leave': lambda b, a, t: append_synthetic(t, 'pointer_leave'),
            'new_input': lambda b, a, t: append_synthetic(t, 'agent_admitted'),
            'incomplete': lambda b, a, t: t.update(overflow=True),
        }
        for mutation in (None, *mutations):
            b, a, t = copy.deepcopy((before, after, stopped))
            with self.subTest(mutation=mutation):
                if mutation:
                    mutations[mutation](b, a, t)
                    with self.assertRaises(AssertionError):
                        passive_focus_evidence(b, a, t)
                else:
                    self.assertEqual(passive_focus_evidence(b, a, t)['lanes'], [1])


class ProvenanceTests(unittest.TestCase):
    def test_runtime_provenance_refusal_precedes_app_inspection(self):
        with patch('production_realapp_proof.runtime_provenance',
                   side_effect=AssertionError('loaded artifact mismatch')) as runtime, \
                patch('production_realapp_proof.subprocess.check_output') as command:
            args = SimpleNamespace()
            with self.assertRaisesRegex(AssertionError, 'loaded artifact mismatch'):
                provenance(args, {})
            runtime.assert_called_once_with(args)
            command.assert_not_called()

    def test_reviewed_packages_must_match_runtime_provenance(self):
        with patch('production_realapp_proof.runtime_provenance', return_value={'packages': {'a': '1'}}), \
                patch('production_realapp_proof.subprocess.check_output') as command:
            with self.assertRaisesRegex(AssertionError, 'package qualification mismatch'):
                provenance(SimpleNamespace(), {'package_versions': {'a': '2'}})
            command.assert_not_called()

    def test_canonical_app_identity_requires_owner_and_native_backend(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            executable = root / 'soffice.bin'
            executable.write_bytes(b'synthetic executable')
            process = root / '20'
            process.mkdir()
            (process / 'exe').symlink_to(executable)
            (process / 'maps').write_text('/usr/lib/libgtk-3.so\n/usr/lib/libvclplug_gtk3lo.so\n')
            with patch('production_realapp_proof.EXECUTABLES', {'calc': executable}), \
                    patch('production_realapp_proof.package_owner') as owner:
                identity = app_process_identity('calc', 20, root)
                owner.assert_called_once_with(executable, 'libreoffice-fresh')
                self.assertEqual(identity['executable'], str(executable))
                self.assertEqual(len(identity['gtk3_maps']), 2)
                self.assertEqual(len(identity['sha256']), 64)
                owner.side_effect = AssertionError('unowned executable')
                with self.assertRaisesRegex(AssertionError, 'unowned executable'):
                    app_process_identity('calc', 20, root)

            with patch('production_realapp_proof.EXECUTABLES', {'calc': root / 'canonical/soffice.bin'}), \
                    patch('production_realapp_proof.package_owner') as owner:
                with self.assertRaisesRegex(AssertionError, 'noncanonical running executable'):
                    app_process_identity('calc', 20, root)
                owner.assert_not_called()

            with patch('production_realapp_proof.EXECUTABLES', {'calc': executable}), \
                    patch('production_realapp_proof.package_owner'):
                for maps, reason in [('', 'did not load GTK3'),
                                     ('/usr/lib/libgtk-3.so', 'did not load its GTK3 backend')]:
                    (process / 'maps').write_text(maps)
                    with self.assertRaisesRegex(AssertionError, reason):
                        app_process_identity('calc', 20, root)


class PolicyCacheTests(unittest.TestCase):
    def test_plan_requires_one_fixed_target_session_and_exact_allow_deny_allow(self):
        validate_plan(policy_cache_plan())
        for mode in ('standard', 'bounded', 'unrestricted'):
            for message in manifest_tool_messages('press_key'):
                candidate = policy_cache_plan()
                candidate['agents'][0]['profile'].update(mode=mode, acknowledge_unrestricted=True)
                candidate['phases'][1]['expect']['message'] = message
                validate_plan(candidate)
        click_denial = "Permission denied: capability manifest denies tool 'click'"
        assert_rejects(self, validate_plan, policy_cache_plan(), [
            ('one persistent runtime', lambda p: p['agents'].append(copy.deepcopy(p['agents'][0]))),
            ('reviewed Calc or Inkscape target', lambda p: p['agents'][0].update(app='fixture')),
            ('fixed session', lambda p: p['agents'][0].update(name='')),
            ('exact window id', lambda p: p['agents'][0]['target'].update(window_id=None)),
            ('approved reviewed manifest', lambda p: p['agents'][0]['profile'].pop('manifest')),
            ('approved reviewed manifest', lambda p: p['agents'][0]['profile'].update(approve_manifest=False)),
            ('explicit acknowledgement', lambda p: p['agents'][0]['profile'].update(mode='unrestricted')),
            ('allow, deny, fresh allow', lambda p: p['phases'].pop()),
            ('reuse agent 0 serially', lambda p: p['phases'][1].update(agent=1)),
            ('reuse agent 0 serially', lambda p: p['phases'][1].update(parallel=[])),
            # Denying the allowed tool must reach the distinct-tool guard, not the message guard.
            ('distinct denied tool', lambda p: p['phases'][1].update(
                tool='click', expect={**p['phases'][1]['expect'], 'message': click_denial})),
            ('distinct denied tool', lambda p: p['phases'][2].update(tool='scroll')),
            ('permitted calls must dispatch', lambda p: p['phases'][2].update(expect={'kind': 'unknown'})),
            ('must be permission_denied', lambda p: p['phases'][1]['expect'].update(reason='lane_busy')),
            ('must be permission_denied', lambda p: p['phases'][1]['expect'].update(
                reason='bounded_resource_outside_manifest')),
            ('exact manifest tool-ceiling refusal', lambda p: p['phases'][1]['expect'].pop('message')),
            ('exact manifest tool-ceiling refusal', lambda p: p['phases'][1]['expect'].update(message='Permission denied')),
            ('overrides reviewed ownership', lambda p: p['phases'][1]['arguments'].update(pid=99)),
            ('overrides reviewed ownership', lambda p: p['phases'][1]['arguments'].update(session='new')),
            ('parked primary', lambda p: p.update(moving_primary=True)),
            ('parked primary', lambda p: p.update(require_overlap=True)),
        ])

    def test_exact_common_envelope_excludes_plugin_and_other_policy_refusals(self):
        expected = policy_cache_plan()['phases'][1]['expect']
        content = {'status': 'refused', 'refusal': {'code': expected['reason'], 'message': expected['message']}}
        check_manifest_refusal({'isError': True, 'structuredContent': content}, expected, 'press_key')
        for change in ({'effect': 'refused', 'reason': 'permission_denied'},
                       {**content, 'delivery': {'mode': 'background'}},
                       {**content, 'refusal': {**content['refusal'], 'message': "Permission denied: user policy: tool 'press_key' is explicitly denied"}},
                       {**content, 'refusal': {**content['refusal'], 'code': 'bounded_resource_outside_manifest'}},
                       {**content, 'refusal': {**content['refusal'], 'message': "Permission denied: capability manifest denies tool 'click'"}}):
            with self.subTest(content=change), self.assertRaises(AssertionError):
                check_manifest_refusal({'isError': True, 'structuredContent': change}, expected, 'press_key')

    def test_summary_requires_same_runtime_session_lane_and_fresh_success(self):
        expected = policy_cache_plan()['phases'][1]['expect']
        success = {'route': 'synthetic_events', 'effect': 'unverifiable', 'delivery': {'mode': 'background'}}
        actions = [dict(agent=0, tool=step['tool'], expected='dispatched', observed=success,
                        runtime_pid=101, session='fixed', compositor_lane=1)
                   for step in policy_cache_plan()['phases']]
        actions[1].update(expected='refused', expect=expected, no_dispatch='verified',
                          observed={'status': 'refused', 'refusal': {'code': expected['reason'], 'message': expected['message']}})
        self.assertEqual(verify_policy_cache(actions)['result'], 'verified')
        for mutate in (lambda a: a.pop(), lambda a: a[2].update(agent=1),
                       lambda a: a[2].update(compositor_lane=2),
                       lambda a: a[2].update(runtime_pid=102),
                       lambda a: a[2].update(session='replacement'),
                       lambda a: a[2].update(expected='unknown'),
                       lambda a: a[1].update(no_dispatch='unproven')):
            bad = copy.deepcopy(actions)
            mutate(bad)
            with self.subTest(actions=bad), self.assertRaises(AssertionError):
                verify_policy_cache(bad)

    def test_mcp_tool_admission_requires_exact_code_and_retained_text(self):
        expected = policy_cache_plan()['phases'][1]['expect']
        response = {'isError': True, 'structuredContent': {'code': 'permission_denied'},
                    'content': [{'type': 'text', 'text': expected['message']}]}
        result = check_manifest_refusal(response, expected, 'press_key')
        self.assertEqual(result['refusal_boundary'], 'mcp-tool-admission')
        self.assertEqual(result['mcp_content'], response['content'])
        for mutate in (lambda r: r.update(isError=False), lambda r: r.pop('content'),
                       lambda r: r['content'].append({'type': 'text', 'text': 'extra'}),
                       lambda r: r['content'][0].update(text='Permission denied'),
                       lambda r: r['content'][0].update(text=expected['message'].replace('press_key', 'hotkey')),
                       lambda r: r['structuredContent'].update(code='lane_busy'),
                       lambda r: r['structuredContent'].update(delivery={'mode': 'background'}),
                       lambda r: r['structuredContent'].update(effect='unverifiable')):
            bad = copy.deepcopy(response)
            mutate(bad)
            with self.subTest(response=bad), self.assertRaises(AssertionError):
                check_manifest_refusal(bad, expected, 'press_key')

    def test_runner_persistent_runtime_quiet_denial_and_failures_without_replay(self):
        # Each failure must fail for its own reason: in the result, or in cleanup.
        failures = {
            None: None,
            'changed_lane': ('error', 'compositor lane changed'),
            'missing_input': ('error', 'admission, input, and completion evidence'),
            'wrong_refusal': ('error', 'wrong MCP manifest tool-ceiling refusal'),
            'plugin_refusal': ('error', 'common authorization refusal, not a plugin error'),
            'admitted_on_denial': ('error', 'denied call reached a synthetic lane'),
            'input_on_denial': ('error', 'denied call reached a synthetic lane'),
            'denial_before_snapshot': ('error', 'denied call reached a synthetic lane'),
            'denial_after_snapshot': ('error', 'denied call reached a synthetic lane'),
            'next_snapshot_input': ('error', 'denied call reached a synthetic lane'),
            'gap_input': ('error', 'denied call reached a synthetic lane'),
            'dead_runtime': ('error', 'Driver process exited'),
            'changed_runtime': ('error', 'policy_cache runtime changed'),
            'transport': ('error', 'unknown effect'),
            'partial': ('error', "'effect': 'partial'"),
            'unknown': ('error', "'mode': 'unknown'"),
            'missing_hook': ('error', 'dispatch telemetry is not live'),
            'reset_trace': ('error', 'trace history changed'),
            'cleanup_reset': ('finish_trace', 'policy_cache trace history changed at cleanup'),
            'foreground_input': ('finish_trace', "'result': 'failed'"),
            'cleanup_failure': ('close_agent_0', 'cleanup failed'),
            'stale_window': ('error', 'reviewed PID/window identity is stale or ambiguous'),
        }
        for failure, expected_error in failures.items():
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                root = Path(directory)
                candidate = policy_cache_plan()
                args = harness_args(root, candidate, trace_socket=root / 'cua-input-v3.sock')
                calls, events, held = [], [START], [True]
                agent = Mock(process=Mock(pid=101, poll=Mock(return_value=None)))
                observer = Mock()
                targets = [candidate['foreground'], candidate['agents'][0]['target']]
                action_count = 0
                snapshot_count = 0

                def tool(name, arguments):
                    nonlocal action_count, snapshot_count
                    if name == 'list_windows':
                        windows = copy.deepcopy(targets)
                        if failure == 'stale_window' and action_count == 1:
                            windows[1]['window_id'] += 1
                        return {'structuredContent': {'windows': windows}}
                    if name == 'get_window_state':
                        calls.append(('snapshot', arguments))
                        snapshot_count += 1
                        if ((failure == 'denial_before_snapshot' and snapshot_count == 7)
                                or (failure == 'next_snapshot_input' and snapshot_count == 9)
                                or (failure == 'denial_after_snapshot' and action_count == 2)):
                            events.append(('agent_admitted', 100, 200, 1, 0))
                        return {'structuredContent': {'screenshot_width': 600,
                                'window_bounds': candidate['agents'][0]['bounds']}}
                    if name == 'get_desktop_state':
                        return {'structuredContent': {'screen_width': 800, 'screen_height': 800}}
                    if name not in ('click', 'press_key'):
                        return {'structuredContent': {}}
                    action_count += 1
                    calls.append((name, arguments))
                    self.assertEqual(arguments, {**candidate['phases'][action_count - 1]['arguments'],
                        **candidate['agents'][0]['target'], 'session': candidate['agents'][0]['name'],
                        'delivery_mode': 'background'})
                    if failure == 'transport' and action_count == 2:
                        raise TimeoutError('unknown effect')
                    if name == 'press_key':
                        if failure == 'dead_runtime':
                            agent.process.poll.return_value = 1
                        if failure == 'changed_runtime':
                            agent.process.pid = 102
                        if failure in ('admitted_on_denial', 'input_on_denial'):
                            kind = 'agent_admitted' if failure == 'admitted_on_denial' else 'keyboard_key'
                            events.append((kind, 100, 200, 1, 0))
                        if failure == 'plugin_refusal':
                            return {'isError': True, 'structuredContent': {'effect': 'refused', 'reason': 'permission_denied'}}
                        expected = candidate['phases'][1]['expect']
                        return {'isError': True, 'structuredContent': {'code': expected['reason']},
                            'content': [{'type': 'text',
                                         'text': 'wrong reason' if failure == 'wrong_refusal' else expected['message']}]}
                    lane = 2 if failure == 'changed_lane' and action_count == 3 else 1
                    rows = capacity_events(lane)
                    events.extend([rows[0], rows[-1]] if failure == 'missing_input' else rows)
                    if failure == 'foreground_input':
                        events.append(('keyboard_key', 100, 200, 0, 0))
                    return {'structuredContent': {'route': 'synthetic_events',
                        'effect': 'partial' if failure == 'partial' else 'unverifiable',
                        'delivery': {'mode': 'unknown' if failure == 'unknown' else 'background'}}}

                agent.tool.side_effect = observer.tool.side_effect = tool
                trace_client = Mock(hello={'protocol': 3})
                def exchange(command):
                    if command == 'TRACE_STOP':
                        if failure == 'cleanup_reset':
                            events[:] = [START]
                        events.append(STOP)
                trace_client.exchange.side_effect = exchange
                def collect():
                    if failure == 'reset_trace' and trace_client.collect.call_count == 4:
                        events[:] = [START]
                    if failure == 'gap_input' and trace_client.collect.call_count == 7:
                        events.append(('agent_admitted', 100, 200, 1, 0))
                    return {**trace(*events), 'active': events[-1] != STOP, 'hook': failure != 'missing_hook'}
                trace_client.collect.side_effect = collect
                if failure == 'cleanup_failure':
                    agent.close.side_effect = RuntimeError('cleanup failed')
                replacements = run_replacements(self, held, DirectMCP=Mock(side_effect=[agent, observer]),
                                                Trace=Mock(return_value=trace_client))
                patch_module(stack, 'production_realapp_proof', replacements)
                self.assertEqual(run(args), 0 if failure is None else 1)
                mutations = [name for name, _ in calls if name in ('click', 'press_key')]
                self.assertEqual(mutations, ['click', 'press_key', 'click'][:len(mutations)])
                for index, (name, arguments) in enumerate(calls):
                    if name in ('click', 'press_key'):
                        self.assertEqual(calls[index - 1][0], 'snapshot')
                        if failure != 'stale_window':
                            self.assertEqual(calls[index + 1][0], 'snapshot')
                agent.close.assert_called_once()
                observer.close.assert_called_once()
                trace_client.close.assert_called_once()
                self.assertFalse(held[0])
                self.assertEqual(replacements['DirectMCP'].call_count, 2)
                self.assertEqual(replacements['DirectMCP'].call_args.args[2],
                                 {'mode': 'unrestricted', 'acknowledge_unrestricted': True})
                result = json.loads((args.evidence / 'result.json').read_text())
                cleanup = {row['operation']: row['error']
                           for row in json.loads((args.evidence / 'cleanup.json').read_text())['errors']}
                if failure is None:
                    self.assertEqual(mutations, ['click', 'press_key', 'click'])
                    self.assertEqual(result['policy_cache']['compositor_lane'], 1)
                    self.assertEqual(result['continuous_isolation'], 'passed')
                    self.assertEqual(result['synthetic_cleanup'], 'verified')
                    self.assertEqual(cleanup, {})
                    for index in range(3):
                        self.assertTrue((args.evidence / f'policy-cache-phase-{index}-trace.json').is_file())
                else:
                    where, pattern = expected_error
                    self.assertRegex(result['error'] if where == 'error' else cleanup[where], pattern)
                if failure in ('transport', 'dead_runtime', 'changed_runtime', 'gap_input', 'next_snapshot_input'):
                    self.assertEqual(mutations, ['click', 'press_key'])


class DragLaneBindingTests(unittest.TestCase):
    def test_overlap_requires_serial_unique_selections_before_drags(self):
        candidate = inkscape_plan()
        candidate['require_overlap'] = True
        selections = [{'agent': i, 'tool': 'hotkey', 'arguments': {'keys': ['ctrl', 'a']},
                       'smoke_stage': 'select'} for i in range(2)]
        drags = {'parallel': [{'agent': i, 'tool': 'drag', 'arguments': {},
                              'pointer_stage': 'move_rectangle'} for i in range(2)]}
        candidate['phases'] = [*selections, drags]
        validate_plan(candidate)
        for phases in ([drags, *selections], [selections[0], drags],
                       [*selections, selections[0], drags], [{'parallel': selections}, drags]):
            with self.subTest(phases=phases), self.assertRaises(AssertionError):
                validate_plan({**candidate, 'phases': phases})

    @staticmethod
    def selects(*lanes):
        return [{'agent': i, 'tool': 'hotkey', 'smoke_stage': 'select', 'compositor_lane': lane}
                for i, lane in enumerate(lanes)]

    def test_binding_comes_from_each_agents_own_select_evidence_not_order(self):
        self.assertEqual(bound_drag_lanes(self.selects(1, 2)), {0: 1, 1: 2})
        self.assertEqual(bound_drag_lanes(self.selects(2, 1)), {0: 2, 1: 1})
        # Unbound plans record no lane evidence; overlap enforcement rejects that at cleanup.
        rows = [{'agent': 0, 'tool': 'hotkey', 'smoke_stage': 'select'},
                {'agent': 1, 'tool': 'drag', 'pointer_stage': 'move_rectangle'}]
        self.assertEqual(bound_drag_lanes(rows), {})

    def test_shared_duplicate_or_invalid_lane_evidence_is_rejected(self):
        for rows in (self.selects(1, 1), self.selects(1, 2) + self.selects(1), self.selects(0),
                     self.selects(3), self.selects(True), self.selects('1'), self.selects(None)):
            with self.subTest(rows=rows), self.assertRaises(AssertionError):
                bound_drag_lanes(rows)

    def test_identical_coordinate_drags_are_ambiguous_without_but_exact_with_binding(self):
        args, oracle = pointer.action(*ink(), 'inkscape', 'move_rectangle')
        effect = pointer.verify(*ink(dx=35, dy=27), oracle)
        rows = []
        for lane_number in (1, 2):
            rows += [('pointer_motion', 100, 200, lane_number, 0), ('agent_drag_start', 100, 200, lane_number, 0),
                     ('pointer_button', 100, 200, lane_number, 1)] + \
                    [('pointer_motion', 100, 200, lane_number, 0)] * 3 + \
                    [('pointer_button', 100, 200, lane_number, 0), ('agent_drag_end', 100, 200, lane_number, 0)]
        data = trace(START, *rows, STOP)
        for base in (1, 9):  # Same local coordinates in both windows.
            for offset, xy in ((0, [145, 165]), (3, [149, 168]), (4, [165, 180]), (5, [185, 195])):
                data['events'][base + offset].extend(xy)
        with self.assertRaisesRegex(AssertionError, 'missing or ambiguous'):
            pointer.verify_drag_trace(data, args, effect)
        # Swapped independently proven bindings select swapped lanes, never agent order.
        for agents in (self.selects(1, 2), self.selects(2, 1)):
            lanes = bound_drag_lanes(agents)
            for agent, lane_number in lanes.items():
                self.assertEqual(pointer.verify_drag_trace(data, args, effect, expected_lane=lanes[agent])['lane'],
                                 lane_number)

    def test_absent_or_ambiguous_select_trace_cannot_bind_a_lane(self):
        before = {**trace(START), 'active': True}
        two_lanes = {**trace(START, *capacity_events(1), *capacity_events(2)), 'active': True}
        for after in (before, two_lanes):
            with self.subTest(after=after['events']), self.assertRaisesRegex(AssertionError, 'exactly one compositor lane'):
                capacity_lane(before, after, 'click')


class CapacityTests(unittest.TestCase):
    def test_plan_requires_three_serial_independent_qualified_targets(self):
        for app_profile, factory in (('calc-inkscape', capacity_plan),
                                     ('inkscape-only', lambda: inkscape_plan(capacity=True))):
            validate_plan(factory())
            for mutate in (lambda p: p.update(phases=[]),
                           lambda p: p.update(phases=p['phases'][:2]),
                           lambda p: p.update(agents=p['agents'][:2]),
                           lambda p: p['phases'][1].update(agent=0),
                           lambda p: p['phases'][2].update(agent=0),
                           lambda p: p['phases'][0].update(parallel=[]),
                           lambda p: p['phases'][0].update(expect={'kind': 'unknown'}),
                           lambda p: p['phases'][2].pop('expect'),
                           lambda p: p['phases'][2].update(expect={'kind': 'refused', 'reason': 'permission_denied'}),
                           lambda p: p['agents'][2].update(target=p['agents'][1]['target']),
                           lambda p: p['agents'][2]['target'].update(window_id=None),
                           lambda p: p['agents'][2].update(app='fixture'),
                           lambda p: p.update(moving_primary=True),
                           lambda p: p.update(require_overlap=True)):
                bad = factory()
                mutate(bad)
                with self.subTest(app_profile=app_profile, plan=bad), self.assertRaises(AssertionError):
                    validate_plan(bad)
            # Capacity does not redefine the normal reviewed permission contract.
            for mode in ('standard', 'bounded', 'unrestricted'):
                candidate = factory()
                candidate['agents'][0]['profile']['mode'] = mode
                validate_plan(candidate)
            for purpose in ('apps', 'policy', 'negative_control'):
                with self.assertRaises(AssertionError):
                    validate_plan({**factory(), 'purpose': purpose})

    def test_lane_needs_actual_ordered_input_and_completion(self):
        before = {**trace(START), 'active': True}
        events = capacity_events(1)
        after = {**trace(START, *events), 'active': True}
        self.assertEqual(capacity_lane(before, after, 'click'), 1)
        for rows in ([], events[:1], events[1:], events[:-1],
                     [events[0], events[-1]], list(reversed(events)),
                     [events[0], *capacity_events(2)],
                     [(kind, x, y, 0, state) for kind, x, y, lane, state in events]):
            with self.subTest(rows=rows), self.assertRaises(AssertionError):
                capacity_lane(before, {**trace(START, *rows), 'active': True}, 'click')
        # Page validity belongs to trace_interval; one case proves it is applied.
        with self.assertRaisesRegex(AssertionError, 'dropped events'):
            capacity_lane(before, {**after, 'overflow': True}, 'click')
        # A pointer click cannot count as keyboard input.
        with self.assertRaisesRegex(AssertionError, 'admission, input, and completion'):
            capacity_lane(before, after, 'press_key')

    def test_summary_rejects_incomplete_wrong_lane_and_wrong_refusal(self):
        observed = {'route': 'synthetic_events', 'effect': 'unverifiable', 'delivery': {'mode': 'background'}}
        actions = [{'agent': i, 'expected': 'dispatched', 'observed': observed, 'compositor_lane': i + 1}
                   for i in range(2)] + [{'agent': 2, 'expected': 'refused', 'no_dispatch': 'verified',
                                         'observed': {'effect': 'refused', 'reason': 'lane_busy'}}]
        self.assertEqual(verify_capacity(actions)['result'], 'verified')
        for mutate in (lambda a: a.clear(), lambda a: a.pop(),
                       lambda a: a[1].update(compositor_lane=1),
                       lambda a: a[1].pop('compositor_lane'),
                       lambda a: a[0].update(observed={}),
                       lambda a: a[2].update(no_dispatch='unproven'),
                       lambda a: a[2]['observed'].update(reason='permission_denied'),
                       lambda a: a[2]['observed'].update(delivery={'mode': 'background'})):
            bad = copy.deepcopy(actions)
            mutate(bad)
            with self.subTest(actions=bad), self.assertRaises(AssertionError):
                verify_capacity(bad)

    def test_runner_serial_capacity_and_failures_without_replay(self):
        failures = {None: None, 'same_lane': 'capacity needs distinct compositor lanes',
                    'missing_input': 'capacity needs admission, input, and completion evidence',
                    'wrong_refusal': "'reason': 'permission_denied'",
                    'dispatch_on_refusal': 'denied call reached a synthetic lane',
                    'dead_runtime': 'Driver process exited',
                    'stale_window': 'reviewed PID/window identity is stale or ambiguous',
                    'transport': 'unknown effect', 'missing_hook': 'dispatch telemetry is not live',
                    'reset_trace': 'trace history changed'}
        owner_failures = {'owner_lost': 'capacity owner lost its lane reservation',
                          'owner_changed': 'capacity lane ownership changed',
                          'document_changed': 'snapshot document mismatch'}
        cases = [(app_profile, failure, error) for app_profile in ('calc-inkscape', 'inkscape-only')
                 for failure, error in failures.items()]
        cases += [('inkscape-only', failure, error) for failure, error in owner_failures.items()]
        for app_profile, failure, expected_error in cases:
            with self.subTest(app_profile=app_profile, failure=failure), tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                root = Path(directory)
                candidate = capacity_plan()
                if app_profile == 'inkscape-only':
                    candidate['app_profile'] = app_profile
                    for i, spec in enumerate(candidate['agents']):
                        spec.update(app='inkscape', document=str(root.resolve() / f'lane-{i}.svg'))
                args = harness_args(root, candidate, trace_socket=root / 'cua-input-v3.sock')
                calls, events, held = [], [START], [True]
                agents = [Mock(process=Mock(pid=101 + i, poll=Mock(return_value=None))) for i in range(3)]
                observer = Mock()
                targets = [candidate['foreground']] + [spec['target'] for spec in candidate['agents']]

                def tool(index, name, arguments):
                    if name == 'list_windows':
                        windows = copy.deepcopy(targets)
                        if failure == 'stale_window':
                            windows[-1]['window_id'] += 1
                        return {'structuredContent': {'windows': windows}}
                    if name == 'get_window_state':
                        calls.append(('snapshot', index))
                        return {'structuredContent': {'screenshot_width': 600,
                                'window_title': 'unrelated.svg' if failure == 'document_changed' else f'lane-{index}.svg',
                                'window_bounds': candidate['agents'][0]['bounds']}}
                    if name == 'get_desktop_state':
                        return {'structuredContent': {'screen_width': 800, 'screen_height': 800}}
                    if name != 'click':
                        return {'structuredContent': {}}
                    calls.append(('click', index))
                    self.assertEqual(arguments['delivery_mode'], 'background')
                    self.assertEqual({key: arguments[key] for key in ('pid', 'window_id')},
                                     candidate['agents'][index]['target'])
                    if failure == 'transport':
                        raise TimeoutError('unknown effect')
                    if index < 2:
                        lane = 1 if failure == 'same_lane' else index + 1
                        rows = capacity_events(lane)
                        events.extend([rows[0], rows[-1]] if failure == 'missing_input' else rows)
                        if failure == 'dead_runtime':
                            agents[0].process.poll.return_value = 1
                        return {'structuredContent': {'route': 'synthetic_events', 'effect': 'unverifiable',
                                                      'delivery': {'mode': 'background'}}}
                    if failure == 'dispatch_on_refusal':
                        events.extend(capacity_events(1))
                    return {'isError': True, 'structuredContent': {'effect': 'refused',
                            'reason': 'permission_denied' if failure == 'wrong_refusal' else 'lane_busy'}}

                for i, mcp in enumerate(agents + [observer]):
                    mcp.tool.side_effect = lambda name, arguments, i=i: tool(i, name, arguments)
                trace_client = Mock(hello={'protocol': 3})
                trace_client.exchange.side_effect = lambda command: events.append(STOP) if command == 'TRACE_STOP' else None
                def collect():
                    if failure == 'reset_trace' and trace_client.collect.call_count == 3:
                        events[:] = [START]
                    return {**trace(*events), 'active': events[-1] != STOP, 'hook': failure != 'missing_hook'}
                trace_client.collect.side_effect = collect
                def input_status():
                    third_called = ('click', 2) in calls
                    return lane_status(*(lane(index, reserved=not (third_called and failure == 'owner_lost'),
                                              epoch=100 if third_called and failure == 'owner_changed' else 51 + index)
                                         for index in (0, 1)))
                replacements = run_replacements(self, held, read_input_status=input_status,
                                                DirectMCP=Mock(side_effect=agents + [observer]),
                                                Trace=Mock(return_value=trace_client))
                patch_module(stack, 'production_realapp_proof', replacements)
                self.assertEqual(run(args), 0 if failure is None else 1)
                action_indexes = [index for name, index in calls if name == 'click']
                self.assertEqual(action_indexes, list(range(len(action_indexes))))
                if failure == 'missing_hook':
                    self.assertEqual(action_indexes, [])
                if failure == 'reset_trace':
                    self.assertEqual(action_indexes, [0])
                for i, call in enumerate(calls):
                    if call[0] == 'click':
                        self.assertEqual(calls[i - 1], ('snapshot', call[1]))
                        self.assertEqual(calls[i + 1][0], 'snapshot')
                for mcp in agents:
                    mcp.close.assert_called_once()
                if failure != 'stale_window':
                    observer.close.assert_called_once()
                    self.assertFalse(held[0])
                result = json.loads((args.evidence / 'result.json').read_text())
                if failure is None:
                    self.assertEqual(action_indexes, [0, 1, 2])
                    self.assertEqual(result['capacity']['lanes'], [1, 2])
                    self.assertEqual(result['continuous_isolation'], 'passed')
                    self.assertEqual(result['synthetic_cleanup'], 'verified')
                    for i in range(3):
                        self.assertTrue((args.evidence / f'capacity-agent-{i}-trace.json').is_file())
                    if app_profile == 'inkscape-only':
                        self.assertEqual(set(result['actions'][2]['persistent_owners']), {'1', '2'})
                        self.assertTrue((args.evidence / 'capacity-agent-2-owners-before.json').is_file())
                        self.assertTrue((args.evidence / 'capacity-agent-2-owners-after.json').is_file())
                else:
                    self.assertRegex(result['error'], expected_error)


class PlanTests(unittest.TestCase):
    def test_smoke_stages_allow_only_the_exact_app_keyboard_steps(self):
        for index, app in enumerate(('calc', 'inkscape')):
            for stage, (tool, arguments) in SMOKE_STEPS[app].items():
                with self.subTest(app=app, stage=stage):
                    candidate = plan()
                    candidate['phases'] = [{'agent': index, 'smoke_stage': stage,
                                            'tool': tool, 'arguments': arguments}]
                    validate_plan(candidate)
                    for change in ({'smoke_stage': 'after'}, {'smoke_stage': None},
                                   {'smoke_stage': []}, {'tool': 'click'},
                                   {'arguments': {**arguments, 'x': 1}},
                                   {'arguments': {'key': 'Escape'}}):
                        bad = copy.deepcopy(candidate)
                        bad['phases'][0].update(change)
                        with self.assertRaises(AssertionError):
                            validate_plan(bad)
                    candidate['agents'][index]['app'] = 'unknown'
                    with self.assertRaises(AssertionError):
                        validate_plan(candidate)

    def test_moving_primary_is_optional_boolean_and_excludes_negative_control(self):
        validate_plan({**plan(), 'moving_primary': True})
        for value in ('true', 1, None):
            with self.assertRaises(AssertionError):
                validate_plan({**plan(), 'moving_primary': value})
        negative = {**plan(), 'purpose': 'negative_control',
                    'phases': [{'negative_control': True}]}
        validate_plan(negative)
        with self.assertRaisesRegex(AssertionError, 'parked'):
            validate_plan({**negative, 'moving_primary': True})

    def test_real_apps_need_independent_processes_and_both_output_oracles(self):
        validate_plan(plan())
        for mutate in (lambda p: p['agents'][1].update(target=p['agents'][0]['target']),
                       lambda p: p['agents'][1].update(app='gtk-fixture'),
                       lambda p: p.update(outputs=p['outputs'][:1]),
                       lambda p: p.update(phases=[])):
            bad = plan()
            mutate(bad)
            with self.assertRaises(AssertionError):
                validate_plan(bad)

    def test_public_arguments_cannot_override_reviewed_target_or_session(self):
        for key in ('pid', 'window_id', 'session', 'delivery_mode'):
            bad = plan()
            bad['phases'][0]['parallel'][0]['arguments'][key] = 'other'
            with self.assertRaises(AssertionError):
                validate_plan(bad)

    def test_one_connection_cannot_execute_parallel_calls(self):
        bad = plan()
        bad['phases'][0]['parallel'][1]['agent'] = 0
        with self.assertRaises(AssertionError):
            validate_plan(bad)

    def test_parallel_denial_has_no_quiet_no_dispatch_interval(self):
        bad = plan()
        bad['phases'][0]['parallel'][0]['expect'] = {'kind': 'refused', 'reason': 'permission_denied'}
        with self.assertRaises(AssertionError):
            validate_plan(bad)

    def test_policy_plan_cannot_count_dispatched_action_as_deny(self):
        bad = plan()
        bad['purpose'] = 'policy'
        with self.assertRaises(AssertionError):
            validate_plan(bad)


class SmokeStageTests(unittest.TestCase):
    def test_parallel_prebarrier_failure_preserves_root_cause_and_aborts_sibling(self):
        steps = [{'agent': i, 'tool': 'press_key'} for i in range(2)]
        entered = threading.Event()
        calls = []
        def action(step, barrier):
            calls.append(step['agent'])
            if step['agent'] == 1:
                self.assertTrue(entered.wait(1))
                raise RuntimeError('selection grounding unavailable')
            entered.set()
            barrier.wait(timeout=2)
            self.fail('sibling must not dispatch')
        results, errors = parallel_actions(steps, action)
        self.assertEqual(results, [])
        self.assertCountEqual(calls, [0, 1])
        self.assertEqual(errors, [
            {'agent': 0, 'tool': 'press_key', 'error_type': 'BrokenBarrierError', 'message': ''},
            {'agent': 1, 'tool': 'press_key', 'error_type': 'RuntimeError',
             'message': 'selection grounding unavailable'}])

    def test_parallel_postbarrier_failure_retains_successful_sibling_without_replay(self):
        steps = [{'agent': i, 'tool': 'press_key'} for i in range(2)]
        calls = []
        def action(step, barrier):
            barrier.wait(timeout=2)
            calls.append(step['agent'])
            if step['agent'] == 0:
                raise RuntimeError('unconfirmed effect')
            return {'agent': 1, 'expected': 'dispatched'}
        results, errors = parallel_actions(steps, action)
        self.assertEqual(results, [{'agent': 1, 'expected': 'dispatched'}])
        self.assertCountEqual(calls, [0, 1])
        self.assertEqual(errors, [{'agent': 0, 'tool': 'press_key', 'error_type': 'RuntimeError',
                                   'message': 'unconfirmed effect'}])

    def test_runner_grounds_full_snapshots_and_never_recovers_or_replays(self):
        failures = {None: None, 'unmarked': None,
                    'truncated': 'not proven complete', 'incomplete': 'not proven complete',
                    'degraded': 'not proven complete', 'missing_budget': 'not proven complete',
                    'no_elements': 'snapshot has no semantic elements',
                    'dialog': 'unexpected dialog; no dismissal keys were sent',
                    'extra_window': 'reviewed PID/window identity is stale or ambiguous',
                    'after_dialog': 'unexpected dialog; no dismissal keys were sent',
                    'transport': 'unknown input outcome',
                    'identity_before_once': None, 'identity_after_once': None,
                    'identity_before_permanent': 'not proven complete',
                    'identity_after_permanent': 'not proven complete',
                    'identity_window_changed': 'reviewed PID/window identity is stale or ambiguous',
                    'identity_truncated': 'not proven complete',
                    'identity_incomplete': 'not proven complete'}
        no_input = ('no_elements', 'dialog', 'extra_window', 'truncated', 'incomplete', 'degraded',
                    'missing_budget', 'identity_before_permanent', 'identity_window_changed',
                    'identity_truncated', 'identity_incomplete')
        for app, stage, elements in (
                ('calc', 'insert', [{'role': 'table cell', 'label': 'A1', 'selected': True}]),
                ('inkscape', 'select', INKSCAPE['elements']),
                ('inkscape', 'move', INKSCAPE_SELECTED['elements'])):
            for failure, expected_error in failures.items():
                with self.subTest(app=app, stage=stage, failure=failure), \
                        tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                    root = Path(directory)
                    candidate = plan()
                    index = 0 if app == 'calc' else 1
                    tool_name, arguments = SMOKE_STEPS[app][stage]
                    candidate['phases'] = [{'agent': index, 'smoke_stage': stage,
                                            'tool': tool_name, 'arguments': arguments}]
                    if failure == 'unmarked':
                        del candidate['phases'][0]['smoke_stage']
                    bounds = {'x': 0, 'y': 0, 'width': 600, 'height': 600}
                    for i, spec in enumerate(candidate['agents']):
                        spec.update(bounds=bounds, name=f'agent-{i}', profile={'mode': 'standard'})
                        path = root / f'{i}.xml'
                        path.write_text('<synthetic/>')
                        candidate['outputs'][i]['path'] = str(path)
                    args = harness_args(root, candidate)
                    calls, held = [], [True]
                    agents = [Mock(process=Mock(pid=101 + i, poll=Mock(return_value=None))) for i in range(2)]
                    observer = Mock()
                    targets = [candidate['foreground']] + [spec['target'] for spec in candidate['agents']]

                    identity_seen, phase_count = [0], {False: 0, True: 0}

                    def tool(name, parameters):
                        if name == 'list_windows':
                            windows = copy.deepcopy(targets)
                            if failure == 'extra_window' or (failure == 'identity_window_changed'
                                                             and identity_seen[0]):
                                windows.append({**candidate['agents'][index]['target'], 'window_id': 999})
                            return {'structuredContent': {'windows': windows}}
                        if name == 'get_window_state':
                            calls.append(('snapshot', parameters))
                            sent = any(row[0] == 'input' for row in calls)
                            rows = elements
                            if failure in ('no_elements', 'unmarked'):
                                rows = []
                            if failure == 'dialog' or (failure == 'after_dialog' and sent):
                                rows = [{'role': 'dialog'}]
                            phase_count[sent] += parameters.get('timeout_ms') == OBSERVATION_TIMEOUT_MS
                            identity = ((failure in ('identity_truncated', 'identity_incomplete',
                                                     'identity_window_changed') and not sent)
                                        or ((failure or '').startswith('identity_before') and not sent)
                                        or ((failure or '').startswith('identity_after') and sent))
                            if (failure or '').endswith('_once') and phase_count[sent] > 1:
                                identity = False
                            identity = identity and parameters.get('timeout_ms') == OBSERVATION_TIMEOUT_MS
                            identity_seen[0] += identity
                            return {'structuredContent': {'screenshot_width': 600, 'window_bounds': bounds,
                                                          'truncated': failure in ('truncated', 'identity_truncated'),
                                                          'elements_complete': failure not in ('incomplete',
                                                                                               'identity_incomplete'),
                                                          'degraded': failure == 'degraded' or identity,
                                                          **({'degraded_reason': 'accessibility_window_identity_unproven'
                                                              ': title transition'} if identity else {}),
                                                          'timeout_ms': None if failure == 'missing_budget' else OBSERVATION_TIMEOUT_MS,
                                                          'tree_markdown': (INKSCAPE_SELECTED if stage == 'move'
                                                                            else INKSCAPE)['tree_markdown'],
                                                          'elements': rows}}
                        if name == 'get_desktop_state':
                            return {'structuredContent': {'screen_width': 800, 'screen_height': 800}}
                        if name != tool_name:
                            return {'structuredContent': {}}
                        calls.append(('input', parameters))
                        if failure == 'transport':
                            raise TimeoutError('unknown input outcome')
                        return {'structuredContent': {'route': 'synthetic_events', 'effect': 'unverifiable',
                                                      'delivery': {'mode': 'background'}}}

                    for mcp in agents + [observer]:
                        mcp.tool.side_effect = tool
                    patch_module(stack, 'production_realapp_proof', run_replacements(
                        self, held, DirectMCP=Mock(side_effect=agents + [observer]),
                        verify_output=Mock(return_value={'verified': True})))
                    self.assertEqual(run(args), 0 if expected_error is None else 1)
                    inputs = [i for i, row in enumerate(calls) if row[0] == 'input']
                    self.assertEqual(len(inputs), 0 if failure in no_input else 1)
                    snapshots = [row for row in calls if row[0] == 'snapshot'
                                 and row[1].get('timeout_ms') == OBSERVATION_TIMEOUT_MS]
                    bound = {'identity_before_once': 3, 'identity_after_once': 3,
                             'identity_before_permanent': 2, 'identity_after_permanent': 3,
                             'identity_window_changed': 1, 'identity_truncated': 1,
                             'identity_incomplete': 1, 'truncated': 1, 'incomplete': 1,
                             'degraded': 1, 'missing_budget': 1}
                    if failure in bound:
                        self.assertEqual(len(snapshots), bound[failure])
                    if inputs:
                        i = inputs[0]
                        self.assertEqual(calls[i - 1][0], 'snapshot')
                        self.assertEqual(calls[i + 1][0], 'snapshot')
                        self.assertEqual(calls[i][1]['delivery_mode'], 'background')
                        self.assertNotIn('smoke_stage', calls[i][1])
                        for _, parameters in (calls[i - 1], calls[i + 1]):
                            self.assertEqual('max_elements' in parameters, failure == 'unmarked')
                            self.assertEqual('max_depth' in parameters, failure == 'unmarked')
                            if failure != 'unmarked':
                                self.assertEqual(parameters['timeout_ms'], OBSERVATION_TIMEOUT_MS)
                    for mcp in agents + [observer]:
                        mcp.close.assert_called_once()
                    self.assertFalse(held[0])
                    report = json.loads((args.evidence / 'result.json').read_text())
                    if failure is None:
                        self.assertEqual(report['actions'][0]['smoke_stage'], stage)
                    if expected_error:
                        self.assertRegex(report['error'], expected_error)


class PointerStageTests(unittest.TestCase):
    def test_only_declared_intermediate_episodes_may_omit_saved_outputs(self):
        for index, name in enumerate(POINTER_EPISODES):
            candidate = plan()
            candidate.update(pointer_episode={'name': name, 'index': index, 'count': 5},
                             require_overlap=name == 'drags')
            if name != 'save':
                candidate['outputs'] = []
            validate_plan(candidate)
            moving = copy.deepcopy(candidate)
            moving['moving_primary'] = True
            if name == 'drags':
                validate_plan(moving)
            else:
                with self.assertRaises(AssertionError):
                    validate_plan(moving)
            for mutation in (lambda p: p['pointer_episode'].update(count=4),
                             lambda p: p['pointer_episode'].update(index=True),
                             lambda p: p['pointer_episode'].update(name='unknown'),
                             lambda p: p['pointer_episode'].update(extra=True),
                             lambda p: p.update(purpose='policy'),
                             lambda p: p.update(require_overlap=name != 'drags')):
                invalid = copy.deepcopy(candidate)
                mutation(invalid)
                with self.assertRaises(AssertionError):
                    validate_plan(invalid)
        for metadata in ({}, {'pointer_episode': None},
                         {'pointer_episode': {'name': 'save', 'index': 4, 'count': 5}}):
            with self.subTest(metadata=metadata), self.assertRaises(AssertionError):
                validate_plan({**plan(), **metadata, 'outputs': []})

    def test_primary_guard_fails_at_deadline_or_any_helper_exit(self):
        helper = Mock(poll=Mock(return_value=None))
        with patch('production_realapp_proof.time.monotonic_ns', return_value=99) as clock:
            require_primary_active(helper, 100)
            for now in (100, 101):
                clock.return_value = now
                with self.assertRaisesRegex(AssertionError, 'deadline expired'):
                    require_primary_active(helper, 100)
            clock.return_value = 99
            for code in (0, 1, -15):
                helper.poll.return_value = code
                with self.assertRaisesRegex(AssertionError, 'helper exited'):
                    require_primary_active(helper, 100)

    def test_pointer_stages_reject_supplied_coordinates_or_wrong_tool(self):
        candidate = plan()
        candidate['phases'] = [{'agent': 0, 'pointer_stage': 'click_b2', 'tool': 'click', 'arguments': {}}]
        validate_plan(candidate)
        for change in ({'arguments': {'x': 1, 'y': 2}}, {'tool': 'press_key'},
                       {'pointer_stage': 'unknown'}, {'smoke_stage': 'insert'},
                       {'expect': {'kind': 'partial'}}):
            changed = copy.deepcopy(candidate)
            changed['phases'][0].update(change)
            with self.subTest(change=change), self.assertRaises(AssertionError):
                validate_plan(changed)

    def test_pointer_actions_use_the_same_response_image_and_never_replay(self):
        for failure in (None, 'before', 'after', 'after_recovers', 'missing_image', 'transport',
                        'helper_before', 'deadline_before', 'helper_after', 'deadline_after'):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                root = Path(directory)
                candidate = plan()
                candidate['phases'] = [{'agent': 0, 'pointer_stage': 'click_b2', 'tool': 'click', 'arguments': {}}]
                bounds = {'x': 0, 'y': 0, 'width': 600, 'height': 600}
                for index, spec in enumerate(candidate['agents']):
                    spec.update(bounds=bounds, name=f'agent-{index}', profile={'mode': 'standard'})
                    output = root / f'{index}.xml'
                    output.write_text('<synthetic/>')
                    candidate['outputs'][index]['path'] = str(output)
                args = harness_args(root, candidate)
                targets = [candidate['foreground']] + [spec['target'] for spec in candidate['agents']]
                clients, calls, held = [], [], [True]
                clock_now = [1]
                grab = Mock(poll=Mock(return_value=None))
                def expire_primary(phase):
                    if failure == 'helper_' + phase:
                        grab.poll.return_value = 0
                    if failure == 'deadline_' + phase:
                        clock_now[0] = 1 + PRIMARY_LIFETIME_MS * 1_000_000
                def client(driver, folder, profile):
                    mcp = Mock(directory=folder, counter=0,
                               process=Mock(pid=100 + len(clients), poll=Mock(return_value=None)))
                    clients.append(mcp)
                    def tool(name, parameters):
                        mcp.counter += 1
                        if name == 'list_windows':
                            return {'structuredContent': {'windows': targets}}
                        if name == 'get_window_state':
                            if any(row[0] == 'input' for row in calls):
                                expire_primary('after')
                            calls.append(('snapshot', parameters, folder.name, mcp.counter))
                            image = folder / f'{mcp.counter}.png'
                            image.write_bytes(b'synthetic image read by a stub')
                            return {'structuredContent': {'screenshot_width': 600, 'window_bounds': bounds,
                                    'truncated': False, 'elements_complete': True,
                                    'timeout_ms': OBSERVATION_TIMEOUT_MS},
                                    'content': [] if failure == 'missing_image' else
                                    [{'type': 'image', 'image_file': image.name}]}
                        if name == 'get_desktop_state':
                            return {'structuredContent': {'screen_width': 800, 'screen_height': 800}}
                        if name == 'click':
                            calls.append(('input', parameters))
                            if failure == 'transport':
                                raise TimeoutError('unknown outcome')
                            return {'structuredContent': {'route': 'synthetic_events', 'effect': 'unverifiable'}}
                        return {'structuredContent': {}}
                    mcp.tool.side_effect = tool
                    return mcp
                def ground_pointer(*_):
                    if failure == 'before':
                        raise RuntimeError('missing grounding')
                    expire_primary('before')
                    return {'x': 103, 'y': 205}, {'app': 'calc', 'stage': 'click_b2'}
                grounding = Mock(side_effect=ground_pointer)
                verification = Mock(return_value={'verified': True},
                                    side_effect=AssertionError('unchanged app') if failure == 'after' else None)
                if failure == 'after_recovers':
                    verification.side_effect = [AssertionError('not settled'), {'verified': True}, {'verified': True}]
                patch_module(stack, 'production_realapp_proof', run_replacements(
                    self, held, DirectMCP=client, **{'subprocess.Popen': Mock(return_value=grab),
                    'time.monotonic_ns': lambda: clock_now[0],
                    'verify_output': Mock(return_value={'verified': True}),
                    'pointer_grounding.read_pixels': lambda path: path,
                    'pointer_grounding.action': grounding, 'pointer_grounding.verify': verification}))
                self.assertEqual(run(args), 0 if failure is None else 1)
                inputs = [index for index, row in enumerate(calls) if row[0] == 'input']
                self.assertEqual(len(inputs), 0 if failure in
                                 ('before', 'missing_image', 'helper_before', 'deadline_before') else 1)
                for index in inputs:
                    self.assertEqual(calls[index - 1][0], 'snapshot')
                    self.assertEqual(calls[index + 1][0], 'snapshot')
                    self.assertEqual(calls[index][1], {**candidate['agents'][0]['target'],
                                                      'session': 'agent-0', 'delivery_mode': 'background',
                                                      'x': 103, 'y': 205})
                    before = calls[index - 1]
                    self.assertTrue(grounding.call_args.args[1].endswith(f'{before[2]}/{before[3]}.png'))
                    self.assertEqual(grounding.call_args.args[0]['proof_image'], grounding.call_args.args[1])
                if failure is None:
                    after = calls[inputs[0] + 1]
                    self.assertTrue(verification.call_args.args[1].endswith(f'{after[2]}/{after[3]}.png'))
                    report = json.loads((args.evidence / 'result.json').read_text())
                    self.assertTrue(report['actions'][0]['app_effect_verified'])
                    self.assertEqual(report['actions'][0]['pointer_stage'], 'click_b2')
                    self.assertEqual(report['actions'][0]['pointer_evidence'],
                                     {'before_request': before[3], 'after_request': after[3]})
                if inputs:
                    self.assertEqual(len(list(args.evidence.glob('pointer-agent-*.json'))), 1)
                if failure in ('after', 'after_recovers'):
                    diagnostic = json.loads((args.evidence / 'pointer-effect-failure-agent-0.json').read_text())
                    self.assertFalse(diagnostic['replayed'])
                    self.assertEqual(len(diagnostic['samples']), 2)
                    self.assertEqual(verification.call_count, 3)
                    if failure == 'after_recovers':
                        self.assertTrue(all(row['effect']['verified'] for row in diagnostic['samples']))
                    report = json.loads((args.evidence / 'result.json').read_text())
                    self.assertEqual(report['result'], 'failed')
                    self.assertEqual(report['actions'], [])
                if failure and failure.startswith(('helper_', 'deadline_')):
                    report = json.loads((args.evidence / 'result.json').read_text())
                    self.assertEqual(report['result'], 'failed')
                    self.assertIn('primary grab', report['error'])
                    self.assertEqual(report['actions'], [])
                for mcp in clients:
                    mcp.close.assert_called_once()
                self.assertFalse(held[0])


class ResponseTests(unittest.TestCase):
    def test_common_policy_refusal_uses_existing_envelope_not_invented_action_fields(self):
        result = {'isError': True, 'structuredContent': {'status': 'refused',
                  'refusal': {'code': 'bounded_resource_outside_manifest', 'message': 'out of scope'}}}
        check_response(result, {'kind': 'refused', 'reason': 'bounded_resource_outside_manifest'})
        with self.assertRaises(AssertionError):
            check_response(result, {'kind': 'refused', 'reason': 'permission_denied'})

    def test_dispatched_does_not_mean_verified_app_effect(self):
        response = {'structuredContent': {'route': 'synthetic_events', 'effect': 'unverifiable',
                                         'delivery': {'mode': 'background'}}}
        checked = check_response(response, {'kind': 'dispatched'})
        self.assertFalse(checked['app_effect_verified'])
        for change in ({'effect': 'partial'}, {'effect': 'suspected_noop'},
                       {'delivery': {'mode': 'unknown'}}, {'route': 'global_input'}):
            with self.assertRaises(AssertionError):
                check_response({'structuredContent': {**response['structuredContent'], **change}},
                               {'kind': 'dispatched'})

    def test_refusal_requires_exact_reason_and_absent_delivery(self):
        content = {'effect': 'refused', 'reason': 'permission_denied'}
        expected = {'kind': 'refused', 'reason': 'permission_denied'}
        check_response({'isError': True, 'structuredContent': content}, expected)
        for change in ({'reason': 'unsupported'}, {'effect': 'partial'},
                       {'delivery': {'mode': 'unknown', 'delivered_count': 0}}):
            with self.assertRaises(AssertionError):
                check_response({'isError': True, 'structuredContent': {**content, **change}}, expected)

    def test_partial_and_unknown_are_explicit_not_success_relabels(self):
        content = {'route': 'synthetic_events', 'effect': 'partial',
                   'delivery': {'mode': 'unknown', 'delivered_count': 2}}
        for kind in ('partial', 'unknown'):
            self.assertEqual(check_response({'isError': True, 'structuredContent': content},
                                           {'kind': kind})['expected'], kind)
        with self.assertRaises(AssertionError):
            check_response({'structuredContent': {**content, 'delivery': {'mode': 'background'}}},
                           {'kind': 'partial'})

    def test_no_dispatch_rejects_press_without_completion(self):
        before = {**trace(START), 'active': True}
        assert_no_dispatch(before, copy.deepcopy(before))
        for kind in ('pointer_button', 'agent_admitted', 'agent_approved', 'agent_drag_start'):
            after = {**trace(START, (kind, 100, 200, 1, 1)), 'active': True}
            with self.assertRaises(AssertionError):
                assert_no_dispatch(before, after)

    def test_no_dispatch_requires_valid_telemetry(self):
        before = {**trace(START), 'active': True}
        with self.assertRaisesRegex(AssertionError, 'dropped events'):
            assert_no_dispatch(before, {**before, 'overflow': True})


class TraceIntervalTests(unittest.TestCase):
    """Owner of dispatch-interval page validity for every proof that reuses it."""

    def test_returns_only_rows_appended_after_a_valid_prefix(self):
        before = {**trace(START), 'active': True}
        after = {**trace(START, ('agent_admitted', 100, 200, 1, 0)), 'active': True}
        self.assertEqual(trace_interval(before, after), [after['events'][1]])
        self.assertEqual(trace_interval(before, before), [])
        motion = {**trace(START, ('pointer_motion', 100, 200, 1, 0)), 'active': True}
        motion['events'][1].extend([10, 20])  # Surface coordinates are a valid row shape.
        self.assertEqual(trace_interval(before, motion), [motion['events'][1]])

    def test_rejects_missing_incomplete_malformed_stopped_or_rewritten_pages(self):
        before = {**trace(START), 'active': True}
        after = {**trace(START, ('cursor', 100, 200, 0, 0)), 'active': True}
        def changed(update):
            page = copy.deepcopy(after)
            update(page)
            return page
        cases = [
            ('missing dispatch telemetry', None),
            ('not live', {**after, 'hook': False}),
            ('not live', {**after, 'active': False}),
            ('dropped events', {**after, 'overflow': True}),
            ('dropped events', {**after, 'timed_out': True}),
            ('empty dispatch telemetry', {**after, 'events': [], 'count': 0}),
            ('incomplete dispatch telemetry', {**after, 'count': 3}),
            ('malformed dispatch telemetry', changed(lambda p: p['events'][-1].pop())),
            ('malformed trace sequence', changed(lambda p: p['events'][-1].__setitem__(0, '2'))),
            ('incomplete dispatch telemetry', changed(lambda p: p['events'][-1].__setitem__(2, 'unknown'))),
            ('incomplete dispatch telemetry', changed(lambda p: p['events'][-1].__setitem__(0, 3))),
            ('trace already stopped', changed(lambda p: p['events'].insert(1, [2, 0, 'stop', 100, 200, 0, 0])
                                              or p['events'][2].__setitem__(0, 3) or p.update(count=3))),
            ('trace history changed', changed(lambda p: p['events'][0].__setitem__(3, 101))),
        ]
        for pattern, page in cases:
            with self.subTest(pattern=pattern, page=page), self.assertRaisesRegex(AssertionError, pattern):
                trace_interval(before, page)
        # The prefix is held to the same contract as the interval end.
        with self.assertRaisesRegex(AssertionError, 'dropped events'):
            trace_interval({**before, 'overflow': True}, after)


class OutputTests(unittest.TestCase):
    def test_svg_asserts_saved_translation_and_rejects_resize(self):
        before = b'<svg><rect id="shape" x="1" y="2" width="3" height="4"/></svg>'
        after = b'<svg><rect id="shape" x="11" y="32" width="3" height="4"/></svg>'
        oracle = {'agent': 1, 'path': 'drawing.svg', 'xpath': './rect',
                  'rect_translation': [[10, 10], [30, 30]]}
        self.assertTrue(verify_output(before, after, oracle)['verified'])
        for invalid in (before, after.replace(b'width="3"', b'width="5"')):
            with self.assertRaises(AssertionError):
                verify_output(before, invalid, oracle)

    def test_calc_can_use_independently_read_ods_content(self):
        def ods(value):
            stream = io.BytesIO()
            with zipfile.ZipFile(stream, 'w') as archive:
                archive.writestr('content.xml', f'<sheet><cell value="{value}"/></sheet>')
            return stream.getvalue()
        oracle = {'agent': 0, 'path': 'sheet.ods', 'zip_member': 'content.xml',
                  'xpath': './cell', 'attributes': {'value': '96'}}
        self.assertTrue(verify_output(ods(1), ods(96), oracle)['verified'])
        with self.assertRaises(AssertionError):
            verify_output(ods(1), ods(75), oracle)


def motion_command(sequence, point, command_ns=1, ack_ns=2):
    x, y = point
    return {'sequence': sequence, 'x': x, 'y': y, 'command_ns': command_ns,
            'ack_ns': ack_ns, 'acknowledgement': f'MOVED {x} {y}\n'}


class MovingPrimaryTests(unittest.TestCase):
    def test_entire_square_must_fit_inside_foreground_and_desktop(self):
        bounds = {'x': 0, 'y': 0, 'width': 600, 'height': 600}
        desktop = {'screen_width': 800, 'screen_height': 800}
        route = primary_trajectory(bounds, [100, 200], desktop)
        self.assertEqual(len(route), 32)
        self.assertEqual(route[0], [120, 200])
        self.assertEqual(route[-1], [100, 200])
        for point in ([450, 200], [100, 450], [-1, 200]):
            with self.assertRaises(AssertionError):
                primary_trajectory(bounds, point, desktop)
        with self.assertRaisesRegex(AssertionError, 'desktop'):
            primary_trajectory({**bounds, 'x': 700}, [100, 200], desktop)

    def test_moving_endpoints_allow_only_cursor_change(self):
        before = {'pid': 10, 'address': '0x10', 'workspace': 1, 'cursor': {'x': 100, 'y': 200}}
        after = {**before, 'cursor': {'x': 120, 'y': 200}}
        assert_primary_state(before, after, True)
        with self.assertRaises(AssertionError):
            assert_primary_state(before, after, False)
        for key in ('pid', 'address', 'workspace'):
            with self.assertRaises(AssertionError):
                assert_primary_state(before, {**after, key: 'changed'}, True)

    def test_missing_malformed_incomplete_and_reordered_logs_fail(self):
        route = [[120, 200], [140, 200]]
        commands = [motion_command(1, route[0]), motion_command(2, route[1], 3, 4)]
        self.assertEqual(expected_primary_motion(commands, route), route)
        malformed = [None, [], {}, ['bad'], commands[1:], list(reversed(commands))]
        for change in ({'sequence': True}, {'sequence': 3}, {'x': float('nan')},
                       {'y': 300}, {'command_ns': 0}, {'ack_ns': None}, {'ack_ns': -1},
                       {'acknowledgement': None}, {'acknowledgement': 'MOVED 140 200\n'}):
            malformed.append([{**commands[0], **change}, commands[1]])
        for log in malformed:
            with self.subTest(log=log), self.assertRaises(AssertionError):
                expected_primary_motion(log, route)

    def test_acknowledgement_rejects_timeout_eof_partial_and_oversized_lines(self):
        stream = Mock()
        for chunks, readiness in (([b''], [[stream]]), ([b'MOVED 120'], [[stream], []]),
                                  ([b'x' * 128, b'x\n'], [[stream], [stream]])):
            with patch('production_realapp_proof.os.read', side_effect=chunks), \
                    patch('production_realapp_proof.select.select', side_effect=[(r, [], []) for r in readiness]), \
                    self.assertRaises(AssertionError):
                primary_acknowledgement(stream)
        with patch('production_realapp_proof.os.read', side_effect=[b'MOVED ', b'120 200\n']), \
                patch('production_realapp_proof.select.select', return_value=([stream], [], [])):
            self.assertEqual(primary_acknowledgement(stream), 'MOVED 120 200\n')

    def test_independent_stream_retains_each_command_and_requires_exact_ack(self):
        for acknowledgement in ('MOVED 120 200\n', 'MOVED 999 200\n', 'MOVED 120 200\nextra\n'):
            commands, grab, ready = [], Mock(), Mock()
            done = Mock(wait=Mock(side_effect=[False, True]))
            with patch('production_realapp_proof.primary_acknowledgement', return_value=acknowledgement):
                if acknowledgement == 'MOVED 120 200\n':
                    move_primary(grab, [[120, 200]], done, ready, commands, Mock())
                    self.assertEqual(expected_primary_motion(commands, [[120, 200]]), [[120, 200]])
                    ready.set.assert_called_once()
                else:
                    with self.assertRaisesRegex(AssertionError, 'malformed'):
                        move_primary(grab, [[120, 200]], done, ready, commands, Mock())
                    ready.set.assert_not_called()
            grab.stdin.write.assert_called_once_with('MOVE 120 200\n')
            grab.stdin.flush.assert_called_once()
            self.assertEqual(commands[0]['acknowledgement'], acknowledgement)

    def test_runner_uses_acknowledged_motion_and_brackets_background_action(self):
        # Exercise orchestration without a compositor, Driver process, or GUI.
        for during_action, failure in ((True, None), (False, None), (True, 'ack'),
                                       (True, 'join'), (True, 'action'), (True, 'startup'),
                                       (True, 'late_ack'), (True, 'motion')):
            with self.subTest(during_action=during_action, failure=failure), \
                    tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                root = Path(directory)
                bounds = {'x': 0, 'y': 0, 'width': 600, 'height': 600}
                spec = {'target': {'pid': 20, 'window_id': 200}, 'bounds': bounds,
                        'name': 'agent', 'profile': {'mode': 'standard'}}
                args = harness_args(root, {
                    'purpose': 'policy', 'moving_primary': True, 'primary_point': [100, 200],
                    'foreground': {'pid': 10, 'window_id': 100}, 'agents': [spec],
                    'phases': [{'agent': 0, 'tool': 'click', 'arguments': {'x': 10, 'y': 20},
                                'expect': {'kind': 'refused', 'reason': 'permission_denied'}}]},
                    trace_socket=root / 'cua-input-v3.sock')
                log, action_calls, held = [], [], [True]

                def append_motion(point):
                    now = time.monotonic_ns()
                    log.append(motion_command(len(log) + 1, point, now, now))

                def movement(grab, trajectory, done, ready, commands, mark):
                    nonlocal log
                    log = commands
                    append_motion([120, 200])
                    if failure == 'motion':
                        raise RuntimeError('movement failed')
                    ready.set()

                def tool(name, arguments):
                    if name == 'get_window_state':
                        action_calls.append('snapshot')
                        return {'structuredContent': {'screenshot_width': 600, 'window_bounds': bounds}}
                    if name == 'get_desktop_state':
                        return {'structuredContent': {'screen_width': 800, 'screen_height': 800}}
                    if name == 'click':
                        action_calls.append('click')
                        self.assertEqual(arguments['delivery_mode'], 'background')
                        if during_action:
                            append_motion([140, 200])
                            if failure == 'ack':
                                log[-1]['acknowledgement'] = None
                            if failure == 'late_ack':
                                log[-1]['ack_ns'] += 1_000_000_000_000
                        if failure == 'action':
                            raise RuntimeError('transport failed')
                        return {'isError': True, 'structuredContent': {
                            'effect': 'refused', 'reason': 'permission_denied'}}
                    return {'structuredContent': {}}

                agent = Mock(process=Mock(pid=11, poll=Mock(return_value=None)))
                observer = Mock()
                agent.tool.side_effect = observer.tool.side_effect = tool
                grab = Mock(stdout=io.StringIO('HELD\n'), poll=Mock(return_value=None))
                trace_client = Mock(hello={'protocol': 3})
                initial = ('cursor', 120, 200, 0, 0)
                final = ('cursor', 140, 200, 0, 0)
                events = [initial, final] if during_action else [initial]
                trace_client.collect.side_effect = [
                    {**trace(START, initial), 'active': True},
                    {**trace(START, *events), 'active': True},
                    trace(START, *events, ('stop', *events[-1][1:3], 0, 0))]

                workers = []
                def thread(target, daemon):
                    self.assertTrue(daemon)
                    worker = Mock(is_alive=Mock(side_effect=lambda: failure == 'join' and held[0]))
                    worker.start.side_effect = target
                    workers.append(worker)
                    return worker

                replacements = run_replacements(self, held, **{
                    'DirectMCP': Mock(side_effect=[agent, observer]),
                    'subprocess.Popen': Mock(return_value=grab),
                    'primary_acknowledgement': Mock(side_effect=AssertionError('incomplete HELD'))
                        if failure == 'startup' else Mock(return_value='HELD\n'),
                    'select.select': Mock(return_value=([grab.stdout], [], [])),
                    'wm': lambda: {'pid': 10, 'address': '0x10', 'workspace': 1,
                                   'cursor': {'x': log[-1]['x'] if log else 100, 'y': 200}},
                    'Trace': Mock(return_value=trace_client), 'threading.Thread': thread,
                    'move_primary': movement})
                patch_module(stack, 'production_realapp_proof', replacements)
                self.assertEqual(run(args), 0 if during_action and failure is None else 1)
                if failure not in ('startup', 'motion'):
                    click_index = action_calls.index('click')
                    self.assertEqual(action_calls[click_index - 1:click_index + 2], ['snapshot', 'click', 'snapshot'])
                self.assertIn('controlled', replacements['subprocess.Popen'].call_args.args[0])
                report = json.loads((args.evidence / 'result.json').read_text())
                if during_action and failure is None:
                    self.assertEqual(report['continuous_isolation'], 'passed')
                    self.assertEqual(report['primary_commands_during_actions'], 1)
                    self.assertEqual(json.loads((args.evidence / 'expected-primary-motion.json').read_text()),
                                     [[120, 200], [140, 200]])
                    self.assertEqual(report['actions'][0]['no_dispatch'], 'verified')
                else:
                    self.assertEqual(report['continuous_isolation'], 'unproven')
                self.assertEqual(json.loads((args.evidence / 'primary-motion-commands.json').read_text()), log)
                self.assertFalse(held[0])
                agent.close.assert_called_once()
                observer.close.assert_called_once()
                if failure != 'startup':
                    trace_client.close.assert_called_once()
                    workers[0].join.assert_called_with(timeout=3)
                    self.assertEqual(workers[0].join.call_count, 2)
                if failure == 'join':
                    cleanup = json.loads((args.evidence / 'cleanup.json').read_text())
                    self.assertIn('stop_primary_motion', [row['operation'] for row in cleanup['errors']])
                    self.assertFalse(workers[0].is_alive())


class RunnerGateTests(unittest.TestCase):
    def test_unprovable_plans_fail_before_provenance_or_any_process(self):
        cases = (
            ('policy_cache requires continuous trace', policy_cache_plan(), {}, {'policy_cache': {'result': 'unproven'}}),
            ('capacity requires continuous trace', capacity_plan(), {}, {'capacity': {'result': 'unproven'}}),
            ('moving primary requires continuous trace', {**plan(), 'moving_primary': True}, {}, {}),
            ('requires the independent primary observer', plan(), {'artifact_role': 'production'}, {}),
        )
        for error, candidate, overrides, retained in cases:
            with self.subTest(error=error), tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
                args = harness_args(directory, candidate, **overrides)
                launches = [stack.enter_context(patch('production_realapp_proof.' + name))
                            for name in ('provenance', 'DirectMCP', 'subprocess.Popen')]
                self.assertEqual(run(args), 1)
                for launch in launches:
                    launch.assert_not_called()
                result = json.loads((args.evidence / 'result.json').read_text())
                self.assertEqual(result['result'], 'failed')
                self.assertRegex(result['error'], error)
                self.assertEqual(result['continuous_isolation'], 'unproven')
                for key, value in retained.items():
                    self.assertEqual(result[key], value)

    def test_preflight_failure_is_retained_as_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            args = harness_args(directory, plan())
            with patch('production_realapp_proof.provenance', side_effect=AssertionError('SHA mismatch')):
                self.assertEqual(run(args), 1)
            result = json.loads((args.evidence / 'result.json').read_text())
            self.assertEqual(result['result'], 'failed')
            self.assertEqual(result['error'], 'SHA mismatch')
            self.assertTrue((args.evidence / 'cleanup.json').is_file())

if __name__ == '__main__':
    unittest.main()
