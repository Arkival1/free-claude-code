"""JARVIS Workstation - the owner's local desktop app (v3.2).

One window for the owner: paste a YouTube link, watch JARVIS get the audio from the
website in its own browser window, approve the download, and get a transcript + notes in
Obsidian. Also: every background job (including ones the LM Studio model started),
download approvals, a system check and an emergency STOP.

This app is the OWNER's side: approving here is the owner's decision, exactly like the
Control Panel. The AI model can never press these buttons. No network listener is opened.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import messagebox, ttk
from urllib.parse import quote

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from jarvis_core.browser_dom import BrowserDOM  # noqa: E402
from jarvis_core.download_approvals import DownloadApprovals  # noqa: E402
from jarvis_core.files import FileTools  # noqa: E402
from jarvis_core.network import WebTools  # noqa: E402
from jarvis_core.policy import PolicyError, Settings  # noqa: E402
from jarvis_core.vault import Vault  # noqa: E402
from jarvis_core.workstation_core import build_pipeline  # noqa: E402
from jarvis_core.youtube import YouTubeTools, canonical_video  # noqa: E402

VERSION = '3.5.1'
STEPS = [('find_format', 'Find the best audio format'), ('awaiting_approval', 'Your approval'),
         ('download', 'Download + check the file'), ('transcribe', 'Transcribe on this PC'),
         ('save', 'Save transcript to Obsidian'), ('notes', 'Write study notes')]
STAGE_TO_STEP = {'website': 'find_format', 'find_format': 'find_format', 'audio': 'download',
                 'awaiting_approval': 'awaiting_approval', 'human_check': 'download', 'download': 'download',
                 'transcribe': 'transcribe', 'save': 'save', 'notes': 'notes', 'done': 'notes'}
COMING_NEXT = [
    'Research desk - web research with sources saved to Obsidian',
    'Project builder - website / game projects with live preview and tests',
    'Memory desk - search and review everything JARVIS remembers',
    'App pilot - accessibility-based control of desktop apps (UIA), with screenshots as proof',
    'Daily brief - what JARVIS did today, what is waiting for you',
]


def open_path(path: Path):
    try:
        if os.name == 'nt':
            os.startfile(str(path))  # noqa: S606 - owner clicked "open"; files are notes/folders only
        else:
            subprocess.Popen(['xdg-open', str(path)])
    except OSError as exc:
        messagebox.showerror('Could not open', str(exc))


class Workstation(tk.Tk):
    def __init__(self):
        super().__init__()
        self.settings = Settings(BASE / 'config.json')
        files = FileTools(self.settings)
        web = WebTools(self.settings)
        vault = Vault(self.settings, files)
        youtube = YouTubeTools(self.settings, web, files, None, vault)
        self.approvals = web.approvals if hasattr(web, 'approvals') else DownloadApprovals(self.settings)
        self.pipeline, self.jobs, self.openwhispr = build_pipeline(
            self.settings, files, vault, youtube, self.approvals, BrowserDOM(self.settings))
        self.current_job = None
        self.title(f'JARVIS Workstation {VERSION}')
        self.geometry('1040x760')
        self.minsize(900, 640)
        self._style()
        self._build()
        self.after(400, self._tick)

    # ---------- look ----------
    def _style(self):
        st = ttk.Style(self)
        try:
            st.theme_use('clam')
        except tk.TclError:
            pass
        bg = '#f4f6fa'
        self.configure(background=bg)
        st.configure('.', background=bg, font=('Segoe UI', 10))
        st.configure('Header.TFrame', background='#1f2a44')
        st.configure('Header.TLabel', background='#1f2a44', foreground='white', font=('Segoe UI Semibold', 15))
        st.configure('Sub.TLabel', background='#1f2a44', foreground='#b8c4e0', font=('Segoe UI', 10))
        st.configure('Title.TLabel', font=('Segoe UI Semibold', 13))
        st.configure('Muted.TLabel', foreground='#5b6478')
        st.configure('Step.TLabel', font=('Segoe UI', 11))
        st.configure('Big.TButton', font=('Segoe UI Semibold', 11), padding=(18, 8))
        st.configure('Stop.TButton', font=('Segoe UI Semibold', 10), foreground='white', background='#c0392b')
        st.map('Stop.TButton', background=[('active', '#a93226')])
        st.configure('Approve.TButton', font=('Segoe UI Semibold', 11), foreground='white', background='#1e8449', padding=(14, 6))
        st.map('Approve.TButton', background=[('active', '#196f3d')])
        st.configure('Ask.TFrame', background='#fff4cc')
        st.configure('Ask.TLabel', background='#fff4cc', font=('Segoe UI', 10))
        st.configure('AskTitle.TLabel', background='#fff4cc', font=('Segoe UI Semibold', 11))

    def _build(self):
        head = ttk.Frame(self, style='Header.TFrame', padding=(18, 12))
        head.pack(fill='x')
        ttk.Label(head, text='JARVIS Workstation', style='Header.TLabel').pack(side='left')
        self.status_lbl = ttk.Label(head, text='', style='Sub.TLabel')
        self.status_lbl.pack(side='left', padx=16)
        self.stop_btn = ttk.Button(head, text='EMERGENCY STOP', style='Stop.TButton', command=self._toggle_stop)
        self.stop_btn.pack(side='right')
        tabs = ttk.Notebook(self)
        tabs.pack(fill='both', expand=True, padx=12, pady=10)
        self._video_tab(tabs)
        self._jobs_tab(tabs)
        self._approvals_tab(tabs)
        self._check_tab(tabs)
        self._next_tab(tabs)

    # ---------- Video -> Notes ----------
    def _video_tab(self, tabs):
        f = ttk.Frame(tabs, padding=16)
        tabs.add(f, text='  Video → Notes  ')
        ttk.Label(f, text='Turn a YouTube video into a transcript and study notes', style='Title.TLabel').grid(row=0, column=0, columnspan=4, sticky='w')
        ttk.Label(f, text='YouTube link:').grid(row=1, column=0, sticky='w', pady=(14, 4))
        self.url = tk.StringVar()
        ttk.Entry(f, textvariable=self.url, font=('Segoe UI', 11)).grid(row=1, column=1, columnspan=2, sticky='ew', pady=(14, 4), padx=6)
        ttk.Button(f, text='Paste', command=self._paste).grid(row=1, column=3, sticky='w', pady=(14, 4))
        cfg = self.pipeline.config()
        self.source = tk.StringVar(value=cfg['source'])
        self.engine = tk.StringVar(value=cfg['engine'])
        self.notes = tk.BooleanVar(value=bool(cfg['write_notes']))
        ttk.Label(f, text='Get audio from:').grid(row=2, column=0, sticky='w', pady=4)
        src = ttk.Frame(f); src.grid(row=2, column=1, columnspan=3, sticky='w')
        ttk.Radiobutton(src, text='ytmp3.zone website (watch JARVIS do it)', variable=self.source, value='ytmp3').pack(side='left')
        ttk.Radiobutton(src, text='Direct from YouTube', variable=self.source, value='direct').pack(side='left', padx=18)
        ttk.Label(f, text='Transcribe with:').grid(row=3, column=0, sticky='w', pady=4)
        eng = ttk.Frame(f); eng.grid(row=3, column=1, columnspan=3, sticky='w')
        ttk.Radiobutton(eng, text='OpenWhispr (your local model)', variable=self.engine, value='openwhispr').pack(side='left')
        ttk.Radiobutton(eng, text='Built-in Whisper', variable=self.engine, value='whisper').pack(side='left', padx=18)
        ttk.Checkbutton(f, text='Write study notes with my LM Studio model', variable=self.notes).grid(row=4, column=1, columnspan=2, sticky='w', pady=4)
        btns = ttk.Frame(f)
        btns.grid(row=5, column=0, columnspan=4, sticky='w', pady=(10, 6))
        self.start_btn = ttk.Button(btns, text='Start', style='Big.TButton', command=self._start)
        self.start_btn.pack(side='left')
        self.cancel_btn = ttk.Button(btns, text='Cancel', command=self._cancel, state='disabled')
        self.cancel_btn.pack(side='left', padx=8)

        self.ask = ttk.Frame(f, style='Ask.TFrame', padding=12)
        self.ask_title = ttk.Label(self.ask, text='', style='AskTitle.TLabel')
        self.ask_title.pack(anchor='w')
        self.ask_text = ttk.Label(self.ask, text='', style='Ask.TLabel', wraplength=880, justify='left')
        self.ask_text.pack(anchor='w', pady=(4, 8))
        ab = ttk.Frame(self.ask, style='Ask.TFrame')
        ab.pack(anchor='w')
        self.approve_btn = ttk.Button(ab, text='Approve download', style='Approve.TButton', command=lambda: self._decide(True))
        self.approve_btn.pack(side='left')
        self.deny_btn = ttk.Button(ab, text='Deny', command=lambda: self._decide(False))
        self.deny_btn.pack(side='left', padx=8)

        steps = ttk.Frame(f)
        steps.grid(row=7, column=0, columnspan=2, sticky='nw', pady=(12, 0))
        self.step_lbls = {}
        for key, label in STEPS:
            lbl = ttk.Label(steps, text=f'○  {label}', style='Step.TLabel')
            lbl.pack(anchor='w', pady=3)
            self.step_lbls[key] = (lbl, label)
        res = ttk.Frame(steps)
        res.pack(anchor='w', pady=(14, 0))
        self.open_tr = ttk.Button(res, text='Open transcript', state='disabled', command=lambda: self._open_result('transcript'))
        self.open_tr.pack(side='left')
        self.open_nt = ttk.Button(res, text='Open notes', state='disabled', command=lambda: self._open_result('notes'))
        self.open_nt.pack(side='left', padx=6)
        ttk.Button(res, text='Open folder', command=lambda: open_path(self._yt_folder())).pack(side='left')
        logf = ttk.Frame(f)
        logf.grid(row=7, column=2, columnspan=2, sticky='nsew', pady=(12, 0), padx=(12, 0))
        ttk.Label(logf, text='What JARVIS is doing', style='Muted.TLabel').pack(anchor='w')
        self.log = tk.Text(logf, height=16, wrap='word', font=('Consolas', 9), relief='flat', background='white')
        self.log.pack(fill='both', expand=True)
        self.log.configure(state='disabled')
        f.columnconfigure(1, weight=1)
        f.columnconfigure(2, weight=1)
        f.rowconfigure(7, weight=1)

    def _paste(self):
        try:
            self.url.set(self.clipboard_get().strip())
        except tk.TclError:
            pass

    def _start(self):
        try:
            canonical_video(self.url.get().strip())
            job = self.pipeline.start(self.url.get().strip(), self.source.get(), self.engine.get(), self.notes.get())
        except PolicyError as exc:
            messagebox.showerror('Cannot start', str(exc))
            return
        self.current_job = job['id']
        self._render(job)

    def _cancel(self):
        if self.current_job:
            self.jobs.cancel(self.current_job)

    def _decide(self, approve: bool, job=None):
        job = job or (self.jobs.get(self.current_job) if self.current_job else None)
        appr = (job or {}).get('approval')
        if not appr:
            return
        verb = 'APPROVE' if approve else 'DENY'
        if not messagebox.askyesno('Your decision', f'{verb} this download?\n\nVideo: {appr["url"]}\nFile: {appr["filename"]}\n'
                                   f'How: {appr["description"]}\n\nOnly approve videos you are allowed to download.'):
            return
        try:
            self.approvals.owner_decide(int(appr['request_id']), approve)
        except PolicyError as exc:
            messagebox.showerror('Could not save decision', str(exc))

    def _render(self, job):
        status, stage = job.get('status'), job.get('stage')
        running = status in ('running', 'waiting')
        self.start_btn.configure(state='disabled' if running else 'normal')
        self.cancel_btn.configure(state='normal' if running else 'disabled')
        current = STAGE_TO_STEP.get(stage)
        order = [k for k, _ in STEPS]
        cur_i = order.index(current) if current in order else -1
        for i, key in enumerate(order):
            lbl, text = self.step_lbls[key]
            if status == 'done' or i < cur_i:
                mark = '✓'
            elif i == cur_i:
                mark = '✗' if status in ('failed', 'cancelled', 'stale') else ('◆' if status == 'waiting' else '▶')
            else:
                mark = '○'
            lbl.configure(text=f'{mark}  {text}')
        need = job.get('needs_owner') if status == 'waiting' else ''
        if need:
            appr = job.get('approval') or {}
            if stage == 'awaiting_approval' and appr:
                self.ask_title.configure(text='JARVIS needs your approval to download')
                self.ask_text.configure(text=f'File: {appr.get("filename")}\nHow: {appr.get("description")}\nVideo: {appr.get("url")}')
                self.approve_btn.state(['!disabled']); self.deny_btn.state(['!disabled'])
            else:
                self.ask_title.configure(text='JARVIS needs you in the browser window')
                self.ask_text.configure(text=need)
                self.approve_btn.state(['disabled']); self.deny_btn.state(['disabled'])
            self.ask.grid(row=6, column=0, columnspan=4, sticky='ew', pady=(6, 0))
        else:
            self.ask.grid_remove()
        lines = list(job.get('log_tail') or [])
        if status in ('failed', 'cancelled', 'stale'):
            lines.append(f'{status.upper()}: {job.get("error") or job.get("detail")}')
        self.log.configure(state='normal'); self.log.delete('1.0', 'end')
        self.log.insert('end', '\n'.join(lines)); self.log.see('end'); self.log.configure(state='disabled')
        result = job.get('result') or {}
        self.open_tr.configure(state='normal' if result.get('transcript_files') else 'disabled')
        self.open_nt.configure(state='normal' if result.get('notes_file') else 'disabled')
        self._last_result = result

    def _yt_folder(self):
        p = self.settings.workspace / 'JARVIS_Brain' / 'Research' / 'YouTube'
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _open_result(self, which):
        r = getattr(self, '_last_result', {}) or {}
        rel = (r.get('transcript_files') or [''])[0] if which == 'transcript' else r.get('notes_file', '')
        if rel:
            path = self.settings.in_workspace(rel)
            webbrowser.open('obsidian://open?path=' + quote(str(path)))

    # ---------- Jobs ----------
    def _jobs_tab(self, tabs):
        f = ttk.Frame(tabs, padding=16)
        tabs.add(f, text='  Jobs  ')
        ttk.Label(f, text='Background jobs (including ones the LM Studio model started)', style='Title.TLabel').pack(anchor='w')
        cols = ('time', 'title', 'status', 'stage')
        self.jobs_tree = ttk.Treeview(f, columns=cols, show='headings', height=14)
        for c, w in zip(cols, (150, 330, 110, 300)):
            self.jobs_tree.heading(c, text=c.title()); self.jobs_tree.column(c, width=w, anchor='w')
        self.jobs_tree.pack(fill='both', expand=True, pady=8)
        b = ttk.Frame(f); b.pack(anchor='w')
        ttk.Button(b, text='Show in Video tab', command=self._follow_selected).pack(side='left')
        ttk.Button(b, text='Cancel selected', command=lambda: self._selected_job() and self.jobs.cancel(self._selected_job())).pack(side='left', padx=6)

    def _selected_job(self):
        sel = self.jobs_tree.selection()
        return sel[0] if sel else None

    def _follow_selected(self):
        jid = self._selected_job()
        if jid:
            self.current_job = jid

    # ---------- Approvals ----------
    def _approvals_tab(self, tabs):
        f = ttk.Frame(tabs, padding=16)
        tabs.add(f, text='  Approvals  ')
        ttk.Label(f, text='Download requests - JARVIS can only download what you approve here (one use, 24 h)', style='Title.TLabel').pack(anchor='w')
        cols = ('id', 'status', 'file', 'link')
        self.req_tree = ttk.Treeview(f, columns=cols, show='headings', height=14)
        for c, w in zip(cols, (50, 90, 260, 480)):
            self.req_tree.heading(c, text=c.title()); self.req_tree.column(c, width=w, anchor='w')
        self.req_tree.pack(fill='both', expand=True, pady=8)
        b = ttk.Frame(f); b.pack(anchor='w')
        ttk.Button(b, text='Approve selected', style='Approve.TButton', command=lambda: self._decide_req(True)).pack(side='left')
        ttk.Button(b, text='Deny selected', command=lambda: self._decide_req(False)).pack(side='left', padx=6)

    def _decide_req(self, approve):
        sel = self.req_tree.selection()
        if not sel:
            return
        rid = int(sel[0])
        row = next((r for r in self.approvals.list_requests() if r['id'] == rid), None)
        if not row or row['status'] != 'pending':
            messagebox.showinfo('Not pending', 'Choose a request that is still pending.'); return
        if messagebox.askyesno('Your decision', f'{"APPROVE" if approve else "DENY"}?\n\n{row["url"]}\nFile: {row["filename"]}'):
            try:
                self.approvals.owner_decide(rid, approve)
            except PolicyError as exc:
                messagebox.showerror('Could not save', str(exc))

    # ---------- System check ----------
    def _check_tab(self, tabs):
        f = ttk.Frame(tabs, padding=16)
        tabs.add(f, text='  System check  ')
        top = ttk.Frame(f); top.pack(fill='x')
        ttk.Label(top, text='Is everything JARVIS needs ready?', style='Title.TLabel').pack(side='left')
        ttk.Button(top, text='Run check', command=self._run_check).pack(side='right')
        self.check_tree = ttk.Treeview(f, columns=('ok', 'item', 'detail'), show='headings', height=16)
        for c, w in zip(('ok', 'item', 'detail'), (40, 300, 580)):
            self.check_tree.heading(c, text={'ok': '', 'item': 'Item', 'detail': 'Details / how to fix'}[c]); self.check_tree.column(c, width=w, anchor='w')
        self.check_tree.tag_configure('bad', foreground='#b03a2e')
        self.check_tree.tag_configure('good', foreground='#1e8449')
        self.check_tree.pack(fill='both', expand=True, pady=8)

    def checks(self):
        import importlib.util as iu
        out = []
        def add(ok, item, detail): out.append(('✓' if ok else '✗', item, detail))
        add(iu.find_spec('playwright') is not None, 'Browser automation (Playwright)', 'START_JARVIS.bat option 1 installs it')
        add(iu.find_spec('yt_dlp') is not None, 'yt-dlp (direct YouTube route)', 'START_JARVIS.bat 9 > 2')
        add(iu.find_spec('faster_whisper') is not None, 'Built-in Whisper', 'START_JARVIS.bat 9 > 3')
        model = self.settings.data_dir / 'models' / 'faster-whisper-base' / 'model.bin'
        add(model.is_file(), 'Built-in Whisper model', str(model) if model.is_file() else 'START_JARVIS.bat 9 > 4')
        add(bool(shutil.which('ffprobe')), 'FFmpeg / ffprobe (optional)', 'Checks audio codecs. Install: winget install Gyan.FFmpeg')
        ow = self.openwhispr.status()
        detail = (f'Model: {ow["default_model"]["model"]}' if ow.get('can_transcribe_files') else ow.get('reason', ''))
        add(bool(ow.get('can_transcribe_files')), 'OpenWhispr (open, with a local model)', detail)
        try:
            import requests
            s = requests.Session(); s.trust_env = False
            ids = [m.get('id') for m in s.get('http://127.0.0.1:1234/v1/models', timeout=3).json().get('data', [])]
            add(bool(ids), 'LM Studio server (for notes)', ', '.join(ids[:3]) or 'No model loaded')
        except Exception:
            add(False, 'LM Studio server (for notes)', 'LM Studio > Developer > Start server (port 1234)')
        try:
            from jarvis_core.browser_dom import _browser_executable
            add(True, 'Opera / Edge for the JARVIS browser', _browser_executable())
        except Exception as exc:
            add(False, 'Opera / Edge for the JARVIS browser', str(exc)[:150])
        brain = self.settings.workspace / 'JARVIS_Brain'
        add(brain.is_dir(), 'Obsidian vault', str(brain))
        add(not self.settings.kill_switch_path().exists(), 'Emergency STOP is off', 'STOP is ON - JARVIS will not act' if self.settings.kill_switch_path().exists() else 'OK')
        return out

    def _run_check(self):
        self.check_tree.delete(*self.check_tree.get_children())
        for row in self.checks():
            self.check_tree.insert('', 'end', values=row, tags=('good' if row[0] == '✓' else 'bad',))

    # ---------- Coming next ----------
    def _next_tab(self, tabs):
        f = ttk.Frame(tabs, padding=16)
        tabs.add(f, text='  Coming next  ')
        ttk.Label(f, text='Planned Workstation modules', style='Title.TLabel').pack(anchor='w', pady=(0, 8))
        for item in COMING_NEXT:
            ttk.Label(f, text='•  ' + item).pack(anchor='w', pady=3)

    # ---------- STOP + refresh ----------
    def _toggle_stop(self):
        stop = self.settings.kill_switch_path()
        if stop.exists():
            if messagebox.askyesno('Resume JARVIS', 'Remove the emergency STOP and let JARVIS act again?'):
                stop.unlink(missing_ok=True)
        else:
            stop.write_text('Owner pressed EMERGENCY STOP in JARVIS Workstation.\n', encoding='utf-8')

    def _tick(self):
        try:
            stopped = self.settings.kill_switch_path().exists()
            self.status_lbl.configure(text=('⛔ STOPPED - JARVIS will not act' if stopped else '● Ready') + f'   v{VERSION}')
            self.stop_btn.configure(text='RESUME' if stopped else 'EMERGENCY STOP')
            jobs = self.jobs.list(15)
            if self.current_job is None:
                waiting = next((j for j in jobs if j['status'] == 'waiting'), None)
                if waiting:
                    self.current_job = waiting['id']   # a job the model started needs the owner
            if self.current_job:
                self._render(self.jobs.get(self.current_job))
            sel = self.jobs_tree.selection()
            self.jobs_tree.delete(*self.jobs_tree.get_children())
            for j in jobs:
                self.jobs_tree.insert('', 'end', iid=j['id'], values=(j['created'][:19].replace('T', ' '), j['title'], j['status'], j['stage']))
            if sel and self.jobs_tree.exists(sel[0]):
                self.jobs_tree.selection_set(sel[0])
            rsel = self.req_tree.selection()
            self.req_tree.delete(*self.req_tree.get_children())
            for r in self.approvals.list_requests(30):
                self.req_tree.insert('', 'end', iid=str(r['id']), values=(r['id'], r['status'], r['filename'], r['url']))
            if rsel and self.req_tree.exists(rsel[0]):
                self.req_tree.selection_set(rsel[0])
        except (PolicyError, OSError) as exc:
            self.status_lbl.configure(text='Problem: ' + str(exc)[:120])
        self.after(800, self._tick)


if __name__ == '__main__':
    if os.name == 'nt':
        import ctypes
        if ctypes.windll.shell32.IsUserAnAdmin():
            raise SystemExit('JARVIS Workstation will not run as administrator.')
    Workstation().mainloop()
