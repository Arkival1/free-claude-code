@echo off
setlocal
cd /d "%~dp0"
title JARVIS 3.5.1 + Voice Orb
echo ============================================================
echo  STEP 1 of 2: Update JARVIS (keeps your settings and notes)
echo  Close LM Studio first.
echo ============================================================
call UPDATE_JARVIS.bat
echo.
echo ============================================================
echo  STEP 2 of 2: Install the JARVIS voice Orb
echo  Downloads it from github.com/Arkival1/free-claude-code.
echo  The first time takes a few minutes. Do not run as administrator.
echo ============================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; & ([scriptblock]::Create((Invoke-RestMethod 'https://raw.githubusercontent.com/Arkival1/free-claude-code/refs/heads/claude/funny-ramanujan-w4p3v6/scripts/install.ps1'))) -OrbOnly -Source 'https://github.com/Arkival1/free-claude-code/archive/refs/heads/claude/funny-ramanujan-w4p3v6.zip'"
if errorlevel 1 goto :failed
echo.
echo ALL DONE.
echo   1. Open LM Studio, load your model, and switch on its local server (Developer tab).
echo   2. Double-click "JARVIS Orb" on your desktop.
echo   The first time, the orb downloads Jarvis's voice once (about 120 MB).
goto :end
:failed
echo.
echo The Orb install did not finish. Read the message above, then run this file again.
:end
echo.
pause
