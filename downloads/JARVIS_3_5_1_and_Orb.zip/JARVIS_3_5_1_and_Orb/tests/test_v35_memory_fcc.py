"""v3.5: Obsidian long-term memory (offload / RAG recall / resume) and FCC orb tools."""
import io
import json
import tempfile
import threading
import unittest
import unittest.mock
import urllib.error
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from jarvis_core.fcc_bridge import FccBridge
from jarvis_core.files import FileTools
from jarvis_core.memory_vault import MemoryVault, clean_tags, clean_title
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.rag import RagIndex, chunk_markdown, tokens
from jarvis_core.vault import Vault


def make(**extra):
    d = Path(tempfile.mkdtemp())
    cfg = {'workspace': str(d / 'ws'), 'data_dir': str(d / 'data'), 'permissions': {'files': True}}
    cfg.update(extra)
    (d / 'c.json').write_text(json.dumps(cfg))
    s = Settings(d / 'c.json')
    files = FileTools(s)
    vault = Vault(s, files)
    clock = lambda: datetime(2026, 11, 27, 20, 15).astimezone()
    return s, vault, MemoryVault(s, files, vault, clock=clock)


class Offload(unittest.TestCase):
    def test_saves_note_with_front_matter_index_and_daily_link(self):
        s, vault, mem = make()
        out = mem.offload('Owner coffee: preference!', 'Owner drinks flat whites, no sugar.', 'preference', '#drinks, Food')
        self.assertEqual(out['title'], 'Owner coffee preference')
        note = (s.workspace / out['saved']).read_text(encoding='utf-8')
        self.assertTrue(note.startswith('---\ntype: memory\nkind: preference\ntags: [drinks, food]'))
        self.assertIn('# Owner coffee preference\n\nOwner drinks flat whites, no sugar.', note)
        self.assertIn('[[Memory Index]]', note)
        index = (s.workspace / 'JARVIS_Brain/Memory/Memory Index.md').read_text(encoding='utf-8')
        self.assertIn('· preference · [[Owner coffee preference]] — Owner drinks flat whites', index)
        daily = next((s.workspace / 'JARVIS_Brain/Daily').glob('*.md')).read_text(encoding='utf-8')
        self.assertIn('Memory saved: [[Owner coffee preference]]', daily)

    def test_same_title_adds_update_instead_of_duplicate(self):
        s, _, mem = make()
        mem.offload('JARVIS orb', 'Voice is George.', 'project', ['jarvis'])
        out = mem.offload('JARVIS orb', 'Speed set to 1.1.', 'project', ['voice'])
        self.assertTrue(out['updated_existing_note'])
        note = (s.workspace / out['saved']).read_text(encoding='utf-8')
        self.assertIn('Voice is George.', note); self.assertIn('## Update 2026-11-27 20:15\nSpeed set to 1.1.', note)
        self.assertIn('tags: [jarvis, voice]', note)
        self.assertEqual(note.count('---\ntype: memory'), 1)

    def test_conversations_are_dated_and_bad_input_refused(self):
        _, _, mem = make()
        self.assertEqual(mem.offload('Orb chat', 'talked', 'conversation')['title'], '2026-11-27 Orb chat')
        for bad in (dict(kind='gossip'), dict(content=''), dict(content='x' * 15001), dict(title='!!!')):
            args = {'title': 'T', 'content': 'c', 'kind': 'fact', **bad}
            with self.assertRaises(PolicyError):
                mem.offload(**args)
        self.assertEqual(clean_title('../../etc/passwd'), 'etc passwd')
        self.assertEqual(clean_tags(['#Project/JARVIS', 'a b', '']), ['project/jarvis', 'a-b'])

    def test_respects_permissions_and_stop_file(self):
        s, _, mem = make(permissions={'files': False})
        with self.assertRaises(PolicyError):
            mem.offload('T', 'c')
        s, _, mem = make()
        s.kill_switch_path().write_text('stop')
        with self.assertRaises(PolicyError):
            mem.offload('T', 'c')


class Recall(unittest.TestCase):
    def test_finds_memories_and_ordinary_notes_by_words(self):
        s, vault, mem = make()
        mem.offload('Owner birthday', 'The owner was born on 3 March. Likes chocolate cake.', 'fact')
        mem.offload('Garden plans', 'Planting tomatoes and beans in spring.', 'project')
        vault.note('Research', 'Rust ownership', 'Borrowing rules and lifetimes in Rust programs.')
        hits = mem.recall('when is the owner birthday')['matches']
        self.assertEqual(hits[0]['title'], 'Owner birthday')
        self.assertEqual(mem.recall('planted tomato')['matches'][0]['title'], 'Garden plans')   # stemming
        self.assertEqual(mem.recall('rust lifetimes')['matches'][0]['file'], 'JARVIS_Brain/Research/Rust ownership.md')
        self.assertEqual(mem.recall('quantum zebra')['matches'], [])
        self.assertIn('do not invent', mem.recall('quantum zebra')['note'])

    def test_index_is_incremental_and_notices_edits_and_deletes(self):
        s, vault, mem = make()
        mem.offload('Car', 'Blue estate car.', 'fact')
        first = mem.reindex()
        self.assertGreaterEqual(first['notes'], 2)
        self.assertEqual(mem.index().refresh()['reindexed'], 0)                 # nothing changed
        car = s.workspace / 'JARVIS_Brain/Memory/Car.md'
        car.write_text(car.read_text(encoding='utf-8').replace('Blue', 'Red'), encoding='utf-8')
        import os; os.utime(car, (car.stat().st_atime, car.stat().st_mtime + 5))
        self.assertEqual(mem.recall('red estate')['matches'][0]['title'], 'Car')
        car.unlink()
        self.assertEqual(mem.recall('red estate')['matches'], [])
        self.assertTrue((s.data_dir / 'rag_index.json').is_file())

    def test_chunks_keep_headings_and_skip_front_matter(self):
        text = '---\nkind: fact\n---\n# Title\nintro\n## Part A\n' + 'alpha words. ' * 120 + '\n## Part B\nbeta'
        chunks = chunk_markdown('Title', text, size=300)
        self.assertNotIn('kind: fact', chunks[0]['text'])
        self.assertTrue(any(c['heading'] == 'Title > Part A' for c in chunks))
        self.assertEqual(chunks[-1], {'heading': 'Title > Part B', 'text': 'beta'})
        self.assertTrue(all(len(c['text']) <= 300 for c in chunks))
        self.assertEqual(tokens("The owner's plans, planning"), ['owner', 'plan', 'plann'])

    def test_optional_embeddings_rerank(self):
        s, vault, mem = make()
        mem.offload('Alpha', 'shared word apple', 'fact')
        mem.offload('Beta', 'shared word banana', 'fact')
        def embed(texts):
            return [[1.0, 0.0] if 'banana' in t or 'yellow' in t else [0.0, 1.0] for t in texts]
        idx = RagIndex(s.workspace / 'JARVIS_Brain', s.data_dir / 'emb.json', workspace=s.workspace, embedder=embed)
        hits = idx.search('shared yellow word', 2)
        self.assertEqual(hits[0]['title'], 'Beta')
        def broken(texts):
            raise OSError('LM Studio has no embedding model')
        idx = RagIndex(s.workspace / 'JARVIS_Brain', s.data_dir / 'b.json', workspace=s.workspace, embedder=broken)
        self.assertTrue(idx.search('shared word', 2))                         # falls back to BM25


class Resume(unittest.TestCase):
    def test_briefing_has_facts_last_conversations_and_related_notes(self):
        _, _, mem = make()
        self.assertIn('fresh start', mem.resume())
        mem.offload('Owner name', 'The owner is called Spawn.', 'fact')
        mem.offload('Orb chat', '## Decisions\nUse a British voice for the orb.', 'conversation')
        brief = mem.resume('orb voice')
        self.assertIn('[[Owner name]]', brief)
        self.assertIn('## Earlier conversation: 2026-11-27 Orb chat', brief)
        self.assertIn('Use a British voice', brief)
        self.assertIn('## Notes related to "orb voice"', brief)
        self.assertLessEqual(len(mem.resume('', max_chars=500)), 500)


class FakeFcc:
    def __init__(self):
        self.said, self.asked, self.advisor_on = [], [], False
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _j(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                if self.path == '/admin/api/status':
                    self._j({'status': 'running', 'instance_id': 'x' * 32})
                elif self.path == '/orb/api/status':
                    self._j({'version': '6.3.0', 'model': 'qwen3.5-4b', 'servers': ['jarvis-clean-v3'], 'state': 'idle'})
                else:
                    self._j({}, 404)

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                if self.path == '/orb/api/advise':
                    outer.asked.append(body)
                    if outer.advisor_on:
                        self._j({'advice': 'ADVICE: use video_to_notes', 'advisor_model': 'claude-sonnet'})
                    else:
                        self._j({'advice': 'ERROR: the advisor is off. Turn it on in the orb settings.', 'advisor_model': None})
                    return
                outer.said.append(body)
                self._j({'id': len(outer.said)})

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), H)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.url = f'http://127.0.0.1:{self.server.server_address[1]}'


class Fcc(unittest.TestCase):
    def setUp(self):
        self.fake = FakeFcc()
        self.addCleanup(self.fake.server.shutdown)
        self.s, _, _ = make(fcc_url=self.fake.url)

    def test_status_and_say_through_the_orb(self):
        bridge = FccBridge(self.s)
        st = bridge.status()
        self.assertTrue(st['fcc_running']); self.assertEqual(st['orb_model'], 'qwen3.5-4b')
        self.assertEqual(st['orb_tool_servers'], ['jarvis-clean-v3'])
        self.assertEqual(bridge.say('  Notes saved, sir. ')['id'], 1)
        self.assertEqual(self.fake.said, [{'text': 'Notes saved, sir.', 'source': 'lmstudio'}])
        with self.assertRaises(PolicyError):
            bridge.say('x' * 1501)

    def test_advisor_question_only_and_off_by_default(self):
        bridge = FccBridge(self.s)
        with self.assertRaises(RuntimeError) as cm:
            bridge.ask_advisor('Which tool makes notes from a video?')
        self.assertIn('advisor is off', str(cm.exception))
        self.fake.advisor_on = True
        out = bridge.ask_advisor('  Which tool makes notes from a video?  ')
        self.assertEqual(out['advice'], 'ADVICE: use video_to_notes')
        self.assertEqual(self.fake.asked[-1], {'question': 'Which tool makes notes from a video?'})
        with self.assertRaises(PolicyError):
            bridge.ask_advisor('x' * 2001)

    def test_not_running_and_non_local_urls(self):
        s, _, _ = make(fcc_url='http://127.0.0.1:9')
        st = FccBridge(s).status()
        self.assertFalse(st['fcc_running']); self.assertIn('fcc_open_orb', st['next'])
        with self.assertRaises(RuntimeError):
            FccBridge(s).say('hello')
        for bad in ('http://example.com:8082', 'https://127.0.0.1:8082', 'http://127.0.0.1.evil.com'):
            s, _, _ = make(fcc_url=bad)
            with self.assertRaises(PolicyError):
                FccBridge(s).status()

    def test_old_fcc_without_orb_is_explained(self):
        def opener_404():
            class O:
                def open(self, req, timeout):
                    raise urllib.error.HTTPError(req.full_url, 404, 'nf', {}, io.BytesIO(b''))
            return O()
        with self.assertRaises(RuntimeError) as cm:
            FccBridge(self.s, opener=opener_404()).say('hi')
        self.assertIn('fcc-update', str(cm.exception))

    def test_open_orb_runs_fcc_orb_or_explains(self):
        calls = []
        bridge = FccBridge(self.s, popen=lambda cmd, **kw: calls.append(cmd))
        bridge.orb_command = lambda: r'C:\Users\me\.local\bin\fcc-orb.exe'
        self.assertIn('orb_url', bridge.open_orb())
        self.assertEqual(calls, [[r'C:\Users\me\.local\bin\fcc-orb.exe']])
        bridge.orb_command = lambda: None
        with self.assertRaises(RuntimeError) as cm:
            bridge.open_orb()
        self.assertIn('Arkival1/free-claude-code', str(cm.exception))


if __name__ == '__main__':
    unittest.main()


class RecallQuality(unittest.TestCase):
    def test_content_beats_link_sections_and_daily_bookkeeping(self):
        s, vault, mem = make()
        mem.offload('Owner favourite drink', 'The owner loves Earl Grey tea, no milk.', 'preference')
        hits = mem.recall('favourite drink')['matches']
        self.assertEqual(hits[0]['title'], 'Owner favourite drink')
        self.assertIn('Earl Grey', hits[0]['text'])
        self.assertFalse(any('Memory saved' in h['text'] for h in hits))
        self.assertFalse(any(h['text'].strip() == '- [[Memory Index]]' for h in hits))
        long = mem.offload('Trip', 'Going to Rome in May.\nFlights booked with BA.', 'task')
        note = (s.workspace / long['saved']).read_text(encoding='utf-8')
        self.assertIn('> Going to Rome in May.', note)


class SetupMenuOrb(unittest.TestCase):
    def test_open_orb_launches_or_explains_install(self):
        import jarvis_setup
        calls, logs = [], []
        with unittest.mock.patch.object(jarvis_setup, 'find_fcc_orb', return_value=r'C:\u\.local\bin\fcc-orb.exe'), \
             unittest.mock.patch.object(jarvis_setup, 'log', logs.append):
            self.assertTrue(jarvis_setup.open_orb(popen=calls.append))
        self.assertEqual(calls, [[r'C:\u\.local\bin\fcc-orb.exe']])
        with unittest.mock.patch.object(jarvis_setup, 'find_fcc_orb', return_value=None), \
             unittest.mock.patch.object(jarvis_setup, 'log', logs.append):
            self.assertFalse(jarvis_setup.open_orb(popen=calls.append))
        self.assertIn('Arkival1/free-claude-code/main/scripts/install.ps1', logs[-1])


class OneClick(unittest.TestCase):
    def test_install_everything_updates_jarvis_then_installs_orb_only(self):
        root = Path(__file__).resolve().parents[1]
        raw = (root / 'INSTALL_EVERYTHING.bat').read_bytes()
        self.assertIn(b'\r\n', raw)                          # Windows line endings
        text = raw.decode('ascii')
        self.assertLess(text.index('call UPDATE_JARVIS.bat'), text.index('powershell.exe'))
        self.assertIn('-OrbOnly', text)
        self.assertIn("-Source 'https://github.com/Arkival1/free-claude-code/archive/refs/heads/", text)
        self.assertIn('raw.githubusercontent.com/Arkival1/free-claude-code/', text)


class OneClickPrepare(unittest.TestCase):
    def test_install_everything_downloads_voice_and_ears_last(self):
        text = (Path(__file__).resolve().parents[1] / 'INSTALL_EVERYTHING.bat').read_text(encoding='ascii')
        self.assertLess(text.index('powershell.exe'), text.index('--prepare'))
        self.assertIn('start "" /wait "%ORB%" --prepare', text)
        self.assertIn('STEP 3 of 3', text)
