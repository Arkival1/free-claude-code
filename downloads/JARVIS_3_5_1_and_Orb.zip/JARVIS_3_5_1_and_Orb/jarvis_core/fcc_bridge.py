"""Tools for working with FCC (Free Claude Code) and its JARVIS Orb on this PC.

FCC runs a local web server (default http://127.0.0.1:8082). The orb page at /orb
speaks text aloud; /orb/api/say lets JARVIS speak through it from LM Studio.
Only 127.0.0.1/localhost addresses are ever contacted.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import urllib.error
import urllib.request
from pathlib import Path

from .policy import PolicyError

DEFAULT_URL = 'http://127.0.0.1:8082'
_LOCAL = re.compile(r'^http://(127\.0\.0\.1|localhost)(:\d{1,5})?$')
HELP = """FCC = Free Claude Code, a local server on this PC. Its JARVIS Orb is a voice window:
- The owner opens it with the "JARVIS Orb" desktop shortcut (or ask me: fcc_open_orb).
- In the orb, the owner talks or types; I answer with the LM Studio model and my tools,
  then my reply is read aloud. Older parts of long talks are saved to Obsidian Memory.
- From LM Studio chat, fcc_say(text) speaks a short message through the orb
  (e.g. "Your transcript is ready, sir."). Keep it to one or two sentences.
- fcc_ask_advisor(question): if the owner turned the advisor on in the orb settings, a
  bigger API model that can ONLY read your tool list gives advice on which tools to use.
  Ask in general terms; never include personal details, memories, files or passwords.
- fcc_status tells you if FCC and the orb are running and which model the orb uses.
- If FCC is not installed: the owner runs the installer command from the
  Arkival1/free-claude-code README once; later updates are fcc-update.
"""


class FccBridge:
    def __init__(self, settings, opener=None, popen=subprocess.Popen):
        self.settings = settings
        self._opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self._popen = popen

    def url(self) -> str:
        url = str(self.settings.data.get('fcc_url', DEFAULT_URL)).rstrip('/')
        if not _LOCAL.match(url):
            raise PolicyError('fcc_url must be a http://127.0.0.1:<port> address on this PC.')
        return url

    def _call(self, path, payload=None, timeout=4.0):
        data = None if payload is None else json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(self.url() + path, data=data,
                                     headers={'Content-Type': 'application/json'} if data else {})
        with self._opener.open(req, timeout=timeout) as response:
            return json.loads(response.read().decode('utf-8'))

    def status(self):
        try:
            server = self._call('/admin/api/status')
        except (OSError, urllib.error.URLError, ValueError):
            return {'fcc_running': False, 'url': self.url(),
                    'next': 'FCC is not running. Ask me to call fcc_open_orb, or double-click "JARVIS Orb" on the desktop.'}
        orb = {}
        try:
            orb = self._call('/orb/api/status')
        except (OSError, urllib.error.URLError, ValueError):
            pass
        return {'fcc_running': True, 'url': self.url(), 'fcc_version': orb.get('version'),
                'orb_available': bool(orb), 'orb_url': self.url() + '/orb',
                'orb_model': orb.get('model'), 'orb_tool_servers': orb.get('servers', []),
                'orb_state': orb.get('state'), 'orb_last_error': orb.get('last_error', ''),
                'server_status': server.get('status')}

    def say(self, text):
        self.settings.require_not_stopped()
        if not isinstance(text, str) or not text.strip():
            raise PolicyError('fcc_say needs the words to speak.')
        if len(text) > 1500:
            raise PolicyError('Keep spoken messages short (under 1500 characters); save long text to a note.')
        try:
            answer = self._call('/orb/api/say', {'text': text.strip(), 'source': 'lmstudio'})
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError('This FCC has no orb yet. Update FCC (fcc-update) to the Arkival1 version.') from exc
            raise RuntimeError(f'FCC refused the message (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError('FCC is not running, so nothing was spoken. Call fcc_open_orb first.') from exc
        return {'spoken_via_orb': True, 'id': answer.get('id'),
                'note': 'The orb window must be open to hear it.'}

    def ask_advisor(self, question):
        """Ask FCC's read-only advisor. It sees only this question and the tool list."""
        self.settings.require_not_stopped()
        if not isinstance(question, str) or not question.strip():
            raise PolicyError('Ask the advisor a question.')
        if len(question) > 2000:
            raise PolicyError('Keep advisor questions under 2000 characters and in general terms.')
        try:
            answer = self._call('/orb/api/advise', {'question': question.strip()}, timeout=200.0)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError('This FCC has no advisor yet. Update FCC (fcc-update).') from exc
            raise RuntimeError(f'The advisor failed (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError('FCC is not running. Call fcc_open_orb first.') from exc
        advice = str(answer.get('advice', ''))
        if advice.startswith('ERROR:'):
            raise RuntimeError(advice[6:].strip())
        return {'advice': advice, 'advisor_model': answer.get('advisor_model'),
                'note': 'Advice only. You decide and run the tools yourself.'}

    def orb_command(self):
        found = shutil.which('fcc-orb')
        if found:
            return found
        home = Path(os.environ.get('USERPROFILE') or Path.home())
        for candidate in (home / '.local' / 'bin' / 'fcc-orb.exe', home / '.local' / 'bin' / 'fcc-orb'):
            if candidate.is_file():
                return str(candidate)
        return None

    def open_orb(self):
        self.settings.require_not_stopped()
        command = self.orb_command()
        if not command:
            raise RuntimeError('FCC with the JARVIS Orb is not installed (fcc-orb not found). '
                               'Install it from the Arkival1/free-claude-code README, then try again.')
        extra = {'creationflags': 0x08000000} if os.name == 'nt' else {}    # no console window
        self._popen([command], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, **extra)
        return {'opening': command, 'orb_url': self.url() + '/orb',
                'note': 'FCC starts in the background if needed; the orb window appears in a few seconds.'}

    @staticmethod
    def help():
        return HELP
