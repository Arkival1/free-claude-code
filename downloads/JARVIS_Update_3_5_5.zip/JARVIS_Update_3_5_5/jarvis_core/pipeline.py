"""YouTube link -> audio -> local transcript -> Obsidian notes, as ONE background job - v3.2.

The steps live in tested code instead of being chained by a small model:
  1. audio: ytmp3.zone website (like a person, in the JARVIS browser) or direct YouTube (yt-dlp);
  2. OWNER APPROVAL of the exact video + format (the job waits; it can never approve itself);
  3. download + file checks;
  4. transcription: OpenWhispr's local model (via its own loopback bridge) or built-in Whisper;
  5. full transcript saved to JARVIS_Brain/Research/YouTube, then study notes written by the
     local LM Studio model (if its server is on), then a daily-journal entry.
Each stage reports progress, honours Cancel and the STOP file, and fails with a plain reason.
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime
from pathlib import Path

import requests

from .policy import PolicyError
from .converter import ffprobe_check, sniff
from .youtube import canonical_video

DEFAULTS = {'source': 'fcc', 'fallback_source': 'ytmp3', 'engine': 'fcc', 'fallback_engine': 'openwhispr',
            'write_notes': True, 'approval_wait_minutes': 30, 'human_check_wait_minutes': 15,
            'auto_approve_audio': False}
# Only these file names can ever be auto-approved: one YouTube video's audio, nothing else.
AUTO_OK = re.compile(r'[A-Za-z0-9_-]{11}(?:\.ytmp3|\.fcc)?\.(?:opus|webm|m4a|mp3)')


class OwnerSaidNo(PolicyError):
    """The owner denied a download. Stops the whole job: JARVIS never asks again by another route."""
SOURCES = ('fcc', 'ytmp3', 'direct')     # fcc = FCC downloads with yt-dlp on this PC
ENGINES = ('fcc', 'openwhispr', 'whisper')   # fcc = Whisper inside FCC, on this PC
AUDIO_EXTS = ('opus', 'webm', 'm4a', 'mp3')
LMSTUDIO = 'http://127.0.0.1:1234/v1'
NOTES_PROMPT = (
    'You turn a video transcript into study notes for an Obsidian vault. Use ONLY the transcript. '
    'Do not invent facts, names or timestamps. Write Markdown with these sections: '
    '## Summary (5-10 sentences), ## Key points (bullets, with [hh:mm:ss] timestamps when the transcript has them), '
    '## Steps shown (numbered, or "None"), ## Tools and resources mentioned, ## Questions to research. '
    'Keep your own opinions out.')


def safe_title(text: str) -> str:
    t = re.sub(r'[^A-Za-z0-9 _\-]+', ' ', text or '')
    return re.sub(r'\s+', ' ', t).strip()[:60] or 'YouTube video'


class VideoPipeline:
    def __init__(self, settings, files, vault, youtube, approvals, openwhispr, converter, jobs, fcc=None):
        self.settings, self.files, self.vault, self.youtube = settings, files, vault, youtube
        self.approvals, self.openwhispr, self.converter, self.jobs = approvals, openwhispr, converter, jobs
        self.fcc = fcc   # FCC toolkit (download + Whisper); None = not available

    def config(self) -> dict:
        cfg = dict(DEFAULTS)
        user = self.settings.data.get('video_pipeline')
        if isinstance(user, dict):
            cfg.update({k: v for k, v in user.items() if k in DEFAULTS})
        return cfg

    # ---------- entry point ----------
    def start(self, url: str, source: str = 'auto', engine: str = 'auto', write_notes=None) -> dict:
        for perm in ('downloads', 'files', 'web_research'):
            self.settings.require(perm)
        self.settings.require_not_stopped()
        canonical, vid = canonical_video(url)
        cfg = self.config()
        source = cfg['source'] if source in ('auto', '', None) else source
        engine = cfg['engine'] if engine in ('auto', '', None) else engine
        if source not in SOURCES:
            raise PolicyError('source must be auto, fcc, ytmp3 or direct.')
        if engine not in ENGINES:
            raise PolicyError('engine must be auto, fcc, openwhispr or whisper.')
        notes = cfg['write_notes'] if write_notes is None else bool(write_notes)
        job = self.jobs.start('video_to_notes', f'Video notes {vid}', self._run,
                              url=canonical, source=source, engine=engine, write_notes=notes)
        job['next'] = ('Running in the background. The owner approves the download in JARVIS Workstation '
                       '(or Control Panel > Download Requests). Check progress with job_status(job_id, wait_seconds=30).')
        return job

    # ---------- the job ----------
    def _run(self, ctx, url, source, engine, write_notes):
        canonical, vid = canonical_video(url)
        cfg = self.config()
        title = self._title(canonical) or vid
        ctx.stage('start', f'"{title}" - audio from {source}, transcript by {engine}')
        audio, last_error = None, None
        for src in dict.fromkeys([source, 'fcc', cfg['fallback_source'], 'direct']):
            if src not in SOURCES or (src == 'fcc' and self.fcc is None):
                continue
            try:
                audio = self._audio(ctx, src, canonical, vid)
                break
            except OwnerSaidNo:
                raise
            except PolicyError as exc:
                last_error = exc
                ctx.log(f'Audio via {src} failed: {exc}')
        if audio is None:
            raise last_error or PolicyError('No audio source worked.')
        transcript = self._transcribe(ctx, engine, cfg['fallback_engine'], audio)
        saved = self._save_transcript(ctx, title, canonical, audio, transcript)
        notes = self._write_notes(ctx, title, canonical, saved, transcript) if write_notes else None
        try:
            self.vault.daily(f'Made notes for YouTube video "{title}" ({canonical}). Audio: {audio["route"]} '
                             f'{audio["kind"]}. Transcript: {transcript["engine"]}, {len(transcript["text"])} characters. '
                             f'Files: {", ".join(saved["files"])}' + (f', {notes["file"]}' if notes and notes.get('file') else ''))
        except (PolicyError, OSError) as exc:
            ctx.log('Daily journal entry skipped: ' + str(exc))
        return {'video': canonical, 'title': title, 'audio_file': audio['relative'], 'audio_route': audio['route'],
                'audio_format': audio['kind'], 'transcript_engine': transcript['engine'],
                'transcript_characters': len(transcript['text']), 'transcript_files': saved['files'],
                'notes_file': (notes or {}).get('file', ''), 'notes_written_by': (notes or {}).get('model', ''),
                'next': 'Read the transcript with workspace_read or youtube_transcript_section; notes are in Obsidian.'}

    def _title(self, canonical: str) -> str:
        try:
            r = requests.get('https://www.youtube.com/oembed', params={'url': canonical, 'format': 'json'}, timeout=8)
            if r.ok:
                return str(r.json().get('title', ''))[:150]
        except (requests.RequestException, ValueError):
            pass
        return ''

    # ---------- audio ----------
    def _existing(self, vid: str, route: str):
        base = self.settings.in_workspace('Downloads/YouTube/x').parent
        tag = {'ytmp3': '.ytmp3', 'fcc': '.fcc'}.get(route, '')
        names = [f'{vid}{tag}.{e}' for e in AUDIO_EXTS]
        for name in names:
            if (base / name).is_file() and (base / name).stat().st_size > 0:
                return name
        return None

    def _audio(self, ctx, route, canonical, vid):
        found = self._existing(vid, route)
        if found:
            ctx.stage('audio', f'Using audio already downloaded earlier: {found}')
            return self._audio_info(route, found)
        if route == 'fcc':
            return self._audio_fcc(ctx, canonical, vid)
        if route == 'ytmp3':
            ctx.stage('find_format', 'Opening ytmp3.zone in the JARVIS browser and reading the real format list')
            info = self.converter.find_formats(canonical, ctx)
            choice = info.get('choice')
            if not choice:
                raise PolicyError('ytmp3.zone offered no Opus, M4A or 320 kbps MP3 for this video.')
            filename = f'{vid}.ytmp3.{choice["kind"]}'
            ctx.log(f'Formats on site: {"; ".join(info.get("formats_on_site", []))}. Chosen: {choice["text"]}')
            self._await_approval(ctx, canonical, filename, f'ytmp3.zone website, {choice["text"]}')
            max_bytes = min(int(self.settings.data.get('max_download_mb', 100)), 150) * 1024 * 1024
            res = self.converter.download(
                canonical, choice['kind'], self.settings.in_workspace('Downloads/YouTube/x').parent, filename, ctx,
                max_bytes=max_bytes, verify_wait=float(self.config()['human_check_wait_minutes']) * 60,
                # one-use approval is spent right before the click, never earlier
                before_click=lambda: self.approvals.consume_once(canonical, filename))
            ctx.log(f'Saved {res["bytes"]} bytes ({res["container"]}); check: {json.dumps(res["verification"])[:200]}')
            return self._audio_info(route, filename)
        # direct YouTube download with yt-dlp
        ctx.stage('find_format', 'Reading the video\'s audio formats from YouTube (no download yet)')
        req = self.youtube.audio_download_request(canonical)
        if req.get('status') == 'unsupported':
            raise PolicyError(req.get('reason', 'No acceptable audio format.'))
        filename = req['filename']
        fmt = req.get('format') or {}
        self._await_approval(ctx, canonical, filename, f'direct from YouTube, {fmt.get("kind", "")} {fmt.get("abr_kbps") or ""} kbps')
        ctx.stage('download', 'Downloading audio from YouTube')
        res = self.youtube.audio_download(canonical)
        ctx.log(f'Saved {res["downloaded_bytes"]} bytes; check: {json.dumps(res.get("verification"))[:200]}')
        return self._audio_info(route, filename)

    def _audio_fcc(self, ctx, canonical, vid):
        ctx.stage('find_format', 'Starting FCC (the JARVIS Orb engine) on this PC')
        try:
            self.fcc.ensure_running()
        except RuntimeError as exc:
            raise PolicyError(str(exc))
        filename = f'{vid}.fcc.m4a'
        self._await_approval(ctx, canonical, filename, 'audio only, downloaded by FCC on this PC (yt-dlp)')
        self.approvals.consume_once(canonical, filename)     # one-use approval, spent right before the download
        ctx.stage('download', 'FCC is downloading the audio from YouTube')
        folder = self.settings.in_workspace('Downloads/YouTube/x').parent
        max_bytes = min(int(self.settings.data.get('max_download_mb', 100)), 150) * 1024 * 1024
        try:
            path = self.fcc.download_youtube_audio(canonical, folder, vid, max_bytes, job_id=ctx.id)
        except RuntimeError as exc:
            raise PolicyError(str(exc))
        kind = {'webm': 'opus'}.get(path.suffix[1:], path.suffix[1:])
        try:
            real = sniff(path, kind)
            check = ffprobe_check(path)
        except PolicyError:
            path.unlink(missing_ok=True)
            raise
        ctx.log(f'FCC saved {path.stat().st_size} bytes ({real}); check: {json.dumps(check)[:200]}')
        return self._audio_info('fcc', path.name)

    def _audio_info(self, route, filename):
        rel = 'Downloads/YouTube/' + filename
        kind = filename.rsplit('.', 1)[1]
        label = {'ytmp3': 'ytmp3.zone website', 'fcc': 'FCC on this PC (yt-dlp)'}.get(route, 'direct YouTube')
        return {'route': label, 'relative': rel,
                'path': self.settings.in_workspace(rel), 'kind': 'opus' if kind == 'webm' else kind}

    def _await_approval(self, ctx, url, filename, description):
        latest = self.approvals.latest(url, filename)
        if not latest or latest['status'] not in ('pending', 'approved'):
            latest = self.approvals.request(url, filename)
            latest = {'id': latest['request_id'], 'status': latest['status']}
        if latest['status'] == 'approved':
            return
        if self.config().get('auto_approve_audio') is True and AUTO_OK.fullmatch(filename):
            # The OWNER switched this on in START_JARVIS.bat (option A). The model cannot change config.json.
            self.approvals.owner_decide(int(latest['id']), True)
            ctx.log(f'Auto-approved {filename} (owner setting "auto-approve YouTube audio" is ON).')
            return
        approval = {'request_id': latest['id'], 'url': url, 'filename': filename, 'description': description}
        ctx.set(status='waiting', approval=approval,
                needs_owner='Approve this download in JARVIS Workstation (or Control Panel > Download Requests).')
        ctx.stage('awaiting_approval', f'Waiting for YOUR approval: {filename} ({description})')
        minutes = float(self.config()['approval_wait_minutes'])
        waited = 0.0
        while waited < minutes * 60:
            ctx.sleep(2); waited += 2
            now = self.approvals.latest(url, filename)
            state = (now or {}).get('status')
            if state == 'approved':
                ctx.set(status='running', needs_owner='')
                ctx.log('Owner approved the download.')
                return
            if state == 'denied':
                ctx.set(status='running', needs_owner='')
                raise OwnerSaidNo('You denied the download, so JARVIS stopped. Nothing was downloaded.')
            if state in ('expired', None):
                ctx.set(status='running', needs_owner='')
                raise PolicyError(f'Download request was {state or "removed"}; nothing downloaded.')
        ctx.set(status='running', needs_owner='')
        raise PolicyError(f'No approval within {minutes:g} minutes; nothing downloaded. Start again when ready.')

    # ---------- transcription ----------
    def _transcribe(self, ctx, engine, fallback, audio):
        last = None
        for eng in dict.fromkeys([engine, 'fcc', fallback, 'whisper']):
            if eng not in ENGINES or (eng == 'fcc' and self.fcc is None):
                continue
            try:
                if eng == 'fcc':
                    try:
                        self.fcc.ensure_running()
                        ctx.stage('transcribe', 'Whisper inside FCC is transcribing on this PC (this can take a while)')
                        out = self.fcc.transcribe_file(audio['path'], job_id=ctx.id)
                    except RuntimeError as exc:
                        raise PolicyError(str(exc))
                    if not out['lines']:
                        raise PolicyError('FCC Whisper found no speech in the audio.')
                    return {'text': '\n'.join(out['lines']), 'engine': out['model'], 'timestamps': True}
                if eng == 'openwhispr':
                    st = self.openwhispr.status()
                    if not st.get('can_transcribe_files'):
                        raise PolicyError('OpenWhispr not ready: ' + st.get('reason', 'unknown'))
                    model = (st.get('default_model') or {}).get('model', '')
                    ctx.stage('transcribe', f'OpenWhispr is transcribing with its local model {model} (this can take a while)')
                    out = self.openwhispr.transcribe(audio['path'])
                    if not out['text'].strip():
                        raise PolicyError('OpenWhispr found no speech in the audio.')
                    return {'text': out['text'].strip(), 'engine': f'OpenWhispr ({out["model"] or model}, local)', 'timestamps': False}
                ctx.stage('transcribe', 'Built-in Whisper is transcribing on the CPU (this can take a while)')
                out = self.youtube.transcribe_full(audio['relative'])
                if not out['lines']:
                    raise PolicyError('Whisper found no speech in the audio.')
                return {'text': '\n'.join(out['lines']), 'engine': out['engine'], 'timestamps': True}
            except PolicyError as exc:
                last = exc
                ctx.log(f'Transcription with {eng} failed: {exc}')
        raise last or PolicyError('No transcription engine worked.')

    # ---------- saving ----------
    def _unique(self, rel: str) -> str:
        stem, n = rel[:-3], 1
        while self.settings.in_workspace(rel).exists():
            n += 1
            rel = f'{stem} {n}.md'
        return rel

    def _save_transcript(self, ctx, title, canonical, audio, transcript):
        ctx.stage('save', 'Saving the full transcript to Obsidian (Research/YouTube)')
        name = f'{safe_title(title)} Transcript'
        header = (f'# {title} - Transcript\n\n- Video: {canonical}\n- Audio: {audio["route"]}, {audio["kind"]} '
                  f'(`{audio["relative"]}`)\n- Transcribed by: {transcript["engine"]}\n'
                  f'- Saved: {datetime.now():%Y-%m-%d %H:%M}\n- Links: [[Research]] [[{safe_title(title)} Notes]]\n\n')
        limit = int(self.settings.data.get('max_file_kb', 256)) * 1024 - 4096
        text = transcript['text']
        if not transcript.get('timestamps'):
            text = re.sub(r'([.!?])\s+', r'\1\n', text)   # one sentence per line, easier to read and split
        lines = []
        for line in text.splitlines() or [text]:
            while len(line.encode('utf-8')) > limit // 2:      # hard-wrap absurdly long lines
                lines.append(line[:2000]); line = line[2000:]
            lines.append(line)
        parts, current = [], ''
        for line in lines:
            if len((current + line).encode('utf-8')) > limit and current:
                parts.append(current); current = ''
            current += line + '\n'
        parts.append(current)
        files = []
        for i, body in enumerate(parts, 1):
            suffix = f' Part {i}' if len(parts) > 1 else ''
            rel = self._unique(f'JARVIS_Brain/Research/YouTube/{name}{suffix}.md')
            self.files.write_text(rel, header + ('## Transcript' + suffix + '\n\n') + body)
            files.append(rel)
        # Read back: prove the text really landed.
        back = self.files.read_text(files[0])
        if parts[0].strip()[:200] not in back:
            raise PolicyError('Transcript file did not read back correctly.')
        ctx.log(f'Transcript saved and read back: {", ".join(files)}')
        return {'files': files}

    def _lmstudio_model(self, session):
        r = session.get(LMSTUDIO + '/models', timeout=5)
        r.raise_for_status()
        ids = [m.get('id') for m in r.json().get('data', []) if isinstance(m, dict)]
        ids = [i for i in ids if i and 'embed' not in i.casefold()]
        if not ids:
            raise PolicyError('No chat model is loaded in LM Studio.')
        return ids[0]

    def _write_notes(self, ctx, title, canonical, saved, transcript):
        name = f'{safe_title(title)} Notes'
        rel = self._unique(f'JARVIS_Brain/Research/YouTube/{name}.md')
        header = (f'# {title} - Notes\n\n- Video: {canonical}\n- Transcript: '
                  + ' '.join(f'[[{Path(f).stem}]]' for f in saved['files']) + '\n- Links: [[Research]] [[Knowledge Wiki]] [[Skills]]\n\n')
        session = requests.Session(); session.trust_env = False
        try:
            ctx.stage('notes', 'Asking your local LM Studio model to write study notes from the transcript')
            model = self._lmstudio_model(session)
            tokens = int(self.settings.data.get('context_tokens', 8192))
            chunk = max(6000, int(tokens * 2.4))       # ~2.4 characters per token, leaving room for the answer
            text = transcript['text']
            pieces = [text[i:i + chunk] for i in range(0, len(text), chunk)][:12]
            total = len(pieces) + (1 if len(pieces) > 1 else 0)      # parts + the final merge
            partial = []
            for n, p in enumerate(pieces, 1):
                ctx.set(progress=round((n - 1) * 100 / total, 1),
                        detail=f'Your LM Studio model is writing notes: part {n} of {len(pieces)}')
                partial.append(self._ask(session, model, f'Transcript part {n}/{len(pieces)}:\n\n{p}', ctx))
            if len(partial) == 1:
                body = partial[0]
            else:
                ctx.set(progress=round(len(pieces) * 100 / total, 1), detail='Your LM Studio model is merging the notes')
                body = self._ask(session, model, 'Merge these partial notes of ONE video into one set of notes with the same sections:\n\n'
                                 + '\n\n---\n\n'.join(partial), ctx)
            ctx.set(progress=100.0)
            note = header + f'_Written by the local model `{model}` from the transcript only. Check important facts._\n\n' + body.strip() + '\n'
            used = model
        except (requests.RequestException, ValueError, KeyError, PolicyError) as exc:
            ctx.log('AI notes skipped: ' + str(exc)[:200])
            note = header + ('_LM Studio\'s server was not available, so no AI notes were written._\n'
                             'Ask JARVIS: "Write study notes from the transcript linked above."\n')
            used = ''
        finally:
            session.close()
        cap = int(self.settings.data.get('max_file_kb', 256)) * 1024 - 1024
        self.files.write_text(rel, note.encode('utf-8')[:cap].decode('utf-8', 'ignore'))
        ctx.log('Notes saved: ' + rel)
        return {'file': rel, 'model': used}

    def _ask(self, session, model, content, ctx):
        ctx.check()
        if 'qwen' in str(model).lower():
            content += '\n\n/no_think'      # Qwen: skip long hidden thinking; notes come much faster
        body = {'model': model, 'temperature': 0.3, 'max_tokens': 4096,
                'messages': [{'role': 'system', 'content': NOTES_PROMPT}, {'role': 'user', 'content': content}]}
        answer = {}

        def call():
            try:
                answer['r'] = session.post(LMSTUDIO + '/chat/completions', timeout=(10, 1800), json=body)
            except Exception as exc:   # handed back to the job below
                answer['e'] = exc
        worker = threading.Thread(target=call, name='jarvis-notes-request', daemon=True)
        worker.start()
        while worker.is_alive():
            ctx.sleep(3)                     # heartbeat: the job is alive while the model writes (and can be cancelled)
        if 'e' in answer:
            raise answer['e']
        r = answer['r']
        r.raise_for_status()
        text = r.json()['choices'][0]['message'].get('content') or ''
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.S).strip()  # drop Qwen thinking blocks
        if not text:
            raise PolicyError('The model returned empty notes.')
        return text
