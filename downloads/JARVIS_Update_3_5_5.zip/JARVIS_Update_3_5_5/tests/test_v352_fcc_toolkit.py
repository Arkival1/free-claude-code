"""v3.5.2: FCC as JARVIS's local toolkit - downloads YouTube audio and transcribes it on this PC."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from jarvis_core import pipeline as pl  # noqa: E402
import test_v32_pipeline as base  # noqa: E402
URL, wait_for = base.URL, base.wait_for


class FakeFcc:
    def __init__(self, fail_download=None, fail_transcribe=None, payload=b'\x00\x00\x00\x18ftypM4A ' + b'\x00' * 64):
        self.calls, self.fail_download, self.fail_transcribe, self.payload = [], fail_download, fail_transcribe, payload

    def ensure_running(self):
        self.calls.append('start')
        return True

    def download_youtube_audio(self, url, dest_dir, vid, max_bytes, job_id=None):
        self.job_ids = getattr(self, 'job_ids', []) + [job_id]
        self.calls.append('download')
        if self.fail_download:
            raise RuntimeError(self.fail_download)
        path = Path(dest_dir) / f'{vid}.fcc.m4a'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.payload)
        return path

    def transcribe_file(self, path, job_id=None):
        self.job_ids = getattr(self, 'job_ids', []) + [job_id]
        self.calls.append('transcribe')
        if self.fail_transcribe:
            raise RuntimeError(self.fail_transcribe)
        return {'lines': ['[00:00:01] Welcome back.', '[00:00:05] Step one is to plan.'], 'model': 'Whisper base.en (FCC, on this PC)'}


class FccToolkit(base.PipelineTests):
    # Run only this file's tests, not the inherited ytmp3/OpenWhispr ones.
    test_full_run_waits_for_owner_then_saves_transcript_and_notes = None
    test_denied_means_nothing_downloaded = None
    test_openwhispr_closed_falls_back_to_builtin_whisper = None
    test_reuses_audio_already_downloaded = None
    test_bad_inputs_and_permissions = None

    def run_job(self, fcc, auto=True):
        self.build(video_pipeline={'auto_approve_audio': auto})
        self.p.fcc = fcc
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}):
            job = self.p.start(URL, write_notes=False)
            return wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)

    def test_fcc_downloads_and_transcribes_on_this_pc(self):
        fcc = FakeFcc()
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        r = done['result']
        self.assertEqual(fcc.calls, ['start', 'download', 'start', 'transcribe'])
        self.assertEqual(r['audio_route'], 'FCC on this PC (yt-dlp)')
        self.assertEqual(r['audio_file'], 'Downloads/YouTube/WftF2zJkvHY.fcc.m4a')
        self.assertIn('FCC', r['transcript_engine'])
        self.assertIn('[00:00:05] Step one is to plan.', self.files.read_text(r['transcript_files'][0]))
        self.assertEqual(self.conv.calls, [])                         # the ytmp3 website was never opened
        self.assertEqual(fcc.job_ids, [done['id'], done['id']])       # FCC's % goes on this job's bar

    def test_waits_for_owner_approval_before_fcc_downloads(self):
        fcc = FakeFcc()
        self.build()
        self.p.fcc = fcc
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}):
            job = self.p.start(URL, write_notes=False)
            waiting = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] == 'waiting' and j)
            self.assertEqual(waiting['approval']['filename'], 'WftF2zJkvHY.fcc.m4a')
            self.assertEqual(fcc.calls, ['start'])                    # nothing downloaded yet
            self.approve_when_asked()
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)

    def test_fcc_download_fails_then_ytmp3_website_is_used(self):
        fcc = FakeFcc(fail_download='YouTube asked to confirm you are not a bot.')
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        self.assertEqual(self.conv.calls, ['find', 'download'])
        self.assertEqual(fcc.calls[:2], ['start', 'download'])       # FCC was tried first
        self.assertIn('FCC', done['result']['transcript_engine'])    # FCC still transcribes the website's file

    def test_not_audio_is_deleted(self):
        fcc = FakeFcc(payload=b'MZ\x90\x00 this is an exe')
        done = self.run_job(fcc)
        self.assertFalse((self.root / 'ws/Downloads/YouTube/WftF2zJkvHY.fcc.m4a').exists())
        self.assertEqual(done['status'], 'done', done)               # the website route took over
        self.assertEqual(done['result']['audio_route'], 'ytmp3.zone website')

    def test_fcc_transcription_fails_then_openwhispr(self):
        fcc = FakeFcc(fail_transcribe='Whisper is not downloaded yet. Run fcc-orb --prepare.')
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        self.assertIn('OpenWhispr', done['result']['transcript_engine'])
        self.assertIn('fcc-orb --prepare', '\n'.join(done['log_tail']))

    def test_model_picking_openwhispr_still_falls_back_to_fcc(self):
        # The owner's run: the model passed engine="openwhispr" while OpenWhispr was closed.
        fcc = FakeFcc()
        self.build(video_pipeline={'auto_approve_audio': True})
        self.p.fcc = fcc
        self.srv.shutdown()                                           # OpenWhispr is closed
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}), \
             patch.object(self.p.openwhispr, 'status', lambda: {'can_transcribe_files': False, 'reason': 'not running'}):
            job = self.p.start(URL, source='ytmp3', engine='openwhispr', write_notes=False)
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)
        self.assertIn('FCC', done['result']['transcript_engine'])


if __name__ == '__main__':
    unittest.main()


class LiveActivity(unittest.TestCase):
    def make(self):
        from jarvis_core.fcc_bridge import FccBridge
        settings = base.make_settings(Path(__import__('tempfile').mkdtemp()), fcc_url='http://127.0.0.1:18082')
        bridge = FccBridge(settings)
        sent = []
        bridge._send_later = sent.append
        return bridge, sent

    def test_video_job_stages_become_progress_steps(self):
        bridge, sent = self.make()
        job = {'id': 'j1', 'kind': 'video_to_notes', 'title': 'Video notes x', 'status': 'running', 'stage': 'download',
               'detail': 'FCC is downloading', 'log': ['00:40:25 download: FCC is downloading the audio']}
        bridge.report_job(job)
        bridge.report_job(dict(job))                                  # same again: not re-sent
        bridge.report_job(dict(job, stage='transcribe', log=job['log'] + ['00:40:30 transcribe: Whisper']))
        self.assertEqual(len(sent), 2)
        self.assertEqual((sent[0]['step'], sent[0]['steps'], sent[0]['step_name']), (2, 6, 'Downloading audio'))
        self.assertTrue(sent[0]['reset_percent'] and sent[1]['reset_percent'])
        self.assertEqual(sent[1]['step_name'], 'Transcribing')
        self.assertEqual(sent[1]['log'][-1], 'transcribe: Whisper')  # clock prefix dropped
        bridge.report_job(dict(job, stage='awaiting_approval', status='waiting', needs_owner='Approve this download'))
        self.assertEqual((sent[2]['status'], sent[2]['detail']), ('waiting', 'Approve this download'))
        bridge.report_job(dict(job, stage='notes', progress=50.0, detail='part 2 of 4'))
        self.assertEqual((sent[3]['step_name'], sent[3]['percent']), ('Writing notes', 50.0))
        self.assertNotIn('reset_percent', sent[3])                    # its own % is kept, not wiped
        bridge.report_job(dict(job, stage='done', status='done'))
        self.assertEqual(sent[4]['step'], 6)

    def test_jobs_report_every_change_and_survive_reporter_errors(self):
        from jarvis_core.jobs import Jobs
        import tempfile
        settings = base.make_settings(Path(tempfile.mkdtemp()))
        seen = []
        jobs = Jobs(settings, reporter=lambda data: seen.append(data['stage']))

        def work(ctx):
            ctx.stage('download', 'x')
            return {'ok': True}
        job = jobs.start('video_to_notes', 'T', work)
        wait_for(lambda: jobs.get(job['id'])['status'] == 'done')
        self.assertIn('download', seen); self.assertIn('done', seen)
        def broken(data):
            raise RuntimeError('display crashed')
        jobs2 = Jobs(settings, reporter=broken)
        job2 = jobs2.start('video_to_notes', 'T2', work)
        self.assertEqual(wait_for(lambda: jobs2.get(job2['id'])['status'] == 'done' and 'ok'), 'ok')


class SlowNotes(base.PipelineTests):
    test_full_run_waits_for_owner_then_saves_transcript_and_notes = None
    test_denied_means_nothing_downloaded = None
    test_openwhispr_closed_falls_back_to_builtin_whisper = None
    test_reuses_audio_already_downloaded = None
    test_bad_inputs_and_permissions = None

    def test_slow_model_never_looks_stale_and_reports_parts(self):
        import json
        import threading
        import time
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from jarvis_core import jobs as jobs_mod
        asked = []

        class Slow(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, obj):
                b = json.dumps(obj).encode()
                self.send_response(200); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                self._json({'data': [{'id': 'qwen3.5-4b'}]})

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                asked.append(body['messages'][-1]['content'])
                time.sleep(3)                                          # slower than the stale limit below
                self._json({'choices': [{'message': {'content': '## Summary\nGood video.'}}]})
        srv = ThreadingHTTPServer(('127.0.0.1', 0), Slow)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.shutdown)
        self.build(video_pipeline={'auto_approve_audio': True}, context_tokens=2500)
        fcc = FakeFcc()
        long_lines = [f'[00:{i // 60:02d}:{i % 60:02d}] sentence number {i} about planning the garden' for i in range(400)]
        fcc.transcribe_file = lambda path, job_id=None: {'lines': long_lines, 'model': 'Whisper (FCC)'}
        self.p.fcc = fcc
        seen_status, seen_progress = set(), []
        with patch.object(pl, 'LMSTUDIO', f'http://127.0.0.1:{srv.server_address[1]}/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}), \
             patch.object(jobs_mod, 'STALE_AFTER_SECONDS', 2):
            job = self.p.start(URL)
            end = time.monotonic() + 60
            while time.monotonic() < end:
                j = self.jobs.get(job['id'])
                seen_status.add(j['status'])
                raw = self.jobs._read(job['id'])
                if raw.get('progress') is not None:
                    seen_progress.append(raw['progress'])
                if j['status'] in ('done', 'failed'):
                    break
                time.sleep(0.3)
        self.assertEqual(j['status'], 'done', j)
        self.assertNotIn('stale', seen_status)                        # heartbeat while the model writes
        self.assertGreater(len(asked), 2)                             # several parts + a merge
        self.assertTrue(all(a.endswith('/no_think') for a in asked))  # Qwen thinking switched off
        self.assertEqual(seen_progress[-1], 100.0)
        self.assertTrue(any(0 < p < 100 for p in seen_progress))
        self.assertIn('Good video.', self.files.read_text(j['result']['notes_file']))
