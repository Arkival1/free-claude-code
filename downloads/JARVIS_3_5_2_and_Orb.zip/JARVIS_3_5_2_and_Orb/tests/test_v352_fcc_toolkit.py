"""v3.5.2: FCC as JARVIS's local toolkit - downloads YouTube audio and transcribes it on this PC."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from jarvis_core import pipeline as pl  # noqa: E402
import test_v32_pipeline as base  # noqa: E402
URL, wait_for = base.URL, base.wait_for


class FakeFcc:
    def __init__(self, fail_download=None, fail_transcribe=None, payload=b'\x00\x00\x00\x18ftypM4A ' + b'\x00' * 64):
        self.calls, self.fail_download, self.fail_transcribe, self.payload = [], fail_download, fail_transcribe, payload

    def ensure_running(self):
        self.calls.append('start')
        return True

    def download_youtube_audio(self, url, dest_dir, vid, max_bytes):
        self.calls.append('download')
        if self.fail_download:
            raise RuntimeError(self.fail_download)
        path = Path(dest_dir) / f'{vid}.fcc.m4a'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.payload)
        return path

    def transcribe_file(self, path):
        self.calls.append('transcribe')
        if self.fail_transcribe:
            raise RuntimeError(self.fail_transcribe)
        return {'lines': ['[00:00:01] Welcome back.', '[00:00:05] Step one is to plan.'], 'model': 'Whisper base.en (FCC, on this PC)'}


class FccToolkit(base.PipelineTests):
    # Run only this file's tests, not the inherited ytmp3/OpenWhispr ones.
    test_full_run_waits_for_owner_then_saves_transcript_and_notes = None
    test_denied_means_nothing_downloaded = None
    test_openwhispr_closed_falls_back_to_builtin_whisper = None
    test_reuses_audio_already_downloaded = None
    test_bad_inputs_and_permissions = None

    def run_job(self, fcc, auto=True):
        self.build(video_pipeline={'auto_approve_audio': auto})
        self.p.fcc = fcc
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}):
            job = self.p.start(URL, write_notes=False)
            return wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)

    def test_fcc_downloads_and_transcribes_on_this_pc(self):
        fcc = FakeFcc()
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        r = done['result']
        self.assertEqual(fcc.calls, ['start', 'download', 'start', 'transcribe'])
        self.assertEqual(r['audio_route'], 'FCC on this PC (yt-dlp)')
        self.assertEqual(r['audio_file'], 'Downloads/YouTube/WftF2zJkvHY.fcc.m4a')
        self.assertIn('FCC', r['transcript_engine'])
        self.assertIn('[00:00:05] Step one is to plan.', self.files.read_text(r['transcript_files'][0]))
        self.assertEqual(self.conv.calls, [])                         # the ytmp3 website was never opened

    def test_waits_for_owner_approval_before_fcc_downloads(self):
        fcc = FakeFcc()
        self.build()
        self.p.fcc = fcc
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'), \
             patch.object(pl, 'ffprobe_check', lambda path: {'codec_checked': False}):
            job = self.p.start(URL, write_notes=False)
            waiting = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] == 'waiting' and j)
            self.assertEqual(waiting['approval']['filename'], 'WftF2zJkvHY.fcc.m4a')
            self.assertEqual(fcc.calls, ['start'])                    # nothing downloaded yet
            self.approve_when_asked()
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)

    def test_fcc_download_fails_then_ytmp3_website_is_used(self):
        fcc = FakeFcc(fail_download='YouTube asked to confirm you are not a bot.')
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        self.assertEqual(self.conv.calls, ['find', 'download'])
        self.assertEqual(fcc.calls[:2], ['start', 'download'])       # FCC was tried first
        self.assertIn('FCC', done['result']['transcript_engine'])    # FCC still transcribes the website's file

    def test_not_audio_is_deleted(self):
        fcc = FakeFcc(payload=b'MZ\x90\x00 this is an exe')
        done = self.run_job(fcc)
        self.assertFalse((self.root / 'ws/Downloads/YouTube/WftF2zJkvHY.fcc.m4a').exists())
        self.assertEqual(done['status'], 'done', done)               # the website route took over
        self.assertEqual(done['result']['audio_route'], 'ytmp3.zone website')

    def test_fcc_transcription_fails_then_openwhispr(self):
        fcc = FakeFcc(fail_transcribe='Whisper is not downloaded yet. Run fcc-orb --prepare.')
        done = self.run_job(fcc)
        self.assertEqual(done['status'], 'done', done)
        self.assertIn('OpenWhispr', done['result']['transcript_engine'])
        self.assertIn('fcc-orb --prepare', '\n'.join(done['log_tail']))


if __name__ == '__main__':
    unittest.main()
