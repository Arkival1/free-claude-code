@echo off
setlocal
cd /d "%~dp0"
title JARVIS 3.5.2 + Voice Orb (everything runs on this PC)
echo ============================================================
echo  STEP 1 of 3: Update JARVIS (keeps your settings and notes)
echo  Close LM Studio first.
echo ============================================================
call UPDATE_JARVIS.bat
echo.
echo ============================================================
echo  STEP 2 of 3: Install the JARVIS voice Orb
echo  Downloads it from github.com/Arkival1/free-claude-code.
echo  The first time takes a few minutes. Do not run as administrator.
echo ============================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; & ([scriptblock]::Create((Invoke-RestMethod 'https://raw.githubusercontent.com/Arkival1/free-claude-code/refs/heads/claude/funny-ramanujan-w4p3v6/scripts/install.ps1'))) -OrbOnly -Source 'https://github.com/Arkival1/free-claude-code/archive/refs/heads/claude/funny-ramanujan-w4p3v6.zip'"
if errorlevel 1 goto :failed
echo.
echo ============================================================
echo  STEP 3 of 3: Download JARVIS's voice and ears (one time, about 270 MB)
echo  After this, the orb never needs the internet.
echo ============================================================
set "ORB=%USERPROFILE%\.local\bin\fcc-orb.exe"
if not exist "%ORB%" for /f "delims=" %%i in ('where fcc-orb 2^>nul') do set "ORB=%%i"
if exist "%ORB%" (
    echo Downloading... this can take several minutes. Please wait.
    start "" /wait "%ORB%" --prepare
    type "%USERPROFILE%\.fcc\orb_prepare.log" 2>nul
) else (
    echo Could not find fcc-orb yet. The orb will download them the first time it opens.
)
echo.
echo ALL DONE.
echo   1. Open LM Studio, load your model, and switch on its local server (Developer tab).
echo   2. Double-click "JARVIS Orb" on your desktop.
echo   Voice, ears and memory all run on this PC.
goto :end
:failed
echo.
echo The Orb install did not finish. Read the message above, then run this file again.
:end
echo.
pause
