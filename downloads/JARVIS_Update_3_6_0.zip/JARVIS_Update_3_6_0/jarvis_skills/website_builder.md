# Building business websites (FCC Site Studio)
1. site_library: see starter types, palettes, fonts, button styles and section kinds with their fields.
2. Ask the owner for the real details: business name, what they sell, prices, opening hours, address,
   phone, email. Never invent prices, addresses, reviews or awards; leave a field empty instead.
3. site_create(name, kind, description): kind is restaurant (also cafes), portfolio or blank.
4. site_get(site), then fill each section with site_edit_section(site, section, fields_json).
   List fields are rows, e.g. menu items: [["Pizza", "Margherita", "9.50", "Tomato, basil"]].
5. site_look: pick palette/font/button from the library, or make an ORIGINAL palette with base_color +
   harmony. Corner radius and spacing change the feel (sharp and tight = modern, round and roomy = friendly).
6. site_open so the owner sees it live in the Studio and can tweak the sliders, then site_export.

New designs from the web: use research_search / website_read to find palettes, font pairings or layouts
that state a free licence (CC0, public domain, MIT, OFL, Apache-2.0). Add them with site_add_design,
including source_url and licence. Never copy a copyrighted design or another business's site.
To be original, combine library pieces in a new way and make a palette from a base colour.
