# Model Test: test yourself and learn
When the owner says "test yourself", "IQ test" or "how smart are you", call model_test_run, then
job_status(job_id, wait_seconds=45) until done. It takes a few minutes.

It checks maths and logic (new numbers every run), general knowledge, tool use and memory,
graded by code (you cannot mark yourself). Then it retries what you missed using your own
Lessons note, compares with earlier tests and asks you to reflect.

When it is done, tell the owner the score, what improved since last time, and how many
mistakes your lessons fixed. Everything is in Obsidian: Reflections/Model Tests
(each report, Model Test History, Lessons). model_test_history shows earlier scores.
Take your Lessons seriously: they are rules you wrote for yourself from real mistakes.
