"""Single owner-operated menu/installer for clean local JARVIS on Windows.

No registry writes, no uninstall of an old JARVIS, no manipulation of LM Studio's
MCP configuration or Obsidian files. All pip installs need owner confirmation.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VENV_PY = ROOT / '.venv' / 'Scripts' / 'python.exe'
CONFIG = ROOT / 'config.json'
SNIPPET = ROOT / 'LM_STUDIO_SNIPPET.json'


def log(s=''):
    print(s, flush=True)


def run(cmd, *, check=True):
    log('RUNNING: ' + ' '.join(str(x) for x in cmd))
    result = subprocess.run([str(x) for x in cmd], cwd=str(ROOT), check=False)
    if check and result.returncode:
        raise RuntimeError(f'Command failed with exit code {result.returncode}: {cmd[0]}')
    return result.returncode


def yes(prompt):
    return input(prompt + ' [y/N]: ').strip().lower() in ('y', 'yes')


def workspace_candidates(home: Path) -> list[Path]:
    return [
        home / 'OneDrive' / 'Desktop' / 'CJARVIS_Workspace',
        home / 'Desktop' / 'CJARVIS_Workspace',
        home / 'OneDrive' / 'Desktop' / 'JARVIS_Workspace',
        home / 'Desktop' / 'JARVIS_Workspace',
        home / 'Documents' / 'JARVIS_Workspace',
    ]


def suggest_workspace(home: Path) -> Path:
    for candidate in workspace_candidates(home)[:-1]:
        if (candidate / 'JARVIS_Brain').is_dir():
            return candidate
    for candidate in workspace_candidates(home)[:-1]:
        if candidate.is_dir():
            return candidate
    return workspace_candidates(home)[-1]


def build_config(workspace: Path) -> dict:
    from jarvis_core.policy import DEFAULT_CONFIG
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    cfg['workspace'] = str(workspace)
    cfg['data_dir'] = r'%LOCALAPPDATA%\JARVIS_Clean_v3\data'
    cfg['desktop_mode'] = 'all_user_apps'
    return cfg


def write_config_if_missing(workspace: Path) -> bool:
    """Never replace an existing configuration, even if its contents are invalid."""
    if CONFIG.exists():
        log(f'Existing config preserved: {CONFIG}')
        return False
    cfg = build_config(workspace)
    # Do not silently overwrite a file created by another process.
    with CONFIG.open('x', encoding='utf-8') as handle:
        json.dump(cfg, handle, indent=2)
        handle.write('\n')
    log(f'Created new config: {CONFIG}')
    return True


def write_snippet(python_path=VENV_PY, server_path=None) -> Path:
    server_path = server_path or (ROOT / 'server.py')
    if not python_path.is_file():
        raise RuntimeError('Setup incomplete: local .venv Python not found. Use option 1 first.')
    if not server_path.is_file():
        raise RuntimeError('Incomplete extraction: server.py missing. Extract the entire ZIP.')
    data = {'mcpServers': {'jarvis-clean-v3': {
        'command': str(python_path.resolve()),
        'args': [str(server_path.resolve())],
    }}}
    SNIPPET.write_text(json.dumps(data, indent=2), encoding='utf-8')
    log(f'LM Studio connection written to {SNIPPET}')
    return SNIPPET


def ensure_environment():
    if os.name != 'nt':
        raise RuntimeError('This installer is for Windows only.')
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 or newer required. Install it from python.org.')
    if not VENV_PY.is_file():
        log('Creating fresh private Python environment inside this JARVIS folder...')
        run([sys.executable, '-m', 'venv', str(ROOT / '.venv')])
    if not VENV_PY.is_file():
        raise RuntimeError('venv setup did not produce .venv\\Scripts\\python.exe')
    # Run all pip operations with exact interpreter later given to LM Studio.
    return VENV_PY


def install_dependencies(requirements: str):
    file = ROOT / requirements
    if not file.is_file():
        raise RuntimeError(f'Missing {requirements}. Extract the whole ZIP again.')
    run([VENV_PY, '-m', 'pip', 'install', '-r', file])


def verify_python_dependencies():
    if not VENV_PY.is_file():
        raise RuntimeError('Missing .venv Python. Choose Setup/Repair first.')
    run([VENV_PY, '-c',
         'from mcp.server.fastmcp import FastMCP; '
         'from playwright.sync_api import sync_playwright; '
         'import requests, PIL, pyautogui; '
         'print("OK: Core MCP, Playwright, requests, Pillow, PyAutoGUI all import in THIS Python")'])


def setup():
    log('\n=== JARVIS CLEAN v3.4 - ONE-TIME SETUP / REPAIR ===')
    log('This is a separate installation. Your old JARVIS and Obsidian notes are not removed.')
    log('Browser Playwright package will be installed in the SAME environment LM Studio will use.')
    log('Packages download from Python package indexes; no remote AI model is used.')
    log(f'Program folder: {ROOT}')
    if 'onedrive' in str(ROOT).lower():
        log('TIP: Program installation is more reliable outside OneDrive; chat notes may still use OneDrive.')
    if CONFIG.exists():
        try:
            cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
            log(f'Existing workspace preserved: {cfg.get("workspace", "(not configured)")}')
        except (OSError, ValueError):
            raise RuntimeError('config.json is invalid. Back it up and fix the JSON; setup will not overwrite it.')
    else:
        default = suggest_workspace(Path.home())
        log('\nChoose where JARVIS will read/write workspace files and Obsidian notes.')
        log('If you already have JARVIS_Brain, REUSE its PARENT CJARVIS_Workspace folder.')
        log(f'Proposed workspace: {default}')
        choice = input('Workspace folder [Enter for proposed, or paste exact path]: ').strip().strip('"')
        workspace = Path(choice).expanduser() if choice else default
        if not workspace.is_absolute():
            raise RuntimeError('Workspace must be a complete absolute path, e.g. C:\\Users\\...')
        workspace = workspace.resolve(strict=False)
        if workspace.name.casefold() == 'jarvis_brain':
            raise RuntimeError('Select the PARENT workspace folder, not JARVIS_Brain itself.')
        if (workspace / 'JARVIS_Brain').is_dir():
            log('FOUND existing Obsidian JARVIS_Brain - it will NOT be erased or copied.')
        else:
            log('No JARVIS_Brain in that folder yet. It can be created later as new notes.')
        log(f'Chosen workspace: {workspace}')
        if not yes('Confirm this workspace and install Python dependencies?'):
            log('Cancelled - no changes.'); return
        workspace.mkdir(parents=True, exist_ok=True)
        write_config_if_missing(workspace)
    if not yes('Approve Python package downloads and setup/repair (includes Playwright)?'):
        log('Cancelled. Nothing installed.'); return
    ensure_environment()
    install_dependencies('requirements.txt')
    install_dependencies('requirements-browser-dom.txt')
    verify_python_dependencies()
    write_snippet()
    log('\n=== SETUP COMPLETE ===')
    log('All required packages including Playwright are in the JARVIS v3 .venv.')
    log('NEXT: menu 2 -> copy jarvis-clean-v3 into LM Studio MCP configuration.')
    log('Disable your old jarvis-local-v2 connection (do not delete any files).')


def doctor():
    log('\n=== JARVIS CLEAN v3.4 - DIAGNOSTICS ===')
    log(f'Program: {ROOT}')
    log(f'Python for LM Studio: {VENV_PY}')
    log('Virtual environment: ' + ('FOUND' if VENV_PY.is_file() else 'MISSING - run Setup/Repair'))
    if VENV_PY.is_file():
        try:
            verify_python_dependencies()
        except (RuntimeError, OSError) as exc:
            log(f'MISSING or FAILED Python dependency: {exc}')
    if CONFIG.exists():
        try:
            from jarvis_core.policy import Settings
            settings = Settings(CONFIG)
            log(f'Workspace: {settings.workspace}')
            log(f'Existing brain: {settings.workspace / "JARVIS_Brain"}')
            log('Brain found: ' + ('YES' if (settings.workspace/'JARVIS_Brain').is_dir() else 'NOT YET'))
            log(f'Separate data: {settings.data_dir}')
            log(f'STOP file active: {settings.kill_switch_path().exists()}')
        except (ValueError, OSError, KeyError) as exc:
            log(f'CONFIG ERROR: {exc}')
    else:
        log('CONFIG MISSING - Setup/Repair is needed.')
    if SNIPPET.exists():
        try:
            snippet = json.loads(SNIPPET.read_text(encoding='utf-8'))['mcpServers']['jarvis-clean-v3']
            actual = Path(snippet['command']).resolve()
            log('LM Studio snippet: ' + ('CORRECT PYTHON' if actual == VENV_PY.resolve() else 'WRONG PYTHON - choose menu 2 to regenerate'))
        except (KeyError, ValueError, OSError):
            log('LM Studio snippet INVALID - choose menu 2.')
    else:
        log('LM Studio snippet: MISSING - run Setup/Repair.')
    if os.name == 'nt' and VENV_PY.is_file():
        # Run inside the JARVIS .venv: this menu runs on the system Python, which
        # does not have JARVIS packages such as requests installed.
        code = ('from jarvis_core.browser_dom import _browser_executable\n'
                'try:\n    print("Opera / Edge found: " + _browser_executable())\n'
                'except ValueError as exc:\n    print("Opera / Edge NOT FOUND: " + str(exc))')
        subprocess.run([str(VENV_PY), '-c', code], cwd=str(ROOT), check=False)
    media_pipeline_status()
    log('No live browser website, Whisper transcription or LM Studio model call was tested by this diagnostic.')


def open_connection():
    write_snippet()
    log('\nLM Studio: MCP Integrations -> edit mcp.json')
    log('Use the jarvis-clean-v3 entry. Disable old jarvis-local-v2 to avoid confusion.')
    log('Merge with any other mcpServers; do not replace your entire config if it contains other servers.')
    try:
        if os.name == 'nt':
            subprocess.Popen(['notepad.exe', str(SNIPPET)])
        else:
            log(SNIPPET.read_text(encoding='utf-8'))
    except OSError:
        log(f'Open in Notepad manually: {SNIPPET}')


def checked_script(file, *args):
    if not VENV_PY.is_file():
        raise RuntimeError('Setup/Repair first: .venv is missing.')
    target = ROOT / file
    if not target.is_file():
        raise RuntimeError(f'Missing {file} (incomplete ZIP extraction).')
    run([VENV_PY, target, *args])


def approve_project():
    log('Approved projects let JARVIS keep tasks, notes and code scaffolds for that project.')
    name = input('Project name to approve (blank cancels): ').strip()
    if not name:
        log('Cancelled.'); return
    if yes(f'Approve project "{name}" for JARVIS?'):
        checked_script('manage.py', 'approve', name)


def media_pipeline_status():
    """Report each piece the YouTube -> audio -> Whisper pipeline needs, using the .venv Python."""
    log('\nAudio/transcription pipeline:')
    if VENV_PY.is_file():
        code = ('import importlib.util as u;'
                'print("yt-dlp:", "FOUND" if u.find_spec("yt_dlp") else "MISSING (menu 9 > 2)");'
                'print("faster-whisper:", "FOUND" if u.find_spec("faster_whisper") else "MISSING (menu 9 > 3)")')
        subprocess.run([str(VENV_PY), '-c', code], cwd=str(ROOT), check=False)
    for exe in ('ffmpeg', 'ffprobe'):
        found = shutil.which(exe)
        log(f'{exe}: ' + (found if found else 'NOT FOUND (needed for .opus files / codec checks; install FFmpeg and add it to PATH)'))
    if CONFIG.exists():
        try:
            from jarvis_core.policy import Settings
            model = Settings(CONFIG).data_dir / 'models' / 'faster-whisper-base' / 'model.bin'
            log('Whisper model: ' + ('FOUND' if model.is_file() else f'MISSING {model} (menu 9 > 4)'))
        except (ValueError, OSError, KeyError) as exc:
            log(f'Whisper model: cannot check ({exc})')
    try:
        from urllib.request import urlopen
        with urlopen('http://127.0.0.1:1234/v1/models', timeout=3) as res:
            ids = [m.get('id') for m in json.load(res).get('data', []) if isinstance(m, dict)]
        log('LM Studio server: REACHABLE, models: ' + (', '.join(ids[:5]) or 'none loaded'))
    except (OSError, ValueError) as exc:
        log(f'LM Studio server: NOT REACHABLE ({str(exc)[:80]}). Start the Local Server in LM Studio.')


def extras():
    log('OWNER-APPROVED OPTIONAL DOWNLOADS (installed only to this v3 Python):')
    log('1. Windows accessibility UI controls (pywinauto)')
    log('2. YouTube captions (yt-dlp; no video download without task approval)')
    log('3. Local faster-whisper transcription package')
    log('4. Download an offline Whisper model into new JARVIS data (requires owner approval)')
    selected = input('Choose 1, 2, 3 or 4, blank cancels: ').strip()
    packages = {'1': 'pywinauto>=0.6.9,<1', '2': 'yt-dlp>=2026.1', '3': 'faster-whisper>=1.1,<3'}
    if selected in packages:
        if not yes('Approve downloading ' + packages[selected] + ' from Python package repositories?'):
            return
        ensure_environment()
        run([VENV_PY, '-m', 'pip', 'install', packages[selected]])
        log('Optional package install complete.')
    elif selected == '4':
        if not yes('Approve launching the model download wizard, which asks again before downloading?'):
            return
        checked_script('install_whisper_model.py')
    else:
        log('Cancelled optional install.')


FCC_INSTALL_HELP = (
    'The voice orb comes with FCC (Free Claude Code), installed once:\n'
    '  1. Open PowerShell (not as administrator).\n'
    '  2. Paste: irm https://raw.githubusercontent.com/Arkival1/free-claude-code/main/scripts/install.ps1 | iex\n'
    '  3. A "JARVIS Orb" shortcut appears on your desktop. Updates later: run fcc-update.')


def find_fcc_orb():
    found = shutil.which('fcc-orb')
    if found:
        return found
    home = Path(os.environ.get('USERPROFILE') or Path.home())
    for candidate in (home / '.local' / 'bin' / 'fcc-orb.exe', home / '.local' / 'bin' / 'fcc-orb'):
        if candidate.is_file():
            return str(candidate)
    return None


def open_orb(popen=subprocess.Popen):
    command = find_fcc_orb()
    if not command:
        log(FCC_INSTALL_HELP)
        return False
    popen([command])
    log('Opening the JARVIS Orb (FCC starts in the background if needed)...')
    return True


def auto_approve_audio(set_to=None):
    """Owner switch: let JARVIS approve its own YouTube AUDIO downloads for video notes."""
    data = json.loads(CONFIG.read_text(encoding='utf-8'))
    vp = data.setdefault('video_pipeline', {})
    now = bool(vp.get('auto_approve_audio') is True)
    if set_to is None:
        log('Auto-approve YouTube audio is currently ' + ('ON' if now else 'OFF') + '.')
        log('When ON, JARVIS approves ONLY audio files (Opus/M4A/MP3) for video notes by itself.')
        log('Every other download (programs, files) still needs your approval. Files are still checked and')
        log('quarantined. "Verify you are human" checks on websites still need you.')
        if not yes('Turn it ' + ('OFF' if now else 'ON') + '?'):
            log('Unchanged.'); return now
        set_to = not now
    vp['auto_approve_audio'] = bool(set_to)
    tmp = CONFIG.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, CONFIG)
    log('Auto-approve YouTube audio is now ' + ('ON' if set_to else 'OFF') + '. Restart LM Studio\'s JARVIS connection to be sure it is used.')
    return bool(set_to)


def stop_or_resume(stop):
    target = ROOT / 'STOP_JARVIS.txt'
    if stop:
        if yes('Create STOP_JARVIS.txt to block NEW agent actions?'):
            target.write_text('Owner requested STOP. Remove only after reviewing actions.\n', encoding='utf-8')
            log(f'STOP file created: {target}\nClose a running task to stop in-flight actions.')
    elif target.is_file():
        if yes('Clear the STOP file and allow JARVIS tools to work again?'):
            target.unlink()
            log('STOP file cleared. Restart MCP if needed.')
    else:
        log('No STOP file to clear.')


def redirect_to_real_install(find=None, opener=None, ask=input):
    """START_JARVIS was opened inside a downloaded UPDATE folder (no settings here).
    Point the owner at their real JARVIS and offer to open its menu instead."""
    log('\nThis is the downloaded UPDATE folder, not your JARVIS.')
    log('  To update: close this window and double-click UPDATE_JARVIS.bat in this folder.')
    try:
        if find is None:
            from update_jarvis import find_installs as find
        installs = find()
    except Exception:
        installs = []
    if not installs:
        log('  No JARVIS install was found. For a brand-new install, choose 1 (Set up) below.')
        return False
    real = installs[0]
    log(f'  Your real JARVIS is here: {real}')
    if ask('Press Enter to open YOUR JARVIS menu there (or type n to stay here): ').strip().casefold() in ('n', 'no'):
        return False
    (opener or os.startfile)(str(real / 'START_JARVIS.bat'))
    log('Opened your real JARVIS menu in a new window. You can close this one.')
    return True


def menu():
    if os.name != 'nt':
        log('JARVIS is a Windows desktop agent. Run START_JARVIS.bat on Windows.')
        return 1
    if not CONFIG.exists() and not VENV_PY.is_file() and (ROOT / 'UPDATE_JARVIS.bat').is_file():
        if redirect_to_real_install():
            return 0
    while True:
        log('\n' + '='*53)
        log('JARVIS CLEAN v3.6  |  NEW SEPARATE INSTALL')
        log('='*53)
        log('W  OPEN JARVIS WORKSTATION (video to notes, approvals, jobs)')
        log('O  OPEN JARVIS VOICE ORB (needs FCC from Arkival1/free-claude-code)')
        log('1  SET UP / REPAIR (core tools + Playwright together)')
        log('2  LM STUDIO CONNECTION (create + open correct snippet)')
        log('3  DIAGNOSE local Python, Playwright, config and vault')
        log('4  TEST BROWSER form entry (no download)')
        log('5  START MEMORY CHAT (rolling Obsidian memory)')
        log('6  START AUTONOMOUS AGENT (uses local LM Studio model)')
        log('7  LIVE MONITOR')
        log('8  OWNER CONTROL PANEL')
        log('9  OPTIONAL transcription / UI extras')
        log('C  CONTINUE a paused autonomous task')
        log('P  APPROVE a project for tasks/notes/code')
        log('A  AUTO-APPROVE YouTube audio for video notes (on/off)')
        log('S  EMERGENCY STOP new JARVIS tool actions')
        log('R  CLEAR STOP (owner decision)')
        log('0  EXIT')
        choice = input('Select: ').strip().upper()
        if choice == '0':
            return 0
        try:
            if choice == 'W': checked_script('workstation.py')
            elif choice == 'O': open_orb()
            elif choice == '1': setup()
            elif choice == '2': open_connection()
            elif choice == '3': doctor()
            elif choice == '4': checked_script('jarvis_browser_dom_test.py')
            elif choice == '5': checked_script('memory_chat_gui.py')
            elif choice == '6': checked_script('agent_runner.py')
            elif choice == '7': checked_script('live_monitor.py')
            elif choice == '8': checked_script('control_panel.py')
            elif choice == '9': extras()
            elif choice == 'C': checked_script('agent_runner.py', '--resume')
            elif choice == 'P': approve_project()
            elif choice == 'A': auto_approve_audio()
            elif choice == 'S': stop_or_resume(True)
            elif choice == 'R': stop_or_resume(False)
            else: log('Unknown selection.')
        except (RuntimeError, OSError, ValueError, KeyError, ImportError) as exc:
            log('\nERROR: ' + str(exc))
            log('Fix the reported issue, then choose option 3 to diagnose. Existing notes were not deleted.')


if __name__ == '__main__':
    sys.exit(menu())
