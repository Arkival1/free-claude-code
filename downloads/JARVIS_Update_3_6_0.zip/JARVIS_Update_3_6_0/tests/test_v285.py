"""v2.8.5 tests: real desktop app launch requests and task-based auto launch."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, Mock
from urllib.parse import urlsplit,parse_qs

import agent_runner as agent
from jarvis_core.desktop import Desktop
from jarvis_core.vault import Vault
from jarvis_core.files import FileTools
from jarvis_core.policy import Settings,PolicyError


class DesktopAppOpenTests(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory()
        self.addCleanup(self.d.cleanup)
        root=Path(self.d.name)
        config={
            'workspace':str(root/'Workspace'), 'data_dir':str(root/'data'),
            'permissions':{'files':True,'notes_and_tasks':True,'screen':True,
                           'desktop_control':True,'app_launch':True},
            'desktop_mode':'all_user_apps','apps':{},'approved_desktop_exes':[]}
        self.config_path=root/'config.json'
        self.config_path.write_text(json.dumps(config))
        self.settings=Settings(self.config_path)
        self.desktop=Desktop(self.settings)
        self.vault=Vault(self.settings,FileTools(self.settings))
        self.vault.build_second_brain()

    def test_obsidian_uri_opens_existing_dashboard_inside_workspace(self):
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.os.startfile',create=True) as start, \
             patch.object(self.desktop,'list_windows',return_value=[{'exe':'obsidian.exe'}]):
            result=self.desktop.open_obsidian('dashboard')
        start.assert_called_once()
        url=start.call_args.args[0]
        self.assertEqual(urlsplit(url).scheme,'obsidian')
        self.assertEqual(urlsplit(url).netloc,'open')
        target=parse_qs(urlsplit(url).query)['path'][0]
        self.assertEqual(Path(target),self.settings.in_workspace('JARVIS_Brain/Second Brain Dashboard.md'))
        self.assertTrue(result['window_observed'])
        self.assertTrue(result['launch_requested'])

    def test_canvas_and_home_requested_when_needed(self):
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.os.startfile',create=True) as start, \
             patch.object(self.desktop,'list_windows',return_value=[]):
            result=self.desktop.open_obsidian('canvas')
        self.assertIn('JARVIS Second Brain.canvas',parse_qs(urlsplit(start.call_args.args[0]).query)['path'][0])
        self.assertFalse(result['window_observed'])  # do not claim a window actually opened

    def test_missing_uri_handler_tries_installed_obsidian_exe(self):
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.os.startfile',create=True,side_effect=OSError('URI not registered')), \
             patch.object(self.desktop,'launch',return_value='Launched Obsidian') as launch, \
             patch.object(self.desktop,'list_windows',return_value=[]):
            result=self.desktop.open_obsidian('home')
        launch.assert_called_once_with('obsidian')
        self.assertFalse(result['uri_sent'])
        self.assertIn('Open folder as vault',result['setup_if_not_opened'])

    def test_invalid_view_rejected_before_protocol_open(self):
        with patch.object(self.desktop,'_windows_only'):
            with self.assertRaises(PolicyError):self.desktop.open_obsidian('obsidian://evil.example')

    def test_cannot_open_when_app_launch_disabled_or_stopped(self):
        config=json.loads(self.config_path.read_text())
        config['permissions']['app_launch']=False
        self.config_path.write_text(json.dumps(config))
        with patch.object(self.desktop,'_windows_only'):
            with self.assertRaises(PolicyError):self.desktop.open_obsidian()
        config['permissions']['app_launch']=True
        self.config_path.write_text(json.dumps(config))
        self.settings.kill_switch_path().write_text('STOP')
        with patch.object(self.desktop,'_windows_only'):
            with self.assertRaises(PolicyError):self.desktop.open_obsidian()

    def test_approved_mode_does_not_bypass_allowlist_with_obsidian_uri(self):
        config=json.loads(self.config_path.read_text())
        config['desktop_mode']='approved_apps'
        self.config_path.write_text(json.dumps(config))
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.os.startfile',create=True) as start:
            with self.assertRaises(PolicyError):self.desktop.open_obsidian('dashboard')
        start.assert_not_called()

    def test_alias_launch_uses_verified_registered_exe_and_no_shell(self):
        exe=Path(self.d.name)/'Obsidian.exe';exe.write_bytes(b'MZ')
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.registered_apps',return_value={'obsidian.exe':str(exe)}), \
             patch('jarvis_core.desktop.subprocess.Popen') as proc:
            self.desktop.launch('Obsidian')
        proc.assert_called_once()
        self.assertEqual(proc.call_args.args[0],[str(exe)])
        self.assertIs(proc.call_args.kwargs['shell'],False)

    def test_never_accepts_model_paths_or_shell_app_names(self):
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.registered_apps',return_value={}), \
             patch('jarvis_core.desktop.subprocess.Popen') as proc:
            for name in ('cmd','powershell','C:/Windows/System32/cmd.exe','obsidian --flag'):
                with self.subTest(name=name),self.assertRaises(PolicyError):
                    self.desktop.launch(name)
        proc.assert_not_called()

    def test_vscode_alias_launch(self):
        exe=Path(self.d.name)/'Code.exe';exe.write_bytes(b'MZ')
        with patch.object(self.desktop,'_windows_only'), \
             patch('jarvis_core.desktop.registered_apps',return_value={'code.exe':str(exe)}), \
             patch('jarvis_core.desktop.subprocess.Popen') as proc:
            self.desktop.launch('VS Code')
        self.assertEqual(proc.call_args.args[0],[str(exe)])


class AutonomousAppWorkTests(unittest.TestCase):
    def test_obsidian_and_coding_goal_auto_launch_by_default(self):
        seen=[]
        def call(name,args):
            seen.append((name,args));return {'launch_requested':True}
        result=agent.kickoff_work_app('Create your Obsidian mind map for your knowledge wiki',desktop=True,call=call)
        self.assertEqual(result[0],'desktop_open_obsidian')
        self.assertEqual(result[1]['view'],'canvas')
        self.assertEqual(agent.kickoff_work_app('Build me a website',desktop=True,call=call)[1]['app_name'],'vscode')
        self.assertEqual(len(seen),2)

    def test_no_auto_start_from_unrelated_research_or_without_desktop(self):
        called=Mock()
        self.assertIsNone(agent.kickoff_work_app('What is an Obsidian crystal?',desktop=True,call=called))
        self.assertIsNone(agent.kickoff_work_app('Create an Obsidian wiki',desktop=False,call=called))
        called.assert_not_called()

    def test_relevant_tool_available_when_creating_brain(self):
        choices={x['function']['name'] for x in agent.focused_tools('Create Obsidian brain',desktop=True)}
        self.assertIn('desktop_open_obsidian',choices)
        self.assertIn('desktop_launch_app',choices)

    def test_mcp_api_has_direct_obsidian_open_tool(self):
        import ast
        source=(Path(__file__).resolve().parents[1]/'server.py').read_text(encoding='utf8')
        tree=ast.parse(source)
        functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
        self.assertIn('desktop_open_obsidian',functions)
        self.assertIn('_show_obsidian_after_write',functions)
        self.assertIn('desktop.open_obsidian',source)
        self.assertIn("'version':'3.6.0'",source)

    def test_no_adviser_added(self):
        self.assertFalse(any('adviser' in name for name in agent.ACTIONS))
        self.assertIsNone(agent.DEFAULT_MAX_TURNS)


if __name__=='__main__':unittest.main()
