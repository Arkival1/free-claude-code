"""v3.6: Model Test - graded by code, learning check with Lessons, history in Obsidian."""
import json
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v32_pipeline as base  # noqa: E402
from jarvis_core import model_test as mt  # noqa: E402
from jarvis_core.files import FileTools  # noqa: E402
from jarvis_core.jobs import Jobs  # noqa: E402
from jarvis_core.memory_vault import MemoryVault  # noqa: E402
from jarvis_core.vault import Vault  # noqa: E402

KNOW = dict(mt.KNOWLEDGE)


class FakeModel:
    """Answers maths right, gets 'Australia' wrong unless its Lessons mention Canberra, uses tools properly."""

    def __init__(self):
        self.seen = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, obj):
                b = json.dumps(obj).encode()
                self.send_response(200); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                self._json({'data': [{'id': 'qwen3.5-4b'}]})

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                outer.seen.append(body)
                self._json({'choices': [{'message': outer.reply(body)}]})
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f'http://127.0.0.1:{self.srv.server_address[1]}/v1'

    def reply(self, body):
        msgs = body['messages']
        system, user = msgs[0]['content'], msgs[-1]['content']
        if body.get('tools'):                                   # live memory test
            if msgs[-1]['role'] == 'tool':
                code = json.loads(msgs[-1]['content'])['matches'][0]['text'].split('code word is ')[1].split('.')[0]
                return {'content': f'The code word is {code}.'}
            return {'content': '', 'tool_calls': [{'id': 't1', 'type': 'function',
                                                   'function': {'name': 'memory_recall', 'arguments': '{"query": "model test code word"}'}}]}
        if 'reflect honestly' in system:
            return {'content': '## What went wrong and why\nI guessed a capital.\n## Lessons\nLESSON: The capital of Australia is Canberra, not Sydney.\nLESSON: Check units before answering.'}
        if user.startswith('Available tools'):
            for q, tool, args in mt.TOOLS:
                if q in user:
                    return {'content': json.dumps({'tool': tool, 'args': {k: f'x {v} y' for k, v in args.items()}})}
        q = user.replace('\n\n/no_think', '')
        if q in KNOW:
            if 'Australia' in q and 'Canberra' not in system:
                return {'content': 'ANSWER: A'}                 # the classic mistake
            return {'content': f'ANSWER: {KNOW[q]}'}
        for item_q, a in mt.MATHS:
            if q == item_q:
                return {'content': 'Working... 17:20' if '14:45' in q else f'ANSWER: {a}'}
        nums = [int(n) for n in __import__('re').findall(r'\d+', q)]
        if q.startswith('What is') and ' x ' in q:
            return {'content': f'ANSWER: {nums[0] * nums[1]:,}'}
        if '% of' in q:
            return {'content': f'ANSWER: {nums[1] * nums[0] / 100}'}
        if '6th number' in q:
            return {'content': f'ANSWER: {nums[1] + 5 * (nums[2] - nums[1])}'}
        return {'content': 'ANSWER: no idea'}


class ModelTestTests(unittest.TestCase):
    def setUp(self):
        root = Path(tempfile.mkdtemp())
        self.settings = base.make_settings(root)
        files = FileTools(self.settings)
        self.files = files
        self.jobs = Jobs(self.settings)
        memory = MemoryVault(self.settings, files, Vault(self.settings, files))
        self.model = FakeModel(); self.addCleanup(self.model.srv.shutdown)
        self.test = mt.ModelTest(self.settings, files, memory, self.jobs, base_url=self.model.url, seed=7)

    def run_once(self):
        job = self.test.start()
        return base.wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 60)

    def test_first_run_grades_saves_report_history_and_lessons(self):
        done = self.run_once()
        self.assertEqual(done['status'], 'done', done)
        r = done['result']
        self.assertEqual(r['scores']['maths'], 100)                  # incl. "17:20" and "1,234" style answers
        self.assertEqual(r['scores']['tools'], 100)
        self.assertEqual(r['scores']['memory'], 100)                 # it called memory_recall and found the code
        self.assertEqual(r['scores']['knowledge'], 90)               # Australia wrong
        self.assertEqual(r['fixed_with_lessons'], '0 of 1')          # no lessons yet
        report = self.files.read_text(r['report'])
        self.assertIn('type: model-test', report)
        self.assertIn('❌ | knowledge | What is the capital of Australia', report)
        lessons = self.files.read_text(mt.LESSONS_NOTE)
        self.assertIn('Canberra, not Sydney', lessons)
        self.assertIn('| Date | Model | Total |', self.files.read_text(mt.HISTORY_NOTE))

    def test_second_run_uses_lessons_and_shows_improvement(self):
        self.run_once()
        done = self.run_once()
        self.assertEqual(done['status'], 'done', done)
        r = done['result']
        self.assertEqual(r['fixed_with_lessons'], '1 of 1')          # retry with its Lessons fixed Australia
        report = self.files.read_text(r['report'])
        self.assertIn('fixed ✅', report)
        self.assertIn('| knowledge | 90% | 90% | = same |', report)
        retry_systems = [b['messages'][0]['content'] for b in self.model.seen if 'Your own lessons' in b['messages'][0]['content']]
        self.assertTrue(retry_systems and 'Canberra' in retry_systems[0])
        history = self.files.read_text(mt.HISTORY_NOTE)
        self.assertEqual(history.count('| qwen3.5-4b |'), 2)
        self.assertEqual(len(self.test.history()['runs']), 2)
        self.assertEqual(self.files.read_text(mt.LESSONS_NOTE).count('Canberra'), 1)   # lessons not duplicated

    def test_graders(self):
        self.assertTrue(mt.grade_number('ANSWER: 17:20', 1720))
        self.assertTrue(mt.grade_number('£30', 30))
        self.assertTrue(mt.grade_number('0,05', 0.05))
        self.assertTrue(mt.grade_number('2,108', 2108))
        self.assertFalse(mt.grade_number('31', 30))
        self.assertTrue(mt.grade_choice('B) Mercury', 'B'))
        self.assertFalse(mt.grade_choice('Mercury', 'B'))
        self.assertTrue(mt.grade_tool('{"tool": "job_status", "args": {"job_id": "20261128-1200-abc"}}', 'job_status', {'job_id': '20261128-1200-abc'}))
        self.assertFalse(mt.grade_tool('{"tool": "memory_recall"}', 'job_status', {}))
        self.assertEqual(mt.final_answer('<think>x</think>Some work\nANSWER: 42'), '42')


if __name__ == '__main__':
    unittest.main()


class WebsiteTools(unittest.TestCase):
    def setUp(self):
        self.calls = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                outer.calls.append(('GET', self.path, None))
                if self.path == '/admin/api/status':
                    return self._json({'status': 'running'})
                self._json({'slug': 'luigi', 'name': 'Luigi', 'theme': {}, 'sections': [{'kind': 'hero', 'variant': 'split', 'fields': {}}]})

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])) or b'{}')
                outer.calls.append(('POST', self.path, body))
                if body.get('licence') == 'All rights reserved':
                    return self._json({'detail': 'Only designs with a free licence can be added'}, 400)
                if self.path.endswith('/export'):
                    return self._json({'file': 'C:/fcc/export/luigi/index.html', 'html': '<!doctype html><title>Luigi</title>'})
                self._json({'slug': 'luigi', 'name': 'Luigi', 'sections': [{'kind': 'nav'}, {'kind': 'hero'}]})
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.addCleanup(self.srv.shutdown)
        root = Path(tempfile.mkdtemp())
        self.settings = base.make_settings(root, fcc_url=f'http://127.0.0.1:{self.srv.server_address[1]}')
        from jarvis_core.fcc_bridge import FccBridge
        self.fcc = FccBridge(self.settings)

    def test_tools_call_the_site_studio(self):
        made = self.fcc.site_create("Luigi's", 'restaurant', 'Italian')
        self.assertEqual(made['sections'], ['0:nav', '1:hero'])
        self.fcc.site_edit_section("Luigi's", 'menu', '{"title": "Menu"}')
        self.assertEqual(self.calls[-1], ('POST', '/orb/api/sites/luigi-s/section', {'action': 'edit', 'which': 'menu', 'fields': {'title': 'Menu'}, 'variant': ''}))
        with self.assertRaises(mt.PolicyError):
            self.fcc.site_edit_section('luigi', 'menu', '{not json')
        self.fcc.site_look('luigi', font='Classic Serif', base_color='#a63d2f', harmony='split')
        paths = [c[1] for c in self.calls]
        self.assertIn('/orb/api/sites/palette', paths); self.assertIn('/orb/api/sites/luigi/theme', paths)
        with self.assertRaises(RuntimeError) as cm:
            self.fcc.site_add_design('palette', 'X', '{"bg": "#fff"}', 'https://x.org', 'All rights reserved')
        self.assertIn('free licence', str(cm.exception))
        files = FileTools(self.settings)
        out = self.fcc.site_export('luigi', files)
        self.assertEqual(out['workspace_file'], 'Projects/Websites/luigi/index.html')
        self.assertIn('<title>Luigi</title>', files.read_text(out['workspace_file']))

    def test_websites_profile_group(self):
        from jarvis_core.tool_groups import profile_tool_names
        names = profile_tool_names('websites')
        self.assertIn('site_create', names); self.assertIn('model_test_run', names)
        with self.assertRaises(ValueError):
            profile_tool_names('nonsense')
