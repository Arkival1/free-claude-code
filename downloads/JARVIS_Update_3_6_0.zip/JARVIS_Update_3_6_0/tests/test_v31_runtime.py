"""v3.1: prompt budget for a small local model, on-demand tool groups, model-friendly arguments."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import agent_runner as a
import chat_runner as c
from jarvis_core.files import FileTools
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.vault import Vault

# ~4 characters per token. Tools + system prompt must leave room for the task in a ~7-16K context.
BUDGET_CHARS = 18_000   # about 4.5K tokens


def size(goal, desktop=True, extra=()):
    return len(json.dumps(a.focused_tools(goal, desktop, extra))) + len(a.system_prompt(goal, desktop, extra))


class PromptBudget(unittest.TestCase):
    def test_everyday_goals_fit_small_context(self):
        for goal in ('Summarise what you know about lanterns', 'Write hello.txt in Demo',
                     'Build a small website for my project', 'Research Godot tilemaps',
                     'Add a note to Obsidian about today'):
            with self.subTest(goal=goal):
                self.assertLess(size(goal), BUDGET_CHARS)

    def test_video_desktop_goal_is_bounded(self):
        # Video + screen fallback needs ~33 tools; still well under the old 78-tool payload.
        # Video + screen needs ~55 tools since v3.4 app control (~8K tokens); fine for 16K+ contexts.
        self.assertLess(size('Transcribe this YouTube video and save notes to Obsidian'), 34_000)

    def test_old_behaviour_was_far_bigger(self):
        everything = a.TOOLS + a.DESKTOP_TOOLS + a.BROWSER_DOM_TOOLS
        self.assertGreater(len(json.dumps(everything)) + len(a.SYS), 2 * BUDGET_CHARS)

    def test_long_video_guidance_only_for_video_or_desktop(self):
        self.assertNotIn('ytmp3', a.system_prompt('Write hello.txt'))
        self.assertIn('browser_dom_open', a.system_prompt('Transcribe this YouTube video', True))

    def test_loader_offered_and_desktop_respected(self):
        names = {t['function']['name'] for t in a.focused_tools('Write hello.txt', desktop=False)}
        self.assertIn('jarvis_load_tools', names)
        self.assertFalse(any(n.startswith('desktop_') for n in names))
        names = {t['function']['name'] for t in a.focused_tools('x', desktop=False, extra_groups=['desktop'])}
        self.assertFalse(any(n.startswith('desktop_') for n in names))

    def test_every_tool_reachable_through_some_group(self):
        grouped = set(a.CORE_TOOLS).union(*[set(v[1]) for v in a.TOOL_GROUPS.values()])
        declared = {t['function']['name'] for t in a.TOOLS + a.DESKTOP_TOOLS + a.BROWSER_DOM_TOOLS}
        self.assertEqual(declared - grouped, set())
        self.assertTrue(grouped <= set(a.ACTIONS) | {'desktop_screenshot', 'desktop_screenshot_guided', 'desktop_screenshot_zoom', 'youtube_video_frame'})

    def test_loaded_groups_restored_on_resume(self):
        msgs = [{'role': 'assistant', 'tool_calls': [{'function': {'name': 'jarvis_load_tools', 'arguments': '{"group":"projects"}'}}]},
                {'role': 'assistant', 'tool_calls': [{'function': {'name': 'jarvis_load_tools', 'arguments': '{"group":"nope"}'}}]}]
        self.assertEqual(a.loaded_groups(msgs), {'projects'})

    def test_memory_chat_hello_is_small(self):
        self.assertLess(len(json.dumps(c.choose_tools('hello how are you'))), 8_000)


class RunnerLoadsGroup(unittest.TestCase):
    """Drive the real run_agent loop with a scripted model that loads a group then uses it."""
    def test_load_then_use(self):
        sent = []
        script = [
            {'content': '', 'tool_calls': [{'id': '1', 'type': 'function', 'function': {'name': 'jarvis_load_tools', 'arguments': '{"group":"files"}'}}]},
            {'content': '', 'tool_calls': [{'id': '2', 'type': 'function', 'function': {'name': 'workspace_mkdir', 'arguments': '{"folder":"X"}'}}]},
            {'content': 'TASK_COMPLETE: made X'},
        ]
        class Resp:
            status_code = 200
            def __init__(self, m): self.m = m
            def raise_for_status(self): pass
            def json(self): return {'choices': [{'message': self.m}]}
        class Session:
            def __init__(self): self.trust_env = True
            def post(self, url, json=None, timeout=None):
                sent.append({t['function']['name'] for t in json['tools']})
                return Resp(script[len(sent) - 1])
        made = []
        with patch.object(a.requests, 'Session', Session), patch.object(a, 'log', lambda _: None), \
             patch.object(a, 'kickoff_goal', lambda g: None), patch.object(a, 'kickoff_work_app', lambda g, desktop=False: None), \
             patch.object(a.MISSIONS, 'save', lambda *x, **k: None), \
             patch.dict(a.ACTIONS, {'workspace_mkdir': lambda folder: made.append(folder) or 'ok'}):
            self.assertTrue(a.run_agent('Write hello.txt', 'm', max_steps=6))
        self.assertNotIn('workspace_mkdir', sent[0])
        self.assertIn('workspace_mkdir', sent[1])
        self.assertEqual(made, ['X'])


class ModelFriendlyArgs(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup)
        cfg = Path(t.name) / 'config.json'
        cfg.write_text(json.dumps({'workspace': str(Path(t.name) / 'ws'), 'data_dir': str(Path(t.name) / 'd'),
                                   'permissions': {'files': True}}))
        s = Settings(cfg); self.ws = Path(t.name) / 'ws'
        self.vault = Vault(s, FileTools(s))

    def test_links_as_list_or_text(self):
        self.vault.note('Research', 'A', 'body', ['Knowledge Wiki', '[[Skills]]'])
        self.vault.note('Research', 'B', 'body', 'Projects, Research')
        a_txt = (self.ws / 'JARVIS_Brain/Research/A.md').read_text()
        self.assertIn('[[Knowledge Wiki]]', a_txt); self.assertIn('[[Skills]]', a_txt)
        self.assertIn('[[Projects]]', (self.ws / 'JARVIS_Brain/Research/B.md').read_text())
        with self.assertRaises(PolicyError): self.vault.note('Research', 'C', 'b', 5)

    def test_canvas_accepts_object_nodes(self):
        out = self.vault.canvas('Map', '[{"id":"a","text":"Goal"},"Step"]', '[[0,1]]')
        self.assertEqual((out['nodes'], out['edges']), (2, 1))



class McpProfile(unittest.TestCase):
    def test_profile_names(self):
        from jarvis_core.tool_groups import profile_tool_names
        self.assertIsNone(profile_tool_names('full'))
        self.assertIsNone(profile_tool_names(''))
        names = profile_tool_names('video, brain')
        self.assertIn('youtube_audio_download_request', names); self.assertIn('jarvis_status', names)
        self.assertNotIn('desktop_click', names)
        with self.assertRaises(ValueError): profile_tool_names('video,hacking')

    def test_server_registers_only_profile(self):
        import os, subprocess, sys
        code = ('import server;print(len(server.mcp._tool_manager.list_tools()))')
        root = Path(__file__).resolve().parents[1]
        full = subprocess.run([sys.executable, '-c', code], cwd=root, capture_output=True, text=True, timeout=60)
        env = dict(os.environ, JARVIS_TOOL_PROFILE='video,brain')
        small = subprocess.run([sys.executable, '-c', code], cwd=root, capture_output=True, text=True, timeout=60, env=env)
        self.assertEqual(full.returncode, 0, full.stderr[-400:]); self.assertEqual(small.returncode, 0, small.stderr[-400:])
        self.assertGreater(int(full.stdout.split()[-1]), 80)
        self.assertLessEqual(int(small.stdout.split()[-1]), 48)   # +12 always-on memory and FCC tools in 3.5


if __name__ == '__main__':
    unittest.main()


class ContextScaling(unittest.TestCase):
    def test_bigger_context_keeps_more(self):
        msgs = [{'role': 'system', 'content': 's'}, {'role': 'user', 'content': 'goal'}]
        for i in range(60):
            msgs.append({'role': 'assistant', 'content': 'x' * 500})
        with patch.dict(a.SETTINGS.data, {'context_tokens': 8192}), patch.object(a, '_archive_trimmed_context', lambda r: None):
            small = len(a.compact_context([dict(m) for m in msgs]))
        with patch.dict(a.SETTINGS.data, {'context_tokens': 50000}), patch.object(a, '_archive_trimmed_context', lambda r: None):
            big = len(a.compact_context([dict(m) for m in msgs]))
        self.assertLessEqual(small, 26)
        self.assertGreater(big, small)
