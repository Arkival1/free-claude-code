"""v2.8.3 tests for owner-requested broad, non-admin default access."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from jarvis_core.policy import enable_all_nonadmin_tools, DEFAULT_CONFIG, PolicyError
import agent_runner

class V283(unittest.TestCase):
    def test_new_install_defaults_broad(self):
        d=json.loads((Path(__file__).parents[1]/'config.json').read_text(encoding='utf8'))
        self.assertEqual(d['desktop_mode'],'all_user_apps')
        self.assertEqual(DEFAULT_CONFIG['desktop_mode'],'all_user_apps')
        for name in ('files','notes_and_tasks','screen','desktop_control','app_launch','web_research','downloads','coding_lab','preview_local'):
            self.assertTrue(d['permissions'][name], name)
            self.assertTrue(DEFAULT_CONFIG['permissions'][name], name)
        self.assertNotIn('auto_approve_downloads',d)

    def test_pure_merge_keeps_owner_data(self):
        conf={'permissions':{'screen':False, 'app_launch':False},
              'desktop_mode':'approved_apps', 'workspace':'D:/Original',
              'data_dir':'D:/Original/Brain', 'local_advisers':{'disabled':True},
              'approved_download_domains':['example.com'], 'extra_owner_key':42}
        enable_all_nonadmin_tools(conf)
        self.assertEqual(conf['workspace'],'D:/Original')
        self.assertEqual(conf['data_dir'],'D:/Original/Brain')
        self.assertEqual(conf['approved_download_domains'],['example.com'])
        self.assertEqual(conf['extra_owner_key'],42)
        self.assertEqual(conf['desktop_mode'],'all_user_apps')
        self.assertTrue(conf['permissions']['app_launch'])
        self.assertTrue(conf['permissions']['screen'])
        self.assertNotIn('auto_approve_downloads',conf)

    @unittest.skip("Legacy upgrade helper intentionally excluded from fresh-install package")
    def test_upgrade_turns_all_tools_on_preserves_work_and_backup(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            old=root/'previous_install';old.mkdir()
            old_conf={'workspace':'C:/Users/Spawn/MyJarvisProjects',
                'data_dir':'C:/Users/Spawn/JarvisMemories',
                'permissions':{'screen':False,'desktop_control':False,'app_launch':False,'files':False},
                'desktop_mode':'approved_apps', 'approved_desktop_exes':['notepad.exe'],
                'apps':{'custom':{'path':'C:/Program Files/Custom/app.exe','args':[]}},
                'approved_download_domains':['example.com'], 'owner_custom_field':'preserve'}
            (old/'server.py').write_text('version old')
            (old/'config.json').write_text(json.dumps(old_conf),encoding='utf8')
            (old/'notes.txt').write_text('keep original memory')
            with patch.object(apply_upgrade,'SRC',Path(__file__).parents[1]):
                backup=apply_upgrade.upgrade(old)
            doc=json.loads((old/'config.json').read_text(encoding='utf8'))
            self.assertEqual(doc['desktop_mode'],'all_user_apps')
            for name in ('files','notes_and_tasks','web_research','screen','desktop_control','app_launch','downloads','coding_lab','preview_local'):
                self.assertTrue(doc['permissions'][name],name)
            for key in ('workspace','data_dir','apps','approved_download_domains','owner_custom_field'):
                self.assertEqual(doc[key],old_conf[key])
            self.assertEqual((old/'notes.txt').read_text(),'keep original memory')
            self.assertEqual(json.loads((backup/'config.json').read_text()),old_conf)
            self.assertTrue((old/'tests'/'test_v283.py').exists())
            self.assertIn('3.6.0',(old/'server.py').read_text())

    def test_invalid_config_rejected(self):
        for doc in ({}, {'permissions': None}, {'permissions': []}):
            with self.subTest(doc=doc), self.assertRaises(PolicyError):
                enable_all_nonadmin_tools(doc)

    def test_no_fixed_turn_budget(self):
        self.assertIsNone(agent_runner.DEFAULT_MAX_TURNS)

if __name__=='__main__': unittest.main()
