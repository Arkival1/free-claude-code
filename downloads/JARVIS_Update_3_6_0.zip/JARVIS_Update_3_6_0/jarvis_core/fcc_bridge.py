"""Tools for working with FCC (Free Claude Code) and its JARVIS Orb on this PC.

FCC runs a local web server (default http://127.0.0.1:8082). The orb page at /orb
speaks text aloud; /orb/api/say lets JARVIS speak through it from LM Studio.
Only 127.0.0.1/localhost addresses are ever contacted.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

from .policy import PolicyError

DEFAULT_URL = 'http://127.0.0.1:8082'
_LOCAL = re.compile(r'^http://(127\.0\.0\.1|localhost)(:\d{1,5})?$')
HELP = """FCC = Free Claude Code, a local server on this PC. Its JARVIS Orb is a voice window:
- The owner opens it with the "JARVIS Orb" desktop shortcut (or ask me: fcc_open_orb).
- In the orb, the owner talks or types; I answer with the LM Studio model and my tools,
  then my reply is read aloud. Older parts of long talks are saved to Obsidian Memory.
- From LM Studio chat, fcc_say(text) speaks a short message through the orb
  (e.g. "Your transcript is ready, sir."). Keep it to one or two sentences.
- fcc_ask_advisor(question): if the owner turned the advisor on in the orb settings, a
  bigger API model that can ONLY read your tool list gives advice on which tools to use.
  Ask in general terms; never include personal details, memories, files or passwords.
- FCC is also JARVIS's local toolkit: video_to_notes uses it to download YouTube audio
  (yt-dlp) and transcribe it (Whisper) on this PC. fcc_transcribe(file) transcribes any
  audio or video file in the workspace. FCC starts by itself in the background when needed.
- fcc_status tells you if FCC and the orb are running and which model the orb uses.
- If FCC is not installed: the owner runs the installer command from the
  Arkival1/free-claude-code README once; later updates are fcc-update.
"""


# Video job stages -> the steps shown on FCC's progress bar.
VIDEO_STEPS = ('Finding the audio', 'Waiting for your approval', 'Downloading audio', 'Transcribing',
               'Saving transcript', 'Writing notes')
STAGE_STEP = {'start': 0, 'starting': 0, 'find_format': 0, 'audio': 2, 'awaiting_approval': 1,
              'download': 2, 'transcribe': 3, 'save': 4, 'notes': 5, 'done': 6}


class FccBridge:
    def __init__(self, settings, opener=None, popen=subprocess.Popen):
        self.settings = settings
        self._opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self._popen = popen
        self._quiet_until = 0.0        # FCC unreachable: stop trying for a while
        self._last_sent = {}           # job id -> last report (skip repeats)

    def url(self) -> str:
        url = str(self.settings.data.get('fcc_url', DEFAULT_URL)).rstrip('/')
        if not _LOCAL.match(url):
            raise PolicyError('fcc_url must be a http://127.0.0.1:<port> address on this PC.')
        return url

    def _call(self, path, payload=None, timeout=4.0):
        data = None if payload is None else json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(self.url() + path, data=data,
                                     headers={'Content-Type': 'application/json'} if data else {})
        with self._opener.open(req, timeout=timeout) as response:
            return json.loads(response.read().decode('utf-8'))

    def status(self):
        try:
            server = self._call('/admin/api/status')
        except (OSError, urllib.error.URLError, ValueError):
            return {'fcc_running': False, 'url': self.url(),
                    'next': 'FCC is not running. Ask me to call fcc_open_orb, or double-click "JARVIS Orb" on the desktop.'}
        orb = {}
        try:
            orb = self._call('/orb/api/status')
        except (OSError, urllib.error.URLError, ValueError):
            pass
        return {'fcc_running': True, 'url': self.url(), 'fcc_version': orb.get('version'),
                'orb_available': bool(orb), 'orb_url': self.url() + '/orb',
                'orb_model': orb.get('model'), 'orb_tool_servers': orb.get('servers', []),
                'orb_state': orb.get('state'), 'orb_last_error': orb.get('last_error', ''),
                'server_status': server.get('status')}

    def say(self, text):
        self.settings.require_not_stopped()
        if not isinstance(text, str) or not text.strip():
            raise PolicyError('fcc_say needs the words to speak.')
        if len(text) > 1500:
            raise PolicyError('Keep spoken messages short (under 1500 characters); save long text to a note.')
        try:
            answer = self._call('/orb/api/say', {'text': text.strip(), 'source': 'lmstudio'})
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError('This FCC has no orb yet. Update FCC (fcc-update) to the Arkival1 version.') from exc
            raise RuntimeError(f'FCC refused the message (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError('FCC is not running, so nothing was spoken. Call fcc_open_orb first.') from exc
        return {'spoken_via_orb': True, 'id': answer.get('id'),
                'note': 'The orb window must be open to hear it.'}

    def ask_advisor(self, question):
        """Ask FCC's read-only advisor. It sees only this question and the tool list."""
        self.settings.require_not_stopped()
        if not isinstance(question, str) or not question.strip():
            raise PolicyError('Ask the advisor a question.')
        if len(question) > 2000:
            raise PolicyError('Keep advisor questions under 2000 characters and in general terms.')
        try:
            answer = self._call('/orb/api/advise', {'question': question.strip()}, timeout=200.0)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError('This FCC has no advisor yet. Update FCC (fcc-update).') from exc
            raise RuntimeError(f'The advisor failed (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError('FCC is not running. Call fcc_open_orb first.') from exc
        advice = str(answer.get('advice', ''))
        if advice.startswith('ERROR:'):
            raise RuntimeError(advice[6:].strip())
        return {'advice': advice, 'advisor_model': answer.get('advisor_model'),
                'note': 'Advice only. You decide and run the tools yourself.'}

    # ---------- FCC as a local toolkit (download + transcribe on this PC) ----------
    def running(self):
        try:
            return self._call('/admin/api/status', timeout=2.0).get('status') in ('running', 'stopping')
        except (OSError, urllib.error.URLError, ValueError):
            return False

    def desktop_command(self):
        found = shutil.which('fcc-desktop')
        if found:
            return found
        home = Path(os.environ.get('USERPROFILE') or Path.home())
        for candidate in (home / '.local' / 'bin' / 'fcc-desktop.exe', home / '.local' / 'bin' / 'fcc-desktop'):
            if candidate.is_file():
                return str(candidate)
        return None

    def ensure_running(self, wait=60.0, sleep=time.sleep):
        """Start FCC quietly in the background (no window) if it is not running."""
        if self.running():
            return True
        self.settings.require_not_stopped()
        command = self.desktop_command()
        if not command:
            raise RuntimeError('FCC is not installed, so it cannot download or transcribe. Run UPDATE_ORB.bat from the FCC Orb update download.')
        extra = {'creationflags': 0x08000000} if os.name == 'nt' else {}
        self._popen([command], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    env=dict(os.environ, FCC_OPEN_BROWSER='false'), **extra)
        waited = 0.0
        while waited < wait:
            sleep(1.0); waited += 1.0
            if self.running():
                return True
        raise RuntimeError('FCC did not start within a minute.')

    def _post_raw(self, path, data, content_type, timeout, job_id=None):
        headers = {'Content-Type': content_type}
        if job_id:
            headers['X-Jarvis-Job'] = str(job_id)[:64]       # FCC puts its download/transcribe % on this job's bar
        req = urllib.request.Request(self.url() + path, data=data, headers=headers)
        try:
            return self._opener.open(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise RuntimeError('This FCC is too old for that. Run UPDATE_ORB.bat from the FCC Orb update download.') from exc
            try:
                detail = json.loads(exc.read().decode('utf-8')).get('detail', '')
            except (ValueError, OSError):
                detail = ''
            raise RuntimeError(detail or f'FCC refused (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError(f'Could not reach FCC: {exc}') from exc

    def download_youtube_audio(self, url, dest_dir, video_id, max_bytes, job_id=None):
        """FCC downloads one YouTube video's audio (yt-dlp on this PC); saved as <id>.fcc.<ext>."""
        body = json.dumps({'url': url}).encode('utf-8')
        with self._post_raw('/orb/api/youtube/audio', body, 'application/json', 1800, job_id) as response:
            ext = (response.headers.get('X-Audio-Ext') or '').lower()
            if ext not in ('m4a', 'webm', 'opus', 'mp3'):
                raise RuntimeError(f'FCC returned an unexpected file type ({ext or "none"}).')
            dest = Path(dest_dir) / f'{video_id}.fcc.{ext}'
            dest.parent.mkdir(parents=True, exist_ok=True)
            got = 0
            with dest.open('wb') as out:
                while True:
                    chunk = response.read(1 << 16)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > max_bytes:
                        out.close(); dest.unlink(missing_ok=True)
                        raise RuntimeError(f'The audio is bigger than your download limit ({max_bytes // (1024 * 1024)} MB).')
                    out.write(chunk)
        return dest

    def transcribe_file(self, path, job_id=None):
        """Whisper inside FCC transcribes a local audio file. Returns timestamped lines."""
        data = Path(path).read_bytes()
        with self._post_raw('/orb/api/transcribe', data, 'application/octet-stream', 4 * 3600, job_id) as response:
            out = json.loads(response.read().decode('utf-8'))
        return {'lines': list(out.get('lines') or []), 'model': out.get('model', 'Whisper (FCC, on this PC)'),
                'seconds': out.get('seconds', 0)}

    # ---------- live activity in the FCC orb window ----------
    def _send_later(self, payload):
        """Fire-and-forget POST to FCC's activity panel; never slows JARVIS down."""
        if time.monotonic() < self._quiet_until:
            return

        def send():
            try:
                req = urllib.request.Request(self.url() + '/orb/api/activity', data=json.dumps(payload).encode('utf-8'),
                                             headers={'Content-Type': 'application/json'})
                with self._opener.open(req, timeout=1.5):
                    pass
            except (OSError, urllib.error.URLError, ValueError, PolicyError):
                self._quiet_until = time.monotonic() + 20
        threading.Thread(target=send, name='jarvis-fcc-activity', daemon=True).start()

    def note(self, text, source='jarvis'):
        self._send_later({'note': str(text)[:300], 'source': source})

    def report_job(self, job):
        """Called by Jobs on every change: shows the job as a progress bar in the orb."""
        stage, status = str(job.get('stage') or ''), str(job.get('status') or 'running')
        step = STAGE_STEP.get(stage)
        log = [line[9:] if line[:2].isdigit() else line for line in (job.get('log') or [])[-4:]]
        payload = {'id': job.get('id'), 'title': job.get('title', 'JARVIS job'), 'source': 'jarvis',
                   'status': status if status in ('running', 'waiting', 'done', 'failed', 'cancelled') else 'running',
                   'detail': (job.get('needs_owner') or job.get('error') or job.get('detail') or '')[:400], 'log': log}
        if job.get('kind') == 'video_to_notes' and step is not None:
            payload.update(steps=len(VIDEO_STEPS), step=min(step, len(VIDEO_STEPS)),
                           step_name=VIDEO_STEPS[min(step, len(VIDEO_STEPS) - 1)] if step < 6 else 'Finished')
        else:
            payload['step_name'] = stage.replace('_', ' ')
        progress = job.get('progress') if (stage == 'notes' or job.get('kind') != 'video_to_notes') else None
        if isinstance(progress, (int, float)):
            payload['percent'] = max(0.0, min(100.0, float(progress)))   # JARVIS's own % (notes parts)
        previous = self._last_sent.get(payload['id'])
        signature = (stage, payload['status'], payload['detail'], tuple(log), payload.get('percent'))
        if previous == signature:
            return
        if (previous is None or previous[0] != stage) and 'percent' not in payload:
            payload['reset_percent'] = True          # a new step starts at 0%
        self._last_sent[payload['id']] = signature
        self._send_later(payload)

    # ---------- websites (FCC Site Studio) ----------
    def _site(self, method, path, body=None, timeout=60.0):
        self.ensure_running()
        data = None if body is None else json.dumps(body).encode('utf-8')
        req = urllib.request.Request(self.url() + path, data=data, method=method,
                                     headers={'Content-Type': 'application/json'} if data else {})
        try:
            with self._opener.open(req, timeout=timeout) as response:
                return json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as exc:
            if exc.code == 404 and path.startswith('/orb/api/sites/library'):
                raise RuntimeError('This FCC has no Site Studio yet. Run UPDATE_ORB.bat.') from exc
            try:
                detail = json.loads(exc.read().decode('utf-8')).get('detail', '')
            except (ValueError, OSError):
                detail = ''
            raise RuntimeError(detail or f'Site Studio refused (HTTP {exc.code}).') from exc
        except (OSError, urllib.error.URLError) as exc:
            raise RuntimeError(f'Could not reach FCC: {exc}') from exc

    @staticmethod
    def _slug(site):
        slug = re.sub(r'[^a-z0-9]+', '-', str(site or '').lower()).strip('-')[:48]
        if not slug:
            raise PolicyError('Say which site (its name or slug; site_list shows them).')
        return slug

    def site_library(self):
        lib = self._site('GET', '/orb/api/sites/library')
        return {'starters': lib['starters'], 'palettes': list(lib['palettes']), 'fonts': list(lib['fonts']),
                'buttons': lib['buttons'], 'my_presets': list(lib.get('presets', {})),
                'sections': {k: {'variants': v['variants'], 'fields': {f: (t if isinstance(t, str) else 'list: ' + ' | '.join(t['columns']))
                                                                     for f, t in v['fields'].items()}} for k, v in lib['sections'].items()}}

    def site_list(self):
        return self._site('GET', '/orb/api/sites')

    def site_create(self, name, kind='restaurant', description=''):
        spec = self._site('POST', '/orb/api/sites', {'name': name, 'kind': kind, 'description': description})
        return {'site': spec['slug'], 'name': spec['name'], 'sections': [f'{i}:{s["kind"]}' for i, s in enumerate(spec['sections'])],
                'studio': self.url() + '/orb/sites?site=' + spec['slug'],
                'next': 'Fill each section with the real business details (site_edit_section), pick a look (site_look), then site_open.'}

    def site_get(self, site):
        spec = self._site('GET', f'/orb/api/sites/{self._slug(site)}')
        return {'site': spec['slug'], 'name': spec['name'], 'theme': spec['theme'],
                'sections': [{'index': i, 'kind': s['kind'], 'variant': s['variant'], 'fields': s['fields']} for i, s in enumerate(spec['sections'])]}

    def site_edit_section(self, site, section, fields_json='{}', variant=''):
        try:
            fields = json.loads(fields_json) if isinstance(fields_json, str) else dict(fields_json or {})
        except ValueError as exc:
            raise PolicyError(f'fields_json must be a JSON object: {exc}') from exc
        if not isinstance(fields, dict):
            raise PolicyError('fields_json must be a JSON object, e.g. {"title": "Our menu"}.')
        return self._site('POST', f'/orb/api/sites/{self._slug(site)}/section',
                          {'action': 'edit', 'which': section, 'fields': fields, 'variant': variant})

    def site_add_section(self, site, kind, variant='', position=-1):
        return self._site('POST', f'/orb/api/sites/{self._slug(site)}/section',
                          {'action': 'add', 'kind': kind, 'variant': variant, 'position': int(position)})

    def site_remove_section(self, site, section):
        return self._site('POST', f'/orb/api/sites/{self._slug(site)}/section', {'action': 'remove', 'which': section})

    def site_look(self, site, palette='', font='', button='', radius=-1, spacing=-1.0, base_color='', harmony='complementary', mode='light'):
        slug = self._slug(site)
        made = None
        if base_color:
            made = self._site('POST', '/orb/api/sites/palette', {'base': base_color, 'harmony': harmony, 'mode': mode, 'apply_to': slug})
        changes = {k: v for k, v in {'palette': palette or None, 'font': font or None, 'button': button or None,
                                     'radius': radius if radius >= 0 else None, 'spacing': spacing if spacing > 0 else None}.items() if v is not None}
        theme = self._site('POST', f'/orb/api/sites/{slug}/theme', changes) if changes else None
        return {'original_palette': made, 'theme': theme or 'unchanged'}

    def site_add_design(self, kind, name, data_json, source_url, licence):
        try:
            data = json.loads(data_json) if isinstance(data_json, str) else data_json
        except ValueError as exc:
            raise PolicyError(f'data_json must be JSON: {exc}') from exc
        return self._site('POST', '/orb/api/sites/library', {'kind': kind, 'name': name, 'data': data,
                                                              'source_url': source_url, 'licence': licence})

    def site_export(self, site, files=None):
        slug = self._slug(site)
        out = self._site('POST', f'/orb/api/sites/{slug}/export', {}, timeout=120)
        result = {'fcc_file': out['file']}
        if files is not None:
            rel = f'Projects/Websites/{slug}/index.html'
            files.write_text(rel, out['html'], overwrite=True)
            result['workspace_file'] = rel
        result['next'] = 'Open the file in a browser to see the finished site, or upload it to any web host.'
        return result

    def site_open(self, site=''):
        url = self.url() + '/orb/sites' + (f'?site={self._slug(site)}' if site else '')
        self.ensure_running()
        opener = getattr(os, 'startfile', None)
        if opener is not None:
            opener(url)
        else:
            import webbrowser
            webbrowser.open(url)
        return {'opened': url}

    def orb_command(self):
        found = shutil.which('fcc-orb')
        if found:
            return found
        home = Path(os.environ.get('USERPROFILE') or Path.home())
        for candidate in (home / '.local' / 'bin' / 'fcc-orb.exe', home / '.local' / 'bin' / 'fcc-orb'):
            if candidate.is_file():
                return str(candidate)
        return None

    def open_orb(self):
        self.settings.require_not_stopped()
        command = self.orb_command()
        if not command:
            raise RuntimeError('FCC with the JARVIS Orb is not installed (fcc-orb not found). '
                               'Install it from the Arkival1/free-claude-code README, then try again.')
        extra = {'creationflags': 0x08000000} if os.name == 'nt' else {}    # no console window
        self._popen([command], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, **extra)
        return {'opening': command, 'orb_url': self.url() + '/orb',
                'note': 'FCC starts in the background if needed; the orb window appears in a few seconds.'}

    @staticmethod
    def help():
        return HELP
