"""v3.1 tool groups shared by the autonomous runner, Memory Chat and the MCP server profile.

Groups only decide which tool DESCRIPTIONS a model sees. They never grant permission:
each tool still checks config permissions, approvals and the STOP file.
"""
from __future__ import annotations

CORE_TOOLS=('workspace_list','workspace_read','workspace_write','skills_list','skills_read',
            'obsidian_memory_search','obsidian_daily_memory')
TOOL_GROUPS={
 'files':('Copy, move, find, folders, Python syntax check',
          ('workspace_mkdir','workspace_copy','workspace_move','workspace_find','python_syntax_check')),
 'projects':('Approved projects: tasks, notes, scaffolds, previews, offline coding lab',
          ('task_add','task_list','task_set_state','note_add','note_search','project_scaffold','project_check',
           'project_preview_start','project_preview_open','project_preview_stop','coding_lab_python','coding_lab_run')),
 'research':('Web search, open and read public pages, research notes',
          ('research_search','research_learn','browser_search','browser_open','website_read')),
 'video':('YouTube to Obsidian notes (video_to_notes + job_status), captions, transcript websites, local Whisper, frames',
          ('video_to_notes','job_status','job_list','job_cancel','openwhispr_status','youtube_open_video','youtube_transcript','youtube_transcript_section','youtube_transcript_fallback_sites',
           'youtube_transcript_website_open','youtube_transcript_clipboard_import','youtube_transcript_copy_import',
           'youtube_transcript_extension_open','youtube_video_frame','youtube_transcribe_local',
           'youtube_audio_download_request','youtube_audio_download','obsidian_note')),
 'brain':('Obsidian notes, second brain, canvas mind maps, open Obsidian',
          ('obsidian_second_brain_build','obsidian_vault_init','obsidian_note','obsidian_canvas',
           'desktop_open_obsidian','desktop_launch_app')),
 'downloads':('Owner-approved software/file downloads', ('download_request','official_download')),
 'browser_dom':('Verified webpage fields on allowed transcript/converter sites (Windows)',
          ('browser_dom_open','browser_dom_inspect','browser_dom_fill_youtube','browser_dom_click_action','browser_dom_read_page')),
 'desktop':('Windows apps by name (controls, click, type into, menus, wait) plus screenshots, clicks, typing, hotkeys',
          ('desktop_ui_controls','desktop_click_named','desktop_type_into','desktop_read_text','desktop_menu',
           'desktop_wait_for','desktop_focus_app',
           'desktop_list_windows','desktop_activate_window','desktop_find_installed_apps','desktop_launch_app',
           'desktop_open_obsidian','desktop_screenshot','desktop_screenshot_guided','desktop_screen_info',
           'desktop_click_image','desktop_click_box_image',
           'desktop_type','desktop_hotkey','desktop_scroll_image','desktop_click')),
 'desktop_precise':('Zoom, hover, drag paths, pointer info, raw move/drag/press/scroll',
          ('desktop_screenshot_zoom','desktop_move_image','desktop_drag_image','desktop_drag_path_image',
           'desktop_hover_image','desktop_pointer_info','desktop_move','desktop_drag','desktop_press','desktop_scroll')),
}
DESKTOP_GROUPS=('browser_dom','desktop','desktop_precise')
GROUP_KEYWORDS={
 'files':('copy','move ','rename','find ','folder','organi','syntax'),
 'projects':('project','code','coding','website','web site','game','godot','python','script','build ','app ','debug','test'),
 'research':('research','search','look up','learn','find out','article','docs','documentation','http'),
 'video':('youtube','youtu.be','transcri','caption','video','whisper','audio','podcast'),
 'brain':('obsidian','second brain','mind map','knowledge','wiki','vault','canvas','note'),
 'downloads':('download','install'),
 'browser_dom':('youtube','youtu.be','transcri','converter','webpage','web page','website field','opera','edge','browser'),
 'desktop':('open ','click','screen','window','launch',' app','opera','edge','openwhispr','type ','watch '),
 'desktop_precise':('drag','hover','zoom','canvas','precise','slider'),
}

# Always registered over MCP whatever the profile, so status and memory keep working.
MCP_ALWAYS=('jarvis_status','chat_memory_save','chat_memory_search','chat_memory_status','approved_projects',
            'memory_offload','memory_recall','memory_resume','memory_reindex',
            'fcc_status','fcc_say','fcc_open_orb','fcc_ask_advisor','fcc_transcribe','fcc_help',
            'model_test_run','model_test_history')


# MCP-only groups (not used by the autonomous runner): named in mcp_tool_profile, e.g. "video,websites".
MCP_GROUPS={
 'websites':('Build business websites in the FCC Site Studio',
          ('site_library','site_list','site_create','site_get','site_edit_section','site_add_section',
           'site_remove_section','site_look','site_add_design','site_export','site_open')),
}


def profile_tool_names(profile):
    """None = full (every tool). Otherwise core + named groups. Unknown group names raise ValueError."""
    if profile is None:return None
    text=str(profile).strip().casefold()
    if text in ('','full','all'):return None
    groups=[g.strip() for g in text.split(',') if g.strip()]
    known={**TOOL_GROUPS,**MCP_GROUPS}
    unknown=[g for g in groups if g not in known]
    if unknown:
        raise ValueError('Unknown mcp_tool_profile group(s): '+', '.join(unknown)+'. Use full or: '+', '.join(known))
    names=set(CORE_TOOLS)|set(MCP_ALWAYS)
    for g in groups:names.update(known[g][1])
    return names
