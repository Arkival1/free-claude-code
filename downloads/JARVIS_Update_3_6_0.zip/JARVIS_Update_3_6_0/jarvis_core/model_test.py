"""Model Test: graded knowledge/IQ checks for the local model, plus a learning check.

Every run:
1. asks maths/logic (some freshly generated each run), general knowledge, tool-use
   and a live memory question (the model must call memory_recall to find a code word);
2. grades every answer with code, never by asking the model to mark itself;
3. retries the missed questions WITH the model's own Lessons note, to measure
   whether what it has learned actually changes its answers;
4. compares with earlier runs (what improved, what it learned since last time);
5. asks the model to reflect and write new lessons, which the next run uses.

Reports go to Obsidian: Reflections/Model Tests/<date> <model>.md, the Model Test
History note and the Lessons note. Nothing leaves this PC (LM Studio on 127.0.0.1).
"""
from __future__ import annotations

import json
import random
import re
import threading
from datetime import datetime

import requests

from .policy import PolicyError

LMSTUDIO = 'http://127.0.0.1:1234/v1'
FOLDER = 'JARVIS_Brain/Reflections/Model Tests'
HISTORY_NOTE = FOLDER + '/Model Test History.md'
LESSONS_NOTE = FOLDER + '/Lessons.md'
CATEGORIES = ('maths', 'knowledge', 'tools', 'memory')
SYSTEM = ('You are being tested. Think carefully, then give the final answer on the LAST line exactly as '
          '"ANSWER: <answer>". For multiple choice answer with the letter only.')

# ---- fixed question bank (exact answers, graded by code) ----
MATHS = [
    ('A shirt costs 40 pounds and is reduced by 25%. What is the new price in pounds?', 30),
    ('If 3 workers build a wall in 12 hours, how many hours do 6 workers take at the same rate?', 6),
    ('What is the next number in the sequence 2, 6, 12, 20, 30, ...?', 42),
    ('A train leaves at 14:45 and the trip takes 2 hours 35 minutes. At what time does it arrive? Answer as HHMM, e.g. 0930.', 1720),
    ('All bloops are razzies. All razzies are lazzies. Are all bloops lazzies? Answer 1 for yes, 0 for no.', 1),
    ('A bat and a ball cost 1.10 in total. The bat costs 1.00 more than the ball. How much does the ball cost?', 0.05),
    ('How many minutes are there in 3.5 hours?', 210),
]
KNOWLEDGE = [
    ('Which planet is closest to the Sun? A) Venus B) Mercury C) Mars D) Earth', 'B'),
    ('What gas do plants take in for photosynthesis? A) Oxygen B) Nitrogen C) Carbon dioxide D) Helium', 'C'),
    ('In which year did World War II end? A) 1939 B) 1918 C) 1945 D) 1950', 'C'),
    ('What is the capital of Australia? A) Sydney B) Melbourne C) Perth D) Canberra', 'D'),
    ('Which organ pumps blood around the body? A) Lungs B) Heart C) Liver D) Kidneys', 'B'),
    ('H2O is the chemical formula for? A) Salt B) Hydrogen C) Water D) Oxygen', 'C'),
    ('Who wrote "Romeo and Juliet"? A) Charles Dickens B) William Shakespeare C) Jane Austen D) Mark Twain', 'B'),
    ('Which is the largest ocean on Earth? A) Atlantic B) Indian C) Arctic D) Pacific', 'D'),
    ('What does CPU stand for? A) Central Processing Unit B) Computer Power Unit C) Core Program Utility D) Central Print Unit', 'A'),
    ('Which word is a synonym of "rapid"? A) Slow B) Quick C) Heavy D) Quiet', 'B'),
]
TOOL_LIST = (
    'video_to_notes(url): make Obsidian notes from a YouTube video\n'
    'memory_offload(title, content, kind): save something to long-term memory\n'
    'memory_recall(query): search long-term memory\n'
    'obsidian_note(category, title, body): write a note in Obsidian\n'
    'job_status(job_id, wait_seconds): check a background job\n'
    'fcc_transcribe(file): transcribe an audio or video file\n')
TOOLS = [
    ('The owner says: "Make notes from https://www.youtube.com/watch?v=WftF2zJkvHY".',
     'video_to_notes', {'url': 'WftF2zJkvHY'}),
    ('The owner says: "Remember that my sister is called Amy."', 'memory_offload', {'content': 'amy'}),
    ('The owner asks: "What did I tell you about my sister?"', 'memory_recall', {'query': 'sister'}),
    ('You started job 20261128-1200-abc and want to know if it finished.', 'job_status', {'job_id': '20261128-1200-abc'}),
    ('The owner says: "Transcribe Downloads/talk.mp3".', 'fcc_transcribe', {'file': 'talk.mp3'}),
]


def generated_maths(rng: random.Random) -> list[tuple[str, float]]:
    """Fresh numbers every run, so a score can't come from memorising answers."""
    a, b = rng.randint(12, 89), rng.randint(12, 89)
    n, p = rng.randint(2, 9) * 20, rng.choice([10, 15, 20, 30, 40])
    start, step = rng.randint(1, 9), rng.randint(3, 7)
    return [(f'What is {a} x {b}?', a * b),
            (f'What is {p}% of {n}?', n * p / 100),
            (f'What is the 6th number in the sequence {start}, {start + step}, {start + 2 * step}, ...?', start + 5 * step)]


def final_answer(text: str) -> str:
    text = re.sub(r'<think>.*?</think>', '', text or '', flags=re.S).strip()
    found = re.findall(r'ANSWER:\s*(.+)', text, flags=re.I)
    return (found[-1] if found else (text.splitlines() or [''])[-1]).strip().strip('*').strip()


def grade_number(answer: str, expected: float) -> bool:
    cleaned = re.sub(r'(?<=\d),(?=\d{3}\b)', '', answer)      # 1,000 -> 1000
    cleaned = re.sub(r'(?<=\d):(?=\d\d)', '', cleaned)          # 17:20 -> 1720
    cleaned = cleaned.replace(',', '.')                         # 0,05 -> 0.05
    for raw in re.findall(r'-?\d+(?:\.\d+)?', cleaned):
        if abs(float(raw) - expected) <= 1e-6 + abs(expected) * 1e-4:
            return True
    return False


def grade_choice(answer: str, expected: str) -> bool:
    m = re.search(r'\b([A-D])\b', answer.upper())
    return bool(m) and m.group(1) == expected


def grade_tool(answer: str, tool: str, args: dict) -> bool:
    m = re.search(r'\{.*\}', answer, flags=re.S)
    if not m:
        return False
    try:
        data = json.loads(m.group(0))
    except ValueError:
        return False
    if not isinstance(data, dict) or str(data.get('tool', '')).strip() != tool:
        return False
    got = data.get('args') if isinstance(data.get('args'), dict) else {}
    return all(str(v).casefold() in str(got.get(k, '')).casefold() for k, v in args.items())


class ModelTest:
    def __init__(self, settings, files, memory, jobs, base_url=LMSTUDIO, seed=None):
        self.settings, self.files, self.memory, self.jobs = settings, files, memory, jobs
        self.base_url = base_url
        self.seed = seed

    # ---------- entry ----------
    def start(self):
        self.settings.require('files')
        self.settings.require_not_stopped()
        job = self.jobs.start('model_test', 'Model test', self._run)
        job['next'] = 'Running in the background (a few minutes). Check with job_status(job_id, wait_seconds=45).'
        return job

    def history(self):
        runs = self._runs()
        return {'runs': [{k: r[k] for k in ('date', 'model', 'total', 'scores', 'fixed_with_lessons') if k in r} for r in runs[-10:]],
                'notes': {'history': HISTORY_NOTE, 'lessons': LESSONS_NOTE}}

    # ---------- the job ----------
    def _run(self, ctx):
        session = requests.Session(); session.trust_env = False
        try:
            model = self._model(session)
            rng = random.Random(self.seed)
            items = ([{'cat': 'maths', 'q': q, 'a': a} for q, a in MATHS + generated_maths(rng)]
                     + [{'cat': 'knowledge', 'q': q, 'a': a} for q, a in KNOWLEDGE]
                     + [{'cat': 'tools', 'q': q, 'tool': t, 'args': a} for q, t, a in TOOLS])
            for n, item in enumerate(items):
                item['id'] = f'{item["cat"]}-{n}'
            total_steps = len(items) + 4
            ctx.stage('questions', f'Asking {len(items)} questions to {model}')
            for n, item in enumerate(items, 1):
                ctx.set(progress=round(n * 100 / total_steps, 1), detail=f'Question {n} of {len(items)} ({item["cat"]})')
                item['given'] = self._ask_item(session, model, item, ctx)
                item['ok'] = self._grade(item)
            ctx.stage('memory', 'Memory test: can it find a code word saved in Obsidian?')
            memory_item = self._memory_test(session, model, rng, ctx)
            items.append(memory_item)
            ctx.set(progress=round((len(items) + 1) * 100 / total_steps, 1))
            ctx.stage('lessons', 'Retrying the missed questions with its own Lessons note')
            lessons = self._lessons_text()
            missed = [i for i in items if not i['ok'] and i['cat'] != 'memory']
            for item in missed:
                item['retry'] = self._ask_item(session, model, item, ctx, lessons=lessons)
                item['retry_ok'] = self._grade(item, item['retry'])
            ctx.set(progress=round((len(items) + 2) * 100 / total_steps, 1))
            run = self._score(model, items, missed)
            ctx.stage('reflect', 'Asking the model what it learned and how to improve')
            run['reflection'] = self._reflect(session, model, run, items, ctx)
            ctx.set(progress=round((len(items) + 3) * 100 / total_steps, 1))
            ctx.stage('save', 'Saving the report, history and lessons to Obsidian')
            report = self._save(run, items)
            ctx.set(progress=100.0)
            return {'report': report, 'total': run['total'], 'scores': run['scores'],
                    'fixed_with_lessons': run['fixed_with_lessons'], 'improved_since_last': run['learned_since_last'],
                    'next': f'Open {report} in Obsidian.'}
        finally:
            session.close()

    # ---------- asking ----------
    def _model(self, session):
        r = session.get(self.base_url + '/models', timeout=5)
        r.raise_for_status()
        ids = [m.get('id') for m in r.json().get('data', []) if isinstance(m, dict) and 'embed' not in str(m.get('id', '')).casefold()]
        if not ids:
            raise PolicyError('No chat model is loaded in LM Studio.')
        return ids[0]

    def _chat(self, session, model, messages, ctx, tools=None, max_tokens=700):
        ctx.check()
        if 'qwen' in model.lower() and messages[-1].get('role') == 'user':
            messages = messages[:-1] + [{**messages[-1], 'content': messages[-1]['content'] + '\n\n/no_think'}]
        body = {'model': model, 'temperature': 0, 'max_tokens': max_tokens, 'messages': messages}
        if tools:
            body['tools'] = tools
        answer = {}

        def call():
            try:
                answer['r'] = session.post(self.base_url + '/chat/completions', json=body, timeout=(10, 600))
            except Exception as exc:
                answer['e'] = exc
        worker = threading.Thread(target=call, daemon=True)
        worker.start()
        while worker.is_alive():
            ctx.sleep(0.25)                  # heartbeat: never looks stale; quick answers don't wait
        if 'e' in answer:
            raise answer['e']
        r = answer['r']
        r.raise_for_status()
        return (r.json().get('choices') or [{}])[0].get('message') or {}

    def _ask_item(self, session, model, item, ctx, lessons=''):
        if item['cat'] == 'tools':
            q = (f'Available tools:\n{TOOL_LIST}\n{item["q"]}\nWhich ONE tool do you call, with which arguments? '
                 'Reply with JSON only, like {"tool": "name", "args": {"key": "value"}}.')
        else:
            q = item['q']
        system = SYSTEM + (f'\n\nYour own lessons from earlier tests (use them):\n{lessons}' if lessons else '')
        msg = self._chat(session, model, [{'role': 'system', 'content': system}, {'role': 'user', 'content': q}], ctx)
        return (msg.get('content') or '').strip()[:1500]

    def _grade(self, item, given=None):
        given = item['given'] if given is None else given
        if item['cat'] == 'tools':
            return grade_tool(given, item['tool'], item['args'])
        final = final_answer(given)
        if isinstance(item['a'], str):
            return grade_choice(final, item['a'])
        return grade_number(final, float(item['a']))

    def _memory_test(self, session, model, rng, ctx):
        code = rng.choice(['amber', 'cobalt', 'falcon', 'meadow', 'orbit', 'harbor']) + '-' + str(rng.randint(100, 999))
        self.memory.offload('Model test code word', f'The model test code word is {code}.', 'fact', ['model-test'])
        tools = [{'type': 'function', 'function': {
            'name': 'memory_recall', 'description': 'Search long-term memory in Obsidian.',
            'parameters': {'type': 'object', 'properties': {'query': {'type': 'string'}}, 'required': ['query']}}}]
        messages = [{'role': 'system', 'content': 'You are JARVIS. Use your tools. Answer briefly.'},
                    {'role': 'user', 'content': 'What is the model test code word saved in your memory?'}]
        used_tool, answer = False, ''
        for _ in range(3):
            msg = self._chat(session, model, messages, ctx, tools=tools, max_tokens=400)
            calls = msg.get('tool_calls') or []
            if not calls:
                answer = (msg.get('content') or '').strip()
                break
            used_tool = True
            messages.append({'role': 'assistant', 'content': msg.get('content') or '', 'tool_calls': calls})
            for call in calls:
                try:
                    args = json.loads((call.get('function') or {}).get('arguments') or '{}')
                    found = self.memory.recall(str(args.get('query') or 'code word'), 3)
                except (ValueError, PolicyError) as exc:
                    found = {'error': str(exc)}
                messages.append({'role': 'tool', 'tool_call_id': call.get('id', 'm'), 'content': json.dumps(found)[:3000]})
        return {'id': 'memory-live', 'cat': 'memory', 'q': 'What is the model test code word saved in your memory?',
                'a': code, 'given': answer[:600], 'used_tool': used_tool, 'ok': used_tool and code in answer.lower()}

    # ---------- scoring and growth ----------
    def _runs(self):
        path = self.settings.data_dir / 'model_tests.json'
        try:
            return json.loads(path.read_text(encoding='utf-8')).get('runs', [])
        except (OSError, ValueError):
            return []

    def _score(self, model, items, missed):
        scores = {}
        for cat in CATEGORIES:
            group = [i for i in items if i['cat'] == cat]
            if group:
                scores[cat] = round(100 * sum(i['ok'] for i in group) / len(group))
        total = round(100 * sum(i['ok'] for i in items) / len(items))
        fixed = sum(1 for i in missed if i.get('retry_ok'))
        previous = self._runs()
        last = previous[-1] if previous else None
        stable = [i for i in items if not i['id'].startswith('maths-') or i['q'] in dict(MATHS)]
        learned = []
        if last:
            before = set(last.get('missed_ids', []))
            learned = [i['id'] for i in stable if i['id'] in before and i['ok']]
        return {'date': datetime.now().strftime('%Y-%m-%d %H:%M'), 'model': model, 'total': total, 'scores': scores,
                'fixed_with_lessons': f'{fixed} of {len(missed)}' if missed else 'nothing to fix',
                'fixed_count': fixed, 'missed_count': len(missed),
                'learned_since_last': len(learned), 'missed_ids': [i['id'] for i in stable if not i['ok']],
                'last': {k: last[k] for k in ('date', 'total', 'scores') if k in last} if last else None}

    def _lessons_text(self):
        path = self.settings.in_workspace(LESSONS_NOTE)
        if not path.is_file():
            return ''
        lines = [ln[2:].strip() for ln in path.read_text('utf-8', errors='replace').splitlines() if ln.startswith('- ')]
        return '\n'.join(f'- {ln}' for ln in lines[-15:])

    def _reflect(self, session, model, run, items, ctx):
        wrong = [f'- ({i["cat"]}) {i["q"][:160]} | you said: {final_answer(i["given"])[:80]} | correct: '
                 f'{i.get("a", i.get("tool"))}' + (' | fixed with lessons' if i.get('retry_ok') else '')
                 for i in items if not i['ok']][:12]
        trend = (f'Last time: {run["last"]["total"]}% ({run["last"]["date"]}). Now: {run["total"]}%.' if run['last']
                 else f'First test. Score: {run["total"]}%.')
        prompt = (f'Your test results. {trend} Scores by area: {run["scores"]}. With your lessons you fixed '
                  f'{run["fixed_with_lessons"]} of the questions you missed. Questions now right that were wrong last time: '
                  f'{run["learned_since_last"]}.\nMistakes:\n' + ('\n'.join(wrong) or '- none') +
                  '\n\nWrite short Markdown with these headings: ## What went wrong and why, '
                  '## Is my saved knowledge helping my decisions?, ## How I am improving, '
                  '## Lessons (3 to 5 lines, each starting with "LESSON:" and a concrete rule to apply next time).')
        try:
            msg = self._chat(session, model, [{'role': 'system', 'content': 'You reflect honestly on your own test results.'},
                                              {'role': 'user', 'content': prompt}], ctx, max_tokens=900)
            text = re.sub(r'<think>.*?</think>', '', msg.get('content') or '', flags=re.S).strip()
        except (requests.RequestException, ValueError) as exc:
            text = f'_Reflection skipped: {exc}_'
        return text[:6000]

    # ---------- saving to Obsidian ----------
    def _save(self, run, items):
        self.files.create_folder(FOLDER)
        stamp = datetime.now().strftime('%Y-%m-%d %H%M')
        safe_model = re.sub(r'[^A-Za-z0-9 ._-]+', ' ', run['model'])[:40].strip()
        rel, n = f'{FOLDER}/{stamp} {safe_model}.md', 1
        while self.settings.in_workspace(rel).exists():
            n += 1
            rel = f'{FOLDER}/{stamp} {safe_model} {n}.md'
        last = run['last']
        compare = '\n'.join(
            f'| {cat} | {last["scores"].get(cat, "-") if last else "-"}% | {run["scores"][cat]}% | '
            + (_arrow(last['scores'].get(cat), run['scores'][cat]) if last else 'first run') + ' |'
            for cat in run['scores'])
        rows = '\n'.join(
            f'| {"✅" if i["ok"] else "❌"} | {i["cat"]} | {i["q"][:90].replace("|", "/")} | '
            f'{(final_answer(i["given"]) if i["cat"] != "tools" else i["given"])[:60].replace(chr(10), " ").replace("|", "/")} | '
            f'{str(i.get("a", i.get("tool")))[:30]} | '
            + ('fixed ✅' if i.get('retry_ok') else ('still wrong' if 'retry' in i else '')) + ' |'
            for i in items)
        props = (f'---\ntype: model-test\nmodel: "{run["model"]}"\ndate: {run["date"]}\ntotal: {run["total"]}\n'
                 + ''.join(f'{cat}: {v}\n' for cat, v in run['scores'].items())
                 + f'fixed_with_lessons: "{run["fixed_with_lessons"]}"\nlearned_since_last: {run["learned_since_last"]}\n'
                 'tags: [model-test]\n---\n')
        body = (f'# Model test {run["date"]} · {run["model"]}\n\n'
                f'**Score: {run["total"]}%** · fixed with its own lessons: **{run["fixed_with_lessons"]}** · '
                f'right now but wrong last time: **{run["learned_since_last"]}**\n\n'
                f'## Compared with last time\n\n| Area | Last | Now | Change |\n|---|---|---|---|\n{compare}\n\n'
                f'## Every question\n\n| | Area | Question | Its answer | Correct | Retry with lessons |\n|---|---|---|---|---|---|\n{rows}\n\n'
                f'## Its reflection\n\n{run["reflection"]}\n\n'
                f'Links: [[Model Test History]] · [[Lessons]]\n')
        self.files.write_text(rel, props + body)
        # history (data + note)
        runs = self._runs() + [{k: run[k] for k in ('date', 'model', 'total', 'scores', 'fixed_with_lessons',
                                                  'learned_since_last', 'missed_ids')} | {'report': rel}]
        path = self.settings.data_dir / 'model_tests.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({'runs': runs[-200:]}, indent=1), encoding='utf-8')
        table = '\n'.join(
            f'| {r["date"]} | {r["model"]} | {r["total"]}% | ' + ' | '.join(f'{r["scores"].get(c, "-")}%' for c in CATEGORIES)
            + f' | {r["fixed_with_lessons"]} | [[{r["report"].rsplit("/", 1)[-1][:-3]}]] |' for r in reversed(runs[-50:]))
        history = ('---\ntype: index\ntags: [model-test]\n---\n# Model Test History\n\nNewest first. '
                   'Graded by code. "Fixed with lessons" = missed questions answered right on a retry with its Lessons note.\n\n'
                   '| Date | Model | Total | Maths | Knowledge | Tools | Memory | Fixed with lessons | Report |\n'
                   '|---|---|---|---|---|---|---|---|---|\n' + table + '\n\nSee also: [[Lessons]]\n')
        hp = self.settings.in_workspace(HISTORY_NOTE)
        self.files.write_text(HISTORY_NOTE, history, overwrite=hp.exists())
        # lessons the next run will use
        new = [ln.split('LESSON:', 1)[1].strip() for ln in run['reflection'].splitlines() if 'LESSON:' in ln]
        old = self._lessons_text().splitlines()
        seen = {re.sub(r'\s*\(\d{4}-\d\d-\d\d\)$', '', ln[2:]).casefold() for ln in old}
        added = [ln for ln in new if ln and ln.casefold() not in seen][:5]
        lines = [ln[2:] for ln in old] + [f'{lesson} ({run["date"][:10]})' for lesson in added]
        lp = self.settings.in_workspace(LESSONS_NOTE)
        self.files.write_text(LESSONS_NOTE, '---\ntype: lessons\ntags: [model-test]\n---\n# Lessons\n\n'
                              'Rules the model wrote for itself after its tests. The next test gives it these when it retries.\n\n'
                              + '\n'.join(f'- {ln}' for ln in lines[-30:]) + '\n', overwrite=lp.exists())
        return rel


def _arrow(before, now):
    if before is None:
        return 'new'
    return '▲ better' if now > before else ('▼ worse' if now < before else '= same')
