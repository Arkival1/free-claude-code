# Changelog

## 3.5.4 — 28 Nov 2026

### Added
- **Live progress in the FCC orb window:** every JARVIS job (like video notes) shows as a progress bar with "Step 3 of 6: Downloading audio", FCC's real download and transcription %, how long it has been running, and its latest log lines. A live feed lists each tool JARVIS uses, from LM Studio chat or the orb. Needs the FCC Orb update (FCC 6.7.0). If FCC is not running, JARVIS works exactly as before.

## 3.5.3 — 28 Nov 2026

### Changed
- **Separate downloads:** the JARVIS update and the FCC voice Orb update are now two downloads. JARVIS: extract, double-click `UPDATE_JARVIS.bat`. Orb: extract, double-click `UPDATE_ORB.bat`. (`INSTALL_EVERYTHING.bat` is moved aside by the updater.)
- Opening `START_JARVIS.bat` inside a downloaded update folder now says so, finds your real JARVIS and opens its menu instead of showing a config.json error.

## 3.5.2 — 28 Nov 2026

### Changed (from the owner's run: ytmp3 panel changed, OpenWhispr closed, built-in Whisper broken)
- **Video notes now use FCC first, on this PC:** FCC downloads the YouTube audio (yt-dlp with Deno, audio only) and Whisper inside FCC transcribes it with timestamps. FCC starts by itself in the background; the orb window does not need to be open. You still approve the download (or use auto-approve, START_JARVIS.bat → A); the file is checked to be real audio before use.
- Fallbacks stay: audio from the ytmp3.zone website, then direct; transcription by OpenWhispr, then built-in Whisper.
- New tool `fcc_transcribe(file)`: transcribe any audio or video file in the workspace with FCC's Whisper.
- The advisor wording now matches Local only: it uses a model on this PC unless you turn Local only off.

## 3.5.1 — 27 Nov 2026

### Added
- `INSTALL_EVERYTHING.bat`: one double-click updates JARVIS, installs the JARVIS voice Orb (FCC, orb only, no coding agents) and downloads its offline voice and ears. Afterwards the orb runs fully on this PC: LM Studio model, Kokoro voice, Whisper ears, Obsidian memory. Local only is on by default, so the advisor can only be a local model.
- `fcc_ask_advisor`: when you switch the advisor on in the orb settings, JARVIS can ask a second model (a local one while Local only is on) for advice on which tools to use. The advisor can only search and read JARVIS's tool list. It cannot run any tool and never sees your notes, memory, files or chat. JARVIS still decides and acts.

## 3.5.0 — 27 Nov 2026

### Added
- **Long-term memory in Obsidian** (`JARVIS_Brain/Memory/`):
  - `memory_offload` saves facts, preferences, decisions, tasks, people, ideas and conversation summaries as tidy notes (front matter, summary line, tags, links). Each save is listed in **Memory Index** and today's Daily note. Saving the same title again adds an Update section instead of a duplicate.
  - `memory_recall` is a local RAG search over the whole vault: notes are cut into heading-aware chunks, ranked with BM25 (it also matches word forms like "plan / planned"), and refreshed incrementally. Optional LM Studio embeddings re-rank results (`"rag_embeddings": "lmstudio"` in config.json).
  - `memory_resume` gives a short briefing (things to remember, the last conversations, related notes) so a new chat carries on where the old one stopped. `memory_reindex` rebuilds the search index.
- **FCC voice Orb tools:** `fcc_status`, `fcc_open_orb`, `fcc_say` (speak a short message through the orb) and `fcc_help`. Only 127.0.0.1 is contacted.
- **START_JARVIS.bat → O** opens the JARVIS voice Orb, or explains how to install FCC once.
- New skills: `obsidian_memory` (remember, recall, resume, write great notes) and `fcc_orb`.
- These 8 tools stay available whatever `mcp_tool_profile` you choose.

## 3.4.4 — 27 Nov 2026

### Fixed (from the owner's real ytmp3.zone run)
- **Pop-up ads after clicking Download:** JARVIS now waits a few seconds for the download to start. If an ad tab opened, it closes it, returns to the converter and clicks the same row's Download again (up to 5 tries), until the download starts. If an ad sends the converter tab itself to another site, it goes back. It still never clicks anything except the approved row's Download button, and gives up cleanly ("try the direct YouTube route") if no download ever starts.
- `START_JARVIS.bat` run from a downloaded update package now explains to use `UPDATE_JARVIS.bat` instead of showing a config.json error.

## 3.4.3 — 27 Nov 2026

### Added
- **Auto-approve YouTube audio (owner switch, off by default):** `START_JARVIS.bat` → **A**. When ON, video notes no longer wait for you to click Approve. Only one video's audio file (Opus/M4A/MP3) can be auto-approved; programs and every other download still need your approval. Files are still size-limited, checked and quarantined. The model cannot change this setting (it lives in config.json, outside the workspace).

## 3.4.2 — 27 Nov 2026

### Added
- **One-click updates:** extract the ZIP anywhere and double-click `UPDATE_JARVIS.bat`. It finds your JARVIS folder by itself, keeps config.json, .venv, notes and the LM Studio connection, backs up replaced files to `_update_backups`, moves old leftovers aside (never deletes), checks that the new version loads, and offers to install Windows UI Automation. `UPDATE_JARVIS.bat undo` restores the previous version.

## 3.4.1 — 27 Nov 2026 (tested through the real MCP server on a developer fake desktop)

### Obsidian
- Notes can go into folders that already exist in the owner's vault (e.g. `06 Research`), or standard categories can be mapped with `"obsidian_folders": {"Research": "06 Research"}` in config.json. JARVIS never invents new top-level folders, and a wrong folder name now lists the valid ones.
- Search: every word must appear (not necessarily together), best matches first, and the snippet shows the text around the match.
- `desktop_open_obsidian(note=...)` opens ONE note by title or path, and waits up to 8 s for the Obsidian window instead of 0.25 s (it used to report "not visible" while Obsidian was still starting).
- New Obsidian skill guide: search before writing, choosing folders, good titles, links as lists, journal, chat memory, mind maps, showing notes, reading back.

## 3.4.0 — 27 Nov 2026 (tested on a developer fake desktop; not yet run on Windows)

### Added: app control by name (needs optional UI Automation, START_JARVIS.bat 9 > 1)
- `desktop_ui_controls` lists the front app's buttons, boxes and menu items by name (password contents never shown).
- `desktop_click_named` is forgiving ("save as" finds "Save As...", "next" finds "Next >"), lists choices instead of guessing when several match (pick with `index`), tells you when a control is greyed out, and reports whether anything changed.
- New: `desktop_type_into` (fills a named box and reads it back), `desktop_read_text`, `desktop_menu` ("File > Save As..."), `desktop_wait_for`, `desktop_focus_app`.
- The model is told to work by name first and use screenshot clicks only when an app shows no names.

### Improved mouse control
- Every screenshot click now checks what happened: `screen_changed` (with a close-up around the click so small changes such as a tick mark count), the window in front afterwards, and a warning when nothing changed.
- Typing works in any language (Café, ñ, 日本語, ✓) using Windows Unicode input, still without the clipboard.
- New OS layer (`jarvis_core/desktop_backend.py`) separates Windows calls from JARVIS's logic so the logic can be tested.

### Security
- JARVIS refuses to take a screenshot while a protected app (password manager, admin or system tool) is in front. Before, it refused clicks there but would still capture the screen.
- JARVIS never types into or reads password boxes.

### Tested
- 42 practice missions on a developer-only fake desktop at 100 %, 125 % and 150 % display scaling: tiny buttons, zoomed clicks, focus-stealing pop-ups, drag and drop, scrolling, Unicode typing, protected apps, filling a form, menu + Save dialog, duplicate names, app switching. 42/42 pass (before the upgrade: 10/28).

## 3.3.0 — 26 Nov 2026 (simulated end to end; not yet run on Windows)

### Added
- Tested end to end in a developer-only simulation (33 scenarios; not shipped).
- The Self-test tab and `jarvis_sim` folder from the first 3.3 build were removed again: testing is done by the developer, not on the owner's PC.

### Fixed (found by the simulator)
- After approval, JARVIS re-typed the link and pressed Start again: the converter's cross-site frame reports a blank address for ~250 ms on a new connection. JARVIS now waits for it and reuses the page.
- Website down / browser timeouts crashed the job instead of switching to the direct YouTube route.
- A cancelled too-big download left a partial file in quarantine.
- A human check that never cleared used up the owner's approval. Approvals are now spent right before the click.
- Pressing Deny made JARVIS try the other route and ask again. Deny now stops the whole job.
- Running the same video twice could find no Download button on the old page; it now reloads the page once.
- An untrusted converter panel (unknown site, or wrong video) now stops in ~5 s instead of 60 s.
- The runner no longer accepts "TASK_COMPLETE" while the model's video job is still running.
- `job_status` accepts `"45"` as text, caps waits at 50 s, and trims spaces from job ids (small-model habits).

## 3.2.0 — 26 Nov 2026 (offline + local-browser tested; not yet run on Windows)

### Added
- **JARVIS Workstation** (`workstation.py`, `START_WORKSTATION.bat`, menu **W**): owner desktop app with Video → Notes, Jobs, Approvals, System check, Coming next, and an EMERGENCY STOP button. Approve downloads right in the app.
- **`video_to_notes`**: one call does the whole YouTube → audio → local transcript → Obsidian notes job in tested code (`jarvis_core/pipeline.py`), instead of a 4B model chaining 15 tool calls.
- **ytmp3.zone website route** (`jarvis_core/converter.py`): types the link like a person, reads it back, presses Start, finds the converter panel inside its embedded `embed.dlsrv.online` frame (the old DOM tool could never see it), checks the video id, picks Opus → M4A → MP3 320, clicks only that row after owner approval, closes pop-up ads, catches the file in a quarantine folder and checks its signature/codec before keeping it. Human checks ("verify you are human") are left to the owner.
- **OpenWhispr integration** (`jarvis_core/openwhispr.py`) through OpenWhispr's own local bridge (`POST /v1/transcribe`, OpenWhispr 1.10.0+): no mouse clicks, no cloud, uses the model chosen in OpenWhispr.
- **Background jobs** (`jarvis_core/jobs.py`) + `job_status` / `job_list` / `job_cancel`: long work no longer hits LM Studio's tool timeout (the cause of "Tool call failed" and the used-up approval in 3.1).
- Full-length built-in Whisper transcripts (`transcribe_full`), auto-saved transcripts and AI study notes from the local LM Studio model, daily-journal entry, `openwhispr_status` tool, `video_to_obsidian` skill guide.

### Fixed
- Downloads/transcription timing out in LM Studio and the model then claiming approval was missing.
- Diagnose (menu 3) crashing with `No module named 'requests'` (hotfix 1, included).

### Unchanged on purpose
- Downloads still need one-use owner approval. JARVIS cannot approve, and never solves human checks.

## 3.1.0 — 26 Nov 2026 (offline-tested only; not yet run on Windows)

### Added
- Grouped tools (`jarvis_core/tool_groups.py`). The autonomous runner and Memory Chat send only the groups a goal needs; the runner adds a group when the model calls `jarvis_load_tools(group)` and restores loaded groups on resume. Measured request size for a simple task: 39.6 KB → 12.3 KB.
- `mcp_tool_profile` in `config.json` (or `JARVIS_TOOL_PROFILE` env var) to register fewer MCP tools for LM Studio chat. Default `full` is unchanged.
- Audio format priority Opus → M4A → native ≥315 kbps MP3, chosen from the video's real formats; exact format/destination shown before owner approval; no silent substitution; ffprobe codec check; `.opus` accepted for local transcription.
- Menu **C** (continue paused autonomous task) and **P** (approve a project). Before this, the only way was a command-line `py manage.py approve`, and fresh v3 installs had no approved project, so every task/note/project tool failed.
- Diagnose (menu 3) reports yt-dlp, faster-whisper, FFmpeg/ffprobe, Whisper model and LM Studio server status.

### Fixed
- `obsidian_note` rejected a list of links (models usually send a list) with a validation error. Lists and comma text are both accepted; `[[...]]` brackets are stripped.
- `obsidian_canvas` rejected `[{"text": ...}]` nodes; now accepted, and the tool description shows an example.
- Long YouTube/desktop guidance is only added to the system prompt when those tools are offered.
- Stale instructions pointing to `.bat` files that do not exist in v3 (`JARVIS_Memory_Chat.bat`, `JARVIS_Resume.bat`, `JARVIS_Autonomous.bat`, `INSTALL_*.bat`, `py manage.py approve`).

### Unchanged on purpose
- MCP name `jarvis-clean-v3` and the data folder, so 3.1 installs over 3.0.
- ytmp3.zone buttons stay blocked; downloads still need one-use owner approval.
