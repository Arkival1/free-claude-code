"""Owner-only local screen/activity display. Nothing is streamed, stored or uploaded.

This is a real screenshot viewer in the Windows user session, NOT an embedded
LM Studio visualization. The screenshot is kept in memory only.
"""
from __future__ import annotations
from datetime import datetime
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from PIL import ImageGrab,ImageTk
from jarvis_core.policy import Settings

ROOT=Path(__file__).resolve().parent
SETTINGS=Settings(ROOT/'config.json')
STOP=ROOT/'STOP_JARVIS.txt'

class Monitor(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('JARVIS — LIVE LOCAL ACTIVITY')
        self.geometry('1000x760');self.minsize(750,500)
        self.preview=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='Idle — no events observed')
        top=ttk.Frame(self,padding=12);top.pack(fill='x')
        ttk.Label(top,text='JARVIS · Live Activity Monitor',font=('Segoe UI',16,'bold')).pack(side='left')
        ttk.Button(top,text='EMERGENCY STOP',command=self.stop).pack(side='right',padx=(6,0))
        ttk.Button(top,text='Open workspace',command=self.open_workspace).pack(side='right')
        ttk.Checkbutton(top,text='Local screenshot preview',variable=self.preview).pack(side='right',padx=10)
        ttk.Label(self,textvariable=self.status).pack(anchor='w',padx=12)
        self.screen=tk.Label(self,text='Enable Screen in JARVIS Control Panel, then tick Local screenshot preview.\nLive image stays in RAM; it is never recorded by this monitor.',bg='#16202b',fg='#eaf0f8',height=16)
        self.screen.pack(fill='both',expand=True,padx=12,pady=8)
        ttk.Label(self,text='Recent actual MCP tool calls and autonomous-runner events (no tool input or secrets logged):').pack(anchor='w',padx=12)
        self.log=tk.Text(self,height=12,wrap='word',state='disabled',font=('Consolas',10))
        self.log.pack(fill='both',expand=True,padx=12,pady=(4,12))
        self._image=None;self._tick()
    def stop(self):
        STOP.touch(exist_ok=True)
        self.status.set('PAUSED — STOP file created. Disconnect MCP/stop runner for immediate interruption.')
    def open_workspace(self):
        import os
        SETTINGS.reload()
        SETTINGS.workspace.mkdir(parents=True,exist_ok=True)
        os.startfile(str(SETTINGS.workspace))
    def _tick(self):
        try:
            SETTINGS.reload()
            lines=[]
            for fn in ['activity.jsonl','autonomy_log.jsonl']:
                p=SETTINGS.data_dir/fn
                if p.exists():
                    # Bound the file read to last 256 KB to prevent memory pressure.
                    with p.open('rb') as fh:
                        fh.seek(0,2);end=fh.tell();fh.seek(max(0,end-262144));raw=fh.read()
                    for line in raw.splitlines():
                        try:
                            item=json.loads(line.decode('utf8'))
                            lines.append((item.get('time',''),item.get('tool',item.get('name',item.get('type','activity'))),item.get('status',item.get('type','')),item.get('detail',item.get('reason',''))))
                        except (ValueError,UnicodeError):pass
            lines=sorted(lines,key=lambda t:t[0])[-40:]
            content='\n'.join(f'{date[:19]}  {name}  {status}' + (f'  [{detail[:80]}]' if detail else '') for date,name,status,detail in lines) or 'No activity recorded yet.'
            self.log.configure(state='normal');self.log.delete('1.0','end');self.log.insert('1.0',content);self.log.see('end');self.log.configure(state='disabled')
            mission=''
            mp=SETTINGS.data_dir/'active_mission.json'
            if mp.exists():
                try:
                    m=json.loads(mp.read_text(encoding='utf8'))
                    mission=f" · Mission: {m.get('status','?')} / turn {m.get('turns',0)}"
                except (OSError,ValueError):pass
            self.status.set('PAUSED (STOP file exists)' if STOP.exists() else f'No streaming to cloud · {len(lines)} recent events · local MCP'+mission)
            if self.preview.get():
                if not SETTINGS.enabled('screen'):
                    self.screen.config(image='',text='Screenshot permission is OFF. Enable Screen in the owner Control Panel.')
                    self._image=None
                else:
                    img=ImageGrab.grab(all_screens=False)
                    img.thumbnail((940,430))
                    self._image=ImageTk.PhotoImage(img)
                    self.screen.configure(image=self._image,text='')
            else:
                self.screen.configure(image='',text='Local live preview OFF. Tick the checkbox to show desktop screenshots.')
                self._image=None
        except Exception as exc:
            self.status.set('Monitor error: '+str(exc)[:150])
        self.after(1400,self._tick)

if __name__=='__main__':Monitor().mainloop()
