# JARVIS Clean v3.5 — one fresh Windows installation

This is a **new, separate local Windows JARVIS install**, built from the existing v2.8.8 MCP, mouse tools, rolling Obsidian memory chat and autonomous agent. It **does not** automatically repair or replace old installations and is **not** a full rewrite of the reasoning engine.

## Getting started

Close LM Studio. Extract the entire package to a **new permanent directory** outside OneDrive and double-click `START_JARVIS.bat`. Choose **1 Setup/Repair** and approve installation of dependencies, which now installs and verifies **Playwright in the same `.venv` Python** used by LM Studio. You only install dependencies once. Python 3.11+ must already be installed. Internet is used for installing packages; model inference still stays in LM Studio on `127.0.0.1:1234`.

The wizard can reuse your existing workspace at `C:\Users\Spawn\OneDrive\Desktop\CJARVIS_Workspace`, which leaves the original `JARVIS_Brain` vault and its notes in place, or you can choose another workspace. The new agent's internal state is stored separately in `%LOCALAPPDATA%\JARVIS_Clean_v3\data`. Your old installation is not removed. Do not move or overwrite the old folder during installation.

Choose **2 LM Studio Connection** to open the generated `LM_STUDIO_SNIPPET.json`. In LM Studio's MCP configuration, use its **`jarvis-clean-v3`** entry. Disable or remove your OLD `jarvis-local-v2` integration so it doesn't connect to the old Python runtime. Merge the entry into your existing JSON rather than pasting a full object over the top of other integrations. Connect the new server and call `jarvis_status` (expected `3.2.0`).

Use **3 Diagnostic** to confirm that the package, exact interpreter, Playwright and config are correct; **4 Browser Test** to check webpage field entry on a supported public site without downloading; **5 Memory Chat** for rolling long-chat memory and Obsidian journals; **6 Autonomous Runner** for tasks; **7 Live Monitor** and **8 Control Panel** for oversight; **C** continues a paused autonomous task and **P** approves a project for tasks/notes/code. Choose **9** to install owner-approved optional extras for UI automation, YouTube captions or local Whisper transcription.

## New in 3.5: voice Orb and memory that never runs out

**Voice Orb (FCC).** Install FCC once from PowerShell (not as administrator):

    irm https://raw.githubusercontent.com/Arkival1/free-claude-code/main/scripts/install.ps1 | iex

Then double-click **JARVIS Orb** on the desktop (or START_JARVIS.bat -> O). Click the orb and talk, or type.
JARVIS answers with your LM Studio model and his tools, and reads each reply aloud when it finishes typing.
Choose the voice with the gear button. Later FCC updates: run `fcc-update`.

**Memory.** Ask JARVIS to remember anything ("remember that my sister is called Amy"). It is saved to
`JARVIS_Brain/Memory` in Obsidian (`memory_offload`). Ask about the past and he searches the vault first
(`memory_recall`). In the orb, older parts of long talks are saved automatically, and a new talk starts
with a memory briefing (`memory_resume`), so you can keep talking after the context is full.

## Updating JARVIS (one click)

Close LM Studio, extract the new ZIP anywhere, and double-click **`UPDATE_JARVIS.bat`**. It finds your JARVIS folder (even inside nested folders), shows the old and new version, and after you type **y** it backs up every file it replaces (`_update_backups`), copies the new files, moves old leftovers aside, and checks that JARVIS loads. Your `config.json`, `.venv`, notes and LM Studio connection are not touched. **`UPDATE_JARVIS.bat undo`** puts the previous version back.

## New in 3.4: better mouse and app control

Install the optional **Windows UI Automation** package once (`START_JARVIS.bat` → **9** → **1**). Then JARVIS can use Windows apps **by the names of their buttons, boxes and menus**, the way you would read them, instead of guessing pixel positions: list controls, click by name, type into a named box and check it, use menus ("File > Save As..."), wait for dialogs, switch apps. Every click now reports whether anything changed. Typing works in any language. JARVIS will not take screenshots while a password manager or admin tool is in front.

## New in 3.2: JARVIS Workstation (see CHANGELOG.md)

Double-click **`START_WORKSTATION.bat`** (or choose **W** in `START_JARVIS.bat`). Paste a YouTube link, press **Start**, and watch: JARVIS opens ytmp3.zone in its own browser window, types the link, picks the best audio (Opus → M4A → MP3 320), and then **asks you** in the yellow box. Click **Approve download**. It downloads and checks the file, has **OpenWhispr** transcribe it locally (keep the OpenWhispr app open; version 1.10.0 or newer), saves the transcript and study notes to `JARVIS_Brain/Research/YouTube`, and ticks each step.

- If the website shows a "verify you are human" check, the Workstation tells you. Click it yourself in the JARVIS browser window; JARVIS never does that part.
- In LM Studio, just ask: *"Make notes from https://youtu.be/..."*. JARVIS calls `video_to_notes`; the Workstation pops the approval up for you.
- For AI notes, turn on LM Studio's local server (Developer tab, port 1234). Without it you still get the full transcript.

## New in 3.1

- **Smaller prompts for your 4B model.** The autonomous runner and Memory Chat now send only the tool groups a goal needs (about 3K tokens for a simple task instead of about 10K). The model can add a group itself with `jarvis_load_tools`. This changes what the model *sees*, never what it is *allowed* to do.
- **Audio in your preferred format:** `youtube_audio_download_request` picks Opus, then M4A, then native 320 kbps MP3 from the formats the video really has, and shows you format + destination before you approve. `.opus` files can be transcribed.
- **Optional smaller MCP tool list for LM Studio chat:** add `"mcp_tool_profile": "video,brain,desktop"` to `config.json` (groups: files, projects, research, video, brain, downloads, browser_dom, desktop, desktop_precise; default `full`). Restart the MCP connection after changing it.
- Diagnose (menu 3) now checks yt-dlp, faster-whisper, FFmpeg, the Whisper model and whether LM Studio's server is reachable.

## Upgrading from 3.0

Close LM Studio. Extract this ZIP and copy its files **over your existing v3 program folder** (the one with `.venv` and `config.json`). The ZIP contains no `config.json` or `.venv`, so your settings and installed packages stay. The MCP name (`jarvis-clean-v3`) and data folder are unchanged. Restart LM Studio and check `jarvis_status` says `3.2.0`.

## LM Studio context length

Tell JARVIS your context size by adding `"context_tokens": 50000` (your number) to `config.json`. The autonomous runner then keeps much more of the task in view, and Workstation notes are written in one pass instead of pieces. The default is 8192.


In LM Studio, set the loaded model's **Context Length to at least 16384** if your RAM allows (Qwen3.5-4B supports much more). With ~7K, even the slimmer 3.1 prompts leave little room for the conversation, and video tasks that need screen tools use about 7K tokens of tool descriptions on their own.

## Where your work goes

The new program folder contains source and virtual environment. Your configured **workspace** stores projects and `JARVIS_Brain` notes; the **data_dir** stores new agent checkpoints and approval state. The old agent's configured data and chat state are left untouched. The Memory Chat uses the new data directory but can read/search old Markdown notes inside the shared vault. Never delete or format the previous workspace or data folders.

## Browser automation

Playwright is part of the single setup; no `INSTALL_BROWSER_DOM.bat` needed. It controls a separate Opera or Edge session (not your logged-in Opera tab), and the browser test verifies actual form values rather than counting a sent keystroke as success. Real websites may change or block automation; verification can still fail. The DOM bridge blocks converter action buttons and direct downloads. To download media use separate owner-approved tools; browser GUI control could still bypass these restrictions.

## Real-world limits

The fresh install **does not automatically fix unreliable model decisions or fully automate OpenWhisper**. It fixes the missing Playwright setup path, stale installs, config confusion and multiple-runtime issues, while preserving existing MCP functionality. Python tests were run offline, not on your actual Windows machine. A successful browser input test is needed on the Legion.

Run under a standard non-admin Windows account. Screen/click tools can interact with sensitive open apps; close those before autonomous work. OneDrive-backed notes can sync. `STOP_JARVIS.txt` blocks new tool calls; it may not stop actions already underway. `Start JARVIS` offers menu entries for creating/clearing that stop file.
