## v2.8.8 Browser DOM notes

- Playwright is an **owner-approved optional dependency**, not installed automatically.
- Browser automation launches a dedicated Opera/Edge profile under `%LOCALAPPDATA%/JARVIS_Clean_v3/BrowserAutomation`; only public transcript/converter hosts are supported.
- Browser's CDP debug interface is bound to loopback on port 9341, but **any local process may be able to access it**; do not log into sensitive sites inside the dedicated automation profile. Close the automation browser after a task.
- Browser DOM actions explicitly block Download/Install/Payment and converter actions, because downloading must go through owner approval. This is defense-in-depth, not an OS-level download barrier; unrestricted GUI automation can bypass it.
- JARVIS does not automatically download video/audio or install extensions through this bridge. Whisper/OpenWhisper still requires audio saved locally.
- Never assume image-based clicks hit their target. Verify actual page form contents via browser DOM where available. Store only public video URLs.

# JARVIS Clean v3.4 — Security and Limitations

This is owner-operated experimental desktop agent software, **not a security sandbox** for unrestricted Windows GUI automation. It runs the model locally but may access websites for research.

- Run under a separate **standard Windows user**, not administrator. JARVIS refuses elevated startup, but other processes on the machine are outside its control.
- `STOP_JARVIS.txt` blocks new JARVIS tool actions. Ctrl+C/closing its terminal is the most direct stop. Current in-flight network or desktop actions may not stop instantly.
- The autonomous runner has **no turn cap** by default; user controls shutdown, and `TASK_COMPLETE:` ends successful tasks. Repeated exact tool results (5x), repeated errors (3x), no useful reply (3x), invalid requests, or owner approval blockers trigger a **pause** with checkpoint rather than endless retry loops.
- Checkpoints preserve local goal/task messages. Screenshots are not saved into checkpoints, but text/tool messages can include sensitive information. Do not put secrets in prompts. Backups and Windows ACLs are your responsibility.
- The developer lab executes only one source file in preinstalled offline Docker images, no host shell. Rootless user inside container, no network, resource and time limits. Docker is NOT perfect protection against exploits; do not run hostile code you don't trust.
- `official_download` requires owner approval of exact URL+filename. **Broad GUI control can download files outside the tool approval path**, so no claim is made that every download requires consent. To enforce that across Windows, OS-level browser download restrictions or a separate isolated account/VM would be needed.
- No unrestricted terminal tools, no elevation, no installation of downloaded software, no external AI API by default.
- Test on your Legion before using important files or leaving JARVIS unattended. Keep backups and inspect tool logs. Code passes offline automated tests; actual Windows compatibility isn't established here.

- Adviser tool calls have been removed. The active agent uses only the main local model. Existing adviser memories are retained unchanged for a possible future upgrade.

## v2.8.3 owner-confirmed model setup
`JARVIS_Install_Whisper_Model.bat` requires an owner typing YES to download from the specified Hugging Face source. Neither MCP nor autonomous agent exposes this installer. The download is independent from JARVIS's normal approval queue; it is a direct owner action. `JARVIS_Tools_Diagnose.bat` never downloads or executes the tool call it requests from the local model.

## v2.8.3 automatic broad mode

This upgrade enables broad non-admin app/screen/tools **by default**, including on
existing installations. Old settings are backed up before changes. JARVIS MCP
and the autonomous runner refuse to run as administrator. Registered app discovery
and UI automation exclude some protected credential/system/terminal executables.
Native file tools are still confined to the configured workspace.

**Important:** The download approval queue is not a network enforcement layer.
Browser/app UI interactions may download files without invoking it. Do not
assume all downloads require approval. Review trusted browser settings and
use a separate standard Windows account with personal files segregated.

Controls may be disabled again in `JARVIS_Control_Panel.bat` at any time.


### Transcript website and Chrome extension fallback (v2.8.4)
Only public YouTube video links are copied to the browser clipboard by `youtube_transcript_website_open`. Submitting the link to third-party sites discloses it to their servers; ClipSDK additionally retrieves/processes audio on its servers. External page content is untrusted. The clipboard import tool will save the current Windows clipboard text when JARVIS calls it; ensure the model has actually used the page's Copy transcript button first. It does not download files or silently install Chrome extensions. The extension requires owner review/installation through Chrome; its permissions/privacy policy should be checked before approval. `youtube_transcript_clipboard_import` saves to the bounded workspace, never overwrites and exposes only a short excerpt to the model. It is not a system-wide clipboard privacy barrier: any unrestricted GUI agent may still interact with sensitive desktop data, so use a dedicated standard-user account.

### v2.8.6 app-launch workflow
Automatic Obsidian/VS Code launch is limited to the owner's initial task text and still requires non-admin desktop permissions. Obsidian URI requests are constructed only from files inside JARVIS_Brain and never from a model-supplied URL or path. The app may need to be installed and its vault registered once. A request to launch is not proof of a visible window or completed project.

### v2.8.7 conversation-memory privacy
Memory Chat appends conversations (including user messages and bounded tool-action summaries) to `JARVIS_Brain/Chat Memory`. It also saves compact chat state under JARVIS's configured `data_dir`. On this user's Windows setup the Obsidian folder is inside OneDrive and **can sync to Microsoft**, despite inference remaining local. Avoid entering credentials or private account data, or use a non-syncing vault. The manual MCP tool does not access all LM Studio history; it stores **only explicitly passed text**. No built-in LM Studio chat message deletion or context rewrite is claimed.


## v3.0 fresh install
Playwright is installed by the owner-approved unified installer inside the new .venv. Existing data and Obsidian notes are not bundled in this ZIP. To avoid sensitive collision, the new state is stored under %%LOCALAPPDATA%%\JARVIS_Clean_v3\data. The old version remains untouched.

## v3.2 Workstation, website downloads and OpenWhispr

- **Approvals stay human-only.** Approving in the Workstation is the owner's action, the same as the Control Panel; the model has no tool that approves. Each approval names the exact video + format and works once.
- **Website route (ytmp3.zone):** hosts are fixed in code (`ytmp3.zone` page, `embed.dlsrv.online` converter frame), and the frame must carry the same video id. Only the approved row's Download button is clicked. Pop-up tabs are closed. Browser downloads are switched on only for that click, only into `data_dir/quarantine`, and switched back to *deny* afterwards. Files must pass a size limit and an audio signature check (plus ffprobe if installed); HTML, EXE, ZIP or anything else is deleted unopened.
- **Human checks (CAPTCHA/Turnstile) are never solved or bypassed by JARVIS.** It waits for the owner.
- **OpenWhispr bridge:** only `127.0.0.1`, ports 8200-8219, no proxies or redirects. The bridge key is read from `~/.openwhispr/cli-bridge.json` on each call and never shown to the model or logged. Only workspace audio files are sent (as a path; OpenWhispr reads the file itself).
- **Notes by LM Studio** go only to `127.0.0.1:1234`.
- Third-party converter sites carry ads and may change at any time; the direct YouTube route avoids them. Only download videos you are allowed to.

## v3.4 app control and mouse

- App control acts only on the front app when that app is allowed (same rules as clicks: no password managers, terminals, admin or system tools, no elevated apps).
- No screenshot is taken while a protected app is in front.
- Password boxes are never typed into, read, or listed with their contents.
- Name matching never guesses between several matches; it lists them and needs an explicit choice.
- Typing uses Windows Unicode key input, not the clipboard, so clipboard contents are never read or replaced.

## v3.4.3 auto-approve switch
- Off by default. Only the owner can turn it on (START_JARVIS.bat option A edits config.json, which no JARVIS tool can write).
- It covers only YouTube audio files named for one video id (`<id>.opus/.webm/.m4a/.mp3`, website or direct). Programs, archives and any other download still need a click.
- Downloaded files still go through the size limit, audio signature check, ffprobe (if installed) and quarantine.
