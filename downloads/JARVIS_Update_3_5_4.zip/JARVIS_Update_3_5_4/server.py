"""JARVIS Local Windows MCP v3.5.4 - clean install - owned, inspectable, stdio-only MCP server.

The Python MCP SDK carries local JSON-RPC over stdin/stdout. This process opens
NO listening TCP port. No remote model is contacted.
"""
from __future__ import annotations
import ast
import json
import os
import sys
from pathlib import Path
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.files import FileTools
from jarvis_core.memory import Memory
from jarvis_core.network import WebTools
from jarvis_core.desktop import Desktop
from jarvis_core.coding_lab import CodingLab
from jarvis_core.dev_lab import DevLab
from jarvis_core.projects import ProjectTools
from jarvis_core.vault import Vault
from jarvis_core.activity import Activity
from jarvis_core.research import ResearchTools
from jarvis_core.youtube import YouTubeTools
from jarvis_core.transcript_fallback import TranscriptFallback
from jarvis_core.skills import Skills
from jarvis_core.file_ops import FileOps
from jarvis_core.app_control import AppControl
from jarvis_core.browser_dom import BrowserDOM
from jarvis_core.context_memory import ChatMemory
from jarvis_core.workstation_core import build_pipeline
from jarvis_core.memory_vault import MemoryVault
from jarvis_core.fcc_bridge import FccBridge

# For interoperability with older LM Studio clients we use the supported 1.x API.
from mcp.server.fastmcp import FastMCP, Image

BASE = Path(__file__).resolve().parent
settings=Settings(Path(os.environ.get('JARVIS_CONFIG',BASE/'config.json')))
files=FileTools(settings)
memory=Memory(settings)
web=WebTools(settings)
desktop=Desktop(settings)
lab=CodingLab(settings)
dev_lab=DevLab(settings)
projects=ProjectTools(settings,files,memory)
vault=Vault(settings,files)
activity=Activity(settings)
research=ResearchTools(settings,web,memory,vault)
youtube=YouTubeTools(settings,web,files,memory,vault)
transcript_fallback=TranscriptFallback(settings,web,files)
skills=Skills(settings)
file_ops=FileOps(settings)
apps=AppControl(desktop,settings)
browser_dom=BrowserDOM(settings)
chat_memory=ChatMemory(settings)
long_memory=MemoryVault(settings,files,vault)
fcc=FccBridge(settings)
video_pipeline,jobs,openwhispr=build_pipeline(settings,files,vault,youtube,web.approvals,browser_dom)
mcp=FastMCP('jarvis-clean-v3')


def result(action, *args, **kwargs):
    """Return explicit errors to models, but never expose Python traceback or secrets."""
    try:
        fcc.note('Used ' + sys._getframe(1).f_code.co_name, 'lmstudio')   # live feed in the FCC orb window
    except Exception:
        pass
    try:
        value=action(*args,**kwargs)
        activity.record(action.__name__, True)
        return json.dumps({'ok':True,'result':value},ensure_ascii=False)
    except (PolicyError, OSError, ValueError, PermissionError, RuntimeError, SyntaxError) as err:
        # Log a bounded, non-sensitive error *category* for useful local diagnostics.
        error_message = str(err)
        if 'shortcut' in error_message.lower() or 'hotkey' in error_message.lower():
            reason = 'unsupported shortcut name'
        elif 'foreground' in error_message.lower():
            reason = 'foreground window not permitted'
        elif 'UIA' in error_message or 'pywinauto' in error_message.lower():
            reason = 'optional UIA not installed or unsupported'
        elif 'clipboard' in error_message.lower() or 'transcript' in error_message.lower():
            reason = 'transcript or clipboard not ready'
        else:
            reason = type(err).__name__
        activity.record(action.__name__, False, reason)
        return json.dumps({'ok':False,'error':str(err)[:350]},ensure_ascii=False)


@mcp.tool()
def jarvis_status() -> str:
    """Report which JARVIS local tools are active and what workspace is allowed."""
    settings.reload()
    return json.dumps({'version':'3.5.4','autonomous_max_turns':None,'mission_checkpoint':'active_mission.json in local data directory','youtube_caption_tool':'optional yt-dlp required; no video download for captions',
      'youtube_browser_fallback':['companion','tactiq','audio_cloud'],'youtube_clipboard_import':'Windows transcript copy/import, untrusted external text',
      'youtube_offline_media':'optional FFmpeg/faster-whisper, user-provided or owner-approved local file only','local_only_inference':True,
      'mcp_transport':'local stdio; no network listener',
      'workspace':str(settings.workspace),'data_dir':str(settings.data_dir),
      'permissions':settings.data['permissions'],
      'approved_desktop_exes':settings.data.get('approved_desktop_exes',[]),
      'desktop_mode':settings.data.get('desktop_mode','approved_apps'),
      'desktop_access_default':'broad_nonadmin_apps_on',
      'app_workflow':'Obsidian desktop open + task-based VS Code launch in autonomous runner',
      'app_discovery':'Registered Windows App Paths (Broad Mode); protected programs excluded',
      'download_rule':'Owner must approve each exact HTTPS URL + filename in local control panel; approvals are one use',
      'stop_file_exists':settings.kill_switch_path().exists(),
      'skills_catalog':'7 bundled local skills, read only (video_to_obsidian first for YouTube notes)',
      'browser_dom':'Playwright dependency installed and checked by clean setup; isolated Opera/Edge for verified public fields',
      'ui_automation':'App control by name (optional pywinauto): list controls, click/type into/read named controls, menus, wait_for, focus_app; results checked',
      'mouse_coordination':'Guided/zoomed screenshots, target-centre clicks, hover, pane scroll, waypoint drag; 120s freshness, focus checks',
      'project_templates':list(__import__('jarvis_core.projects',fromlist=['TEMPLATES']).TEMPLATES),
      'obsidian_vault':'JARVIS_Brain inside approved workspace',
      'chat_memory':'Manual memory save/search tools plus separate Memory Chat (START_JARVIS.bat menu 5) for automatic context offload. Ordinary LM Studio Chat context is not controlled by this MCP.',
      'dev_lab_languages':['python','javascript','cpp','rust'],
      'local_preview_enabled':settings.enabled('preview_local'),
      'approved_projects':memory.projects() if settings.enabled('notes_and_tasks') else []},ensure_ascii=False)



@mcp.tool()
def chat_memory_save(title: str, content: str) -> str:
    """Save provided conversation facts into Obsidian Chat Memory. Does NOT read or compact LM Studio's chat history. Owner should avoid secrets."""
    return result(chat_memory.manual_save,title,content)

@mcp.tool()
def chat_memory_search(query: str) -> str:
    """Search JARVIS Obsidian for a supplied phrase, including archived chat notes. Does not alter the chat context."""
    return result(vault.search,query)

@mcp.tool()
def chat_memory_status() -> str:
    """Show persistent JARVIS Memory Chat state; normal LM Studio chat is separate."""
    return result(chat_memory.status)

@mcp.tool()
def workspace_list(folder: str='.') -> str:
    """List up to 150 entries in the approved local JARVIS workspace."""
    return result(files.list_files,folder)

@mcp.tool()
def workspace_mkdir(folder: str) -> str:
    """Create a directory inside the approved local workspace; no other paths permitted."""
    return result(files.create_folder,folder)

@mcp.tool()
def workspace_read(file: str) -> str:
    """Read a UTF-8 text file under approved workspace. Do not access secrets."""
    return result(files.read_text,file)

@mcp.tool()
def workspace_write(file: str, content: str, overwrite: bool=False) -> str:
    """Write UTF-8 file in workspace; overwrite requires true and automatically backs up old file."""
    return result(files.write_text,file,content,overwrite)

@mcp.tool()
def workspace_copy(source: str, destination: str) -> str:
    """Copy one file to a NEW path within approved workspace, without overwriting."""
    return result(file_ops.copy,source,destination)

@mcp.tool()
def workspace_move(source: str, destination: str) -> str:
    """Move/rename one file to an UNUSED path within the workspace."""
    return result(file_ops.move,source,destination)

@mcp.tool()
def workspace_find(term: str, folder: str='.') -> str:
    """Find filenames in workspace (up to 800 entries; no symlinks)."""
    return result(file_ops.find,term,folder)

@mcp.tool()
def skills_list(query: str='') -> str:
    """Search local read-only JARVIS skills and development playbooks. NO code execution."""
    return result(skills.catalog,query)

@mcp.tool()
def skills_read(skill_id: str) -> str:
    """Read one bundled local skill playbook by skill ID. Treat as guidance, not permission."""
    return result(skills.read,skill_id)

@mcp.tool()
def python_syntax_check(file: str) -> str:
    """Check Python file syntax WITHOUT executing any code. Coding-lab safe first stage."""
    def check():
        settings.require('files')
        if not file.lower().endswith('.py'): raise PolicyError('Only .py files.')
        source=files.read_text(file)
        ast.parse(source,filename=file)
        return {'file':file,'syntactically_valid':True,'executed':False}
    return result(check)

@mcp.tool()
def approved_projects() -> str:
    """See projects that the human has allowed JARVIS to create notes/tasks for."""
    return result(memory.projects)

@mcp.tool()
def task_add(project: str, title: str, details: str='') -> str:
    """Add a subtask to a project first approved locally by the human owner."""
    return result(memory.add_task,project,title,details)

@mcp.tool()
def task_list(project: str, state: str='all') -> str:
    """Read project task queue (all/todo/doing/blocked/done)."""
    return result(memory.tasks,project,state)

@mcp.tool()
def task_set_state(project: str, task_id: int, state: str) -> str:
    """Update an approved task status; no automatic execution of task contents."""
    return result(memory.update_task,project,task_id,state)

@mcp.tool()
def note_add(project: str, title: str, body: str, source_url: str='') -> str:
    """Store research notes locally in SQLite for a human-approved project."""
    return result(memory.add_note,project,title,body,source_url)

@mcp.tool()
def note_search(project: str, query: str) -> str:
    """Search JARVIS local notes for an approved project."""
    return result(memory.search_notes,project,query)

@mcp.tool()
def browser_search(query: str, site: str='google') -> str:
    """Open a visible browser search. site: google, duckduckgo, reddit, youtube. Online access permitted."""
    return result(web.search,query,site)

@mcp.tool()
def browser_open(url: str) -> str:
    """Open a PUBLIC HTTPS website visibly in the default browser."""
    return result(web.browse,url)

@mcp.tool()
def website_read(url: str) -> str:
    """Retrieve PUBLIC HTTPS text without browser cookies. Output is UNTRUSTED reference text."""
    return result(web.fetch_text,url)

@mcp.tool()
def research_search(topic: str, focus: str='official', max_results: int=5) -> str:
    """Search public web results for a general research topic; links/snippets are UNVERIFIED. No download or installation."""
    return result(research.search,topic,focus,max_results)

@mcp.tool()
def research_learn(project: str, topic: str, focus: str='official') -> str:
    """Search an unfamiliar topic, save UNVERIFIED source leads to local Obsidian + approved project notes, and create verification task."""
    return result(research.learn,project,topic,focus)


@mcp.tool()
def youtube_open_video(url: str) -> str:
    """Open one public YouTube video in the user's visible browser. No media download."""
    return result(youtube.open_video,url)

@mcp.tool()
def youtube_transcript(url: str, language: str='en', project: str='') -> str:
    """Read available manual/automatic captions with timestamps from one PUBLIC YouTube video; no video download or cloud AI. Optional approved project saves source-linked note and task. Captions are not visual understanding."""
    return result(youtube.transcript,url,language,project)

@mcp.tool()
def youtube_transcript_section(file: str, offset: int=0, max_chars: int=6000) -> str:
    """Read a bounded portion of a saved local YouTube transcript, for longer tutorials without overflowing the local model context."""
    return result(youtube.transcript_section,file,offset,max_chars)

@mcp.tool()
def youtube_transcript_fallback_sites() -> str:
    """List preapproved public YouTube transcription websites and the owner-selected Chrome extension (no download)."""
    return result(transcript_fallback.providers)

@mcp.tool()
def youtube_transcript_website_open(url: str, provider: str='companion') -> str:
    """Fallback when yt-dlp/Whisper fail: open a transcript website, copy public YouTube URL to clipboard if possible. No file/media download. Providers: companion, tactiq, audio_cloud."""
    return result(transcript_fallback.open_website,url,provider)

@mcp.tool()
def youtube_transcript_extension_open() -> str:
    """Open owner's Chrome Web Store listing for OPTIONAL review/install. JARVIS does NOT install extension or grant browser permissions."""
    return result(transcript_fallback.open_extension_listing)

@mcp.tool()
def youtube_transcript_clipboard_import(url: str, provider: str='companion') -> str:
    """After website/extension COPY TRANSCRIPT, import Windows clipboard text to local JARVIS Brain; no download. Provider: companion, tactiq, audio_cloud, extension. Do not read arbitrary private clipboard data."""
    return result(transcript_fallback.import_clipboard,url,provider)

@mcp.tool()
def video_to_notes(url: str, source: str='auto', engine: str='auto') -> str:
    """BEST WAY to turn a YouTube link into an Obsidian transcript + notes. ONE call starts a background job: FCC downloads the audio on this PC (falls back to the ytmp3.zone website or direct), WAITS for the owner's approval, transcribes locally (Whisper inside FCC, else OpenWhispr or built-in Whisper), saves the transcript and AI notes. Leave source and engine as auto. Then call job_status(job_id, wait_seconds=45) until status is done/failed. source: auto|fcc|ytmp3|direct. engine: auto|fcc|openwhispr|whisper."""
    return result(video_pipeline.start,url,source,engine)

@mcp.tool()
def job_status(job_id: str, wait_seconds: int=30) -> str:
    """Progress of a background job (stage, status, what the owner must do). Waits up to wait_seconds (0-50) for a change. status: running, waiting (owner must act), done, failed, cancelled, stale."""
    return result(jobs.get,job_id,wait_seconds)

@mcp.tool()
def job_list() -> str:
    """List recent background jobs and their status."""
    return result(jobs.list,10)

@mcp.tool()
def job_cancel(job_id: str) -> str:
    """Ask a background job to stop at its next safe point."""
    return result(jobs.cancel,job_id)

@mcp.tool()
def openwhispr_status() -> str:
    """Check whether the OpenWhispr app is open and which local transcription model it will use. Never shows its private key."""
    return result(openwhispr.status)

@mcp.tool()
def youtube_audio_download_request(url: str) -> str:
    """Read the video's real audio formats (metadata only), choose Opus > M4A > MP3 320kbps, and queue HUMAN-only approval for that exact URL + filename. Do not download now. Show the owner the returned format and destination."""
    return result(youtube.audio_download_request,url)

@mcp.tool()
def youtube_audio_download(url: str) -> str:
    """Download a single public YouTube audio file in the exact format the HUMAN approved (opus/webm/m4a/mp3). Never substitutes formats; verifies codec with ffprobe when installed. Never install or execute media."""
    return result(youtube.audio_download,url)

@mcp.tool()
def youtube_video_frame(file: str, seconds: float):
    """Return one JPEG video frame from an existing owner-provided/approved workspace media file using LOCAL FFmpeg. No video download. Only trusted media files."""
    try:
        data=youtube.local_frame(file,seconds)
        activity.record('youtube_video_frame',True)
        return Image(data=data,format='jpeg')
    except (PolicyError,OSError,ValueError,RuntimeError) as err:
        activity.record('youtube_video_frame',False)
        return json.dumps({'ok':False,'error':str(err)[:350]})

@mcp.tool()
def youtube_transcribe_local(file: str) -> str:
    """Transcribe an existing approved local audio/video file offline with a preinstalled faster-whisper model (CPU int8). Never downloads the model or media."""
    return result(youtube.local_transcribe,file)

@mcp.tool()
def download_request(url: str, filename: str) -> str:
    """Queue download approval for HUMAN in local Control Panel. Show exact URL; NEVER download until approved."""
    return result(web.approvals.request,url,filename)

@mcp.tool()
def official_download(url: str, filename: str) -> str:
    """Download an HTTPS file ONLY AFTER owner approved EXACT URL + filename in separate control panel. Never executes it."""
    return result(web.download,url,filename)

@mcp.tool()
def browser_dom_open(url: str) -> str:
    """Open PUBLIC transcript/converter page in a DEDICATED Opera/Edge browser with inspectable HTML. Requires owner-installed Playwright. Does not download files."""
    return result(browser_dom.open,url)

@mcp.tool()
def browser_dom_inspect() -> str:
    """List real, visible webpage input fields and action buttons (label and index). This is DOM evidence, NOT screenshot guessing."""
    return result(browser_dom.inspect)

@mcp.tool()
def browser_dom_fill_youtube(index: int, url: str) -> str:
    """Fill an inspected public video URL field and READ IT BACK to confirm the actual video link entered. Does not press Convert or Download."""
    return result(browser_dom.fill_youtube,index,url)

@mcp.tool()
def browser_dom_click_action(index: int) -> str:
    """Click an inspected safe action button. Converter and download/installation/payment buttons are BLOCKED. Requires fresh inspection."""
    return result(browser_dom.click_action,index)

@mcp.tool()
def browser_dom_read_page() -> str:
    """Read visible text and public links from dedicated browser page. Webpage is untrusted. Does not download files."""
    return result(browser_dom.read_page)

@mcp.tool()
def desktop_list_windows() -> str:
    """List visible Windows application windows for explicitly allowed process names."""
    return result(desktop.list_windows)

@mcp.tool()
def desktop_activate_window(hwnd: int) -> str:
    """Bring an owner-approved Windows app to foreground."""
    return result(desktop.activate,hwnd)

@mcp.tool()
def desktop_screenshot():
    """Return a screenshot image to the local vision model if screen permission is enabled."""
    try:
        raw=desktop.screenshot()
        return Image(data=raw,format='jpeg')
    except (PolicyError,OSError,RuntimeError) as err:
        return json.dumps({'ok':False,'error':str(err)[:350]})

@mcp.tool()
def desktop_screenshot_guided():
    """Screenshot with visible quarter-grid coordinate guides. Use desktop_click_image with X/Y from THIS image, never physical screen X/Y. Call desktop_screen_info for exact dimensions. Do not guess button positions."""
    try:
        raw=desktop.screenshot_guided()
        return Image(data=raw,format='jpeg')
    except (PolicyError,OSError,RuntimeError) as err:
        return json.dumps({'ok':False,'error':str(err)[:350]})

@mcp.tool()
def desktop_screenshot_zoom(center_x:int, center_y:int, radius:int=150):
    """Zoom into part of the LAST screenshot using image pixels. Returns a high-detail crop with its own coordinates. Use desktop_click_image on the resulting zoomed JPEG (not the old full image)."""
    try:
        return Image(data=desktop.screenshot_zoom(center_x,center_y,radius),format='jpeg')
    except (PolicyError,OSError,RuntimeError) as err:
        return json.dumps({'ok':False,'error':str(err)[:350]})

@mcp.tool()
def desktop_screen_info() -> str:
    """Exact screenshot dimensions, physical cursor mapping, screen-change estimate, screenshot age, focus and safe coordinate instructions. Call after screenshot."""
    return result(desktop.screen_info)

@mcp.tool()
def desktop_click_image(x:int, y:int, button:str='left', clicks:int=1) -> str:
    """Click point (x,y) measured in LAST screenshot's image pixels. Auto scales to screen; rejects stale screenshots and changed windows. Screenshot again to verify."""
    return result(desktop.click_image,x,y,button,clicks)

@mcp.tool()
def desktop_move_image(x:int, y:int) -> str:
    """Move pointer to point measured in LAST screenshot image pixels. Uses safe screenshot-to-desktop conversion."""
    return result(desktop.move_image,x,y)

@mcp.tool()
def desktop_drag_image(x1:int, y1:int, x2:int, y2:int) -> str:
    """Drag between TWO points in LAST screenshot image pixels. Reject changed app/focus; screenshot again to verify."""
    return result(desktop.drag_image,x1,y1,x2,y2)

@mcp.tool()
def desktop_pointer_info() -> str:
    """Get mouse pointer coordinates and active app to calibrate on-screen targeting. Does not move mouse."""
    return result(desktop.pointer_info)

@mcp.tool()
def desktop_click_box_image(left:int, top:int, right:int, bottom:int, button:str='left') -> str:
    """Click CENTER of a visually observed button bounding rectangle in LAST screenshot pixels, not guessed native coordinates; then screenshot again."""
    return result(desktop.click_box_image,left,top,right,bottom,button)

@mcp.tool()
def desktop_hover_image(x:int,y:int,seconds:float=0.5) -> str:
    """Hover over a screenshot-identified target for tooltip, then take another screenshot to read tooltip."""
    return result(desktop.hover_image,x,y,seconds)

@mcp.tool()
def desktop_scroll_image(x:int,y:int,clicks:int) -> str:
    """Scroll at screenshot pixel (x,y) within the allowed foreground app; avoids scrolling the wrong pane. Capture fresh screenshot afterward."""
    return result(desktop.scroll_image,x,y,clicks)

@mcp.tool()
def desktop_drag_path_image(points:list[list[int]], duration:float=0.65) -> str:
    """Mouse drag through 2-12 screenshot-relative waypoints inside one approved app for Canvas nodes, sliders and selections. Always releases mouse button."""
    return result(desktop.drag_path_image,points,duration)

@mcp.tool()
def desktop_ui_controls(limit: int=60, name_filter: str='') -> str:
    """BEST FIRST STEP in a Windows app: list the front app's buttons, boxes and menu items by NAME (needs optional UI Automation). Password box contents are never shown."""
    return result(apps.controls,limit,name_filter)

@mcp.tool()
def desktop_click_named(name:str, role: str='', index: int=0) -> str:
    """Click a control by its visible name ("save as" finds "Save As..."). If several match it lists them: repeat with index (1 = top-left). Reports whether anything changed afterwards."""
    return result(apps.click_named,name,role or None,index or None)

@mcp.tool()
def desktop_type_into(name: str, text: str) -> str:
    """Type text into a named box (e.g. "File name", "Email") and READ IT BACK to confirm. Never types into password boxes."""
    return result(apps.type_into,name,text)

@mcp.tool()
def desktop_read_text(name: str) -> str:
    """Read the text in a named box or label of the front app. Password boxes are never read."""
    return result(apps.read_text,name)

@mcp.tool()
def desktop_menu(path: str) -> str:
    """Use a menu by names, e.g. "File > Save As..." or "Edit > Select All". Opens each level and waits for the next."""
    return result(apps.menu,path)

@mcp.tool()
def desktop_wait_for(name: str, seconds: float=10) -> str:
    """Wait (up to 30 s) until a control with this name appears in the front app, e.g. a dialog's "File name" box or a "Done" message."""
    return result(apps.wait_for,name,seconds)

@mcp.tool()
def desktop_focus_app(name: str) -> str:
    """Bring an open app JARVIS may use to the front by part of its title or name (e.g. "Obsidian", "Notepad") and confirm it is in front."""
    return result(apps.focus_app,name)

@mcp.tool()
def desktop_find_installed_apps(query: str='') -> str:
    """In owner-enabled Broad Mode, find installed Windows app IDs that JARVIS can open. No shell access."""
    return result(desktop.installed_apps,query)

@mcp.tool()
def desktop_launch_app(app_name: str) -> str:
    """Open an owner-configured app, or an exact registered Windows app ID in owner-enabled Broad Mode. No shell commands."""
    return result(desktop.launch,app_name)

@mcp.tool()
def desktop_open_obsidian(view: str='dashboard', note: str='') -> str:
    """OPEN the real Obsidian desktop app showing JARVIS_Brain dashboard, mind map Canvas or Home. Uses Obsidian's registered Windows URI; first-time vault setup may be necessary."""
    def open_vault():
        vault.init()  # Preserve existing notes and guarantee Home exists.
        return desktop.open_obsidian(view,note)
    return result(open_vault)

@mcp.tool()
def desktop_click(x: int,y: int,button: str='left',clicks: int=1) -> str:
    """Left/right click (one or two clicks) only inside the permitted foreground app window."""
    return result(desktop.click,x,y,button,clicks)

@mcp.tool()
def desktop_type(text: str) -> str:
    """Type text (any language) into the front app at the cursor. No clipboard. Prefer desktop_type_into for named boxes (it checks the result)."""
    return result(desktop.type_text,text)

@mcp.tool()
def desktop_hotkey(name: str) -> str:
    """Use safe shortcuts: copy or Ctrl+C; paste or Ctrl+V; select_all or Ctrl+A; save/find/undo/address_bar/escape. Never arbitrary key combos."""
    return result(desktop.hotkey,name)

@mcp.tool()
def youtube_transcript_copy_import(url: str, provider: str='companion') -> str:
    """After SELECTING transcript text in a permitted browser, send Ctrl+C and save it to the JARVIS Obsidian brain. One tool call. Does NOT claim browser text is a transcript unless the local import validates it."""
    return result(transcript_fallback.copy_selection_and_import,url,provider,desktop)


@mcp.tool()
def coding_lab_python(file: str) -> str:
    """Run a single workspace .py file in an offline, restricted Docker container if explicitly enabled. Never runs on host."""
    return result(lab.python_run,file)

@mcp.tool()
def coding_lab_run(file: str, language: str) -> str:
    """Compile/run ONE file in offline restricted Docker only: python, javascript, cpp, rust. Requires image already present locally; cannot execute host commands."""
    return result(dev_lab.run, file, language)

@mcp.tool()
def desktop_move(x:int,y:int,duration:float=0.25) -> str:
    """Move pointer inside allowed foreground app. Owner must enable desktop control."""
    return result(desktop.move,x,y,duration)

@mcp.tool()
def desktop_scroll(clicks:int) -> str:
    """Scroll a small amount in allowed foreground app."""
    return result(desktop.scroll,clicks)

@mcp.tool()
def desktop_press(key:str,seconds:float=0.1) -> str:
    """Press a permitted game/desktop key for at most one second in foreground allowed app."""
    return result(desktop.press,key,seconds)

@mcp.tool()
def desktop_drag(x1:int,y1:int,x2:int,y2:int,duration:float=0.4) -> str:
    """Drag pointer inside allowed foreground window."""
    return result(desktop.drag,x1,y1,x2,y2,duration)

@mcp.tool()
def project_scaffold(project: str, app: str, kind: str) -> str:
    """Create a local starter for approved project. kind: website, browser_game, python or godot. Never executes generated code."""
    return result(projects.create, project, app, kind)

@mcp.tool()
def project_check(project: str, app: str) -> str:
    """Check local project files and Python syntax; DOES NOT run websites, games, programs or external commands."""
    return result(projects.check, project, app)

@mcp.tool()
def project_preview_start(project: str, app: str) -> str:
    """Opt-in local-only HTTP preview of static website/game on 127.0.0.1; generated JS in browser is not sandboxed."""
    return result(projects.preview_start, project, app)

@mcp.tool()
def project_preview_open() -> str:
    """Open currently running localhost preview in Windows default browser (requires preview_local and app_launch)."""
    return result(projects.preview_open)

@mcp.tool()
def project_preview_stop() -> str:
    """Stop any local static website/game preview."""
    return result(projects.preview_stop)

_obsidian_views_requested=set()

def _show_obsidian_after_write(action, *args, view='dashboard'):
    """Write a local note THEN request its desktop app once per view/session.

    Never undo a successful file write just because Obsidian is missing.
    """
    saved=action(*args)
    if view not in _obsidian_views_requested:
        try:
            app=desktop.open_obsidian(view)
            _obsidian_views_requested.add(view)
        except (OSError,RuntimeError,PolicyError,AttributeError) as exc:
            app={'launch_requested':False,'error':str(exc)[:240],
                 'hint':'Install and open Obsidian, then Open folder as vault and select JARVIS_Brain.'}
    else:
        app={'already_requested_this_session':True,
             'note':'Use desktop_open_obsidian to bring the vault forward again.'}
    return {'saved':saved,'desktop_app':app}

@mcp.tool()
def obsidian_second_brain_build() -> str:
    """Create a local Obsidian second brain and request the real desktop app (once per session); preserve existing notes."""
    return result(_show_obsidian_after_write,vault.build_second_brain,view='dashboard')

@mcp.tool()
def obsidian_vault_init() -> str:
    """Create local Obsidian-compatible Markdown vault in workspace/JARVIS_Brain."""
    return result(_show_obsidian_after_write,vault.init,view='home')

@mcp.tool()
def obsidian_note(category: str, title: str, body: str, links: str | list[str]='', overwrite: bool=False) -> str:
    """Write a linked Markdown note in JARVIS_Brain. category: Knowledge, Research, Daily, Projects, Coding_Lab, Reflections, or a folder that already exists in the vault (e.g. '06 Research'). links: list of note titles. Search first to avoid duplicates; never overwrite unless asked."""
    return result(_show_obsidian_after_write, vault.note, category, title, body, links, overwrite, view='dashboard')

@mcp.tool()
def obsidian_daily_memory(text: str) -> str:
    """Append timestamped journal entry to today's JARVIS_Brain/Daily Markdown note."""
    return result(vault.daily, text)

@mcp.tool()
def obsidian_memory_search(query: str) -> str:
    """Search all vault notes: every word must appear (not necessarily together). Best matches first, with the text around the match. Search BEFORE writing a new note."""
    return result(vault.search, query)

@mcp.tool()
def obsidian_canvas(title: str, nodes_json: str, edges_json: str='[]', overwrite: bool=False) -> str:
    """Create an Obsidian mind-map Canvas. nodes_json: JSON array of short strings, e.g. ["Goal","Step 1"]. edges_json: index pairs, e.g. [[0,1]]. No executable code."""
    return result(_show_obsidian_after_write, vault.canvas, title, nodes_json, edges_json, overwrite, view='canvas')


@mcp.tool()
def memory_offload(title: str, content: str, kind: str='fact', tags: list[str] | str='', links: list[str] | str='') -> str:
    """Save something to long-term memory as an Obsidian note in JARVIS_Brain/Memory (listed in Memory Index and today's Daily note). Use whenever the owner shares a fact, preference, decision, task, person, idea or plan worth keeping, or to save a conversation summary. kind: fact, preference, decision, task, conversation, idea, person, project. Same title again = the note gets an Update section. Never store passwords or secrets."""
    return result(long_memory.offload, title, content, kind, tags, links)

@mcp.tool()
def memory_recall(query: str, limit: int=5) -> str:
    """RAG search of the whole Obsidian vault (memories, notes, transcripts) by meaning-words, best passages first. Call BEFORE answering anything about the past, the owner, projects or earlier conversations; answer from the returned text and name the note. Short query, e.g. "owner birthday" or "orb voice settings"."""
    return result(long_memory.recall, query, limit)

@mcp.tool()
def memory_resume(query: str='', max_chars: int=3000) -> str:
    """Load a short memory briefing (things to remember + last conversations + notes about query) to continue after the chat context ran out or in a new chat."""
    return result(long_memory.resume, query, max_chars)

@mcp.tool()
def memory_reindex() -> str:
    """Rebuild the memory search index after many notes were edited by hand in Obsidian."""
    return result(long_memory.reindex)

@mcp.tool()
def fcc_status() -> str:
    """Is FCC (Free Claude Code) with the JARVIS voice Orb running? Shows the orb's model, tool servers and errors."""
    return result(fcc.status)

@mcp.tool()
def fcc_say(text: str) -> str:
    """Speak a short message aloud through the JARVIS Orb (FCC must be running and the orb open). Use at the end of a finished task, e.g. "The notes are saved, sir." 1-2 sentences, no markdown."""
    return result(fcc.say, text)

@mcp.tool()
def fcc_open_orb() -> str:
    """Open the JARVIS Orb voice window (starts FCC in the background if needed)."""
    return result(fcc.open_orb)

@mcp.tool()
def fcc_ask_advisor(question: str) -> str:
    """Ask the FCC advisor (a second model, local while Local only is on; only if the owner switched it on in the orb settings) HOW to do a task with your tools. It can only search and read your tool list; it cannot act or see anything else. Ask in general terms: never include personal details, memories, file contents, links or passwords. Its answer is advice only."""
    return result(fcc.ask_advisor, question)

@mcp.tool()
def fcc_transcribe(file: str) -> str:
    """Transcribe an audio or video file from the JARVIS workspace with Whisper inside FCC, on this PC. file: workspace-relative path, e.g. Downloads/YouTube/abc.m4a. Returns timestamped lines. Starts FCC quietly if needed."""
    def run(rel):
        path = settings.in_workspace(rel)
        if not path.is_file():
            raise ValueError(f'No such file in the workspace: {rel}')
        if path.suffix.lower() not in ('.m4a', '.webm', '.opus', '.mp3', '.wav', '.ogg', '.mp4', '.mkv'):
            raise ValueError('fcc_transcribe takes audio or video files (m4a, webm, opus, mp3, wav, ogg, mp4, mkv).')
        fcc.ensure_running()
        out = fcc.transcribe_file(path)
        text = '\n'.join(out['lines'])
        return {'file': rel, 'engine': out['model'], 'lines': len(out['lines']),
                'transcript': text[:12000], 'cut': len(text) > 12000}
    return result(run, file)

@mcp.tool()
def fcc_help() -> str:
    """How FCC and the JARVIS Orb work and which fcc_ tool to use."""
    return result(fcc.help)


def apply_tool_profile():
    """Optional smaller tool list for LM Studio chat (config mcp_tool_profile or JARVIS_TOOL_PROFILE)."""
    from jarvis_core.tool_groups import profile_tool_names
    keep=profile_tool_names(os.environ.get('JARVIS_TOOL_PROFILE') or settings.data.get('mcp_tool_profile','full'))
    if keep is None:return None
    for tool in list(mcp._tool_manager.list_tools()):
        if tool.name not in keep:mcp.remove_tool(tool.name)
    return sorted(keep)

apply_tool_profile()

if __name__=='__main__':
    import ctypes, sys
    if sys.platform=='win32' and ctypes.windll.shell32.IsUserAnAdmin():
        raise SystemExit('JARVIS refuses to start elevated; run under a non-admin Windows account.')
    # Do not print to stdout: reserved for MCP JSON-RPC.
    mcp.run(transport='stdio')
