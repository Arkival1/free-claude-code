"""Owner-operated local GUI for rolling-memory JARVIS chat. No cloud/API keys."""
from __future__ import annotations
import json
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import requests
from chat_runner import ask, BASE_URL
from jarvis_core.context_memory import ChatMemory
from jarvis_core.policy import PolicyError
import agent_runner as ar


class JarvisChatUI:
    def __init__(self,root):
        self.root=root
        self.root.title('JARVIS — Continuous Memory Chat')
        self.root.geometry('930x710')
        self.root.minsize(620,490)
        self.busy=False
        self.brain=ChatMemory(ar.SETTINGS)
        self.model=tk.StringVar()
        self.status=tk.StringVar(value='Use Refresh Models. LM Studio local server must be ON.')
        toolbar=ttk.Frame(root,padding=9)
        toolbar.pack(fill='x')
        ttk.Label(toolbar,text='Local model:').pack(side='left')
        self.models=ttk.Combobox(toolbar,textvariable=self.model,width=48)
        self.models.pack(side='left',padx=8,fill='x',expand=True)
        ttk.Button(toolbar,text='Refresh Models',command=self.refresh_models).pack(side='left',padx=3)
        ttk.Button(toolbar,text='Memory Status',command=self.show_status).pack(side='left',padx=3)

        self.chat=scrolledtext.ScrolledText(root,wrap='word',state='disabled',font=('Segoe UI',10),padx=14,pady=10)
        self.chat.pack(fill='both',expand=True,padx=10,pady=(0,5))
        self.chat.tag_config('owner',foreground='#2563eb',font=('Segoe UI',10,'bold'))
        self.chat.tag_config('assistant',foreground='#0f766e',font=('Segoe UI',10,'bold'))
        self.chat.tag_config('muted',foreground='#666666')

        ttk.Label(root,textvariable=self.status).pack(anchor='w',padx=12,pady=2)
        bottom=ttk.Frame(root,padding=9)
        bottom.pack(fill='x')
        self.editor=tk.Text(bottom,height=4,wrap='word',font=('Segoe UI',10))
        self.editor.pack(side='left',fill='x',expand=True,padx=(0,8))
        self.editor.bind('<Control-Return>',lambda e:(self.submit(), 'break')[1])
        self.send_btn=ttk.Button(bottom,text='Send  Ctrl+Enter',command=self.submit)
        self.send_btn.pack(side='right',anchor='s')
        self._line('JARVIS','Rolling memory is stored in Obsidian → Chat Memory. Unlike the LM Studio Chat tab, this window can compact its own context.', 'muted')
        past=self.brain.render_history()
        if past:
            self._line('Conversation history (Obsidian archive)',past,'muted')
        self.status.set(f'Restored {self.brain.state["turn_count"]} previous turns. Model server: {BASE_URL}')
        self.refresh_models()

    def _line(self,title,content,tag):
        self.chat.configure(state='normal')
        self.chat.insert('end','\n'+title+':\n',tag)
        self.chat.insert('end',str(content)+'\n')
        self.chat.configure(state='disabled')
        self.chat.see('end')

    def refresh_models(self):
        try:
            response=requests.get(BASE_URL+'/models',timeout=2)
            response.raise_for_status()
            models=[x['id'] for x in response.json().get('data',[]) if isinstance(x,dict) and x.get('id')]
            self.models['values']=models
            if models and not self.model.get().strip():self.model.set(models[0])
            self.status.set('LM Studio online. '+str(len(models))+' models listed. Choose loaded model and send.')
        except (requests.RequestException,ValueError,KeyError):
            self.status.set('LM Studio server unavailable; start server on 127.0.0.1:1234 and press Refresh Models.')

    def show_status(self):
        try: data=self.brain.status()
        except (OSError,PolicyError) as exc:
            messagebox.showerror('Memory status',str(exc));return
        messagebox.showinfo('JARVIS memory',json.dumps(data,indent=2))

    def submit(self):
        if self.busy:return
        prompt=self.editor.get('1.0','end').strip()
        model=self.model.get().strip()
        if not prompt:return
        if not model:
            messagebox.showwarning('Model needed','Load Qwen in LM Studio, start its local server, then Refresh Models.');return
        self.editor.delete('1.0','end')
        self.busy=True
        self.send_btn.state(['disabled'])
        self._line('You',prompt,'owner')
        self.status.set('JARVIS working locally; tool actions may open desktop apps...')
        threading.Thread(target=self._run, args=(model,prompt),daemon=True).start()

    def _run(self,model,prompt):
        try:
            session=requests.Session()
            session.trust_env=False
            reply=ask(session,model,self.brain,prompt)
            error=None
        except (requests.RequestException,KeyError,ValueError,OSError,PolicyError) as exc:
            reply='Unable to finish: '+str(exc)[:500]
            error=str(exc)
        self.root.after(0, lambda:self._finish(reply,error))

    def _finish(self,reply,error):
        self._line('JARVIS',reply,'assistant')
        self.busy=False
        self.send_btn.state(['!disabled'])
        self.status.set('Issue: '+error[:140] if error else
                        f'Chat saved. {self.brain.state["turn_count"]} turns; {self.brain.state["offloads"]} context offloads. Ctrl+Enter to send.')


def main():
    if sys.platform=='win32':
        import ctypes
        if ctypes.windll.shell32.IsUserAnAdmin():
            raise SystemExit('Run JARVIS Memory Chat from a non-admin Windows account.')
    root=tk.Tk()
    JarvisChatUI(root)
    root.mainloop()


if __name__=='__main__':main()
