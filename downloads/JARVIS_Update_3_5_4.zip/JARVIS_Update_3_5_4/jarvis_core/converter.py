"""Owner-approved audio download through the ytmp3.zone website, done like a person - v3.2.

What it does, in the dedicated JARVIS browser window (you can watch it):
  1. opens ytmp3.zone, types the YouTube link, READS IT BACK, clicks Start;
  2. finds the converter panel (an embedded page from embed.dlsrv.online) and checks
     that it is for the SAME video id;
  3. reads the real format table and picks Opus > M4A > MP3 320 kbps;
  4. waits for the owner's approval of that exact video + format (never self-approves);
  5. clicks only that row's Download button with a real mouse click, closes pop-up ads,
     and catches the file in a private quarantine folder;
  6. checks size and file signature (and codec with ffprobe if installed) before moving it
     into the workspace. Anything else (HTML, EXE, ZIP...) is deleted, never opened.

"Verify you are human" checks are NEVER solved or bypassed by JARVIS: it pauses and asks
the owner to click it in the browser window. Hosts are fixed in code, not in config.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from .jobs import JobCancelled
from .policy import PolicyError
from .youtube import canonical_video

CDP_URL = 'http://127.0.0.1:9341'
VERIFY_WORDS = ('verification', 'verify you are human', 'are you human', 'captcha', 'checking your browser')
DOWNLOAD_LABEL = re.compile(r'^\s*download\s*$', re.I)
PRIORITY = ('opus', 'm4a', 'mp3')


@dataclass(frozen=True)
class Site:
    start_url: str
    main_hosts: frozenset
    frame_hosts: frozenset
    https_only: bool = True


YTMP3 = Site('https://ytmp3.zone/en/', frozenset({'ytmp3.zone'}), frozenset({'embed.dlsrv.online'}))

_ROWS_JS = r"""() => {
  const vis = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const btns = [...document.querySelectorAll('button, a')].filter(b => vis(b) && /^\s*download\s*$/i.test(b.innerText || b.value || ''));
  return btns.map((b, i) => {
    let r = b.closest('tr') || b.parentElement;
    for (let k = 0; k < 4 && r && r.innerText.toLowerCase().replace(/download/g, '').trim().length < 3; k++) r = r.parentElement;
    return {i, text: (r ? r.innerText : '').replace(/download/gi, ' ').replace(/\s+/g, ' ').trim().slice(0, 120)};
  });
}"""
_ROW_OF_JS = r"""(b) => { let r = b.closest('tr') || b.parentElement;
  for (let k = 0; k < 4 && r && r.innerText.toLowerCase().replace(/download/g, '').trim().length < 3; k++) r = r.parentElement;
  return (r ? r.innerText : '').replace(/\s+/g, ' ').trim().slice(0, 120); }"""


def host_of(url: str) -> str:
    return (urlsplit(url).hostname or '').casefold().removeprefix('www.')


def classify(row_text: str) -> dict | None:
    """'320kbps mp3 Download' -> {'kind':'mp3','kbps':320}. None for rows we do not want."""
    t = (row_text or '').casefold().replace('download', ' ')
    if re.search(r'\bopus\b', t):
        return {'kind': 'opus', 'kbps': None}
    if re.search(r'\bm4a\b', t):
        return {'kind': 'm4a', 'kbps': None}
    if re.search(r'\bmp3\b', t):
        m = re.search(r'(\d{2,3})\s*kbps', t)
        return {'kind': 'mp3', 'kbps': int(m.group(1)) if m else None}
    return None


def choose(rows: list[dict]) -> dict | None:
    """Owner order: Opus, then M4A, then MP3 at 320 kbps. Never a lower MP3."""
    tagged = [dict(r, **c) for r in rows if (c := classify(r.get('text', '')))]
    for kind in PRIORITY:
        for r in tagged:
            if r['kind'] == kind and (kind != 'mp3' or (r['kbps'] or 0) >= 320):
                return r
    return None


def sniff(path: Path, kind: str) -> str:
    """Return the real container ('ogg','webm','mp4','mp3') if the bytes match the expected audio kind."""
    head = path.read_bytes()[:64] if path.is_file() else b''
    if head[:4] == b'OggS':
        real = 'ogg'
    elif head[:4] == b'\x1a\x45\xdf\xa3':
        real = 'webm'
    elif head[4:8] == b'ftyp':
        real = 'mp4'
    elif head[:3] == b'ID3' or (len(head) > 1 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0):
        real = 'mp3'
    else:
        raise PolicyError('Downloaded file is not audio (wrong file signature). It was deleted and never opened.')
    allowed = {'opus': ('ogg', 'webm'), 'm4a': ('mp4',), 'mp3': ('mp3',)}[kind]
    if real not in allowed:
        raise PolicyError(f'Downloaded file is {real}, not the approved {kind}. It was deleted.')
    return real


def ffprobe_check(path: Path) -> dict:
    exe = shutil.which('ffprobe')
    if not exe:
        return {'codec_checked': False, 'reason': 'ffprobe not installed; file signature was checked instead.'}
    try:
        p = subprocess.run([exe, '-v', 'error', '-show_entries', 'stream=codec_name:format=duration',
                            '-of', 'default=nw=1', str(path)], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'codec_checked': False, 'reason': str(exc)[:120]}
    codec = re.search(r'codec_name=(\w+)', p.stdout or '')
    dur = re.search(r'duration=([\d.]+)', p.stdout or '')
    duration = float(dur.group(1)) if dur else 0.0
    if p.returncode or not codec or duration <= 0:
        raise PolicyError('ffprobe could not read real audio in the downloaded file. It was deleted.')
    return {'codec_checked': True, 'codec': codec.group(1), 'duration_seconds': round(duration, 1)}


class Converter:
    def __init__(self, settings, browser_dom=None, site: Site = YTMP3, cdp_url: str = CDP_URL):
        self.settings = settings
        self.browser_dom = browser_dom
        self.site = site
        self.cdp_url = cdp_url

    # ---------- browser plumbing ----------
    def _allowed(self, url: str, frame=False) -> bool:
        parts = urlsplit(url)
        if self.site.https_only and parts.scheme != 'https':
            return False
        hosts = self.site.frame_hosts if frame else self.site.main_hosts
        return host_of(url) in hosts

    def _connect(self, ctx=None):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise PolicyError('Playwright is missing in this JARVIS Python. Run START_JARVIS.bat option 1.') from exc
        pl = sync_playwright().start()
        deadline = time.monotonic() + 25
        launched = False
        while True:
            try:
                browser = pl.chromium.connect_over_cdp(self.cdp_url, timeout=4000)
                break
            except Exception:
                if not launched and self.browser_dom is not None:
                    self.browser_dom.open(self.site.start_url)  # dedicated profile, not your normal Opera
                    launched = True
                if time.monotonic() > deadline:
                    pl.stop()
                    raise PolicyError('Could not reach the JARVIS automation browser (Opera/Edge with debugging port 9341). '
                                      'Close every Opera window and try again, or use Edge.') from None
                if ctx:
                    ctx.sleep(1)
                else:
                    time.sleep(1)
        if not browser.contexts:
            browser.close(); pl.stop()
            raise PolicyError('Automation browser has no window. Close it and try again.')
        return pl, browser, browser.contexts[0]

    def _main_page(self, context):
        pages = [p for p in context.pages if self._allowed(p.url)]
        page = pages[-1] if pages else (context.pages[0] if context.pages else context.new_page())
        return page

    def _video_frame(self, page, vid: str, settle: float = 3.0):
        """The converter panel comes from another site, so a fresh browser connection can report its
        address as blank for a moment. Give it a few hundred ms before deciding it is not there."""
        end = time.monotonic() + settle
        while True:
            for f in page.frames:
                if self._allowed(f.url, frame=True) and parse_qs(urlsplit(f.url).query).get('videoId', [''])[0] == vid:
                    return f
            if time.monotonic() >= end or not any(f.url in ('', 'about:blank') for f in page.frames[1:]):
                return None
            page.wait_for_timeout(250)

    def _needs_verification(self, frame) -> bool:
        try:
            text = frame.locator('body').inner_text(timeout=3000).casefold()
        except Exception:
            return False
        return any(w in text for w in VERIFY_WORDS)

    def _rows(self, frame) -> list[dict]:
        try:
            return frame.evaluate(_ROWS_JS) or []
        except Exception:
            return []

    def _download_buttons(self, frame):
        loc = frame.locator('button, a').filter(has_text=DOWNLOAD_LABEL)
        return [loc.nth(i) for i in range(min(loc.count(), 40)) if loc.nth(i).is_visible()]

    def _open_video(self, page, canonical: str, vid: str, ctx=None, fresh=False):
        """Type the link like a person, read it back, press Start, wait for the right panel."""
        frame = self._video_frame(page, vid) if (self._allowed(page.url) and not fresh) else None
        if frame:
            return frame
        if ctx: ctx.stage('website', 'Opening ytmp3.zone in the JARVIS browser window')
        response = page.goto(self.site.start_url, wait_until='domcontentloaded', timeout=45000)
        if response is not None and response.status >= 400:
            raise PolicyError(f'The converter website answered with error {response.status}; it may be down right now.')
        if not self._allowed(page.url):
            raise PolicyError('The converter page redirected somewhere unexpected; stopped.')
        box = page.locator('input[type=text], input[type=search], input:not([type]), textarea').first
        box.wait_for(state='visible', timeout=20000)
        box.click()
        box.fill('')
        box.type(canonical, delay=15)  # real key presses, like a person
        if box.input_value() != canonical:
            raise PolicyError('The YouTube link did not land correctly in the website box; stopped instead of guessing.')
        if ctx: ctx.log('Link typed and verified in the box: ' + canonical)
        form_btn = box.locator('xpath=ancestor::form[1]').locator('button[type=submit], input[type=submit]')
        start = form_btn.first if form_btn.count() else page.locator('button[type=submit], input[type=submit]').first
        label = (start.inner_text(timeout=3000) or start.get_attribute('value') or '').strip().casefold()
        if any(w in label for w in ('download', 'install', 'pay', 'buy')):
            raise PolicyError('The form button is not a plain Start/Convert button; stopped.')
        start.click()
        if ctx: ctx.stage('website', 'Pressed Start; waiting for the converter panel')
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            frame = self._video_frame(page, vid, settle=0.5)
            if frame and self._rows(frame):
                return frame
            # Fail fast (instead of waiting a minute) when a panel is there but cannot be trusted.
            for f in page.frames[1:]:
                if not f.url.startswith('http'):
                    continue
                other = parse_qs(urlsplit(f.url).query).get('videoId', [''])[0]
                if self._allowed(f.url, frame=True) and other and other != vid:
                    raise PolicyError(f'The converter panel is for a different video ({other}), not {vid}; nothing was clicked.')
                if not self._allowed(f.url, frame=True) and self._rows(f):
                    raise PolicyError(f'The converter panel now comes from an unknown website ({host_of(f.url)}). '
                                      'JARVIS only trusts the known one, so it stopped. Have the code reviewed before trusting the new site.')
            (ctx.sleep if ctx else time.sleep)(1)
            page.wait_for_timeout(50)
        hosts = sorted({host_of(f.url) for f in page.frames if f.url.startswith('http')})
        raise PolicyError('The converter panel for this video did not appear within 60 seconds. '
                          'Frames seen: ' + ', '.join(hosts)[:200] + '. The website may have changed or blocked automation.')

    # ---------- public steps ----------
    @staticmethod
    def _plain_errors(fn):
        """Browser library errors (timeouts, closed tabs) become plain PolicyErrors so the pipeline
        can explain them and switch to the direct route instead of crashing."""
        def wrapper(self, *a, **k):
            try:
                return fn(self, *a, **k)
            except (PolicyError, JobCancelled):
                raise
            except Exception as exc:
                raise PolicyError(f'Browser step failed ({type(exc).__name__}): {str(exc).splitlines()[0][:200]}') from exc
        wrapper.__name__ = fn.__name__
        return wrapper

    def find_formats(self, url: str, ctx=None) -> dict:
        canonical, vid = canonical_video(url)
        pl, browser, context = self._connect(ctx)
        try:
            page = self._main_page(context)
            frame = self._open_video(page, canonical, vid, ctx)
            rows = self._rows(frame)
            choice = choose(rows)
            return {'video': canonical, 'video_id': vid, 'formats_on_site': [r['text'] for r in rows][:12],
                    'choice': choice, 'human_check_showing': self._needs_verification(frame)}
        finally:
            browser.close(); pl.stop()

    def download(self, url: str, kind: str, dest_dir: Path, filename: str, ctx=None,
                 max_bytes: int = 150 * 1024 * 1024, verify_wait: float = 900, before_click=None,
                 max_tries: int = 5, retry_wait: float = 6.0) -> dict:
        """Click the approved row's Download and catch the file.

        before_click() runs right before the first click (the pipeline spends the one-use owner
        approval there), so a human check that never clears does not waste the approval."""
        canonical, vid = canonical_video(url)
        if kind not in PRIORITY:
            raise PolicyError('Unknown audio kind.')
        quarantine = self.settings.data_dir / 'quarantine'
        quarantine.mkdir(parents=True, exist_ok=True)
        for old in quarantine.iterdir():
            if old.is_file():
                old.unlink(missing_ok=True)
        target = Path(dest_dir) / filename
        if target.exists():
            raise PolicyError('That audio file already exists; not overwriting it.')
        pl, browser, context = self._connect(ctx)
        cdp = None
        ok = False
        try:
            page = self._main_page(context)
            frame = self._open_video(page, canonical, vid, ctx)
            page.bring_to_front()
            # Owner must solve any human check; JARVIS never does.
            waited = 0.0
            while self._needs_verification(frame):
                if waited == 0 and ctx:
                    ctx.set(status='waiting', needs_owner='Click the "verify you are human" check in the JARVIS browser window.')
                    ctx.stage('human_check', 'Waiting for you to complete the website\'s human check in the browser window')
                if waited > verify_wait:
                    raise PolicyError('The website\'s human check was not completed in time.')
                (ctx.sleep if ctx else time.sleep)(2); waited += 2
                frame = self._video_frame(page, vid) or frame
            if ctx and waited:
                ctx.set(status='running', needs_owner='')
            # Allow downloads ONLY now, ONLY into quarantine.
            cdp = browser.new_browser_cdp_session()
            events: dict = {}
            cdp.on('Browser.downloadWillBegin', lambda e: events.setdefault(e['guid'], {}).update(begin=e))
            cdp.on('Browser.downloadProgress', lambda e: events.setdefault(e['guid'], {}).update(progress=e))
            cdp.send('Browser.setDownloadBehavior', {'behavior': 'allowAndName', 'downloadPath': str(quarantine),
                                                     'eventsEnabled': True})
            known_pages = set(id(p) for p in context.pages)
            seen_since = {}

            def pick_button(allow_reclick=False):
                """The approved row's Download button. A NEW one (after 'Converting...') wins; when
                allow_reclick is set, the same button may be pressed again (pop-under ad sites)."""
                again = None
                for btn in self._download_buttons(frame):
                    c = classify(btn.evaluate(_ROW_OF_JS))
                    if not (c and c['kind'] == kind and (kind != 'mp3' or (c['kbps'] or 0) >= 320)):
                        continue
                    if not btn.evaluate('b => b.dataset.jarvisClicked === "1"'):
                        return btn
                    again = again or btn
                return again if allow_reclick else None

            btn = pick_button()
            if btn is None:
                # An older page for this video (already clicked) - load it fresh once, like a person would.
                if ctx: ctx.log('Reloading the converter page for a fresh format list')
                frame = self._open_video(page, canonical, vid, ctx, fresh=True)
                while self._needs_verification(frame) and waited <= verify_wait:
                    (ctx.sleep if ctx else time.sleep)(2); waited += 2
                    frame = self._video_frame(page, vid) or frame
                btn = pick_button()
            if btn is None:
                raise PolicyError(f'The approved {kind} row is no longer on the page; nothing was clicked.')
            if before_click is not None:
                before_click()
            if ctx: ctx.stage('download', f'Clicking Download on the {kind.upper()} row')

            def human_click(b):
                b.evaluate('b => { b.dataset.jarvisClicked = "1"; }')
                b.scroll_into_view_if_needed()
                b.hover()
                page.wait_for_timeout(250)
                b.click()

            def close_popups(grace):
                """Close new tabs that are not the converter (ads). After `grace` seconds, or at once."""
                closed = []
                for p in list(context.pages):
                    if id(p) in known_pages or p is page or self._allowed(p.url):
                        continue
                    first = seen_since.setdefault(id(p), time.monotonic())
                    if time.monotonic() - first >= grace:
                        try:
                            host = host_of(p.url) or 'blank page'
                            p.close()
                            closed.append(host)
                        except Exception:
                            pass
                if closed:
                    try:
                        page.bring_to_front()
                    except Exception:
                        pass
                    if ctx: ctx.log('Closed pop-up tab(s): ' + ', '.join(closed))
                return closed

            def back_to_converter():
                """An ad may send the converter tab itself somewhere else: go back, like a person would."""
                nonlocal frame
                if self._allowed(page.url):
                    if frame.is_detached():   # still on the site, but the converter panel is gone
                        frame = self._video_frame(page, vid) or self._open_video(page, canonical, vid, ctx, fresh=True)
                        if ctx: ctx.log('The converter panel reloaded; found it again')
                        return True
                    return False
                gone_to = host_of(page.url)
                try:
                    page.go_back(wait_until='domcontentloaded', timeout=15000)
                except Exception:
                    pass
                if not self._allowed(page.url):
                    frame = self._open_video(page, canonical, vid, ctx, fresh=True)
                else:
                    frame = self._video_frame(page, vid) or self._open_video(page, canonical, vid, ctx, fresh=True)
                if ctx: ctx.log(f'An ad sent the page to {gone_to}; went back to the converter')
                return True

            human_click(btn)
            tries, started, done = 1, time.monotonic(), None
            last_click = started
            deadline = started + 600
            while time.monotonic() < deadline:
                page.wait_for_timeout(500)  # lets browser events arrive
                if ctx: ctx.check()
                # Ad tabs: give a new tab 1.5 s (it might be the download itself), then close it.
                close_popups(grace=1.5)
                back_to_converter()
                for guid, ev in events.items():
                    prog = ev.get('progress') or {}
                    if prog.get('receivedBytes', 0) > max_bytes:
                        cdp.send('Browser.cancelDownload', {'guid': guid})
                        raise PolicyError('Download is bigger than the configured limit; cancelled.')
                    if prog.get('state') == 'completed':
                        done = (guid, ev)
                    elif prog.get('state') == 'canceled':
                        raise PolicyError('The website cancelled the download.')
                if done:
                    break
                if events:
                    if ctx:
                        ctx.set(progress={'bytes': max((e.get('progress') or {}).get('receivedBytes', 0) for e in events.values())})
                    continue          # a download is running: just wait for it
                frame = self._video_frame(page, vid, settle=0.5) or frame
                fresh = pick_button()                       # a NEW Download link appeared (after "Converting...")
                waited_since = time.monotonic() - last_click
                if (fresh is not None and waited_since > 1.5) or waited_since > retry_wait:
                    if tries >= max_tries:
                        raise PolicyError(f'Clicked Download {tries} times but no download started (pop-up ads or the '
                                          'website blocked it). Nothing was saved. Try the direct YouTube route.')
                    next_button = fresh or pick_button(allow_reclick=True)
                    if next_button is None:
                        raise PolicyError(f'The approved {kind} row disappeared after clicking; nothing was saved.')
                    close_popups(grace=0)
                    human_click(next_button)
                    tries += 1
                    last_click = time.monotonic()
                    if ctx:
                        ctx.log('Converter showed a new Download link; clicked it' if fresh is not None else
                                f'No download started after {retry_wait:g} s; closed pop-ups and clicked Download again (try {tries} of {max_tries})')
            # Tidy up: close any pop-up ad tabs still open.
            close_popups(grace=0)
            if not done:
                raise PolicyError('No download arrived within 10 minutes. Nothing was saved.')
            guid, ev = done
            got = quarantine / guid
            try:
                if not got.is_file() or got.stat().st_size == 0:
                    raise PolicyError('Download finished but the file is empty or missing.')
                if got.stat().st_size > max_bytes:
                    raise PolicyError('Downloaded file is bigger than the configured limit.')
                container = sniff(got, kind)
                probe = ffprobe_check(got)
            except PolicyError:
                got.unlink(missing_ok=True)
                raise
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(got), str(target))
            begin = ev.get('begin') or {}
            ok = True
            return {'local_path': str(target), 'bytes': target.stat().st_size, 'kind': kind, 'container': container,
                    'download_host': host_of(begin.get('url', '')), 'site_filename': str(begin.get('suggestedFilename', ''))[:120],
                    'verification': probe, 'clicks': tries}
        finally:
            if cdp is not None:
                try:
                    cdp.send('Browser.setDownloadBehavior', {'behavior': 'deny'})
                    cdp.detach()
                except Exception:
                    pass
            browser.close(); pl.stop()
            if not ok:   # never leave partial or rejected files behind
                for leftover in quarantine.iterdir():
                    if leftover.is_file():
                        leftover.unlink(missing_ok=True)


Converter.find_formats = Converter._plain_errors(Converter.find_formats)
Converter.download = Converter._plain_errors(Converter.download)
