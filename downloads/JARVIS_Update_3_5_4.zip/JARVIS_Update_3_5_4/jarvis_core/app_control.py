"""App control by NAME through the accessibility tree (Windows UI Automation) - v3.4.

Like a careful person using an app: find the control by its visible name, act on it, then
look again to confirm something happened. No guessed pixel positions.

- controls(): what the front app shows (names, kinds, positions; never field contents of passwords)
- click_named(name, role=None, index=None): forgiving name match ("save as" finds "Save As...");
  if several match, it lists them instead of guessing; index picks one (1 = top-left first)
- type_into(name, text): fill a named box, then READ IT BACK
- read_text(name): read a named box (never password boxes)
- menu("File > Save As..."): open each menu level in turn
- wait_for(name, seconds): wait until something appears (dialogs, confirmations)
- focus_app(name): bring an allowed app to the front and confirm it is in front

Safety: only the permitted front app; password managers, terminals, admin and system apps are
refused by Desktop's rules; password boxes are never typed into or read.
"""
from __future__ import annotations

import hashlib
import json
import re
import time

from .desktop_backend import CLICKABLE_ROLES, TEXT_ROLES
from .policy import PolicyError


def norm(text: str) -> str:
    t = str(text or '').replace('&', '').replace('…', '').casefold()
    t = re.sub(r'\.{2,}$', '', t.strip())
    t = re.sub(r'[<>:*]+', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def match_score(query: str, name: str) -> int:
    q, n = norm(query), norm(name)
    if not q or not n:
        return 0
    if q == n:
        return 3
    if n.startswith(q + ' ') or n.startswith(q):
        return 2
    if re.search(r'(^|\s)' + re.escape(q) + r'(\s|$)', n):
        return 1
    return 0


class AppControl:
    def __init__(self, desktop, settings):
        self.desktop, self.settings = desktop, settings

    # ---------------- plumbing ----------------
    def _front(self, need='screen'):
        self.settings.require(need)
        self.settings.require_not_stopped()
        backend = getattr(self.desktop, 'backend', None)
        if backend is None or not hasattr(backend, 'ui_tree'):
            raise PolicyError('App control works only on Windows.')
        info = self.desktop._active_allowed()
        return info, backend

    def _tree(self, info, backend):
        try:
            tree = backend.ui_tree(info['hwnd'])
        except ImportError:
            raise PolicyError('App control needs the optional Windows UI Automation package: START_JARVIS.bat menu 9 > option 1. '
                              'Screenshot clicking still works without it.') from None
        except (OSError, RuntimeError) as exc:
            raise PolicyError('This app does not expose its controls to Windows UI Automation. Use screenshots instead.') from exc
        l, t, r, b = info['rect']
        inside = []
        for e in tree:
            x1, y1, x2, y2 = e['rect']
            if x2 <= x1 or y2 <= y1:
                continue
            if l - 3 <= x1 and x2 <= r + 3 and t - 3 <= y1 and y2 <= b + 3:
                inside.append(e)
        return inside

    @staticmethod
    def _signature(info, tree):
        light = [(e['name'], e['role'], e['visible'], e['enabled'], tuple(e['rect'])) for e in tree]
        return hashlib.sha1(json.dumps([info['hwnd'], info['title'], light], default=str).encode(), usedforsecurity=False).hexdigest()

    def _find(self, tree, name, roles, index=None, need_enabled=True):
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 90:
            raise PolicyError('Give the visible name of the control (1-90 characters).')
        pool = [e for e in tree if e['visible'] and (not roles or e['role'] in roles) and (e['enabled'] or not need_enabled)]
        scored = [(match_score(name, e['name']), e) for e in pool]
        best = max((s for s, _ in scored), default=0)
        hits = sorted((e for s, e in scored if s == best and s > 0), key=lambda e: (e['rect'][1] // 8, e['rect'][0]))
        if not hits:
            near = sorted({e['name'] for e in pool if e['name']})[:15]
            disabled = [e['name'] for e in tree if e['visible'] and not e['enabled'] and match_score(name, e['name'])]
            hint = f' It exists but is greyed out (disabled): {disabled[0]!r}.' if disabled else ''
            raise PolicyError(f'No visible control matches {name!r}.{hint} Visible names include: {near}')
        if index is not None:
            if type(index) is not int or not 1 <= index <= len(hits):
                raise PolicyError(f'index must be 1..{len(hits)} for {name!r}.')
            return hits[index - 1]
        if len(hits) > 1:
            listing = [f"{i}: {e['name']} ({e['role']})" for i, e in enumerate(hits[:6], 1)]
            raise PolicyError(f'{len(hits)} controls match {name!r}; not guessing. Choose with index (1 = top-left): {listing}')
        return hits[0]

    @staticmethod
    def _public(e):
        return {'name': e['name'], 'role': e['role'], 'rect': e['rect']}

    # ---------------- read ----------------
    def controls(self, limit: int = 60, name_filter: str = ''):
        info, backend = self._front('screen')
        if not isinstance(limit, int) or not 1 <= limit <= 150:
            raise PolicyError('Limit must be 1..150.')
        out = []
        for e in self._tree(info, backend):
            if not e['visible']:
                continue
            if name_filter and not match_score(name_filter, e['name']):
                continue
            item = {'name': '[password box]' if e['password'] else e['name'][:90], 'role': e['role'], 'rect': e['rect']}
            if not e['enabled']:
                item['disabled'] = True
            out.append(item)
            if len(out) >= limit:
                break
        return {'app': info['exe'], 'window': info['title'], 'controls': out,
                'tip': 'Use these names with desktop_click_named / desktop_type_into / desktop_menu. Box contents are not listed.'}

    def read_text(self, name: str):
        info, backend = self._front('screen')
        el = self._find(self._tree(info, backend), name, TEXT_ROLES + ('text',), need_enabled=False)
        if el['password']:
            raise PolicyError('Password boxes are never read.')
        value = backend.ui_get_text(el) if el['role'] != 'text' else el['name']
        return {'name': el['name'], 'text': (value or '')[:4000], 'truncated': len(value or '') > 4000}

    def wait_for(self, name: str, seconds: float = 10):
        try:
            seconds = float(seconds)
        except (TypeError, ValueError):
            raise PolicyError('seconds must be a number.') from None
        seconds = min(max(seconds, 0.5), 30.0)
        end = time.monotonic() + seconds
        while True:
            self.settings.require_not_stopped()
            info, backend = self._front('screen')
            for e in self._tree(info, backend):
                if e['visible'] and match_score(name, e['name']):
                    return {'found': True, 'name': e['name'], 'role': e['role'], 'window': info['title']}
            if time.monotonic() >= end:
                return {'found': False, 'waited_seconds': seconds, 'window': info['title'],
                        'tip': 'Not there yet. Take a screenshot or list controls to see what is showing.'}
            time.sleep(0.4)

    # ---------------- act ----------------
    def click_named(self, name: str, role: str | None = None, index: int | None = None):
        info, backend = self._front('desktop_control')
        roles = (role.casefold(),) if role else CLICKABLE_ROLES
        tree = self._tree(info, backend)
        el = self._find(tree, name, roles, index)
        before = (self._signature(info, tree), self.desktop._snap(info['rect']))
        how = 'ui_automation'
        if not backend.ui_invoke(el):
            x1, y1, x2, y2 = el['rect']
            self.desktop.click((x1 + x2) // 2, (y1 + y2) // 2)
            how = 'mouse_at_control_center'
        return {'clicked': el['name'], 'role': el['role'], 'method': how, **self._after(info, before)}

    def type_into(self, name: str, text: str):
        info, backend = self._front('desktop_control')
        if not isinstance(text, str) or not text or len(text) > 4000:
            raise PolicyError('Text must be 1-4000 characters.')
        el = self._find(self._tree(info, backend), name, TEXT_ROLES)
        if el['password']:
            raise PolicyError('JARVIS does not type into password boxes. Logins stay with the owner.')
        method = 'ui_automation'
        if not backend.ui_set_text(el, text):
            x1, y1, x2, y2 = el['rect']
            self.desktop.click((x1 + x2) // 2, (y1 + y2) // 2)
            self.desktop._gui().hotkey('ctrl', 'a')
            self.desktop.type_text(text)
            method = 'click_select_all_and_type'
        time.sleep(0.25)
        now = backend.ui_get_text(el)
        verified = now == text
        return {'box': el['name'], 'method': method, 'verified': verified,
                **({} if verified else {'read_back': (now or '')[:200],
                                        'warning': 'The box does not show exactly what was typed. Check before continuing.'})}

    def menu(self, path: str):
        if not isinstance(path, str) or not path.strip():
            raise PolicyError('Give a menu path like "File > Save As...".')
        parts = [p.strip() for p in re.split(r'\s*(?:>|->|/)\s*', path) if p.strip()]
        if not 1 <= len(parts) <= 5:
            raise PolicyError('Menu path must have 1-5 levels.')
        done = []
        for i, part in enumerate(parts):
            if i:
                w = self.wait_for(part, 4)
                if not w['found']:
                    raise PolicyError(f'Menu item {part!r} did not appear after opening {" > ".join(done)}.')
            # In a menu path, a menu item wins over a same-named toolbar button.
            try:
                self.click_named(part, 'menuitem', None)
            except PolicyError as exc:
                if 'No visible control' not in str(exc):
                    raise
                try:
                    self.click_named(part, 'menu', None)
                except PolicyError as exc2:
                    if 'No visible control' not in str(exc2):
                        raise
                    self.click_named(part, None, None)
            done.append(part)
            time.sleep(0.2)
        return {'menu_path': done, 'ok': True, 'next': 'A dialog may have opened; use wait_for or list controls.'}

    def focus_app(self, name: str):
        self.settings.require('desktop_control')
        self.settings.require_not_stopped()
        if not isinstance(name, str) or not name.strip():
            raise PolicyError('Give part of the app title or program name.')
        wins = self.desktop.list_windows()     # only apps JARVIS may touch
        scored = sorted(((max(match_score(name, w['title']), match_score(name, w['exe'].removesuffix('.exe'))), w) for w in wins),
                        key=lambda p: -p[0])
        if not scored or scored[0][0] == 0:
            raise PolicyError(f'No app JARVIS may use matches {name!r}. Allowed open windows: {[w["title"][:40] for w in wins][:10]}')
        target = scored[0][1]
        self.desktop.activate(target['hwnd'])
        front = self.desktop._active_allowed()
        return {'in_front': front['title'], 'app': front['exe'], 'confirmed': front['hwnd'] == target['hwnd']}

    def _after(self, info, before):
        time.sleep(0.35)
        backend = self.desktop.backend
        fg = self.desktop._foreground()
        now_info = backend.window_info(fg) or {}
        same = fg == info['hwnd']
        changed = True
        if same:
            try:
                tree_changed = self._signature(info, self._tree(info, backend)) != before[0]
            except PolicyError:
                tree_changed = True
            frac = self.desktop._diff(before[1], self.desktop._snap(info['rect']))
            changed = tree_changed or (frac is not None and frac > 0.002)
        return {'ui_changed': changed, 'front_window_after': {'app': now_info.get('exe'), 'title': now_info.get('title')},
                'new_window_in_front': not same,
                'note': '' if changed else 'Nothing visible changed. The click may not have worked; check before going on.'}
