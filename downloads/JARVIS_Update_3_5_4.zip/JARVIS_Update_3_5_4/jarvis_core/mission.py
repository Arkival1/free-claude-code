"""Local mission checkpoints for foreground JARVIS autonomous runs.

No cloud/network access; only the owner-run task process reads these files.
The checkpoint intentionally does not persist image bytes or full screenshots.
"""
from __future__ import annotations
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from .policy import PolicyError


def _now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def _safe_messages(messages):
    # Preserve context but drop image bytes. Bound disk use and inference context.
    keep = messages[:2] + messages[2:][-36:]
    while len(keep) > 2 and keep[2].get('role') == 'tool':
        keep.pop(2)
    result = []
    for m in keep:
        copy = {'role': str(m.get('role', 'user'))[:20]}
        if isinstance(m.get('content'), str):
            copy['content'] = m['content'][:10000]
        elif isinstance(m.get('content'), list):
            # Model can recapture screenshots after restart; no image bytes saved.
            copy['content'] = '[image omitted from saved checkpoint]'
        else:
            copy['content'] = ''
        if 'tool_call_id' in m:
            copy['tool_call_id'] = str(m['tool_call_id'])[:160]
        if isinstance(m.get('tool_calls'), list):
            calls = []
            for x in m['tool_calls'][:5]:
                fn = x.get('function') or {}
                calls.append({'id': str(x.get('id', ''))[:160], 'type': 'function',
                              'function': {'name': str(fn.get('name', ''))[:90],
                                           'arguments': str(fn.get('arguments', ''))[:9000]}})
            copy['tool_calls'] = calls
        result.append(copy)
    return result


class MissionStore:
    def __init__(self, settings):
        self.settings = settings
        settings.reload()
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = settings.data_dir / 'active_mission.json'

    def save(self, goal, model, messages, turns, status='running', reason=''):
        if status not in ('running','paused','awaiting_approval','completed'):
            raise ValueError('Invalid mission status.')
        if not isinstance(goal,str) or len(goal) > 12000:
            raise ValueError('Invalid goal.')
        state = {'version': 1, 'goal': goal, 'model': model,
                 'turns': int(turns), 'status': status, 'reason': str(reason)[:500],
                 'updated': _now(), 'messages': _safe_messages(messages)}
        temp = self.path.with_name('active_mission.tmp')
        with temp.open('w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        temp.replace(self.path)
        return state

    def load(self):
        if not self.path.exists():
            raise PolicyError('No mission checkpoint exists. Start a new task first.')
        data = json.loads(self.path.read_text(encoding='utf-8'))
        if data.get('version') != 1 or not isinstance(data.get('messages'),list):
            raise PolicyError('Mission checkpoint format is invalid.')
        if data.get('status') == 'completed':
            raise PolicyError('That mission already finished. Start a new task.')
        if not isinstance(data.get('goal'),str) or not isinstance(data.get('model'),str):
            raise PolicyError('Mission checkpoint missing goal/model.')
        # A crash during a multi-tool response can leave unanswered tool_call IDs.
        # Supply an explicit interrupted placeholder; never assume an action ran.
        fixed=[]
        items=data['messages']
        ix=0
        while ix<len(items):
            item=items[ix]
            fixed.append(item)
            if item.get('role')=='assistant' and item.get('tool_calls'):
                j=ix+1
                while j<len(items) and items[j].get('role')=='tool':
                    fixed.append(items[j]);j+=1
                completed={x.get('tool_call_id') for x in items[ix+1:j]}
                for call in item['tool_calls']:
                    ident=call.get('id')
                    if ident not in completed:
                        fixed.append({'role':'tool','tool_call_id':ident,
                            'content':'{"ok":false,"error":"Previous run interrupted before this tool response. Verify real state before retrying."}'})
                ix=j
                continue
            ix+=1
        data['messages']=fixed
        return data
