"""Workspace-scoped text file operations. No delete or arbitrary executable tools."""
import os
from pathlib import Path
import shutil
from datetime import datetime, timezone
from .policy import Settings, PolicyError

class FileTools:
    def __init__(self, settings: Settings):
        self.settings = settings

    def list_files(self, folder='.') -> str:
        self.settings.require('files')
        p = self.settings.in_workspace(folder, allow_root=True)
        if not p.is_dir():
            raise PolicyError('Not a directory.')
        results = []
        for entry in sorted(p.iterdir(), key=lambda x:x.name.lower())[:150]:
            # Enforce safe path, ignore any links/unsupported junctions.
            try:
                self.settings.in_workspace(str(entry.relative_to(self.settings.workspace)))
                results.append(f"{'DIR ' if entry.is_dir() else 'FILE'} {entry.name}")
            except PolicyError:
                results.append(f'BLOCKED {entry.name}')
        return '\n'.join(results) or '[empty folder]'

    def create_folder(self, folder: str) -> str:
        self.settings.require('files')
        self.settings.require_not_stopped()
        p = self.settings.in_workspace(folder)
        p.mkdir(parents=True, exist_ok=True)
        return f'Created/exists: {p}'

    def read_text(self, file: str) -> str:
        self.settings.require('files')
        p = self.settings.in_workspace(file)
        if not p.is_file():
            raise PolicyError('No such text file.')
        if p.stat().st_size > self.settings.data.get('max_file_kb',256) * 1024:
            raise PolicyError('File too large to read through a model tool.')
        return p.read_text(encoding='utf-8')

    def write_text(self, file: str, content: str, overwrite=False) -> str:
        self.settings.require('files')
        self.settings.require_not_stopped()
        p = self.settings.in_workspace(file)
        if not isinstance(content, str) or len(content.encode('utf-8')) > self.settings.data.get('max_file_kb',256)*1024:
            raise PolicyError('Text content too large.')
        if p.exists() and not overwrite:
            raise PolicyError('File exists; pass overwrite=true to replace it after review.')
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.exists():
            if not p.is_file():
                raise PolicyError('Target is not a regular file.')
            # Backup before replacing, retaining original content in local workspace.
            backups = self.settings.workspace / '_backups'
            backups.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            backup = backups / f'{stamp}_{p.name}.bak'
            shutil.copy2(p, backup)
        # Create new with exclusive open to avoid unreviewed replacements; for existing use temp+replace.
        if not p.exists():
            with p.open('x', encoding='utf-8', newline='\n') as fp:
                fp.write(content)
        else:
            import tempfile
            fd, tname = tempfile.mkstemp(dir=str(p.parent), prefix='.jarvis-', suffix='.tmp')
            try:
                with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as fp:
                    fp.write(content)
                os.replace(tname, p)
            finally:
                if os.path.exists(tname): os.unlink(tname)
        return f'Saved {p} ({len(content)} characters). Backups of replaced files go to _backups.'
