"""Read-only discovery of registered Windows desktop applications.

No shell invocation, PATH search, downloads, Start Menu shortcut execution,
PowerShell, or model-provided arbitrary executable paths. Only App Paths entries
registered in Windows are considered. This is a convenience discovery method,
NOT proof that an application is trustworthy or safe to run.
"""
from __future__ import annotations
import os
from pathlib import Path
import sys
from .policy import PolicyError

# Important: these executable categories cannot be launched by the AI even in
# broad desktop mode. They remain accessible to the human outside JARVIS.
BLOCKED_LAUNCH_EXES = {
    'cmd.exe','powershell.exe','pwsh.exe','windowsterminal.exe','wt.exe',
    'regedit.exe','taskmgr.exe','mmc.exe','control.exe','netplwiz.exe',
    'wscript.exe','cscript.exe','mshta.exe','rundll32.exe','msiexec.exe',
    'python.exe','pythonw.exe','py.exe','node.exe','npm.exe','npx.exe',
    'bash.exe','wsl.exe','wslhost.exe','ssh.exe','sc.exe','schtasks.exe',
    'keepass.exe','keepassxc.exe','1password.exe','bitwarden.exe','lastpass.exe',
    'credentialuibroker.exe','consent.exe','securityhealthsystray.exe',
    'windowsdefender.exe'
}


def _safe_executable(raw: str, *,workspace: Path | None=None) -> Path | None:
    """Accept only a literal, existing .exe, never a command or command line."""
    if not isinstance(raw,str) or not raw or '\x00' in raw: return None
    raw=os.path.expandvars(raw.strip().strip('"'))
    # Reject multi-command, arguments, URI schemes, and shortcut/script paths.
    p=Path(raw)
    if not p.is_absolute() or p.suffix.lower()!='.exe' or not p.is_file():return None
    if p.name.lower() in BLOCKED_LAUNCH_EXES:return None
    try:
        actual=p.resolve(strict=True)
        if workspace and (actual==workspace or workspace in actual.parents):return None
        # Do not offer executable files from ordinary download or temp folders.
        # A registered app might be installed in AppData\\Local\\Programs, which is fine.
        if any(part.lower() in ('downloads','jarvis_workspace') for part in actual.parts):return None
        # Windows temp folder must not be used as an app install source.
        if sys.platform=='win32' and any(part.lower() in ('temp','tmp') for part in actual.parts):return None
    except OSError:
        return None
    return actual


def registered_apps(workspace: Path | None=None) -> dict[str, str]:
    """Return {registry app id: executable path} for real installed EXEs.

    Windows App Paths is widely used but not universal; apps absent here can be
    opened manually, or registered by the owner with the existing control panel.
    """
    if sys.platform!='win32':return {}
    import winreg
    folder=r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths'
    found={}
    # Use both registry views where supported, without requiring admin access.
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
            try: root=winreg.OpenKey(hive,folder,0,winreg.KEY_READ|view)
            except OSError:continue
            with root:
                index=0
                while index<3000:
                    try:name=winreg.EnumKey(root,index)
                    except OSError:break
                    index+=1
                    if not name.lower().endswith('.exe') or name.lower() in BLOCKED_LAUNCH_EXES:continue
                    try:
                        with winreg.OpenKey(root,name,0,winreg.KEY_READ) as entry:
                            raw,_=winreg.QueryValueEx(entry,'')
                    except (OSError,ValueError):continue
                    p=_safe_executable(raw,workspace=workspace)
                    if p is None:continue
                    # Require same filename to prevent misleading registry aliases.
                    if p.name.lower()!=name.lower():continue
                    found.setdefault(name.lower(),str(p))
    return dict(sorted(found.items()))
