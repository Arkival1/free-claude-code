"""YouTube research with video-specific transcripts, plus offline analysis of APPROVED local media.

No cookies, no browser login, no remote AI. Video bytes are NOT downloaded by
transcript() or open_video(). Direct media downloads require separate approval.
Use only content you can lawfully access; no DRM, age/login bypass or extraction
from private videos. Captions may be absent or inaccurate.
"""
from __future__ import annotations
import html
import importlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import parse_qs, urlsplit
import requests
from .policy import PolicyError, Settings, public_https_url, is_allowed_domain

VIDEO_ID = re.compile(r'^[A-Za-z0-9_-]{11}$')
MAX_CAPTION_BYTES = 1_500_000
MAX_TRANSCRIPT_CHARS = 50_000
MEDIA_EXTS = {'.mp4', '.mkv', '.webm', '.mp3', '.m4a', '.opus', '.wav', '.ogg', '.flac'}

# Owner's audio preference, best first. Each entry: kind, yt-dlp selector used at
# download time, expected codec family. MP3 is accepted ONLY when the source itself
# offers ~320 kbps MP3; JARVIS never transcodes just to label a file "320 kbps".
AUDIO_PRIORITY = ('opus', 'm4a', 'mp3')
AUDIO_SELECTORS = {
    'opus': 'bestaudio[acodec=opus]',
    'm4a': 'bestaudio[ext=m4a]',
    'mp3': 'bestaudio[acodec=mp3][abr>=315]',
}
AUDIO_FINAL_EXTS = ('opus', 'webm', 'm4a', 'mp3')
FFPROBE_CODEC = {'opus': 'opus', 'webm': 'opus', 'm4a': 'aac', 'mp3': 'mp3'}


def _audio_only(fmt) -> bool:
    return (isinstance(fmt, dict) and fmt.get('vcodec') == 'none'
            and fmt.get('acodec') not in (None, '', 'none'))


def choose_audio_format(formats, have_ffmpeg: bool) -> dict | None:
    """Pick the owner's preferred audio from formats the source ACTUALLY lists.

    Opus > M4A > MP3 (>=315 kbps). Returns None when nothing acceptable exists.
    Opus is saved as .opus (lossless remux, needs FFmpeg) or else kept in its
    original .webm container, so no re-encoding ever happens.
    """
    audio = [f for f in (formats or []) if _audio_only(f)]
    def abr(f):
        try: return float(f.get('abr') or f.get('tbr') or 0)
        except (TypeError, ValueError): return 0.0
    groups = {
        'opus': [f for f in audio if str(f.get('acodec')).lower().startswith('opus')],
        'm4a': [f for f in audio if f.get('ext') == 'm4a'],
        'mp3': [f for f in audio if str(f.get('acodec')).lower() == 'mp3' and abr(f) >= 315],
    }
    for kind in AUDIO_PRIORITY:
        if groups[kind]:
            best = max(groups[kind], key=abr)
            ext = kind
            if kind == 'opus' and not have_ffmpeg:
                ext = 'webm'
            size = best.get('filesize') or best.get('filesize_approx')
            return {'kind': kind, 'final_ext': ext, 'selector': AUDIO_SELECTORS[kind],
                    'format_id': str(best.get('format_id', '')), 'acodec': str(best.get('acodec', '')),
                    'abr_kbps': round(abr(best)) or None, 'source_ext': str(best.get('ext', '')),
                    'estimated_bytes': int(size) if isinstance(size, (int, float)) else None}
    return None



def canonical_video(url: str) -> tuple[str,str]:
    if not isinstance(url,str) or len(url)>500:
        raise PolicyError('Use a single YouTube video URL.')
    p=urlsplit(url)
    if p.scheme!='https' or p.port not in (None,443) or p.username or p.password:
        raise PolicyError('Use an HTTPS YouTube video link.')
    host=(p.hostname or '').lower()
    parts=p.path.strip('/').split('/')
    video_id=''
    if host in ('youtube.com','www.youtube.com','m.youtube.com'):
        if p.path == '/watch': video_id=parse_qs(p.query).get('v',[''])[0]
        elif len(parts)>=2 and parts[0] in ('shorts','live','embed'): video_id=parts[1]
    elif host=='youtu.be' and parts: video_id=parts[0]
    if not VIDEO_ID.fullmatch(video_id):
        raise PolicyError('Only a single public YouTube watch, shorts or youtu.be video link is supported.')
    return 'https://www.youtube.com/watch?v='+video_id,video_id


def caption_segments(raw: str, kind: str) -> list[dict]:
    """Convert VTT or YouTube json3 captions into timestamped transcript segments."""
    if kind=='json3':
        obj=json.loads(raw)
        parts=[]
        for event in obj.get('events',[]):
            text=''.join(seg.get('utf8','') for seg in event.get('segs',[]) if isinstance(seg,dict))
            text=html.unescape(text).strip().replace('\n',' ')
            if text and text!='\n':
                parts.append({'t':round(float(event.get('tStartMs',0))/1000,2),'text':text})
        return parts
    if kind=='vtt':
        parts=[]
        # WebVTT often repeats overlapping lines. Keep timestamped blocks, de-dup consecutive phrases.
        for block in re.split(r'\n\s*\n',raw.replace('\r','')):
            rows=block.strip().splitlines()
            ix=next((i for i,line in enumerate(rows) if '-->' in line),None)
            if ix is None: continue
            m=re.match(r'\s*(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)\s*-->',rows[ix])
            if not m: continue
            t=(int(m.group(1) or '0')*3600+int(m.group(2))*60+float(m.group(3)))
            text=' '.join(re.sub(r'<[^>]+>','',r).strip() for r in rows[ix+1:])
            text=html.unescape(text).strip()
            if text and (not parts or parts[-1]['text']!=text):
                parts.append({'t':round(t,2),'text':text})
        return parts
    raise PolicyError('Only json3 and VTT caption formats are supported.')


class YouTubeTools:
    def __init__(self,settings:Settings,web=None,files=None,memory=None,vault=None):
        self.settings=settings;self.web=web;self.files=files;self.memory=memory;self.vault=vault

    @staticmethod
    def _get_ydl():
        try: return importlib.import_module('yt_dlp').YoutubeDL
        except ImportError as exc:
            raise PolicyError('YouTube tools (captions and audio) need yt-dlp. Use START_JARVIS.bat menu 9 > option 2, then restart LM Studio.') from exc

    def open_video(self,url):
        self.settings.require('web_research');self.settings.require_not_stopped()
        canonical,_=canonical_video(url)
        if self.web is None: raise PolicyError('No browser configured.')
        return {'video':canonical,'browser':self.web.browse(canonical),
                'next':'Use youtube_transcript for captions. Screenshots require separately enabled desktop vision.'}

    def transcript(self,url,language='en',project=''):
        self.settings.require('web_research');self.settings.require_not_stopped()
        canonical,vid=canonical_video(url)
        if not re.fullmatch(r'[a-zA-Z]{2,3}(?:-[a-zA-Z]{2,5})?',language):
            raise PolicyError('Use a language code like en or en-US.')
        YDL=self._get_ydl()
        opts={'skip_download':True,'quiet':True,'no_warnings':True,'ignoreerrors':False,
              'noplaylist':True,'extract_flat':False,'socket_timeout':15,
              'retries':1,'extractor_retries':1,'ignoreconfig':True,
              'cachedir':False,'nocheckcertificate':False,'geo_bypass':False}
        # This requests only metadata/caption URLs; never video/audio files.
        try:
            with YDL(opts) as ydl:
                info=ydl.extract_info(canonical,download=False)
        except Exception as exc:
            raise PolicyError('Unable to read YouTube metadata/captions. Public videos, network access and captions are required: '+str(exc)[:130]) from exc
        if not isinstance(info,dict): raise PolicyError('YouTube did not return video metadata.')
        tracks=info.get('subtitles') or {}
        auto=info.get('automatic_captions') or {}
        # Manual captions preferred. No unrestricted caption-language fallback.
        chosen=None
        for source_name,source in [('manual',tracks),('automatic',auto)]:
            for key in [language,language.split('-')[0]]:
                if key in source:
                    formats=source[key]
                    for format_name in ['json3','vtt']:
                        entry=next((e for e in formats if e.get('ext')==format_name and isinstance(e.get('url'),str)),None)
                        if entry:
                            chosen=(source_name,key,format_name,entry['url']);break
                if chosen:break
            if chosen:break
        if not chosen:
            return {'video':canonical,'title':str(info.get('title',''))[:180],
                    'captions_available':False,'transcribed':False,
                    'reason':'No supported captions for requested language. For local transcription, obtain media with owner approval and use media_transcribe_local.'}
        source_name,lang,kind,caption_url=chosen
        # Subtitle URLs are short-lived and may redirect to Google's CDN; limit to caption domains.
        session=requests.Session();session.trust_env=False
        try:
            url=caption_url
            for _ in range(4):
                public_https_url(url)
                if not is_allowed_domain(urlsplit(url).hostname or '',['youtube.com','googlevideo.com']):
                    raise PolicyError('Unexpected subtitle hosting domain; blocked.')
                r=session.get(url,timeout=(6,18),stream=True,allow_redirects=False)
                if r.status_code in (301,302,303,307,308):
                    from urllib.parse import urljoin
                    url=urljoin(url,r.headers.get('Location',''))
                    r.close();continue
                try:
                    r.raise_for_status()
                    data=bytearray()
                    for chunk in r.iter_content(32768):
                        self.settings.require_not_stopped()
                        data.extend(chunk)
                        if len(data)>MAX_CAPTION_BYTES:raise PolicyError('Captions exceed size limit.')
                    break
                finally:r.close()
            else: raise PolicyError('Too many subtitle redirects.')
        except requests.RequestException as exc:
            raise PolicyError('Caption download failed: '+str(exc)[:180]) from exc
        finally:session.close()
        segments=caption_segments(bytes(data).decode('utf-8','replace'),kind)
        if not segments: raise PolicyError('Captions were empty or could not be parsed.')
        lines=[f"[{int(p['t']//60):02d}:{int(p['t']%60):02d}] {p['text']}" for p in segments]
        text='\n'.join(lines)
        stored_file=''
        if self.files is not None and self.settings.enabled('files'):
            # Never send the whole transcript into an 8B model's narrow context window.
            # Save to a dedicated workspace note only once; never silently overwrite.
            relative='JARVIS_Brain/Research/YouTube/'+vid+'-captions.txt'
            target=self.settings.in_workspace(relative)
            if not target.exists():
                title_line='# '+str(info.get('title') or vid)[:180]+'\nSource: '+canonical+'\nCaption source: '+source_name+'\n\n'
                max_bytes=int(self.settings.data.get('max_file_kb',256))*1024-1024
                body=title_line + text
                while len(body.encode('utf-8')) > max_bytes and len(body)>100:
                    body=body[:max(100,int(len(body)*0.9))]
                self.files.write_text(relative,body)
            stored_file=relative
        truncated=len(text)>9500
        output={'video':canonical,'title':str(info.get('title',''))[:180],
                'caption_source':source_name,'language':lang,'segments':len(lines),
                'transcript_excerpt':text[:9500],'full_transcript_characters':len(text),
                'local_transcript_file':stored_file,'excerpt_truncated':truncated,
                'visual_analysis':False,'audio_transcription':False,
                'warning':'Caption text is unverified and may contain errors; this is NOT full visual analysis. Use youtube_transcript_section for later transcript excerpts.'}
        if project:
            if not self.memory or not self.vault:raise PolicyError('Project memory unavailable.')
            self.settings.require('notes_and_tasks')
            # May require owner approval. Never save full raw transcript automatically.
            title='YouTube transcript lead: '+str(info.get('title') or vid)[:85]
            note='Video: '+canonical+'\nCaption source: '+source_name+'; language: '+lang+'\n'+\
                'Notes: raw transcript available through tool; summarize key points with timestamps after verification.'
            self.memory.add_note(project,title,note,canonical)
            self.memory.add_task(project,'Review YouTube captions: '+str(info.get('title') or vid)[:65],
                                 'Verify claims and use screenshots/video frames if visual demonstration matters: '+canonical)
            output['project_noted']=project
        return output

    def transcript_section(self,file: str, offset: int=0, max_chars: int=6000):
        self.settings.require('files');self.settings.require_not_stopped()
        if not isinstance(file,str) or not file.replace('\\','/').startswith('JARVIS_Brain/Research/YouTube/') or not file.endswith(('-captions.txt','-website.txt')):
            raise PolicyError('Only locally saved YouTube caption or website transcript files may be read with this tool.')
        if not isinstance(offset,int) or offset<0 or not isinstance(max_chars,int) or not 100<=max_chars<=9500:
            raise PolicyError('Offset must be >=0 and max_chars 100..9500.')
        full=self.files.read_text(file)
        return {'file':file,'offset':offset,'content':full[offset:offset+max_chars],
                'next_offset':min(len(full),offset+max_chars),'is_last':offset+max_chars>=len(full)}

    def _ffmpeg(self):
        return shutil.which('ffmpeg')

    def _max_download_bytes(self):
        return min(int(self.settings.data.get('max_download_mb',100)),150)*1024*1024

    def audio_download_request(self,url):
        """Probe the video's real audio formats (metadata only), pick Opus > M4A > MP3 320,
        and queue HUMAN approval for that exact URL + filename. Never downloads media."""
        self.settings.require('downloads');self.settings.require('web_research')
        self.settings.require_not_stopped()
        if not self.web:raise PolicyError('Download approvals unavailable.')
        canonical,vid=canonical_video(url)
        YDL=self._get_ydl()
        opts={'skip_download':True,'quiet':True,'no_warnings':True,'noplaylist':True,
              'socket_timeout':15,'retries':1,'extractor_retries':1,'ignoreconfig':True,
              'cachedir':False,'nocheckcertificate':False,'geo_bypass':False}
        try:
            with YDL(opts) as ydl:
                info=ydl.extract_info(canonical,download=False)
        except Exception as exc:
            raise PolicyError('Could not read the video\'s available formats (no download attempted): '+str(exc)[:130]) from exc
        if not isinstance(info,dict):raise PolicyError('YouTube did not return video metadata.')
        choice=choose_audio_format(info.get('formats'),bool(self._ffmpeg()))
        if not choice:
            return {'status':'unsupported','video':canonical,'requested_order':['opus','m4a','mp3 320kbps'],
                    'reason':'Video lists no Opus, no M4A and no native ~320 kbps MP3 audio. Nothing was queued.'}
        est=choice['estimated_bytes']
        if est and est>self._max_download_bytes():
            raise PolicyError(f'Best allowed audio is about {est//(1024*1024)} MB, over the configured max_download_mb limit. Nothing queued.')
        filename=vid+'.'+choice['final_ext']
        out=self.web.approvals.request(canonical,filename)
        out.update({'title':str(info.get('title',''))[:180],'format':choice,
                    'destination':'Downloads/YouTube/'+filename,
                    'fallback_used':choice['kind']!='opus',
                    'note':('Opus kept in original .webm container because FFmpeg is not installed (no re-encoding).'
                            if choice['final_ext']=='webm' else 'Format chosen from formats the video actually lists.')})
        return out

    def audio_download(self,url):
        """Owner-gated YouTube audio download in the exact format the owner approved."""
        self.settings.require('downloads');self.settings.require('files')
        self.settings.require_not_stopped()
        if not self.web: raise PolicyError('Download approvals unavailable.')
        canonical,vid=canonical_video(url)
        # Which format did the owner approve? Local DB lookup only - no network yet.
        filename=self.web.approvals.approved_filename(canonical,[vid+'.'+e for e in AUDIO_FINAL_EXTS])
        if not filename:
            raise PolicyError('Download not approved for this exact video. Call youtube_audio_download_request and ask the owner to approve it in Control Panel.')
        ext=filename.rsplit('.',1)[1]
        rel='Downloads/YouTube/'+filename
        target=self.settings.in_workspace(rel)
        if target.exists():
            raise PolicyError('Audio file already exists; do not overwrite it.')
        ffmpeg=self._ffmpeg()
        if ext=='opus' and not ffmpeg:
            raise PolicyError('Approved .opus needs FFmpeg for a lossless remux, and FFmpeg is not installed. Approval NOT used; install FFmpeg or request again (.webm).')
        YDL=self._get_ydl()
        # Spend one-use approval before making a network connection or writing files.
        self.web.approvals.consume_once(canonical,filename)
        target.parent.mkdir(parents=True,exist_ok=True)
        outtmpl=str(target.parent/(vid+'.%(ext)s'))
        maxbytes=self._max_download_bytes()
        kind={'webm':'opus'}.get(ext,ext)
        opts={'quiet':True,'no_warnings':True,'noplaylist':True,'ignoreconfig':True,
              'format':AUDIO_SELECTORS[kind]+('[ext=webm]' if ext=='webm' else ''), 'outtmpl':outtmpl,
              'max_filesize':maxbytes,'socket_timeout':20,'retries':1,
              'fragment_retries':1, 'cachedir':False, 'overwrites':False,
              'nopart':False, 'nocheckcertificate':False}
        if ext=='opus':
            # Same codec -> yt-dlp/FFmpeg copies the stream; no quality change.
            opts['postprocessors']=[{'key':'FFmpegExtractAudio','preferredcodec':'opus'}]
            opts['ffmpeg_location']=ffmpeg
        try:
            with YDL(opts) as ydl:
                ydl.download([canonical])
        except Exception as exc:
            raise PolicyError('Owner-approved audio download failed (no format substitution or bypass attempted): '+str(exc)[:130]) from exc
        if not target.exists():
            raise PolicyError(f'Downloader did not create the approved {filename}; no other format was substituted.')
        size=target.stat().st_size
        if size==0 or size>maxbytes:
            target.unlink(missing_ok=True)
            raise PolicyError('Downloaded file was empty or exceeded the configured safety limit and was removed.')
        return {'source':canonical,'local_file':rel,'format':ext,'downloaded_bytes':size,
                'verification':self._probe(target,ext),
                'next':'Call youtube_transcribe_local after the OFFLINE Whisper model is installed. Media was saved locally; no software executed.'}

    @staticmethod
    def _probe(path,ext):
        """Postcondition check with local ffprobe when available: codec + nonzero duration."""
        ffprobe=shutil.which('ffprobe')
        if not ffprobe:
            return {'codec_verified':False,'reason':'ffprobe not installed; only existence and size were checked.'}
        try:
            p=subprocess.run([ffprobe,'-v','error','-select_streams','a:0','-show_entries',
                              'stream=codec_name:format=duration','-of','json',str(path)],
                             capture_output=True,timeout=25,check=False)
            data=json.loads(p.stdout or b'{}')
            codec=(data.get('streams') or [{}])[0].get('codec_name','')
            duration=float((data.get('format') or {}).get('duration') or 0)
        except (subprocess.TimeoutExpired,ValueError,OSError) as exc:
            return {'codec_verified':False,'reason':'ffprobe failed: '+str(exc)[:100]}
        expected=FFPROBE_CODEC.get(ext,'')
        return {'codec_verified':codec==expected and duration>0,'codec':codec,
                'expected_codec':expected,'duration_seconds':round(duration,1)}

    def _approved_media(self,file):
        self.settings.require('files');self.settings.require_not_stopped()
        path=self.settings.in_workspace(file)
        if path.suffix.lower() not in MEDIA_EXTS or not path.is_file():
            raise PolicyError('Use an existing video/audio file under your approved workspace.')
        if path.stat().st_size > 500*1024*1024:
            raise PolicyError('Media file exceeds 500 MB local processing limit.')
        return path

    def local_frame(self,file,seconds:float):
        """Get one JPEG frame from an already downloaded local video. Return raw JPEG bytes."""
        path=self._approved_media(file)
        if path.suffix.lower() not in ('.mp4','.mkv','.webm'):
            raise PolicyError('Frame extraction requires a local video file.')
        if not isinstance(seconds,(int,float)) or not (0 <= seconds <= 10800):
            raise PolicyError('Frame timestamp must be 0..10800 seconds.')
        ffmpeg=shutil.which('ffmpeg')
        if not ffmpeg:raise PolicyError('Install FFmpeg locally to extract frames. No network is used by this tool.')
        args=[ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-ss',str(seconds),'-i',str(path),
              '-frames:v','1','-vf','scale=960:-2','-f','image2pipe','-vcodec','mjpeg','pipe:1']
        try:
            p=subprocess.run(args,capture_output=True,timeout=25,check=False)
        except subprocess.TimeoutExpired as exc:raise PolicyError('Local frame extraction timed out.') from exc
        if p.returncode or not p.stdout or len(p.stdout)>3_000_000:
            raise PolicyError('Could not extract a frame from local media.')
        return p.stdout

    def transcribe_full(self,file):
        """Offline faster-whisper on approved LOCAL media. Returns ALL timestamped lines (no truncation)."""
        path=self._approved_media(file)
        try: fw=importlib.import_module('faster_whisper')
        except ImportError as exc:
            raise PolicyError('Install optional faster-whisper with START_JARVIS.bat menu 9 > option 3, and a model with option 4.') from exc
        root=self.settings.data_dir/'models'/'faster-whisper-base'
        if not root.is_dir() or not (root/'model.bin').is_file():
            raise PolicyError('Local speech model missing: '+str(root)+'. Use START_JARVIS.bat menu 9 > option 4.')
        # CPU int8 deliberately avoids fighting LM Studio for 6 GB VRAM.
        model=fw.WhisperModel(str(root),device='cpu',compute_type='int8',local_files_only=True)
        try:
            segments,info=model.transcribe(str(path),beam_size=2,vad_filter=True)
            lines=[]
            for segment in segments:
                self.settings.require_not_stopped()
                if len(lines)>20000:raise PolicyError('Speech transcription exceeded segment limit.')
                lines.append(f"[{int(segment.start//3600):02d}:{int(segment.start%3600//60):02d}:{int(segment.start%60):02d}] {segment.text.strip()}")
        finally:del model
        return {'lines':lines,'language':getattr(info,'language','unknown'),'engine':'built-in Whisper (faster-whisper base, CPU)'}

    def local_transcribe(self,file,model_dir=''):
        """Offline Whisper transcription for approved LOCAL media, with locally installed model only."""
        if model_dir:
            # Never accept model-proposed absolute paths or arbitrary model downloads.
            raise PolicyError('Custom model paths are not accepted in AI tool calls. Use the JARVIS private model directory.')
        out=self.transcribe_full(file)
        result='\n'.join(out['lines'])
        return {'file':file,'engine':'local faster-whisper CPU int8','language':out['language'],
                'transcript':result[:MAX_TRANSCRIPT_CHARS],'truncated':len(result)>MAX_TRANSCRIPT_CHARS,
                'visual_analysis':False,'cloud_used':False}
