"""Persistent rolling chat memory for a local LM Studio model.

Stores complete text turns as append-only Markdown in the owner's Obsidian vault,
plus compact running context in a LOCAL state JSON file. No remote AI calls.
It does not claim that archives change LM Studio's chat context window.
"""
from __future__ import annotations
from datetime import datetime
import json
import os
from pathlib import Path
import re
import tempfile
from .policy import PolicyError

MEMORY_DIR = 'JARVIS_Brain/Chat Memory'
MAX_SUMMARY = 5600


def safe_text(value, limit=18000):
    """Only store textual material; no binary screenshots or base64 frames."""
    if not isinstance(value, str):
        return '[non-text content omitted]'
    return value[:limit]


def _atomic_json(target: Path, payload: dict):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.jarvis-', suffix='.tmp', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(payload, out, ensure_ascii=False, indent=2)
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, target)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class ChatMemory:
    def __init__(self, settings, session='JARVIS Long Chat'):
        if not re.fullmatch(r'[a-zA-Z0-9 _-]{1,70}', session):
            raise ValueError('Use a short plain chat name, no paths.')
        self.settings = settings
        self.session = session
        self.state_path = settings.data_dir / 'chat_memory' / (session + '.json')
        self.state = {'summary': '', 'recent': [], 'turn_count': 0, 'offloads': 0}
        if self.state_path.is_file():
            state = json.loads(self.state_path.read_text(encoding='utf-8'))
            if isinstance(state, dict) and isinstance(state.get('recent'), list):
                self.state.update(state)

    def _file(self, name):
        return self.settings.in_workspace(f'{MEMORY_DIR}/{name}')

    def _append_note(self, name: str, addition: str):
        self.settings.require('files')
        self.settings.require_not_stopped()
        folder = self.settings.in_workspace(MEMORY_DIR)
        folder.mkdir(parents=True, exist_ok=True)
        target = self._file(name)
        # Append without destroying any existing notes, and never write outside workspace.
        with target.open('a', encoding='utf-8') as fp:
            fp.write(addition)
        return target

    def record(self, user: str, assistant: str, events=None):
        """Persist a complete text turn before pruning any active prompt messages."""
        user = safe_text(user)
        assistant = safe_text(assistant)
        events = [safe_text(x, 700) for x in (events or [])][:15]
        now = datetime.now().astimezone()
        item={'role':'user','content':user}
        item2={'role':'assistant','content':assistant}
        date=now.strftime('%Y-%m-%d')
        lines=(f'\n## Turn {int(self.state["turn_count"])+1} — {now:%Y-%m-%d %H:%M:%S}\n\n'
               f'**Owner:**\n\n{user}\n\n**JARVIS:**\n\n{assistant}\n\n')
        if events:
            lines+='**Tools / verification:**\n'+'\n'.join('- '+e for e in events)+'\n\n'
        self._append_note(f'{self.session} {date}.md',lines)
        self.state['turn_count']+=1
        self.state['recent'].extend([item,item2])
        self.save()

    def save(self):
        self.settings.require_not_stopped()
        _atomic_json(self.state_path, self.state)

    def should_compact(self, max_chars=9000, max_messages=8):
        recent=self.state['recent']
        return len(recent)>max_messages or sum(len(x.get('content','')) for x in recent)>max_chars

    def compact(self, summarizer=None, *, max_chars=9000, max_messages=8):
        """Offload older exchanges, retain recent turns and verified summary.

        The full text is already archived in daily Markdown. The summarizer, if
        given, must be a LOCAL model callback taking previous summary and text.
        """
        if not self.should_compact(max_chars,max_messages):
            return False
        recent=self.state['recent']
        keep=recent[-4:]             # The most recent two conversational exchanges.
        older=recent[:-4]
        source='\n\n'.join(f'{m["role"].upper()}: {safe_text(m["content"],7000)}' for m in older)
        old_summary=safe_text(self.state.get('summary',''),MAX_SUMMARY)
        candidate=''
        if summarizer:
            try:
                candidate=summarizer(old_summary,source)
            except Exception:
                candidate=''
        if not isinstance(candidate,str) or len(candidate.strip())<20:
            # A safe fallback: retain *verbatim* recent excerpts, labelled as such.
            # Full history remains in Obsidian for search; do not invent a summary.
            candidate=('Previous summary:\n'+old_summary+'\nVerbatim recent older exchanges (partial):\n'
                       +source[-2500:]).strip()
        candidate=candidate[:MAX_SUMMARY]
        self._append_note(f'{self.session} Current Context.md',
                          f'\n## Context refresh — {datetime.now().astimezone():%Y-%m-%d %H:%M}\n\n'
                          f'{candidate}\n\nSource: archived daily chat notes in this folder.\n')
        self.state['summary']=candidate
        self.state['recent']=keep
        self.state['offloads']+=1
        self.save()
        return True

    def memory_context(self, query='', *, max_chars=4400):
        """Short summary and a best-effort excerpt from local archived chat only."""
        context='Rolling context summary (may be incomplete; verify archived notes):\n'+safe_text(self.state.get('summary',''),MAX_SUMMARY)
        if query:
            # Search notes in reverse chronological order; never scan outside the vault.
            root=self.settings.in_workspace(MEMORY_DIR)
            terms=[s for s in re.findall(r'[a-zA-Z0-9_-]{4,}',query.lower()) if s not in
                   {'please','could','would','about','should','these','there','what','that','with','have','from'}]
            if root.is_dir() and terms:
                docs=sorted(root.glob(f'{self.session} 20*.md'),reverse=True)[:25]
                for path in docs:
                    if path.stat().st_size>750000:
                        continue
                    body=path.read_text(encoding='utf-8')
                    low=body.lower()
                    found=next((low.find(term) for term in terms if term in low),-1)
                    if found!=-1:
                        context+='\nRelevant archived excerpt from '+path.name+':\n'+body[max(0,found-250):found+450]
                        break
        return context[-max_chars:]

    def render_history(self, max_chars=140000):
        """Show earlier chat in the GUI from its existing Obsidian archives.

        Full originals remain in Markdown. Only visible scrollback is bounded.
        """
        root=self.settings.in_workspace(MEMORY_DIR)
        if not root.exists():
            return ''
        archives=sorted(root.glob(f'{self.session} 20*.md'))[-30:]
        chunks=[]
        for path in archives:
            if path.stat().st_size>1500000:
                # Skip impractically large individual files in the GUI; Obsidian
                # can open the complete original independently.
                continue
            chunks.append(path.read_text(encoding='utf-8'))
        full='\n'.join(chunks)
        if len(full)>max_chars:
            return '[Earlier chat is still preserved in Obsidian → Chat Memory.]\n'+full[-max_chars:]
        return full

    def status(self):
        return {'session':self.session,'turns_saved':self.state['turn_count'],
                'offloads':self.state['offloads'],'active_messages':len(self.state['recent']),
                'archive_folder':str(self.settings.in_workspace(MEMORY_DIR)),
                'summary_file':str(self._file(f'{self.session} Current Context.md'))}

    def manual_save(self, title, content):
        """Save supplied text from an MCP call; cannot see unprovided LM Studio history."""
        if not isinstance(title,str) or not re.fullmatch(r'[a-zA-Z0-9 _-]{1,65}',title):
            raise PolicyError('Memory title must be plain and no more than 65 characters.')
        if not isinstance(content,str) or not content.strip() or len(content)>18000:
            raise PolicyError('Memory text must be 1 to 18000 characters.')
        now=datetime.now().astimezone()
        path=self._append_note('Manually Saved Conversation Notes.md',
                              f'\n## {title} — {now:%Y-%m-%d %H:%M}\n\n{content}\n')
        return {'saved':True,'file':str(path),'note':'Only text supplied to the tool was saved. LM Studio chat history was NOT compacted.'}
