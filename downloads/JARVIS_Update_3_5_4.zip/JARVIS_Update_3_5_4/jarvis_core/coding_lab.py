"""Optional, isolated Python runner using an ALREADY INSTALLED local Docker image.

This is not a VM and not a guarantee against container escape; it is still a
stronger separation than launching generated programs directly on Windows.
No automatic docker pull, install, shell command, or host network is allowed.
"""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import uuid
from .policy import Settings, PolicyError

class CodingLab:
    def __init__(self, settings:Settings): self.settings = settings

    def python_run(self, file:str):
        self.settings.require('coding_lab')
        self.settings.require_not_stopped()
        if not file.lower().endswith('.py'):
            raise PolicyError('Coding Lab accepts only .py files for this release.')
        src=self.settings.in_workspace(file)
        if not src.is_file() or src.stat().st_size>128*1024:
            raise PolicyError('Python file missing or exceeds 128 KB.')
        docker=shutil.which('docker')
        if not docker:
            raise PolicyError('Docker is not installed. Coding Lab cannot execute code on the Windows host. Ask owner to set up Docker Desktop and a Python image.')
        self.settings.reload()
        img=self.settings.data.get('coding_lab_image','python:3.12-alpine')
        # Prevent model- or config-driven arbitrary image strings from becoming CLI options.
        if img not in ('python:3.12-alpine', 'python:3.12-slim'):
            raise PolicyError('Coding Lab image must be from the predefined local image allowlist.')
        probe=subprocess.run([docker,'image','inspect',img],capture_output=True,text=True,timeout=10)
        if probe.returncode != 0:
            raise PolicyError(f'Local Docker image {img} is missing. Owner must pull it manually after approving the source. No automatic image download.')
        run_id='jarvis-lab-'+uuid.uuid4().hex[:12]
        self.settings.data_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='jarvis-lab-',dir=self.settings.data_dir) as temp:
            isolated=Path(temp)
            # Only one plain-text source copied; no secrets, project data or host directories.
            (isolated/'experiment.py').write_bytes(src.read_bytes())
            cmd=[docker,'run','--rm','--name',run_id,'--network','none','--read-only',
                 '--security-opt','no-new-privileges','--cap-drop','ALL',
                 '--pids-limit','48','--cpus','1','--memory','256m','--memory-swap','256m',
                 '--user','65534:65534','--workdir','/lab',
                 '--tmpfs','/tmp:rw,nosuid,nodev,size=16m',
                 '--mount',f'type=bind,src={str(isolated)},dst=/lab,readonly',
                 img,'python','-I','-B','/lab/experiment.py']
            try:
                p=subprocess.run(cmd,text=True,capture_output=True,timeout=12,stdin=subprocess.DEVNULL)
                return {'file':file,'exit_code':p.returncode,'stdout':p.stdout[:6000],
                        'stderr':p.stderr[:3000],'runtime':'local Docker; network disabled',
                        'warning':'Container isolation reduces risk but is not a perfect security boundary.'}
            except subprocess.TimeoutExpired:
                subprocess.run([docker,'rm','-f',run_id],capture_output=True,timeout=8)
                raise PolicyError('Coding experiment stopped after 12 seconds.')
