"""Source-linked web research for JARVIS, with local notes and owner-approved tasks.

All search and source snippets are untrusted. Search sends a sanitized public topic
only to the public search provider; LM Studio inference and stored notes stay local.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import re
from urllib.parse import parse_qs, quote_plus, unquote, urljoin, urlsplit

import requests
from bs4 import BeautifulSoup

from .policy import PolicyError, public_https_url

FOCUSES = {'general', 'official', 'programming', 'reddit', 'youtube'}


class ResearchTools:
    def __init__(self, settings, web, memory, vault):
        self.settings = settings
        self.web = web
        self.memory = memory
        self.vault = vault

    @staticmethod
    def validate_topic(topic: str) -> str:
        if not isinstance(topic, str):
            raise PolicyError('Research topic must be text.')
        topic = ' '.join(topic.split())
        if not (4 <= len(topic) <= 160):
            raise PolicyError('Use a general research topic between 4 and 160 characters.')
        # Obvious sensitive material must not silently leave the local laptop.
        if (re.search(r'(?i)(password\s*[:=]|api[_ -]?key\s*[:=]|bearer\s+\S+|sk-[a-z0-9_-]{12,})',topic)
            or re.search(r'(?i)(?:[a-z]:\\|\\users\\|/users/|/home/)',topic)
            or any(ord(ch) < 32 for ch in topic)):
            raise PolicyError('Search topic appears to contain private paths or secrets. Generalize the question.')
        return topic

    @staticmethod
    def clean_url(href: str, base: str) -> str | None:
        if not isinstance(href, str) or not href.strip():
            return None
        href = urljoin(base, href.strip())
        u = urlsplit(href)
        # DDG search result links are an HTTPS redirect with target in uddg.
        if u.hostname in ('duckduckgo.com','www.duckduckgo.com','html.duckduckgo.com') and u.path.startswith('/l/'):
            href = unquote(parse_qs(u.query).get('uddg',[''])[0])
        try:
            public_https_url(href,resolve_dns=False)
        except (PolicyError, ValueError):
            return None
        return href

    def _search_html(self, url: str, engine: str, max_results: int):
        response, final_url, session = self.web._get(url)
        try:
            content_type = response.headers.get('Content-Type','').lower()
            if 'html' not in content_type:
                raise PolicyError('Search provider returned non-HTML content.')
            data = bytearray()
            for chunk in response.iter_content(32768):
                data.extend(chunk)
                if len(data) > 600_000:
                    raise PolicyError('Search response exceeds size limit.')
            soup = BeautifulSoup(bytes(data).decode(response.encoding or 'utf-8',errors='replace'),'html.parser')
            found, seen = [], set()
            if engine == 'duckduckgo':
                blocks = soup.select('.result')
                for block in blocks:
                    a = block.select_one('a.result__a')
                    if a is None: continue
                    link = self.clean_url(a.get('href',''),final_url)
                    if not link or link in seen: continue
                    snippet = block.select_one('.result__snippet')
                    title = a.get_text(' ',strip=True)
                    if not title: continue
                    seen.add(link)
                    found.append({'title':title[:170],'url':link,
                                  'snippet':snippet.get_text(' ',strip=True)[:350] if snippet else ''})
                    if len(found) >= max_results: break
            else:
                for block in soup.select('li.b_algo'):
                    a = block.select_one('h2 a')
                    if a is None: continue
                    link = self.clean_url(a.get('href',''),final_url)
                    if not link or link in seen: continue
                    title = a.get_text(' ',strip=True)
                    if not title: continue
                    snippet = block.select_one('.b_caption p')
                    seen.add(link)
                    found.append({'title':title[:170],'url':link,
                                  'snippet':snippet.get_text(' ',strip=True)[:350] if snippet else ''})
                    if len(found) >= max_results: break
            return found
        finally:
            response.close()
            session.close()

    def search(self, topic: str, focus: str='official', max_results: int=5):
        """Search public results and return source URLs; do not claim verification."""
        self.settings.require('web_research')
        self.settings.require_not_stopped()
        topic = self.validate_topic(topic)
        if focus not in FOCUSES: raise PolicyError('focus must be: general, official, programming, reddit, youtube.')
        if type(max_results) is not int or not 1 <= max_results <= 8:
            raise PolicyError('max_results must be 1 to 8.')
        modifiers = {
            'official':' official documentation',
            'programming':' official documentation tutorial',
            'reddit':' site:reddit.com',
            'youtube':' site:youtube.com',
            'general':''
        }
        query = topic + modifiers[focus]
        endpoints = [
            ('duckduckgo','https://html.duckduckgo.com/html/?q='+quote_plus(query)),
            ('bing','https://www.bing.com/search?q='+quote_plus(query))
        ]
        errors = []
        for engine,url in endpoints:
            self.settings.require_not_stopped()
            try:
                matches = self._search_html(url,engine,max_results)
                if matches:
                    return {'topic':topic,'focus':focus,'engine':engine,'results':matches,
                            'verification':'Search snippets are unverified. Read original sources before acting.',
                            'privacy':'The research topic was sent to the public search provider; model inference stayed local.'}
                errors.append(engine+': no parseable results')
            except (OSError, ValueError, RuntimeError, requests.RequestException) as exc:
                errors.append(engine+': '+str(exc)[:100])
        return {'topic':topic,'focus':focus,'results':[],
                'warning':'No search results available. Try browser_search and inspect trusted sources manually.',
                'details':errors[:2]}

    def learn(self, project: str, topic: str, focus: str='official'):
        """Search then save *unverified* source leads and a follow-up verification task.

        Requires an owner-approved project. Never installs, downloads, or executes code.
        """
        self.memory.check_project(project)
        self.settings.require('files')
        result = self.search(topic,focus)
        entries = result.get('results',[])
        if not entries:
            return {**result,'saved':False,'reason':'No results to save.'}
        body = ('# Research leads (UNVERIFIED)\n'
                'Do not treat snippets as evidence. Read the original source and test claims.\n\n'
                + '\n\n'.join(f"- {x['title']}\n  URL: {x['url']}\n  Search snippet: {x['snippet']}" for x in entries))
        self.settings.require_not_stopped()
        note_id = self.memory.add_note(project,'Research leads: '+result['topic'][:165],body,entries[0]['url'])
        task_id = self.memory.add_task(project,'Verify research: '+result['topic'][:165],
            'Read original linked sources, verify relevant claims, and test safely before applying. Notes are unverified search leads.')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
        digest = hashlib.sha256((project+'|'+result['topic']).encode()).hexdigest()[:7]
        vault_title = f'Research {stamp} {digest}'
        saved_path = self.vault.note('Research',vault_title,
             f'**Project:** {project}\n\n**Question:** {result["topic"]}\n\n'+body)
        return {'topic':result['topic'],'sources':entries,'project':project,
                'local_note_id':note_id,'verification_task_id':task_id,
                'obsidian_note':saved_path,
                'status':'UNVERIFIED research leads saved locally; factual claims not yet verified.'}
