"""Opt-in Windows GUI automation.

Never call shell. Restrict by foreground process/window and configurable explicit approval.
GUI actions still have inherent TOCTOU and cross-app risks: NOT an isolation boundary.
"""
from __future__ import annotations
import io
import os
import subprocess
import sys
import time
from PIL import ImageChops, ImageDraw
from pathlib import Path
from urllib.parse import quote
from .policy import Settings, PolicyError
from .installed_apps import BLOCKED_LAUNCH_EXES, registered_apps, _safe_executable
from .desktop_backend import default_backend
# Broad desktop access still excludes known credential/system/terminal programs.
# This is NOT a Windows security boundary: GUI can open dialogs/links in other apps.
BLOCKED_EXES = {
  # Visible active process controls use the same protected exclusions.
  'cmd.exe','powershell.exe','pwsh.exe','windowsterminal.exe','wt.exe',
  'regedit.exe','taskmgr.exe','mmc.exe','control.exe','netplwiz.exe',
  'wscript.exe','cscript.exe','mshta.exe','rundll32.exe','msiexec.exe',
  'explorerplusplus.exe','keepass.exe','keepassxc.exe','1password.exe',
  'bitwarden.exe','lastpass.exe','credentialuibroker.exe','consent.exe',
  'securityhealthsystray.exe','windowsdefender.exe'
}


class Desktop:
    def __init__(self, settings: Settings, backend=None):
        self.settings = settings
        self._backend = backend          # None = real Windows backend, created on first use
        self._last_frame = None   # Last PRIMARY monitor image geometry only; never persist pixels.
        self._last_image = None   # In-memory preview for difference estimation, never saved.
        self._last_change = None

    # ---- the OS layer (see desktop_backend.py). These small methods are the only OS touch points. ----
    @property
    def backend(self):
        if self._backend is None:
            self._backend = default_backend()
        return self._backend

    def _windows_only(self):
        if self._backend is None and sys.platform != 'win32':
            raise PolicyError('Desktop control only runs on Windows.')

    def _gui(self):
        return self.backend.gui()

    def _foreground(self) -> int:
        return int(self.backend.foreground() or 0)

    def _window_info(self, hwnd):
        return self.backend.window_info(hwnd)

    def _grab(self):
        return self.backend.grab()

    def _active_allowed(self):
        self._windows_only()
        self.settings.require_not_stopped()
        self.settings.require('desktop_control')
        info=self._window_info(self._foreground())
        if info is None or not self._allowed_process(info):
            raise PolicyError('Foreground app is not permitted for desktop control. Action blocked.')
        return info

    def _allowed_process(self, info):
        if info is None: return False
        self.settings.reload()
        exe=info.get('exe','').lower()
        if exe in BLOCKED_EXES or exe in BLOCKED_LAUNCH_EXES: return False
        mode=self.settings.data.get('desktop_mode','approved_apps')
        if mode == 'all_user_apps':
            # Owner explicitly opted into general control of visible non-elevated GUI apps.
            return bool(exe and info.get('elevated') is False)
        return exe in self.settings.allowed_exes()

    def list_windows(self):
        self._windows_only()
        self.settings.require('screen')
        return [w for w in self.backend.windows() if w.get('title') and self._allowed_process(w)][:30]

    def activate(self, hwnd: int):
        self._windows_only()
        self.settings.require('desktop_control')
        self.settings.require_not_stopped()
        allowed={x['hwnd']:x for x in self.list_windows()}
        if hwnd not in allowed:
            raise PolicyError('Unknown or disallowed window handle.')
        if not self.backend.activate(hwnd):
            raise PolicyError('Windows denied foreground focus. Click application manually and retry.')
        return self._active_allowed()

    def _capture(self, guided=False):
        """Capture primary monitor with a consistent mapping to Windows cursor coords.

        ImageGrab returns raw screen pixels, while Win32/pyautogui may run with
        different DPI awareness. Record the cursor API's display size, not just
        the JPEG thumbnail dimensions. Never save screenshots to disk.
        """
        self._windows_only()
        self.settings.require('screen')
        self.settings.require_not_stopped()
        front=self._window_info(self._foreground())
        if front is not None and not self._allowed_process(front):
            # e.g. a password manager or admin tool is in front: its contents must never reach the model
            raise PolicyError('A protected app is in front (password manager, system or admin tool). '
                              'JARVIS will not take a screenshot. Switch to the app you want help with.')
        native=self._grab()
        native_w,native_h=native.size
        # pyautogui.size and the cursor use the same Windows coordinate system.
        desktop_w,desktop_h=self._gui().size()
        if not (native_w>0 and native_h>0 and desktop_w>0 and desktop_h>0):
            raise PolicyError('Cannot determine current screen dimensions.')
        preview=native.copy()
        preview.thumbnail((1280,800))
        img_w,img_h=preview.size
        # Capture the active window's identity. Clicking a DIFFERENT window
        # using the last screenshot is rejected instead of guessing coordinates.
        foreground=self._foreground()
        foreground_info=self._window_info(foreground)
        current={'image_width':img_w,'image_height':img_h,
                 'capture_width':native_w,'capture_height':native_h,
                 'desktop_width':int(desktop_w),'desktop_height':int(desktop_h),
                 'cursor_bounds':[0.0,0.0,float(desktop_w),float(desktop_h)],
                 'foreground_hwnd':int(foreground or 0),
                 'foreground_rect':foreground_info['rect'] if foreground_info else None,
                 'captured_monotonic':time.monotonic()}
        diff=None
        if self._last_image is not None and self._last_image.size==preview.size:
            # A rough screen-change signal, NOT a successful-click assertion.
            a=preview.resize((96,60)).convert('L')
            b=self._last_image.resize((96,60)).convert('L')
            mask=ImageChops.difference(a,b).point(lambda v:255 if v>18 else 0)
            hist=mask.histogram()
            diff=round(sum(hist[1:])/float(96*60),4)
        self._last_frame=current
        self._last_image=preview.copy()
        self._last_change=diff
        if guided:
            self._grid_overlay(preview)
        buff=io.BytesIO()
        preview.save(buff,format='JPEG',quality=79,optimize=True)
        return buff.getvalue()

    @staticmethod
    def _grid_overlay(preview):
        """Light guide marks every quarter, labels remain inside image pixels."""
        draw=ImageDraw.Draw(preview)
        w,h=preview.size
        for n in (1,2,3):
            x=int(w*n/4); y=int(h*n/4)
            draw.line((x,0,x,h),fill=(255,196,40),width=1)
            draw.line((0,y,w,y),fill=(255,196,40),width=1)
            draw.rectangle((max(0,x-12),0,x+23,14),fill=(20,20,20))
            draw.text((max(0,x-8),2),str(x),fill=(255,255,255))
            draw.rectangle((0,max(0,y-10),30,y+5),fill=(20,20,20))
            draw.text((2,max(0,y-9)),str(y),fill=(255,255,255))

    def _snap(self, rect):
        """Tiny grey thumbnail of a window area (cursor coordinates) for before/after checks. Never stored."""
        try:
            img=self._grab()
            sw,sh=self._gui().size()
            fx,fy=img.size[0]/float(sw),img.size[1]/float(sh)
            l,t,r,b=rect
            box=(max(0,int(l*fx)),max(0,int(t*fy)),min(img.size[0],int(r*fx)),min(img.size[1],int(b*fy)))
            if box[2]-box[0]<4 or box[3]-box[1]<4:
                return None
            return img.crop(box).resize((96,64)).convert('L')
        except Exception:
            return None

    @staticmethod
    def _diff(a,b):
        if a is None or b is None or a.size!=b.size:
            return None
        mask=ImageChops.difference(a,b).point(lambda v:255 if v>18 else 0)
        return round(sum(mask.histogram()[1:])/float(a.size[0]*a.size[1]),4)

    @staticmethod
    def _around(rect, point, half=60):
        """A close-up box around the click, so small changes (a tick mark) are not lost."""
        x,y=point
        l,t,r,b=rect
        return [max(l,x-half),max(t,y-half),min(r,x+half),min(b,y+half)]

    def _verify_after(self, before_info, before_snap, point=None, before_near=None):
        """Look again after an action: did the window change, or did another window jump in front?"""
        time.sleep(0.35)
        fg=self._foreground()
        now=self._window_info(fg) or {}
        same=fg==before_info['hwnd']
        frac=self._diff(before_snap,self._snap(before_info['rect'])) if same else None
        near=None
        if same and point is not None and before_near is not None:
            near=self._diff(before_near,self._snap(self._around(before_info['rect'],point)))
        changed=(not same) or (frac is not None and frac>0.002) or (near is not None and near>0.01)
        out={'screen_changed':bool(changed),'change_fraction':frac,
             'foreground_after':{'app':now.get('exe'),'title':now.get('title')},'new_window_in_front':not same}
        if not changed:
            out['warning']='Nothing visibly changed after the click. It may have missed; look again before continuing.'
        return out

    def screenshot(self):
        """Existing plain image tool; also refreshes coordinate reference."""
        return self._capture(guided=False)

    def screenshot_guided(self):
        """Guide-grid image sized EXACTLY as screen_info reports."""
        return self._capture(guided=True)

    def screen_info(self):
        self._windows_only()
        self.settings.require('screen')
        self.settings.require_not_stopped()
        if self._last_frame is None:
            return {'screenshot_available':False,
                    'next_step':'Call desktop_screenshot_guided to create a coordinate reference.'}
        meta=self._last_frame.copy()
        meta.pop('captured_monotonic',None)
        age=round(time.monotonic()-self._last_frame['captured_monotonic'],2)
        meta.update({'screenshot_available':True,'screenshot_age_seconds':age,
                     'valid_for_targeting':age<=120,
                     'estimated_screen_change_fraction':self._last_change,
                     'coordinate_rule':'For screenshot pixel coordinates use desktop_click_image, NOT desktop_click. Take a fresh screenshot after a click or focus change.',
                     'preview_note':'Primary monitor only; a pixel change does not prove target was clicked.'})
        return meta

    def _image_coords(self, x:int, y:int):
        """Map screenshot pixels to cursor pixels. Reject stale or changed windows."""
        self._windows_only()
        self.settings.require_not_stopped()
        frame=self._last_frame
        if frame is None:
            raise PolicyError('No screenshot reference. Call desktop_screenshot_guided first.')
        if time.monotonic()-frame['captured_monotonic']>120:
            raise PolicyError('Screenshot is older than 120 seconds. Capture a new screenshot before clicking.')
        if type(x) is not int or type(y) is not int:
            raise PolicyError('Screenshot coordinates must be integer pixels.')
        w=frame['image_width']; h=frame['image_height']
        if not 0<=x<w or not 0<=y<h:
            raise PolicyError(f'Image point outside screenshot {w}x{h}. Use image coordinates, not desktop coordinates.')
        info=self._active_allowed()
        if self._foreground()!=frame['foreground_hwnd'] or info['hwnd']!=frame['foreground_hwnd'] or info['rect']!=frame['foreground_rect']:
            raise PolicyError('Foreground window changed since screenshot. Capture new image before clicking.')
        new_w,new_h=self._gui().size()
        if (int(new_w),int(new_h))!=(frame['desktop_width'],frame['desktop_height']):
            raise PolicyError('Display resolution changed. Capture new screenshot before clicking.')
        # Map center of screenshot pixel onto pointer coordinate system.
        left,top,right,bottom=frame.get('cursor_bounds',[0,0,frame['desktop_width'],frame['desktop_height']])
        dx=min(frame['desktop_width']-1,max(0,int(left+(x+0.5)*(right-left)/w)))
        dy=min(frame['desktop_height']-1,max(0,int(top+(y+0.5)*(bottom-top)/h)))
        return dx,dy

    def screenshot_zoom(self,center_x:int,center_y:int,radius:int=150):
        """Grab unshrunk detail from a region identified in the LAST screenshot.

        The next screenshot-relative click is mapped into that crop, preserving
        the true pixel relationship. An ordinary screenshot restores full view.
        """
        if type(radius) is not int or not 40<=radius<=350:
            raise PolicyError('Zoom radius must be between 40 and 350 screenshot pixels.')
        cx,cy=self._image_coords(center_x,center_y)
        prior=self._last_frame
        view_w=prior['image_width']; view_h=prior['image_height']
        left,top,right,bottom=prior['cursor_bounds']
        x_radius=radius*(right-left)/view_w
        y_radius=radius*(bottom-top)/view_h
        view_rect=(max(0,cx-x_radius),max(0,cy-y_radius),
                   min(prior['desktop_width'],cx+x_radius),
                   min(prior['desktop_height'],cy+y_radius))
        self.settings.require('screen')
        img=self._grab()
        native_w,native_h=img.size
        screen_w,screen_h=self._gui().size()
        if (int(screen_w),int(screen_h))!=(prior['desktop_width'],prior['desktop_height']):
            raise PolicyError('Display geometry changed during zoom. Capture a fresh full screenshot.')
        # Check focus again AFTER the screen capture, not just before.
        active=self._active_allowed()
        if (active['hwnd']!=prior['foreground_hwnd'] or active['rect']!=prior['foreground_rect']
            or self._foreground()!=prior['foreground_hwnd']):
            raise PolicyError('Foreground window changed during zoom. Capture a fresh screenshot.')
        bbox=(max(0,int(view_rect[0]*native_w/screen_w)),
              max(0,int(view_rect[1]*native_h/screen_h)),
              min(native_w,int(view_rect[2]*native_w/screen_w)),
              min(native_h,int(view_rect[3]*native_h/screen_h)))
        if bbox[2]-bbox[0]<20 or bbox[3]-bbox[1]<20:
            raise PolicyError('Zoom region too small.')
        crop=img.crop(bbox)
        crop.thumbnail((1280,800))
        width,height=crop.size
        # Base cursor bounds on ACTUAL rounded pixel crop, not the intended ROI.
        cursor_bounds=[bbox[0]*screen_w/native_w,bbox[1]*screen_h/native_h,
                       bbox[2]*screen_w/native_w,bbox[3]*screen_h/native_h]
        self._last_frame={'image_width':width,'image_height':height,
                          'capture_width':native_w,'capture_height':native_h,
                          'desktop_width':int(screen_w),'desktop_height':int(screen_h),
                          'cursor_bounds':cursor_bounds,
                          'foreground_hwnd':prior['foreground_hwnd'],
                          'foreground_rect':prior['foreground_rect'],
                          'captured_monotonic':time.monotonic()}
        self._last_image=None
        self._last_change=None
        self._grid_overlay(crop)
        out=io.BytesIO()
        crop.save(out,format='JPEG',quality=85,optimize=True)
        return out.getvalue()

    def click_image(self,x:int,y:int,button:str='left',clicks:int=1):
        dx,dy=self._image_coords(x,y)
        info=self._active_allowed()
        before=self._snap(info['rect'])
        before_near=self._snap(self._around(info['rect'],(dx,dy)))
        result=self.click(dx,dy,button,clicks)
        self._last_frame=None  # A new screenshot is mandatory after interaction.
        check=self._verify_after(info,before,(dx,dy),before_near)
        return {'image_point':[x,y], 'desktop_point':[dx,dy], 'action_result':result,
                'verified_visual_change':check['screen_changed'], **check,
                'next_step':'Capture a new screenshot to see the new state.'}

    def move_image(self,x:int,y:int,duration:float=0.25):
        dx,dy=self._image_coords(x,y)
        result=self.move(dx,dy,duration)
        return {'image_point':[x,y],'desktop_point':[dx,dy],'action_result':result}

    def drag_image(self,x1:int,y1:int,x2:int,y2:int,duration:float=0.4):
        a,b=self._image_coords(x1,y1)
        c,d=self._image_coords(x2,y2)
        result=self.drag(a,b,c,d,duration)
        self._last_frame=None
        return {'image_start':[x1,y1], 'image_end':[x2,y2],
                'desktop_start':[a,b],'desktop_end':[c,d],
                'action_result':result,'verified_visual_change':False,
                'next_step':'Capture a new screenshot to verify drag outcome.'}


    def pointer_info(self):
        """Report actual pointer position; no movement or input. Useful for calibration."""
        info=self._active_allowed()
        gui=self._gui()
        point=gui.position()
        x,y=int(point[0]),int(point[1])
        result={'desktop_point':[x,y],'foreground_app':info['exe'],
                'foreground_window':info['hwnd'], 'desktop_size':list(map(int,gui.size()))}
        frame=self._last_frame
        if frame and time.monotonic()-frame['captured_monotonic']<=120 and frame['foreground_hwnd']==info['hwnd']:
            left,top,right,bottom=frame['cursor_bounds']
            if left<=x<right and top<=y<bottom:
                result['last_image_point']=[int((x-left)*frame['image_width']/(right-left)),
                                            int((y-top)*frame['image_height']/(bottom-top))]
        result['note']='Pointer position is feedback only; use a fresh screenshot to locate real controls.'
        return result

    def click_box_image(self,left:int,top:int,right:int,bottom:int,button:str='left'):
        """Click the centre of a visually identified button rectangle in screenshot pixels."""
        if any(type(v) is not int for v in (left,top,right,bottom)):
            raise PolicyError('Button box bounds must be integer screenshot pixels.')
        if not (4<=right-left<=500 and 4<=bottom-top<=240):
            raise PolicyError('Button box must be 4-500 pixels wide and 4-240 high; zoom for small/unclear controls.')
        for x,y in ((left,top),(right-1,bottom-1)):
            self._image_coords(x,y)
        result=self.click_image((left+right-1)//2,(top+bottom-1)//2,button,1)
        result['image_box']=[left,top,right,bottom]
        result['verified_target']=False
        return result

    def hover_image(self,x:int,y:int,seconds:float=0.5):
        """Hover a screenshot target to reveal tooltip; next action should capture a new screenshot."""
        if not isinstance(seconds,(int,float)) or isinstance(seconds,bool) or not 0<=seconds<=2:
            raise PolicyError('Hover seconds must be from 0 to 2.')
        dx,dy=self._image_coords(x,y)
        result=self.move(dx,dy,0.2)
        time.sleep(float(seconds))
        self._last_frame=None  # Tooltip may have changed UI; require fresh image.
        return {'image_point':[x,y],'desktop_point':[dx,dy],
                'action_result':result,'next_step':'Capture new screenshot to inspect tooltip; do not assume hover succeeded.'}

    def scroll_image(self,x:int,y:int,clicks:int):
        """Scroll INSIDE a screenshot-identified content area, not where pointer happened to be."""
        if type(clicks) is not int or not -8<=clicks<=8 or clicks==0:
            raise PolicyError('Scroll notches must be an integer -8..-1 or 1..8.')
        dx,dy=self._image_coords(x,y)
        self.move(dx,dy,0.15)
        # Recheck the same allowed window after moving; no scroll on focus change.
        self._image_coords(x,y)
        result=self.scroll(clicks)
        self._last_frame=None
        return {'image_point':[x,y],'desktop_point':[dx,dy],'notches':clicks,
                'action_result':result,'next_step':'Capture fresh screenshot to determine new scroll position.'}

    def drag_path_image(self,points:list,duration:float=0.65):
        """Controlled drag along screenshot waypoints for Canvas/slider/selection tasks.

        Releases left mouse button even on failures or emergency stop; every
        waypoint must remain inside the same currently permitted foreground app.
        """
        if not isinstance(points,list) or not 2<=len(points)<=12:
            raise PolicyError('Drag path must contain 2-12 screenshot pixel points.')
        if not isinstance(duration,(int,float)) or isinstance(duration,bool) or not 0.2<=duration<=3:
            raise PolicyError('Drag duration must be from 0.2 to 3 seconds.')
        normalized=[]
        for p in points:
            if (not isinstance(p,list) or len(p)!=2 or
                    any(type(v) is not int for v in p)):
                raise PolicyError('Each drag waypoint must be [image_x, image_y] integers.')
            normalized.append(self._image_coords(*p))
        frame=self._last_frame.copy()
        gui=self._gui()
        # Verify policy for ALL coordinates and same foreground before mouseDown.
        info=self._active_allowed()
        l,t,r,b=info['rect']
        if not all(l+4<=x<r-4 and t+4<=y<b-4 for x,y in normalized):
            raise PolicyError('Every drag waypoint must be inside permitted foreground window.')
        gui.moveTo(*normalized[0],duration=.1)
        self._image_coords(*points[0])
        pressed=False
        try:
            gui.mouseDown(button='left');pressed=True
            for x,y in normalized[1:]:
                self.settings.require_not_stopped()
                if (self._foreground()!=frame['foreground_hwnd'] or
                    self._active_allowed()['rect']!=frame['foreground_rect']):
                    raise PolicyError('Foreground window changed during drag; stopping.')
                gui.moveTo(x,y,duration=float(duration)/(len(normalized)-1))
        finally:
            if pressed:
                gui.mouseUp(button='left')
            self._last_frame=None
        return {'image_waypoints':points,'desktop_waypoints':[list(p) for p in normalized],
                'verified_visual_change':False,
                'next_step':'Capture screenshot and verify actual drag outcome.'}

    def installed_apps(self, query: str=''):
        """Find registered Windows apps (broad mode only). No shell or shortcuts."""
        self._windows_only()
        self.settings.require('app_launch')
        self.settings.require_not_stopped()
        self.settings.reload()
        if self.settings.data.get('desktop_mode')!='all_user_apps':
            raise PolicyError('Turn on Broad Mode in JARVIS Control Panel to discover installed apps.')
        if not isinstance(query,str) or len(query)>70:
            raise PolicyError('Search query too long.')
        names=registered_apps(workspace=self.settings.workspace)
        matches=[{'app_id':k,'name':Path(v).stem} for k,v in names.items() if query.lower() in k.lower()]
        return {'apps':matches[:70], 'total_matching':len(matches),
                'note':'Apps not registered in Windows App Paths can still be approved manually in Control Panel.'}

    def launch(self, app_name):
        """Launch an owner-registered app, or a registered Windows app in Broad Mode."""
        self._windows_only()
        self.settings.require('app_launch')
        self.settings.require_not_stopped()
        self.settings.reload()
        if not isinstance(app_name,str) or len(app_name)>90 or not app_name:
            raise PolicyError('Use an installed app ID or an owner-configured app name.')
        app=self.settings.data.get('apps',{}).get(app_name)
        if app is not None:
            if not isinstance(app,dict):raise PolicyError('Invalid configured app.')
            executable=Path(str(app.get('path','')))
            if executable.name.lower() in BLOCKED_LAUNCH_EXES:raise PolicyError('Protected app cannot be launched by JARVIS.')
            if executable.name.lower() not in self.settings.allowed_exes() and self.settings.data.get('desktop_mode')!='all_user_apps':
                raise PolicyError('Application is not in approved_desktop_exes.')
            args=app.get('args',[])
            if not isinstance(args,list) or len(args)>8:raise PolicyError('Bad configured app arguments.')
            actual=[str(a).replace('{workspace}',str(self.settings.workspace)) for a in args]
        elif self.settings.data.get('desktop_mode')=='all_user_apps':
            # Trusted app aliases only: never accept a model-supplied path, CLI argument, or substring guess.
            aliases={'obsidian':'obsidian.exe','vscode':'code.exe',
                     'vs code':'code.exe','visual studio code':'code.exe',
                     'chrome':'chrome.exe','google chrome':'chrome.exe',
                     'edge':'msedge.exe','microsoft edge':'msedge.exe',
                     'firefox':'firefox.exe'}
            app_id=aliases.get(app_name.strip().casefold(),app_name.strip().casefold())
            if not app_id.endswith('.exe'):app_id += '.exe'
            if app_id in BLOCKED_LAUNCH_EXES:raise PolicyError('Protected app cannot be launched by JARVIS.')
            apps=registered_apps(workspace=self.settings.workspace)
            path=apps.get(app_id)
            if not path and app_id in ('obsidian.exe','code.exe'):
                # Obsidian and VS Code sometimes do not register Windows App Paths.
                # Search only these well-known installed-app locations, not user-supplied paths.
                local=os.environ.get('LOCALAPPDATA','')
                pf=os.environ.get('ProgramFiles','')
                if app_id=='obsidian.exe':
                    candidates=[Path(local)/'Obsidian'/'Obsidian.exe',
                                Path(local)/'Programs'/'Obsidian'/'Obsidian.exe',
                                Path(pf)/'Obsidian'/'Obsidian.exe']
                else:
                    candidates=[Path(local)/'Programs'/'Microsoft VS Code'/'Code.exe',
                                Path(pf)/'Microsoft VS Code'/'Code.exe']
                for candidate in candidates:
                    if not candidate.is_absolute():continue
                    verified=_safe_executable(str(candidate),workspace=self.settings.workspace)
                    if verified is not None:
                        path=str(verified);break
            if not path:
                raise PolicyError('Installed app not found: '+app_name+'. Install it yourself, or register its executable in JARVIS Control Panel.')
            executable=Path(path)
            actual=[]
        else:
            raise PolicyError('App not configured. Enable Broad Mode or approve app in Control Panel.')
        if not executable.is_absolute() or not executable.is_file() or executable.suffix.lower()!='.exe':
            raise PolicyError('App executable does not exist or is not a Windows .exe.')
        self.settings.workspace.mkdir(parents=True,exist_ok=True)
        subprocess.Popen([str(executable),*actual],cwd=str(self.settings.workspace),shell=False)
        return f'Launched {app_name}. Check window visibility separately. Local Windows app may independently access the internet.'

    def open_obsidian(self, view: str='dashboard', note: str='') -> dict:
        """Request Obsidian to open JARVIS's actual vault, not just create Markdown files.

        The OS URI handler must already be registered by Obsidian and the vault
        must have been opened by the owner once. An attempted URI launch is NOT
        proof the target document is displayed; report this explicitly.
        """
        self._windows_only()
        self.settings.require('app_launch')
        self.settings.require('desktop_control')
        self.settings.require_not_stopped()
        self.settings.reload()
        if self.settings.data.get('desktop_mode')!='all_user_apps' and 'obsidian.exe' not in self.settings.allowed_exes():
            raise PolicyError('Obsidian must be approved in the owner Control Panel when Broad Mode is off.')
        relative={
            'dashboard':'JARVIS_Brain/Second Brain Dashboard.md',
            'home':'JARVIS_Brain/Home.md',
            'canvas':'JARVIS_Brain/Canvas/JARVIS Second Brain.canvas',
            'vault':'JARVIS_Brain/Home.md',
        }.get(view)
        if note:
            # A specific note: a vault-relative path like 'Research/My Note.md', or just its title.
            vault_root=self.settings.in_workspace('JARVIS_Brain')
            wanted=str(note).replace('\\','/').strip().removeprefix('JARVIS_Brain/')
            if not wanted.endswith(('.md','.canvas')):
                hits=[p for p in vault_root.rglob('*.md') if p.stem.casefold()==wanted.casefold()] if vault_root.is_dir() else []
                if len(hits)!=1:
                    raise PolicyError(f'Found {len(hits)} notes titled {wanted!r}. Give the path, e.g. Research/{wanted}.md')
                wanted=str(hits[0].relative_to(vault_root)).replace('\\','/')
            relative='JARVIS_Brain/'+wanted
            if not self.settings.in_workspace(relative).is_file():
                raise PolicyError(f'No note at {relative}.')
        if relative is None:raise PolicyError('Obsidian view must be dashboard, home, canvas or vault.')
        vault=self.settings.in_workspace('JARVIS_Brain')
        if not vault.is_dir():
            raise PolicyError('JARVIS Obsidian vault does not exist. Create it using obsidian_vault_init first.')
        target=self.settings.in_workspace(relative)
        if not target.is_file():
            target=self.settings.in_workspace('JARVIS_Brain/Home.md')
            if not target.is_file():
                raise PolicyError('Obsidian Home.md not created yet. Initialize the vault first.')
        uri='obsidian://open?path='+quote(str(target),safe='')
        uri_sent=False
        fallback=''
        try:
            # This requests the Obsidian Windows protocol handler; no arbitrary URL/model args.
            os.startfile(uri)
            uri_sent=True
        except (OSError,AttributeError) as err:
            # If no URI handler exists, still try launching the installed app.
            fallback=str(err)[:140]
            self.launch('obsidian')
        visible=False
        deadline=time.monotonic()+8   # Obsidian can take several seconds to appear
        while not visible and time.monotonic()<deadline:
            time.sleep(.5)
            try:
                visible=any(w.get('exe')=='obsidian.exe' for w in self.list_windows())
            except (OSError,RuntimeError,PolicyError):
                break
        return {'app':'Obsidian','launch_requested':True,
                'window_observed':visible,'uri_sent':uri_sent,
                'target':str(target),'vault':str(vault),
                'fallback':fallback,
                'setup_if_not_opened':'Open Obsidian manually once, then Open folder as vault and select '+str(vault)+'. Windows must register obsidian:// links. Retry after that.',
                'note':'A request to open is not proof that Obsidian displayed the correct note.'}

    def click(self,x:int,y:int,button:str='left',clicks:int=1):
        info=self._active_allowed()
        l,t,r,b=info['rect']
        if not (l+2 <= x < r-2 and t+2 <= y < b-2):
            raise PolicyError('Click is outside the current approved foreground window.')
        if button not in ('left','right') or clicks not in (1,2):
            raise PolicyError('Only left/right button with one or two clicks is permitted.')
        self._gui().click(x=x,y=y,button=button,clicks=clicks,interval=0.12)
        return f'{button} clicked {clicks} time(s) at ({x},{y}) in allowed foreground app {info["exe"]}.'

    def type_text(self,text):
        info=self._active_allowed()
        if not isinstance(text,str) or not text or len(text)>2000:
            raise PolicyError('Text must be 1-2000 characters.')
        if any(ord(c)<32 and c not in ('\n','\t') for c in text):
            raise PolicyError('Text may not contain control characters (only letters, symbols, tabs and new lines).')
        # Key-by-key Unicode typing (any language, no clipboard, so private clipboard data is never touched).
        typer=getattr(self.backend,'type_text',None) if self._backend is not None or sys.platform=='win32' else None
        if typer is not None:
            typer(text)
        elif all(32<=ord(c)<=126 or c in '\n\t' for c in text):
            self._gui().write(text,interval=0.008)
        else:
            raise PolicyError('Typing non-English characters is not available here.')
        return f'Typed {len(text)} characters into {info["exe"]}. Read the field or take a screenshot to confirm.'

    @staticmethod
    def normalize_hotkey(name: str) -> str:
        """Translate common model shortcut spellings to one safe Windows command.

        No arbitrary key combinations or admin/terminal shortcuts are accepted.
        """
        if not isinstance(name, str) or len(name) > 40:
            raise PolicyError('Shortcut must be a short name such as copy or Ctrl+C.')
        # Retain + and ^ long enough to recognize conventional shortcuts.
        token = name.casefold().strip().replace(' ', '').replace('-', '').replace('_', '')
        aliases = {
            'copy': 'copy', 'ctrl+c': 'copy', 'control+c': 'copy', '^c':'copy',
            'paste': 'paste', 'ctrl+v': 'paste', 'control+v':'paste', '^v':'paste',
            'selectall':'select_all', 'ctrl+a':'select_all', 'control+a':'select_all', '^a':'select_all',
            'save':'save','ctrl+s':'save','control+s':'save', '^s':'save',
            'undo':'undo','ctrl+z':'undo','control+z':'undo', '^z':'undo',
            'find':'find','ctrl+f':'find','control+f':'find', '^f':'find',
            'addressbar':'address_bar','ctrl+l':'address_bar','control+l':'address_bar', '^l':'address_bar',
            'escape':'escape','esc':'escape',
        }
        if token not in aliases:
            raise PolicyError('Unsupported shortcut. Allowed: copy/Ctrl+C, paste/Ctrl+V, '
                              'select_all/Ctrl+A, save/Ctrl+S, undo/Ctrl+Z, '
                              'find/Ctrl+F, address_bar/Ctrl+L, escape. '
                              'Do not retry an unsupported shortcut.')
        return aliases[token]

    def hotkey(self,name):
        info=self._active_allowed()
        action=self.normalize_hotkey(name)
        shortcuts={'select_all':['ctrl','a'],'save':['ctrl','s'],
                   'undo':['ctrl','z'],'find':['ctrl','f'],'copy':['ctrl','c'],
                   'paste':['ctrl','v'],'address_bar':['ctrl','l'],'escape':['esc']}
        self._gui().hotkey(*shortcuts[action])
        return f'Sent {action} to {info["exe"]}; verify screen or clipboard before claiming success.'

    def move(self,x:int,y:int,duration:float=0.25):
        info=self._active_allowed()
        l,t,r,b=info['rect']
        if not (l+4 <= x < r-4 and t+4 <= y < b-4): raise PolicyError('Mouse position outside approved foreground window.')
        dur=min(max(float(duration),0),1.0)
        self._gui().moveTo(x,y,duration=dur)
        return f'Moved mouse to {x},{y} in {info["exe"]}.'

    def scroll(self,clicks:int):
        info=self._active_allowed()
        if not isinstance(clicks,int) or not -8 <= clicks <= 8: raise PolicyError('Scroll must be -8..8 notches.')
        self._gui().scroll(clicks)
        return f'Scrolled {clicks} in {info["exe"]}.'

    def press(self,key:str,seconds:float=0.1):
        info=self._active_allowed()
        # Suitable for basic games with keyboard controls, but not all DirectX games.
        allowed={'up','down','left','right','w','a','s','d','space','enter','esc','tab','shift','ctrl','q','e','r','f','z','x','c','v','1','2','3','4','5','6','7','8','9','0'}
        if key not in allowed: raise PolicyError('Key is not in the safe game/control key list.')
        secs=min(max(float(seconds),0.02),1.0)
        gui=self._gui()
        gui.keyDown(key)
        try: time.sleep(secs)
        finally: gui.keyUp(key)
        return f'Pressed {key} for {secs:.2f}s in {info["exe"]}.'

    def drag(self,x1:int,y1:int,x2:int,y2:int,duration:float=0.4):
        info=self._active_allowed()
        l,t,r,b=info['rect']
        if not all(l+4<=x<r-4 and t+4<=y<b-4 for x,y in ((x1,y1),(x2,y2))):
            raise PolicyError('Drag must remain inside approved foreground window.')
        dur=min(max(float(duration),0.1),1.0)
        gui=self._gui()
        gui.moveTo(x1,y1,duration=0.1)
        gui.dragTo(x2,y2,duration=dur,button='left')
        return f'Dragged pointer in {info["exe"]}.'
