"""Extra file operations confined to the owner-approved workspace."""
from pathlib import Path
import shutil
from .policy import PolicyError

class FileOps:
    def __init__(self,settings): self.settings=settings

    def copy(self,source:str,destination:str):
        self.settings.require('files');self.settings.require_not_stopped()
        a=self.settings.in_workspace(source);b=self.settings.in_workspace(destination)
        if a==b or not a.is_file() or b.exists(): raise PolicyError('Copy needs an existing file and unused destination.')
        if a.stat().st_size>5*1024*1024: raise PolicyError('File too large to copy through model tool.')
        b.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(a,b)
        return {'source':str(a),'destination':str(b),'copied':True}

    def move(self,source:str,destination:str):
        self.settings.require('files');self.settings.require_not_stopped()
        a=self.settings.in_workspace(source);b=self.settings.in_workspace(destination)
        if a==b or not a.is_file() or b.exists(): raise PolicyError('Move needs an existing file and unused destination.')
        if a.stat().st_size>5*1024*1024: raise PolicyError('File too large to move through model tool.')
        b.parent.mkdir(parents=True,exist_ok=True)
        a.rename(b)
        return {'source':str(a),'destination':str(b),'moved':True,'note':'Source path no longer exists.'}

    def find(self,term:str,folder:str='.'):
        self.settings.require('files');self.settings.require_not_stopped()
        if not isinstance(term,str) or not 1<=len(term)<=80: raise PolicyError('Search term length 1-80.')
        root=self.settings.in_workspace(folder,allow_root=True)
        if not root.is_dir():raise PolicyError('Not a directory.')
        result=[];visited=0
        # Limits prevent massive traversal. Do not dereference directory symlinks/junctions.
        for p in root.rglob('*'):
            if visited>=800 or len(result)>=60:break
            visited+=1
            try:
                rel=p.relative_to(self.settings.workspace).as_posix()
                self.settings.in_workspace(rel)
                if p.is_file() and term.casefold() in p.name.casefold():result.append(rel)
            except (PolicyError,OSError):continue
        return {'matches':result,'visited':visited,'truncated':visited>=800 or len(result)>=60}
