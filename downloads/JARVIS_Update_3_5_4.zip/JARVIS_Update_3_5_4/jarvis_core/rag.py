"""Local retrieval (RAG) over the Obsidian vault: chunked notes + BM25 ranking.

The index lives in the JARVIS data folder and is refreshed incrementally: only
notes whose size or modified time changed are re-read. Optional LM Studio
embeddings (config "rag_embeddings": "lmstudio") re-rank the best BM25 matches.
Nothing leaves the PC.
"""
from __future__ import annotations

import json
import math
import re
import urllib.request
from collections import Counter
from pathlib import Path

INDEX_VERSION = 2
CHUNK_CHARS = 900
MAX_FILE_BYTES = 512 * 1024
SKIP_NOTES = frozenset({'Memory Index.md'})
_TOKEN = re.compile(r"[a-z0-9]+(?:'[a-z]+)?")
_STOP = frozenset("""a an and are as at be but by for from has have he her his i if in into is it its
me my no not of on or our she so that the their them then there these they this to was we were what
when which who will with you your""".split())
_HEADING = re.compile(r'^(#{1,6})\s+(.*)$')
_LINK = re.compile(r'\[\[[^\]]*\]\]')
_LOG_LINE = re.compile(r'^Memory (saved|updated): \[\[')     # Daily-note bookkeeping, not knowledge


def tokens(text: str) -> list[str]:
    out = []
    for word in _TOKEN.findall(text.casefold()):
        word = word.replace("'", '')
        if len(word) < 2 or word in _STOP:
            continue
        for suffix in ('ings', 'ing', 'ies', 'es', 's', 'ed'):     # light stemming: plan/plans/planned
            if word.endswith(suffix) and len(word) - len(suffix) >= 3:
                word = word[:-len(suffix)] + ('y' if suffix == 'ies' else '')
                break
        out.append(word)
    return out


def strip_frontmatter(text: str) -> tuple[dict, str]:
    meta = {}
    if text.startswith('---\n'):
        end = text.find('\n---', 4)
        if end > 0:
            for line in text[4:end].splitlines():
                if ':' in line:
                    key, value = line.split(':', 1)
                    meta[key.strip()] = value.strip()
            text = text[end + 4:].lstrip('\n')
    return meta, text


def chunk_markdown(title: str, text: str, size: int = CHUNK_CHARS) -> list[dict]:
    """Split a note by headings, then by paragraphs, keeping the heading path."""
    _, body = strip_frontmatter(text)
    chunks, path, buf = [], [], []

    def flush():
        joined = '\n'.join(buf).strip()
        buf.clear()
        if not joined:
            return
        heading = ' > '.join(path)
        if not tokens(_LINK.sub(' ', joined)):
            return                                               # only links ("Related") or bookkeeping
        while joined:
            piece = joined[:size]
            if len(joined) > size:
                cut = max(piece.rfind('\n\n'), piece.rfind('. '))
                piece = joined[:cut + 1] if cut > size // 3 else piece
            chunks.append({'heading': heading, 'text': piece.strip()})
            joined = joined[len(piece):].strip()

    for line in body.splitlines():
        m = _HEADING.match(line)
        if m:
            flush()
            level = len(m.group(1))
            path[:] = path[:level - 1] + [m.group(2).strip()]
            continue
        if not _LOG_LINE.match(line.strip()):
            buf.append(line)
    flush()
    return chunks or [{'heading': '', 'text': title}]


class RagIndex:
    def __init__(self, root: Path, index_path: Path, *, workspace: Path | None = None, embedder=None):
        self.root = root
        self.index_path = index_path
        self.workspace = workspace or root.parent
        self.embedder = embedder
        self.data = {'version': INDEX_VERSION, 'files': {}}
        try:
            loaded = json.loads(index_path.read_text(encoding='utf-8'))
            if loaded.get('version') == INDEX_VERSION:
                self.data = loaded
        except (OSError, ValueError):
            pass

    def refresh(self) -> dict:
        files = self.data['files']
        seen, changed = set(), 0
        if self.root.is_dir():
            for path in self.root.rglob('*.md'):
                if any(part.startswith('.') for part in path.relative_to(self.root).parts):
                    continue                                  # .obsidian, .trash
                if path.name in SKIP_NOTES:
                    continue                                  # catalogues, not knowledge
                try:
                    stat = path.stat()
                except OSError:
                    continue
                if stat.st_size > MAX_FILE_BYTES:
                    continue
                rel = path.relative_to(self.workspace).as_posix()
                seen.add(rel)
                old = files.get(rel)
                if old and old['mtime'] == stat.st_mtime and old['size'] == stat.st_size:
                    continue
                text = path.read_text(encoding='utf-8', errors='replace')
                meta, _ = strip_frontmatter(text)
                chunks = chunk_markdown(path.stem, text)
                for c in chunks:
                    c['tf'] = Counter(tokens(path.stem + ' ' + c['heading'] + ' ' + c['text']))
                files[rel] = {'mtime': stat.st_mtime, 'size': stat.st_size, 'title': path.stem,
                              'kind': meta.get('kind', ''), 'updated': meta.get('updated', ''), 'chunks': chunks}
                changed += 1
        removed = [rel for rel in files if rel not in seen]
        for rel in removed:
            del files[rel]
        if self.embedder:
            changed += self._embed_missing()
        if changed or removed:
            self.save()
        return {'notes': len(files), 'chunks': sum(len(f['chunks']) for f in files.values()),
                'reindexed': changed, 'removed': len(removed)}

    def save(self):
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.index_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.data, ensure_ascii=False), encoding='utf-8')
        tmp.replace(self.index_path)

    def search(self, query: str, limit: int = 5) -> list[dict]:
        self.refresh()
        q = tokens(query)
        if not q:
            return []
        all_chunks = [(rel, f, c) for rel, f in self.data['files'].items() for c in f['chunks']]
        n = len(all_chunks) or 1
        avg = sum(sum(c['tf'].values()) for _, _, c in all_chunks) / n or 1
        df = Counter(t for _, _, c in all_chunks for t in set(c['tf']) if t in q)
        scored = []
        for rel, f, c in all_chunks:
            tf, length = c['tf'], sum(c['tf'].values()) or 1
            score = 0.0
            for t in q:
                if t in tf:
                    idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                    score += idf * tf[t] * 2.2 / (tf[t] + 1.2 * (0.25 + 0.75 * length / avg))
            if score:
                if query.casefold().strip() in c['text'].casefold():
                    score *= 1.5                                  # exact phrase bonus
                scored.append((score, rel, f, c))
        scored.sort(key=lambda s: -s[0])
        top = scored[:max(limit * 6, 20)]
        if self.embedder and top:
            top = self._rerank(query, top)
        out, per_note = [], Counter()
        for score, rel, f, c in top:
            if per_note[rel] >= 2:                               # variety: at most 2 chunks per note
                continue
            per_note[rel] += 1
            out.append({'title': f['title'], 'file': rel, 'heading': c['heading'], 'kind': f.get('kind', ''),
                        'score': round(score, 3), 'text': c['text'][:700]})
            if len(out) >= limit:
                break
        return out

    def _embed_missing(self) -> int:
        todo = [c for f in self.data['files'].values() for c in f['chunks'] if 'vec' not in c]
        for start in range(0, min(len(todo), 512), 32):             # bounded work per refresh
            batch = todo[start:start + 32]
            try:
                vectors = self.embedder([c['heading'] + '\n' + c['text'] for c in batch])
            except (OSError, ValueError):
                self.embedder = None                              # embeddings off for this session
                return 0
            for c, v in zip(batch, vectors):
                c['vec'] = v
        return 1 if todo else 0

    def _rerank(self, query, top):
        try:
            qv = self.embedder([query])[0]
        except (OSError, ValueError):
            return top
        best = max(s[0] for s in top) or 1
        out = []
        for score, rel, f, c in top:
            cos = _cosine(qv, c['vec']) if c.get('vec') else 0.0
            out.append((0.5 * score / best + 0.5 * cos, rel, f, c))
        out.sort(key=lambda s: -s[0])
        return out


def _cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1
    nb = math.sqrt(sum(y * y for y in b)) or 1
    return dot / (na * nb)


def lmstudio_embedder(base_url: str, model: str):
    """Embeddings from LM Studio's local server (127.0.0.1 only)."""
    if not re.match(r'^http://(127\.0\.0\.1|localhost)(:\d+)?/', base_url + '/'):
        raise ValueError('rag_embeddings only talks to LM Studio on this PC (127.0.0.1).')

    def embed(texts):
        body = json.dumps({'model': model, 'input': list(texts)}).encode()
        req = urllib.request.Request(base_url.rstrip('/') + '/embeddings', data=body,
                                     headers={'Content-Type': 'application/json'})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req, timeout=60) as response:
            data = json.loads(response.read().decode())['data']
        return [row['embedding'] for row in sorted(data, key=lambda r: r['index'])]
    return embed
