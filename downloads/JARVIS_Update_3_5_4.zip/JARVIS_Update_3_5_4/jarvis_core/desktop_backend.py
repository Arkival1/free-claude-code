"""Operating-system layer for JARVIS desktop control (v3.4).

Desktop (desktop.py) holds the logic and safety rules: permissions, which apps may be
touched, screenshot-to-screen coordinates, focus checks, and checking that actions worked.
A backend only does the raw OS work: list windows, take a screenshot, move/click/type, and
read the accessibility tree. WindowsBackend is the real one; tests plug in a stand-in.

Every backend returns windows as dicts:
  {'hwnd': int, 'pid': int, 'exe': 'name.exe', 'title': str, 'rect': [l, t, r, b], 'elevated': bool|None}
and accessibility elements as dicts:
  {'name': str, 'role': 'button'|'edit'|..., 'rect': [l, t, r, b], 'enabled': bool, 'visible': bool,
   'password': bool, 'ref': <opaque backend object>}
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SW_RESTORE = 9
CLICKABLE_ROLES = ('button', 'hyperlink', 'tabitem', 'menuitem', 'checkbox', 'radiobutton', 'listitem',
                   'treeitem', 'splitbutton', 'menu')
TEXT_ROLES = ('edit', 'document', 'combobox')


class WindowsBackend:
    """Win32 + pyautogui + optional pywinauto UI Automation. Windows only."""
    name = 'windows'

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ctypes, self.wintypes = ctypes, wintypes
        # Align screenshot, GetWindowRect and cursor coords under Windows scaling.
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except (OSError, AttributeError):
            pass
        self.user, self.kernel = self._winapi()

    def _winapi(self):
        ctypes, wintypes = self.ctypes, self.wintypes
        user = ctypes.WinDLL('user32', use_last_error=True)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        user.GetForegroundWindow.restype = wintypes.HWND
        user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user.GetWindowThreadProcessId.restype = wintypes.DWORD
        user.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user.GetWindowTextLengthW.restype = ctypes.c_int
        user.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user.GetWindowTextW.restype = ctypes.c_int
        user.IsWindowVisible.argtypes = [wintypes.HWND]
        user.IsWindowVisible.restype = wintypes.BOOL
        user.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user.GetWindowRect.restype = wintypes.BOOL
        user.SetForegroundWindow.argtypes = [wintypes.HWND]
        user.SetForegroundWindow.restype = wintypes.BOOL
        user.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        kernel.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        kernel.QueryFullProcessImageNameW.restype = wintypes.BOOL
        return user, kernel

    # ---------------- windows ----------------
    def foreground(self) -> int:
        return int(self.user.GetForegroundWindow() or 0)

    def window_info(self, hwnd):
        ctypes, wintypes, user, kernel = self.ctypes, self.wintypes, self.user, self.kernel
        if not hwnd:
            return None
        pid = wintypes.DWORD(0)
        user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return None
        handle = kernel.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not handle:
            return None  # never guess exe identity
        try:
            path = ctypes.create_unicode_buffer(32768)
            size = wintypes.DWORD(len(path))
            if not kernel.QueryFullProcessImageNameW(handle, 0, path, ctypes.byref(size)):
                return None
            elevated = None
            try:
                adv = ctypes.WinDLL('advapi32', use_last_error=True)
                adv.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
                adv.OpenProcessToken.restype = wintypes.BOOL
                adv.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
                adv.GetTokenInformation.restype = wintypes.BOOL
                token = wintypes.HANDLE()
                if adv.OpenProcessToken(handle, 0x0008, ctypes.byref(token)):
                    try:
                        elevation = wintypes.DWORD()
                        returned = wintypes.DWORD()
                        if adv.GetTokenInformation(token, 20, ctypes.byref(elevation), ctypes.sizeof(elevation), ctypes.byref(returned)):
                            elevated = bool(elevation.value)
                    finally:
                        kernel.CloseHandle(token)
            except (OSError, AttributeError):
                pass
        finally:
            kernel.CloseHandle(handle)
        size = user.GetWindowTextLengthW(hwnd)
        title = ctypes.create_unicode_buffer(max(size + 1, 2))
        user.GetWindowTextW(hwnd, title, len(title))
        rect = wintypes.RECT()
        if not user.GetWindowRect(hwnd, ctypes.byref(rect)):
            return None
        return {'hwnd': int(hwnd), 'pid': pid.value, 'exe': Path(path.value).name.lower(),
                'title': title.value[:160], 'rect': [rect.left, rect.top, rect.right, rect.bottom], 'elevated': elevated}

    def windows(self) -> list[dict]:
        ctypes, wintypes, user = self.ctypes, self.wintypes, self.user
        found = []
        FN = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @FN
        def each(hwnd, _):
            if user.IsWindowVisible(hwnd):
                info = self.window_info(hwnd)
                if info and info['title']:
                    found.append(info)
            return True
        user.EnumWindows.argtypes = [FN, wintypes.LPARAM]
        user.EnumWindows(each, 0)
        return found

    def activate(self, hwnd: int) -> bool:
        self.user.ShowWindow(self.wintypes.HWND(hwnd), SW_RESTORE)
        ok = bool(self.user.SetForegroundWindow(self.wintypes.HWND(hwnd)))
        time.sleep(0.15)
        return ok

    # ---------------- screen + input ----------------
    @staticmethod
    def gui():
        """pyautogui-style input object: size, position, moveTo, click, mouseDown/Up, dragTo, scroll, hotkey, keyDown/Up, write."""
        import pyautogui
        pyautogui.FAILSAFE = True   # move mouse to top-left corner to interrupt the library
        pyautogui.PAUSE = 0.15
        return pyautogui

    def grab(self):
        from PIL import ImageGrab
        return ImageGrab.grab(all_screens=False).convert('RGB')

    def type_text(self, text: str):
        """Unicode typing with SendInput (KEYEVENTF_UNICODE): any language, emoji, no clipboard."""
        ctypes, wintypes = self.ctypes, self.wintypes
        ULONG_PTR = ctypes.c_size_t

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [('wVk', wintypes.WORD), ('wScan', wintypes.WORD), ('dwFlags', wintypes.DWORD),
                        ('time', wintypes.DWORD), ('dwExtraInfo', ULONG_PTR)]

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [('dx', wintypes.LONG), ('dy', wintypes.LONG), ('mouseData', wintypes.DWORD),
                        ('dwFlags', wintypes.DWORD), ('time', wintypes.DWORD), ('dwExtraInfo', ULONG_PTR)]

        class _U(ctypes.Union):
            _fields_ = [('ki', KEYBDINPUT), ('mi', MOUSEINPUT)]

        class INPUT(ctypes.Structure):
            _fields_ = [('type', wintypes.DWORD), ('u', _U)]

        send = ctypes.WinDLL('user32', use_last_error=True).SendInput
        send.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
        KEYEVENTF_UNICODE, KEYEVENTF_KEYUP, VK_RETURN, VK_TAB = 0x0004, 0x0002, 0x0D, 0x09
        for ch in text:
            if ch in ('\n', '\t'):
                vk = VK_RETURN if ch == '\n' else VK_TAB
                seq = [(vk, 0, 0), (vk, 0, KEYEVENTF_KEYUP)]
            else:
                data = ch.encode('utf-16-le')
                units = [int.from_bytes(data[i:i + 2], 'little') for i in range(0, len(data), 2)]
                seq = []
                for u in units:
                    seq += [(0, u, KEYEVENTF_UNICODE), (0, u, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP)]
            arr = (INPUT * len(seq))()
            for i, (vk, scan, flags) in enumerate(seq):
                arr[i].type = 1
                arr[i].u.ki = KEYBDINPUT(vk, scan, flags, 0, 0)
            send(len(seq), arr, ctypes.sizeof(INPUT))
            time.sleep(0.006)

    # ---------------- accessibility (UI Automation via optional pywinauto) ----------------
    @staticmethod
    def _uia():
        try:
            from pywinauto import Desktop as PyWinDesktop
        except ImportError as err:
            raise ImportError('pywinauto') from err
        return PyWinDesktop(backend='uia')

    def ui_tree(self, hwnd, limit=300) -> list[dict]:
        win = self._uia().window(handle=hwnd)
        out = []
        for obj in win.descendants()[:limit]:
            e = obj.element_info
            role = str(getattr(e, 'control_type', '')).lower()
            try:
                r = obj.rectangle()
                rect = [r.left, r.top, r.right, r.bottom]
                visible, enabled = obj.is_visible(), obj.is_enabled()
            except Exception:
                continue
            password = role == 'edit' and bool(getattr(e, 'is_password', False) or
                                               'password' in str(getattr(e, 'name', '')).casefold())
            out.append({'name': str(getattr(e, 'name', ''))[:120], 'role': role, 'rect': rect,
                        'enabled': bool(enabled), 'visible': bool(visible), 'password': password, 'ref': obj})
        return out

    def ui_invoke(self, el) -> bool:
        """Press a control through UI Automation (no mouse). False if the control has no invoke action."""
        obj = el['ref']
        for method in ('invoke', 'toggle', 'select'):
            fn = getattr(obj, method, None)
            if fn is None:
                continue
            try:
                fn()
                return True
            except Exception:
                continue
        return False

    def ui_set_text(self, el, text) -> bool:
        obj = el['ref']
        try:
            obj.set_edit_text(text)
            return True
        except Exception:
            return False

    def ui_get_text(self, el) -> str:
        obj = el['ref']
        for method in ('get_value', 'window_text'):
            fn = getattr(obj, method, None)
            if fn is None:
                continue
            try:
                value = fn()
                if isinstance(value, str):
                    return value
            except Exception:
                continue
        return ''


def default_backend():
    return WindowsBackend() if sys.platform == 'win32' else None
