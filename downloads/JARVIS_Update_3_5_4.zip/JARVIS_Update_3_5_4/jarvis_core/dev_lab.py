"""Offline execution of one source file in a restricted, preinstalled Docker image.

This does not run generated code on the Windows host. It is a constrained local
container, NOT a perfect sandbox. Docker images are installed by owner only.
"""
from __future__ import annotations
from pathlib import Path
import shutil
import subprocess
import tempfile
import uuid
from .policy import PolicyError

# Language names and image/command are hardcoded, never model-supplied shell fragments.
LANGUAGES = {
    'python': ('.py', 'python:3.12-alpine', ['python','-I','-B','/lab/source.py']),
    'javascript': ('.js', 'node:22-alpine', ['node','/lab/source.js']),
    'cpp': ('.cpp', 'gcc:14', ['sh','-c','g++ -std=c++17 -O0 /lab/source.cpp -o /tmp/run && /tmp/run']),
    'rust': ('.rs', 'rust:1.85', ['sh','-c','rustc --edition=2021 /lab/source.rs -o /tmp/run && /tmp/run']),
}

class DevLab:
    def __init__(self, settings): self.settings = settings

    def run(self, file, language):
        self.settings.require('coding_lab')
        self.settings.require_not_stopped()
        if language not in LANGUAGES:
            raise PolicyError('Allowed languages: python, javascript, cpp, rust.')
        extension,image,command=LANGUAGES[language]
        if not isinstance(file,str) or not file.lower().endswith(extension):
            raise PolicyError(f'{language} source must end in {extension}.')
        src=self.settings.in_workspace(file)
        if not src.is_file() or src.stat().st_size > 128 * 1024:
            raise PolicyError('Source missing or exceeds 128 KB.')
        docker=shutil.which('docker')
        if not docker:
            raise PolicyError('Docker unavailable. Owner installs Docker Desktop and locally loads approved image; no host execution.')
        probe=subprocess.run([docker,'image','inspect',image],capture_output=True,text=True,timeout=15)
        if probe.returncode:
            raise PolicyError(f'Docker image {image} missing. Owner must approve/download it separately; JARVIS will not pull it.')
        self.settings.reload()
        self.settings.data_dir.mkdir(parents=True,exist_ok=True)
        run_id='jarvis-dev-'+uuid.uuid4().hex[:12]
        with tempfile.TemporaryDirectory(prefix='jarvis-dev-',dir=self.settings.data_dir) as tmp:
            filename='source'+extension
            Path(tmp,filename).write_bytes(src.read_bytes())
            cmd=[docker,'run','--rm','--name',run_id,'--network','none','--read-only',
                 '--security-opt','no-new-privileges','--cap-drop','ALL','--pids-limit','64',
                 '--cpus','1','--memory','512m','--memory-swap','512m','--user','65534:65534',
                 '--workdir','/lab','--tmpfs','/tmp:rw,nosuid,nodev,size=128m',
                 '--mount',f'type=bind,src={tmp},dst=/lab,readonly',image,*command]
            try:
                proc=subprocess.run(cmd,text=True,capture_output=True,timeout=75,stdin=subprocess.DEVNULL)
            except subprocess.TimeoutExpired:
                subprocess.run([docker,'rm','-f',run_id],capture_output=True,timeout=10)
                raise PolicyError('Coding Lab timed out after 75 seconds; container was stopped.')
            self.settings.require_not_stopped()
            return {'file':file,'language':language,'exit_code':proc.returncode,
                    'stdout':proc.stdout[:5000],'stderr':proc.stderr[:4000],
                    'runtime':'offline isolated Docker container; no code ran on Windows host',
                    'warning':'Docker containers reduce risk, not a perfect isolation boundary.'}
