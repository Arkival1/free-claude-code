"""Local, minimized activity log for owner monitor. No prompts/contents/credentials."""
from __future__ import annotations
from datetime import datetime,timezone
import json

class Activity:
    def __init__(self,settings):self.settings=settings
    def record(self,tool:str,ok:bool,detail:str=''):
        self.settings.reload()
        self.settings.data_dir.mkdir(parents=True,exist_ok=True)
        path=self.settings.data_dir/'activity.jsonl'
        # Only metadata, NEVER model prompts, tool argument bodies, download URLs or screenshots.
        entry={'time':datetime.now(timezone.utc).isoformat(timespec='seconds'),
               'tool':str(tool)[:70],'status':'ok' if ok else 'error',
               'detail':str(detail)[:80]}
        with path.open('a',encoding='utf-8') as f:
            f.write(json.dumps(entry,ensure_ascii=False)+'\n')
