"""OpenWhispr local transcription through the desktop app's own loopback bridge - v3.2.

OpenWhispr (1.10.0+) writes {version, port, token} to ~/.openwhispr/cli-bridge.json
while it runs, and serves 127.0.0.1:8200-8219. POST /v1/transcribe takes a file PATH;
OpenWhispr reads the file itself and runs the local model chosen in its settings.
No audio leaves the PC and no mouse clicks are needed.

Security: only 127.0.0.1, only ports 8200-8219, no proxies, no redirects. The bridge
token is read from the owner's file for each call and is never returned, logged or
shown to the model. Only workspace media files are sent (checked by the caller).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import requests

from .policy import PolicyError

PORT_MIN, PORT_MAX = 8200, 8219
HOST = '127.0.0.1'
TOKEN_RE = re.compile(r'[0-9a-f]{32,128}')
MIN_VERSION_NOTE = 'OpenWhispr 1.10.0 or newer'


def default_bridge_file() -> Path:
    return Path.home() / '.openwhispr' / 'cli-bridge.json'


class OpenWhispr:
    def __init__(self, bridge_file: Path | None = None):
        self.bridge_file = Path(bridge_file) if bridge_file else default_bridge_file()

    def _bridge(self):
        try:
            raw = json.loads(self.bridge_file.read_text(encoding='utf-8'))
        except FileNotFoundError:
            raise PolicyError('OpenWhispr is not running (no bridge file). Open the OpenWhispr app and try again.') from None
        except (OSError, ValueError):
            raise PolicyError('OpenWhispr bridge file is unreadable. Restart the OpenWhispr app.') from None
        port, token = raw.get('port'), raw.get('token')
        if type(port) is not int or not PORT_MIN <= port <= PORT_MAX:
            raise PolicyError('OpenWhispr bridge file has an unexpected port; refusing to connect.')
        if not isinstance(token, str) or not TOKEN_RE.fullmatch(token):
            raise PolicyError('OpenWhispr bridge file has an unexpected key format; refusing to connect.')
        return port, token

    def _call(self, method: str, path: str, body=None, timeout=10):
        port, token = self._bridge()
        session = requests.Session()
        session.trust_env = False  # never route the private key through a proxy
        try:
            res = session.request(method, f'http://{HOST}:{port}{path}', json=body,
                                  headers={'Authorization': f'Bearer {token}'},
                                  timeout=timeout, allow_redirects=False)
        except requests.ConnectionError:
            raise PolicyError('OpenWhispr bridge is not answering. Make sure the OpenWhispr app is open (not just installed).') from None
        except requests.Timeout:
            raise PolicyError('OpenWhispr took too long to answer.') from None
        finally:
            session.close()
        try:
            payload = res.json()
        except ValueError:
            payload = {}
        if res.status_code == 401:
            raise PolicyError('OpenWhispr refused the key (the app was probably restarted). Try again in a few seconds.')
        if res.status_code == 404 and path.startswith('/v1/transcribe'):
            raise PolicyError(f'This OpenWhispr version cannot transcribe files from other apps. Update to {MIN_VERSION_NOTE}.')
        if res.status_code >= 400:
            err = payload.get('error') if isinstance(payload, dict) else None
            msg = err.get('message') if isinstance(err, dict) else res.text[:200]
            raise PolicyError(f'OpenWhispr error {res.status_code}: {str(msg)[:300]}')
        return payload.get('data') if isinstance(payload, dict) else None

    def status(self) -> dict:
        """Is OpenWhispr open, and which local models are downloaded? Never returns the key."""
        try:
            self._call('GET', '/v1/health', timeout=5)
        except PolicyError as exc:
            return {'available': False, 'reason': str(exc)}
        try:
            models = self._call('GET', '/v1/transcribe/models', timeout=15) or []
        except PolicyError as exc:
            return {'available': True, 'can_transcribe_files': False, 'reason': str(exc)}
        clean = [{'model': str(m.get('model', ''))[:80], 'provider': str(m.get('provider', ''))[:40],
                  'default': bool(m.get('default')), 'downloaded': bool(m.get('downloaded'))}
                 for m in models if isinstance(m, dict)][:40]
        default = next((m for m in clean if m['default'] and m['downloaded']), None)
        return {'available': True, 'can_transcribe_files': bool(default), 'default_model': default,
                'models': clean,
                'reason': '' if default else 'No downloaded default model. In OpenWhispr open Settings > Speech to Text and download/select a local model.'}

    def transcribe(self, audio_path: Path, model: str | None = None, language: str | None = None,
                   timeout: float = 3 * 3600) -> dict:
        path = Path(audio_path)
        if not path.is_absolute() or not path.is_file():
            raise PolicyError('OpenWhispr needs the full path of an existing audio file.')
        body = {'path': str(path)}
        if model:
            body['model'] = str(model)[:80]
        if language:
            if not re.fullmatch(r'[a-zA-Z]{2,3}(?:-[a-zA-Z]{2,5})?', language):
                raise PolicyError('Language must be a code like en or en-US.')
            body['language'] = language
        data = self._call('POST', '/v1/transcribe', body=body, timeout=(10, timeout)) or {}
        text = str(data.get('text') or '')
        return {'text': text, 'provider': str(data.get('provider', ''))[:40], 'model': str(data.get('model', ''))[:80],
                'warning': str(data.get('warning', ''))[:200], 'engine': 'OpenWhispr (local)'}
