"""Local configuration, path confinement, URL and application policy.

This is defense-in-depth, not a Windows sandbox. Model-proposed input is untrusted.
"""
from __future__ import annotations
import ipaddress
import json
import os
from pathlib import Path, PureWindowsPath
import re
import socket
from urllib.parse import urlsplit

DEFAULT_CONFIG = {
    "workspace": r"%USERPROFILE%\JARVIS_Workspace",
    "data_dir": r"%LOCALAPPDATA%\JARVIS\data",
    "permissions": {
        "files": True,
        "notes_and_tasks": True,
        "web_research": True,
        "screen": True,
        "desktop_control": True,
        "app_launch": True,
        "downloads": True,
        "coding_lab": True,
        "preview_local": True
    },
    "desktop_mode": "all_user_apps",
    "coding_lab_image": "python:3.12-alpine",
    "approved_desktop_exes": ["notepad.exe"],
    "apps": {
        "notepad": {"path": "C:\\Windows\\System32\\notepad.exe", "args": []},
        "calculator": {"path": "C:\\Windows\\System32\\calc.exe", "args": []},
        "explorer_workspace": {"path": "C:\\Windows\\explorer.exe", "args": ["{workspace}"]}
    },
    "approved_download_domains": ["godotengine.org", "python.org", "nodejs.org"],
    "max_download_mb": 100,
    "max_file_kb": 256
}

class PolicyError(ValueError):
    pass


# Owner-selected v2.8.3 defaults.  This changes application/tool *configuration*,
# never Windows account rights, workspace confinement, or download approval tokens.
NONADMIN_TOOL_PERMISSIONS = (
    'files', 'notes_and_tasks', 'web_research', 'screen',
    'desktop_control', 'app_launch', 'downloads', 'coding_lab',
    'preview_local',
)

def enable_all_nonadmin_tools(config: dict) -> dict:
    """Apply explicit owner-requested non-admin defaults to a config object.

    Called during an owner-initiated upgrade and by the owner-operated setup
    script. No changes to file paths, private data, downloads, or app registry.
    """
    if not isinstance(config,dict) or not isinstance(config.get('permissions'),dict):
        raise PolicyError('Cannot apply defaults to a malformed JARVIS config.')
    for permission in NONADMIN_TOOL_PERMISSIONS:
        config['permissions'][permission] = True
    config['desktop_mode'] = 'all_user_apps'
    return config

class Settings:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.reload()

    def reload(self):
        with self.path.open('r', encoding='utf-8') as fp:
            self.data = json.load(fp)
        self.workspace = Path(os.path.expandvars(self.data['workspace'])).expanduser().resolve()
        self.data_dir = Path(os.path.expandvars(self.data['data_dir'])).expanduser().resolve()
        return self

    def enabled(self, name: str):
        # Explicitly reload each call so user can revoke without restarting MCP.
        self.reload()
        return bool(self.data.get('permissions', {}).get(name, False))

    def require(self, name: str):
        if not self.enabled(name):
            raise PolicyError(f"Permission '{name}' disabled. Enable it yourself in config.json, then retry.")

    def allowed_exes(self):
        self.reload()
        return {str(x).lower() for x in self.data.get('approved_desktop_exes', [])}

    def kill_switch_path(self):
        return self.path.parent / 'STOP_JARVIS.txt'

    def require_not_stopped(self):
        if self.kill_switch_path().exists():
            raise PolicyError('JARVIS PAUSED: STOP_JARVIS.txt exists. The owner must remove it manually.')

    def in_workspace(self, relative: str, *, allow_root=False) -> Path:
        self.reload()
        if not isinstance(relative, str) or not relative.strip():
            if allow_root and relative == '.':
                return self.workspace
            raise PolicyError('Use a non-empty relative path inside the workspace.')
        if '\\' in relative:
            relative = relative.replace('\\', '/')
        win = PureWindowsPath(relative)
        if win.is_absolute() or win.drive or relative.startswith('/') or '\x00' in relative:
            raise PolicyError('Absolute paths and drive paths are not allowed.')
        parts = relative.split('/')
        if any(x in ('..', '') for x in parts) or re.search(r'[:*?"<>|]', relative):
            raise PolicyError('Traversal, empty path elements and reserved characters are not allowed.')
        candidate = self.workspace.joinpath(*parts)
        self.workspace.mkdir(parents=True, exist_ok=True)
        # Block symlinks, NTFS junctions and reparse paths at every existing component.
        cur = self.workspace
        for part in parts:
            cur = cur / part
            if cur.exists() or cur.is_symlink():
                if cur.is_symlink() or (hasattr(cur, 'is_junction') and cur.is_junction()):
                    raise PolicyError('Links/junctions are not allowed within the workspace.')
        try:
            resolved = candidate.resolve(strict=False)
            resolved.relative_to(self.workspace)
        except ValueError as exc:
            raise PolicyError('Path escapes workspace.') from exc
        if resolved == self.workspace and not allow_root:
            raise PolicyError('Operation on workspace root is disallowed.')
        return resolved


def is_allowed_domain(host: str, domains: list[str]) -> bool:
    host = host.lower().strip('.').removeprefix('www.')
    return any(host == d.lower().removeprefix('www.') or
               host.endswith('.'+d.lower().removeprefix('www.')) for d in domains)


def public_https_url(url: str, *, resolve_dns=True) -> str:
    """Conservatively restrict fetching to public HTTPS sites; reject URL auth/ports/IPs."""
    if not isinstance(url, str) or len(url) > 2048:
        raise PolicyError('Invalid URL.')
    try:
        parts = urlsplit(url)
        host = (parts.hostname or '').lower().rstrip('.')
        port = parts.port
    except ValueError as exc:
        raise PolicyError('Invalid URL structure.') from exc
    if parts.scheme != 'https' or not host or parts.username or parts.password or (port not in (None,443)):
        raise PolicyError('Only public HTTPS URLs with standard ports and no embedded credentials are allowed.')
    if host == 'localhost' or host.endswith('.local') or '.' not in host:
        raise PolicyError('Private or local hostnames are blocked.')
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        raise PolicyError('Direct IP-address URLs are not permitted.')
    if not re.fullmatch(r'[a-z0-9.-]+', host):
        raise PolicyError('Hostname contains invalid characters.')
    if resolve_dns:
        try:
            addresses = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise PolicyError(f'Could not resolve URL hostname: {exc}') from exc
        for addr in addresses:
            ip = ipaddress.ip_address(addr[4][0])
            if not ip.is_global:
                raise PolicyError('Private/loopback network address rejected.')
    return url
