"""Offline starter projects and nonexecuting verification for web, game and coding work.

This creates project source *only* within a pre-approved project. It never runs
Windows shell commands, npm, pip, Godot, or untrusted downloaded software.
"""
from __future__ import annotations
import ast
from html.parser import HTMLParser
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from .policy import PolicyError

_SLG = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,47}$')

WEBSITE = {
 'index.html': '''<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>JARVIS Project</title><link rel="stylesheet" href="style.css"></head>
<body><main><h1>Built by JARVIS</h1><p>This is your local website starter.</p>
<button id="action">Try it</button><p id="output" aria-live="polite"></p></main>
<script src="app.js"></script></body></html>
''',
 'style.css': ''':root{font-family:system-ui,sans-serif;color-scheme:dark}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#121827;color:#ecf3ff}main{max-width:600px;padding:2rem;background:#243047;border-radius:16px}button{padding:.8rem 1.2rem;background:#81baff;border:0;border-radius:8px;cursor:pointer}''',
 'app.js': '''document.querySelector('#action').addEventListener('click',()=>{document.querySelector('#output').textContent='Your website is working!';});\n''',
}
WEB_GAME = {
 'index.html': '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>JARVIS Browser Game</title><link rel="stylesheet" href="style.css"></head><body><main><h1>Star Collector</h1><p>Use arrow keys or WASD to collect the gold star.</p><canvas id="game" width="640" height="400" aria-label="Star collector game"></canvas><p id="score">Score: 0</p></main><script src="game.js"></script></body></html>''',
 'style.css': '''body{margin:0;background:#101726;color:white;font-family:system-ui;text-align:center}main{max-width:720px;margin:auto;padding:12px}canvas{width:100%;max-width:640px;border:2px solid #6885c5;background:#1b2b45}''',
 'game.js': '''const c=document.querySelector('#game'),x=c.getContext('2d');let p={x:50,y:50},s={x:360,y:180},score=0;const held=new Set();addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();held.add(e.key.toLowerCase());});addEventListener('keyup',e=>held.delete(e.key.toLowerCase()));function draw(){let dx=(held.has('arrowright')||held.has('d')?1:0)-(held.has('arrowleft')||held.has('a')?1:0),dy=(held.has('arrowdown')||held.has('s')?1:0)-(held.has('arrowup')||held.has('w')?1:0);p.x=Math.max(12,Math.min(c.width-12,p.x+dx*4));p.y=Math.max(12,Math.min(c.height-12,p.y+dy*4));if(Math.hypot(p.x-s.x,p.y-s.y)<25){score++;document.querySelector('#score').textContent='Score: '+score;s={x:25+Math.random()*590,y:25+Math.random()*350}}x.clearRect(0,0,c.width,c.height);x.fillStyle='#ffe282';x.beginPath();x.arc(s.x,s.y,12,0,Math.PI*2);x.fill();x.fillStyle='#62e1c0';x.fillRect(p.x-12,p.y-12,24,24);requestAnimationFrame(draw)}draw();''',
}
PY_APP={
 'main.py': '''"""Local Python starter created by JARVIS."""\n\ndef main():\n    print("JARVIS project is ready")\n\nif __name__ == "__main__":\n    main()\n''',
 'README.md': '# Python project\n\nRun this ONLY in the optional approved, isolated Coding Lab.\n',
}
GODOT={
 'project.godot': '''; Engine configuration file.\nconfig_version=5\n\n[application]\nconfig/name="JARVIS Godot Project"\nrun/main_scene="res://main.tscn"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\nrenderer/rendering_method.mobile="gl_compatibility"\n''',
 'main.tscn': '''[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://main.gd" id="1"]\n\n[node name="Main" type="Node2D"]\nscript = ExtResource("1")\n''',
 'main.gd': '''extends Node2D\n\nfunc _draw() -> void:\n    draw_circle(Vector2(320, 200), 44.0, Color(0.3, 0.8, 0.9))\n\nfunc _ready() -> void:\n    queue_redraw()\n''',
 'README.md':'# Godot starter\n\nOpen project.godot in your approved Godot desktop app.\nTest in Godot; static file checks cannot prove gameplay.\n'
}
TEMPLATES={'website': WEBSITE,'browser_game':WEB_GAME,'python':PY_APP,'godot':GODOT}

class _Refs(HTMLParser):
    def __init__(self):
        super().__init__();self.refs=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='script' and a.get('src'):self.refs.append(a['src'])
        if tag=='link' and a.get('rel')=='stylesheet' and a.get('href'):self.refs.append(a['href'])

class ProjectTools:
    def __init__(self,settings,files,memory):
        self.settings=settings;self.files=files;self.memory=memory
        self._preview=None;self._thread=None;self._temp=None
    @staticmethod
    def _valid_name(name):
        if not isinstance(name,str) or not _SLG.fullmatch(name) or name.lower() in ('con','prn','aux','nul'):
            raise PolicyError('Use a short project/app name with letters, numbers, hyphen or underscore (must start with a letter).')
        return name
    def _folder(self,project,app):
        self.memory.check_project(project)
        if not isinstance(project,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,60}',project) or project.lower().strip() in ('con','prn','aux','nul'):
            raise PolicyError('Approved project name must be a safe Windows folder name.')
        self._valid_name(app)
        return f'{project}/Projects/{app}'
    def create(self,project:str,app:str,kind:str):
        self.settings.require('files');self.settings.require_not_stopped()
        if kind not in TEMPLATES:raise PolicyError('Choose website, browser_game, python or godot.')
        folder=self._folder(project,app)
        target=self.settings.in_workspace(folder)
        if target.exists() and any(target.iterdir()):
            raise PolicyError('Project folder already exists and is not empty. Refusing to overwrite.')
        created=[]
        for filename,content in TEMPLATES[kind].items():
            relative=f'{folder}/{filename}'
            self.files.write_text(relative,content)
            created.append(relative)
        return {'project':project,'name':app,'kind':kind,'folder':folder,'files_created':created,
                'next':'Modify files via workspace_write, validate with project_check; use optional local preview or approved Godot/VS Code to test.'}
    def check(self,project:str,app:str):
        self.settings.require('files')
        folder=self._folder(project,app)
        root=self.settings.in_workspace(folder)
        if not root.is_dir():raise PolicyError('Project folder does not exist.')
        files=[];python=[];broken=[];html_count=0
        for p in sorted(root.rglob('*')):
            if p.is_dir():continue
            rel=str(p.relative_to(self.settings.workspace)).replace('\\','/')
            self.settings.in_workspace(rel)
            if p.stat().st_size > 256*1024:continue
            files.append(str(p.relative_to(root)).replace('\\','/'))
            if p.suffix.lower()=='.py':
                try:ast.parse(p.read_text('utf-8'),filename=str(p));python.append({'file':p.name,'syntax':'ok'})
                except SyntaxError as e:python.append({'file':p.name,'syntax':'error','line':e.lineno,'message':e.msg})
            if p.suffix.lower()=='.html':
                html_count+=1
                parser=_Refs();parser.feed(p.read_text('utf-8'))
                for reference in parser.refs:
                    if not reference or reference.startswith(('https://','http://','//','data:')):continue
                    if '?' in reference:reference=reference.split('?',1)[0]
                    refparts=PurePosixPath(reference).parts
                    if (not reference or reference.startswith(('/', '\\')) or '..' in refparts or '\\' in reference or not (p.parent / reference).is_file()):
                        broken.append({'html':p.name,'missing':reference})
        return {'project_folder':folder,'files':files[:100], 'python_syntax':python,'missing_local_assets':broken,
                'html_files_checked':html_count,'executed':False,
                'note':'Static checks only. A passing check does not prove a website, game or program works; test in an approved runtime.'}
    def preview_start(self,project:str,app:str):
        self.settings.require('files');self.settings.require('preview_local')
        self.settings.require_not_stopped()
        folder=self._folder(project,app)
        src=self.settings.in_workspace(folder)
        if not src.is_dir() or not (src/'index.html').is_file():
            raise PolicyError('Only website/browser game projects with index.html may be previewed.')
        if self._preview:raise PolicyError('A local preview already runs. Stop it before starting another.')
        temp=tempfile.TemporaryDirectory(prefix='jarvis-preview-')
        target=Path(temp.name)
        total=0
        allowed={'.html','.js','.css','.svg','.json','.png','.jpg','.jpeg','.webp','.gif'}
        for item in src.rglob('*'):
            if item.is_dir():continue
            rel=item.relative_to(src)
            self.settings.in_workspace(f'{folder}/{str(rel).replace(chr(92),"/")}')
            if item.suffix.lower() not in allowed:continue
            size=item.stat().st_size
            if size>1024*1024 or total+size>8*1024*1024:
                temp.cleanup();raise PolicyError('Preview assets exceed local limit.')
            total+=size
            dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(item,dest)
        class Handler(SimpleHTTPRequestHandler):
            def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(target),**kwargs)
            def log_message(self,fmt,*args):pass
        try:
            server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        except Exception:
            temp.cleanup();raise
        self._temp=temp;self._preview=server
        self._thread=threading.Thread(target=server.serve_forever,daemon=True)
        self._thread.start()
        return {'url':f'http://127.0.0.1:{server.server_port}/index.html', 'local_only':True,
                'warning':'Preview JavaScript runs inside your browser and can make web requests; inspect generated code first. This is NOT a sandbox.'}
    def preview_open(self):
        self.settings.require('preview_local')
        self.settings.require('app_launch')
        self.settings.require_not_stopped()
        if not self._preview:
            raise PolicyError('Start a local preview first.')
        import webbrowser
        url=f'http://127.0.0.1:{self._preview.server_port}/index.html'
        if not webbrowser.open(url):
            raise PolicyError('Windows did not confirm opening a browser.')
        return {'opened_url':url,'local_only':True,'warning':'Browser JavaScript is not sandboxed; review source first.'}

    def preview_stop(self):
        if self._preview:
            self._preview.shutdown();self._preview.server_close()
            self._preview=None
        if self._temp:
            self._temp.cleanup();self._temp=None
        return 'Preview stopped.'
