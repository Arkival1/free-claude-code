"""Bundled READ-ONLY local skill guides. Guidance only, no code execution."""
from pathlib import Path
import re
from .policy import PolicyError

SKILLS_ROOT = Path(__file__).resolve().parents[1] / 'jarvis_skills'

class Skills:
    def __init__(self, settings): self.settings = settings

    def catalog(self, query: str = ''):
        self.settings.require_not_stopped()
        if not isinstance(query, str) or len(query)>100: raise PolicyError('Invalid skill search.')
        results=[]
        for p in sorted(SKILLS_ROOT.glob('*.md')):
            text=p.read_text(encoding='utf-8')
            title=text.splitlines()[0].lstrip('# ').strip()
            if query.casefold() in (p.stem+' '+title+' '+text).casefold():
                results.append({'skill_id':p.stem,'title':title})
        return {'skills':results[:40],'note':'Local read-only guidance, NOT executable tools.'}

    def read(self, skill_id:str):
        self.settings.require_not_stopped()
        if not isinstance(skill_id,str) or not re.fullmatch('[a-z0-9_]{2,50}',skill_id):
            raise PolicyError('Invalid skill ID.')
        path=SKILLS_ROOT / (skill_id+'.md')
        if not path.is_file(): raise PolicyError('Unknown built-in skill.')
        return {'skill_id':skill_id,'content':path.read_text(encoding='utf-8')[:7000]}
