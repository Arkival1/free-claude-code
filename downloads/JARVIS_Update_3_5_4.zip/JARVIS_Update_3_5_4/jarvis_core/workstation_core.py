"""Builds the v3.2 video pipeline the same way for the MCP server, the runner and the Workstation app."""
from __future__ import annotations

from .converter import Converter
from .jobs import Jobs
from .openwhispr import OpenWhispr
from .pipeline import VideoPipeline


def build_pipeline(settings, files, vault, youtube, approvals, browser_dom):
    from .fcc_bridge import FccBridge
    fcc = FccBridge(settings)
    jobs = Jobs(settings, reporter=fcc.report_job)     # every job shows live in the FCC orb window
    openwhispr = OpenWhispr()
    converter = Converter(settings, browser_dom)
    pipeline = VideoPipeline(settings, files, vault, youtube, approvals, openwhispr, converter, jobs, fcc=fcc)
    return pipeline, jobs, openwhispr
