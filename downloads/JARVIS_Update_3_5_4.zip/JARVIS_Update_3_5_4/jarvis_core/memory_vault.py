"""Long-term memory in Obsidian: offload facts and conversations, recall them (RAG), resume.

Notes go to JARVIS_Brain/Memory/ with front matter, a summary line and links, and
every save is listed in "Memory Index.md" and today's Daily note. Small models can
then keep talking after their context window fills: the orb (or Memory Chat) saves
older turns here and memory_resume loads the important parts back.
"""
from __future__ import annotations

import re
from datetime import datetime

from .policy import PolicyError
from .rag import RagIndex, lmstudio_embedder, strip_frontmatter

KINDS = ('fact', 'preference', 'decision', 'task', 'conversation', 'idea', 'person', 'project')
FOLDER = 'JARVIS_Brain/Memory'
INDEX_NOTE = FOLDER + '/Memory Index.md'
_BAD_TITLE = re.compile(r'[^a-zA-Z0-9 _-]+')
_TAG = re.compile(r'[^a-z0-9/_-]+')


def clean_title(title: str) -> str:
    text = _BAD_TITLE.sub(' ', str(title or '')).strip()
    text = re.sub(r'\s+', ' ', text)[:64].strip(' -_')
    if not text:
        raise PolicyError('A memory needs a short title (letters, numbers, spaces).')
    return text


def clean_tags(tags) -> list[str]:
    if isinstance(tags, str):
        tags = re.split(r'[,\s]+', tags)
    out = []
    for tag in tags or []:
        t = _TAG.sub('-', str(tag).casefold().lstrip('#')).strip('-/')
        if t and t not in out:
            out.append(t[:40])
    return out[:8]


def summary_line(content: str) -> str:
    for line in content.splitlines():
        line = line.strip().lstrip('#>-* ').strip()
        if len(line) > 3:
            return line[:160]
    return ''


class MemoryVault:
    def __init__(self, settings, files, vault, clock=None):
        self.settings, self.files, self.vault = settings, files, vault
        self.clock = clock or (lambda: datetime.now().astimezone())
        self._index = None

    # ---------- save ----------
    def offload(self, title, content, kind='fact', tags=(), links=()):
        self.settings.require('files'); self.settings.require_not_stopped()
        kind = str(kind or 'fact').casefold().strip()
        if kind not in KINDS:
            raise PolicyError(f'kind must be one of {list(KINDS)}')
        if not isinstance(content, str) or not content.strip():
            raise PolicyError('Nothing to remember: content is empty.')
        if len(content) > 15000:
            raise PolicyError('Memory content must be under 15000 characters; split it into notes.')
        now = self.clock()
        title = clean_title(title)
        if kind == 'conversation' and not title.startswith(f'{now:%Y-%m-%d}'):
            title = clean_title(f'{now:%Y-%m-%d} {title}')
        tag_list = clean_tags(tags) or [kind]
        link_list = [clean_title(x) for x in (links.split(',') if isinstance(links, str) else links or []) if str(x).strip()][:12]
        self.vault.init()
        self.files.create_folder(FOLDER)
        rel = f'{FOLDER}/{title}.md'
        path = self.settings.in_workspace(rel)
        stamp = f'{now:%Y-%m-%d %H:%M}'
        updated = path.is_file()
        if updated:                                         # memories grow: add an update section
            meta, body = strip_frontmatter(self.files.read_text(rel))
            created = meta.get('created', stamp)
            old_tags = clean_tags(meta.get('tags', '').strip('[]').replace('"', ''))
            tag_list = old_tags + [t for t in tag_list if t not in old_tags]
            body = body.rstrip() + f'\n\n## Update {stamp}\n{content.strip()}\n'
        else:
            created = stamp
            lines = [ln for ln in content.strip().splitlines() if ln.strip()]
            lead = f'> {summary_line(content)}\n\n' if len(lines) > 1 else ''
            body = (f'# {title}\n\n{lead}{content.strip()}\n\n'
                    f'## Related\n- [[Memory Index]]\n' + ''.join(f'- [[{x}]]\n' for x in link_list))
        front = (f'---\ntype: memory\nkind: {kind}\ntags: [{", ".join(tag_list)}]\n'
                 f'created: {created}\nupdated: {stamp}\nsource: jarvis\n---\n')
        self.files.write_text(rel, front + body, overwrite=updated)
        self._add_to_index(stamp, kind, title, summary_line(content))
        try:
            self.vault.daily(f'Memory {"updated" if updated else "saved"}: [[{title}]] ({kind})')
        except (PolicyError, OSError):
            pass
        return {'saved': rel, 'title': title, 'kind': kind, 'tags': tag_list,
                'updated_existing_note': updated, 'link': f'[[{title}]]'}

    def _add_to_index(self, stamp, kind, title, summary):
        line = f'- {stamp} · {kind} · [[{title}]] — {summary}\n'
        if self.settings.in_workspace(INDEX_NOTE).is_file():
            old = self.files.read_text(INDEX_NOTE)
            self.files.write_text(INDEX_NOTE, old.rstrip('\n') + '\n' + line, overwrite=True)
        else:
            self.files.write_text(INDEX_NOTE, '# Memory Index\n\nEverything JARVIS has been asked to remember, newest last.\n\n' + line)

    # ---------- recall ----------
    def index(self) -> RagIndex:
        if self._index is None:
            embedder = None
            if str(self.settings.data.get('rag_embeddings', 'off')).casefold() == 'lmstudio':
                embedder = lmstudio_embedder(self.settings.data.get('lm_studio_url', 'http://127.0.0.1:1234/v1'),
                                             self.settings.data.get('rag_embedding_model', 'text-embedding-nomic-embed-text-v1.5'))
            self._index = RagIndex(self.settings.in_workspace('JARVIS_Brain'),
                                   self.settings.data_dir / 'rag_index.json',
                                   workspace=self.settings.workspace, embedder=embedder)
        return self._index

    def recall(self, query, limit=5):
        self.settings.require('files')
        if not isinstance(query, str) or not query.strip() or len(query) > 300:
            raise PolicyError('memory_recall needs a short search query (under 300 characters).')
        limit = max(1, min(int(limit or 5), 10))
        hits = self.index().search(query, limit)
        return {'query': query, 'matches': hits,
                'note': 'Answer from these notes and name the note title. If nothing matches, say you have no memory of it.'
                if hits else 'No matching memories. Say so; do not invent one.'}

    def reindex(self):
        self.settings.require('files')
        self._index = None
        return self.index().refresh()

    # ---------- resume ----------
    def resume(self, query='', max_chars=3000):
        """A compact memory briefing for a new conversation."""
        self.settings.require('files')
        max_chars = max(500, min(int(max_chars or 3000), 8000))
        parts = []
        if self.settings.in_workspace(INDEX_NOTE).is_file():
            lines = [ln for ln in self.files.read_text(INDEX_NOTE).splitlines() if ln.startswith('- ')]
            facts = [ln for ln in lines if ' · conversation · ' not in ln][-15:]
            talks = [ln for ln in lines if ' · conversation · ' in ln][-3:]
            if facts:
                parts.append('## Things the owner asked me to remember\n' + '\n'.join(facts))
            for line in talks:
                m = re.search(r'\[\[([^\]]+)\]\]', line)
                rel = f'{FOLDER}/{m.group(1)}.md' if m else ''
                if rel and self.settings.in_workspace(rel).is_file():
                    _, body = strip_frontmatter(self.files.read_text(rel))
                    parts.append(f'## Earlier conversation: {m.group(1)}\n' + body.split('## Related')[0].strip()[:900])
        if isinstance(query, str) and query.strip():
            hits = self.index().search(query, 3)
            if hits:
                parts.append('## Notes related to "' + query.strip()[:80] + '"\n' +
                             '\n'.join(f'- [[{h["title"]}]] {h["text"][:300]}' for h in hits))
        if not parts:
            return 'No saved memories yet. This is a fresh start.'
        text = '\n\n'.join(parts)
        return text if len(text) <= max_chars else text[-max_chars:]
