"""User-approved project task queue and local SQLite research notes."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from .policy import Settings, PolicyError

def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

class Memory:
    def __init__(self, settings: Settings):
        self.settings = settings
        settings.reload()
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.db = settings.data_dir / 'jarvis.sqlite3'
        self.init()

    @contextmanager
    def connect(self):
        conn=sqlite3.connect(self.db, timeout=5)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def init(self):
        with self.connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS projects (
                name TEXT PRIMARY KEY, approved_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project TEXT NOT NULL REFERENCES projects(name),
                title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
                state TEXT NOT NULL DEFAULT 'todo',
                created TEXT NOT NULL, updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project TEXT NOT NULL REFERENCES projects(name),
                title TEXT NOT NULL, body TEXT NOT NULL,
                source_url TEXT NOT NULL DEFAULT '', created TEXT NOT NULL);
            ''')

    def approve_project_by_owner(self, name: str):
        # Only callable from local manage.py; intentionally NOT exposed as an MCP tool.
        self.validate_text(name, 100)
        with self.connect() as con:
            con.execute('INSERT OR IGNORE INTO projects(name,approved_at) VALUES(?,?)', (name, utc_now()))
        return name

    @staticmethod
    def validate_text(s, limit):
        if not isinstance(s,str) or not s.strip() or len(s) > limit:
            raise PolicyError(f'Text must be non-empty and <= {limit} characters.')

    def check_project(self, name):
        self.settings.require('notes_and_tasks')
        with self.connect() as con:
            if not con.execute('SELECT 1 FROM projects WHERE name=?', (name,)).fetchone():
                raise PolicyError('Project not authorized by owner. Owner uses START_JARVIS.bat option P to approve it')

    def projects(self):
        self.settings.require('notes_and_tasks')
        with self.connect() as con:
            return [x[0] for x in con.execute('SELECT name FROM projects ORDER BY name')]

    def add_task(self, project, title, details=''):
        self.check_project(project)
        self.validate_text(title,200)
        if len(details)>3000: raise PolicyError('Details too long.')
        with self.connect() as con:
            cur = con.execute('INSERT INTO tasks(project,title,details,created,updated) VALUES(?,?,?,?,?)',
                              (project,title,details,utc_now(),utc_now()))
            return cur.lastrowid

    def tasks(self, project, state='all'):
        self.check_project(project)
        if state not in ('all','todo','doing','blocked','done'): raise PolicyError('Unknown state.')
        sql = 'SELECT id,title,state,details FROM tasks WHERE project=?'
        params=[project]
        if state != 'all': sql += ' AND state=?'; params.append(state)
        sql += ' ORDER BY id DESC LIMIT 60'
        with self.connect() as con:
            return [{'id':r[0],'title':r[1],'state':r[2],'details':r[3]} for r in con.execute(sql, params)]

    def update_task(self, project, task_id, state):
        self.check_project(project)
        if state not in ('todo','doing','blocked','done'): raise PolicyError('Unknown state.')
        with self.connect() as con:
            cur = con.execute('UPDATE tasks SET state=?, updated=? WHERE project=? AND id=?',
                             (state,utc_now(),project,task_id))
            if not cur.rowcount: raise PolicyError('Task not found for project.')
        return f'Task {task_id}: {state}'

    def add_note(self, project, title, body, source_url=''):
        self.check_project(project)
        self.validate_text(title,200)
        self.validate_text(body,10000)
        if len(source_url)>2048: raise PolicyError('Source URL too long.')
        with self.connect() as con:
            cur = con.execute('INSERT INTO notes(project,title,body,source_url,created) VALUES(?,?,?,?,?)',
                (project,title,body,source_url,utc_now()))
            return cur.lastrowid

    def search_notes(self, project, query):
        self.check_project(project)
        self.validate_text(query,100)
        with self.connect() as con:
            return [dict(id=r[0],title=r[1],body=r[2],source_url=r[3],created=r[4]) for r in
                con.execute('SELECT id,title,substr(body,1,1000),source_url,created FROM notes '
                    'WHERE project=? AND (title LIKE ? OR body LIKE ?) ORDER BY id DESC LIMIT 15',
                    (project,'%'+query+'%','%'+query+'%'))]
