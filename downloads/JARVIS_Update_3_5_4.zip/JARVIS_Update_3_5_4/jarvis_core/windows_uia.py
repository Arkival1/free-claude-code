"""Kept for older imports: app control by name now lives in app_control.py (v3.4)."""
from .app_control import AppControl as UIInspector  # noqa: F401
