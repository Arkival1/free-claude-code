"""One-time owner-approved HTTPS downloads. The model cannot approve requests.

The approval GUI is a separate trusted local process that updates SQLite.
MCP tools can only submit requests and consume already approved exact URLs.
"""
from __future__ import annotations
import sqlite3
import re
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from pathlib import Path
from .policy import Settings, PolicyError, public_https_url


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


class DownloadApprovals:
    def __init__(self, settings: Settings):
        self.settings = settings
        settings.reload()
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.db = settings.data_dir / 'approvals.sqlite3'
        with self.connect() as conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS downloads (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 url TEXT NOT NULL, filename TEXT NOT NULL,
                 status TEXT NOT NULL CHECK(status IN ('pending','approved','denied','used')),
                 created_at TEXT NOT NULL, expires_at TEXT NOT NULL,
                 decided_at TEXT DEFAULT '', used_at TEXT DEFAULT ''
            )''')

    @contextmanager
    def connect(self):
        conn=sqlite3.connect(self.db, timeout=8)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def request(self, url: str, filename: str):
        self.settings.require('downloads')
        self.settings.require_not_stopped()
        # Validate syntax before writing a request; DNS is checked during download.
        public_https_url(url, resolve_dns=False)
        if not isinstance(filename,str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,120}',filename):
            raise PolicyError('Filename must be a simple filename without path separators.')
        if filename in ('.','..') or filename.startswith('.'):
            raise PolicyError('Invalid filename.')
        with self.connect() as conn:
            row = conn.execute("SELECT id,status FROM downloads WHERE url=? AND filename=? AND expires_at>? AND status IN ('pending','approved') ORDER BY id DESC LIMIT 1", (url, filename, now_iso())).fetchone()
            if row:
                return {'request_id': row[0], 'status': row[1], 'url': url, 'filename': filename,
                        'next_step': 'Owner must approve this exact link in JARVIS Control Panel > Download Requests.'}
            expiration = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat(timespec='seconds')
            cur=conn.execute('INSERT INTO downloads(url,filename,status,created_at,expires_at) VALUES(?,?,?,?,?)',
                             (url,filename,'pending',now_iso(),expiration))
            return {'request_id':cur.lastrowid,'status':'pending','url':url,'filename':filename,
                    'next_step':'STOP. Show the complete URL to the owner. Owner must approve in the local JARVIS Control Panel; do not download yet.'}

    def list_requests(self, limit=60):
        with self.connect() as conn:
            return [dict(id=r[0],url=r[1],filename=r[2],status=r[3],created_at=r[4],expires_at=r[5]) for r in conn.execute(
                'SELECT id,url,filename,status,created_at,expires_at FROM downloads ORDER BY id DESC LIMIT ?', (limit,))]

    def owner_decide(self, request_id:int, approved:bool):
        """Only invoked by local owner GUI, never exposed to the model as an MCP tool."""
        if not isinstance(request_id,int): raise ValueError('Invalid request ID')
        with self.connect() as conn:
            row=conn.execute('SELECT status,expires_at FROM downloads WHERE id=?',(request_id,)).fetchone()
            if not row or row[0]!='pending' or row[1] <= now_iso():
                raise PolicyError('Request missing, already decided, or expired.')
            conn.execute('UPDATE downloads SET status=?,decided_at=? WHERE id=?',
                         ('approved' if approved else 'denied',now_iso(),request_id))

    def latest(self,url,filename):
        """Read-only: newest request for this exact url+filename (status pending/approved/denied/used), or None."""
        with self.connect() as conn:
            row=conn.execute('SELECT id,status,expires_at FROM downloads WHERE url=? AND filename=? ORDER BY id DESC LIMIT 1',
                             (url,filename)).fetchone()
        if not row:return None
        status=row[1]
        if status in ('pending','approved') and row[2]<=now_iso():status='expired'
        return {'id':row[0],'status':status,'expires_at':row[2]}

    def approved_filename(self,url,candidates):
        """Read-only: which of these filenames (in order) has a live approval for url? None if none."""
        with self.connect() as conn:
            for name in candidates:
                row=conn.execute('SELECT id FROM downloads WHERE url=? AND filename=? AND status=? AND expires_at>? LIMIT 1',
                                 (url,name,'approved',now_iso())).fetchone()
                if row:return name
        return None

    def consume_once(self,url,filename):
        """Spend approval atomically BEFORE network transfer; retries need new approval."""
        self.settings.require('downloads')
        self.settings.require_not_stopped()
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            row=conn.execute('SELECT id FROM downloads WHERE url=? AND filename=? AND status=? AND expires_at>? ORDER BY id DESC LIMIT 1',
                             (url,filename,'approved',now_iso())).fetchone()
            if not row:
                raise PolicyError('Download not approved for this exact link and filename. Call download_request and ask the owner to approve it in Control Panel.')
            conn.execute('UPDATE downloads SET status=?,used_at=? WHERE id=?',('used',now_iso(),row[0]))
            return row[0]
