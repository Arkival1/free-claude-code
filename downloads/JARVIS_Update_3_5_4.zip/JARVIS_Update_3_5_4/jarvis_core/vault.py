"""Obsidian-compatible Markdown vault stored in the approved local workspace."""
from __future__ import annotations
from datetime import datetime
import json
import re
from .policy import PolicyError

CATEGORIES=('Knowledge','Research','Daily','Projects','Coding_Lab','Reflections')
_SLUG=re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9 _-]{0,70}$')

class Vault:
    def __init__(self,settings,files): self.settings=settings;self.files=files
    @staticmethod
    def title_ok(title):
        if not isinstance(title,str) or not _SLUG.fullmatch(title) or title.lower().strip() in ('con','prn','nul','aux'):
            raise PolicyError('Note/canvas titles must use letters, numbers, spaces, underscores or hyphens (max 71 chars).')
        return title.strip()
    def init(self):
        self.settings.require('files');self.settings.require_not_stopped()
        for cat in (*CATEGORIES,'Canvas'):
            self.files.create_folder('JARVIS_Brain/'+cat)
        home='JARVIS_Brain/Home.md'
        if not self.settings.in_workspace(home).exists():
            self.files.write_text(home,'# JARVIS Brain\n\nLocal Obsidian knowledge vault.\n\n'+'\n'.join(f'- [[{c}]]' for c in CATEGORIES)+'\n')
        return {'vault':'JARVIS_Brain','path':str(self.settings.in_workspace('JARVIS_Brain')),
                'note':'Open this folder as an Obsidian vault. These are Markdown files on your local drive.'}
    def folders(self):
        """Top-level folders that already exist in the vault (e.g. the owner's '06 Research')."""
        root=self.settings.in_workspace('JARVIS_Brain')
        if not root.is_dir():return []
        return sorted(p.name for p in root.iterdir() if p.is_dir() and not p.name.startswith(('.','_')))

    def folder_for(self,category):
        """Standard category (optionally mapped in config 'obsidian_folders', e.g. {"Research": "06 Research"})
        or a folder that ALREADY exists at the top of the vault. JARVIS never invents new top-level folders here."""
        mapping=self.settings.data.get('obsidian_folders') or {}
        if category in CATEGORIES:
            target=mapping.get(category,category) if isinstance(mapping,dict) else category
        elif isinstance(category,str) and category in self.folders():
            target=category
        else:
            raise PolicyError(f'Unknown vault folder {category!r}. Use one of {list(CATEGORIES)} '
                              f'or an existing vault folder: {self.folders()[:20]}')
        if not isinstance(target,str) or not _SLUG.fullmatch(target) or '/' in target or '\\' in target:
            raise PolicyError('Vault folder names may use letters, numbers, spaces, underscores and hyphens.')
        return target

    def note(self,category,title,body,links='',overwrite=False):
        self.settings.require('files');self.settings.require_not_stopped()
        folder=self.folder_for(category)
        title=self.title_ok(title)
        if not isinstance(body,str) or len(body)>16000:raise PolicyError('Body must be a string <=16000 characters.')
        if isinstance(links,(list,tuple)):raw=[str(x) for x in links]
        elif isinstance(links,str):raw=links.split(',')
        else:raise PolicyError('links must be a list of note titles or comma-separated text.')
        link_list=[self.title_ok(s.strip().strip('[]')) for s in raw if s.strip().strip('[]')]
        if len(link_list)>20:raise PolicyError('Too many links.')
        self.init()
        content=f'# {title}\n\n{body}\n'
        if link_list:content+='\n## Linked notes\n'+ '\n'.join(f'- [[{s}]]' for s in link_list)+'\n'
        relative=f'JARVIS_Brain/{folder}/{title}.md'
        return self.files.write_text(relative,content,overwrite)
    def build_second_brain(self):
        """Idempotent, real filesystem setup; preserve all existing owner notes."""
        self.settings.require('files');self.settings.require_not_stopped()
        result=self.init()
        sections=(
            ('Knowledge','Knowledge Index','Central knowledge index.\n\n- [[Research Index]]\n- [[Project Index]]\n- [[Lessons Learned]]'),
            ('Research','Research Index','Source-linked research notes. Verify sources before marking findings as facts.\n\n- [[Knowledge Index]]\n- [[Video Tutorial Index]]'),
            ('Research','Video Tutorial Index','Record video URLs, caption source, timestamps, and any unverified claims.\n\n- [[Research Index]]'),
            ('Projects','Project Index','Project goals, checkpoints, code locations, tests, blockers and next actions.\n\n- [[Development Index]]'),
            ('Coding_Lab','Development Index','Experiments, syntax checks, sandbox results, and reproducible fixes.\n\n- [[Project Index]]'),
            ('Reflections','Lessons Learned','Verified lessons, failed attempts, recovery actions, and corrections.\n\n- [[Knowledge Index]]'),
        )
        created=[];preserved=[]
        for category,title,body in sections:
            relative=f'JARVIS_Brain/{category}/{title}.md'
            if self.settings.in_workspace(relative).exists():
                preserved.append(relative)
            else:
                self.note(category,title,body)
                created.append(relative)
        dashboard='JARVIS_Brain/Second Brain Dashboard.md'
        if self.settings.in_workspace(dashboard).exists():preserved.append(dashboard)
        else:
            body="""# JARVIS Second Brain Dashboard

Start here. Use Obsidian backlinks and Canvas for local navigation.

- [[Knowledge Index]] — concepts
- [[Research Index]] — sources
- [[Video Tutorial Index]] — captions
- [[Project Index]] — checkpoints
- [[Development Index]] — programming
- [[Lessons Learned]] — verified fixes

Daily memories: open the Daily folder. Verify untrusted sources.
"""
            self.files.write_text(dashboard,body)
            created.append(dashboard)
        canvas_rel='JARVIS_Brain/Canvas/JARVIS Second Brain.canvas'
        if self.settings.in_workspace(canvas_rel).exists():preserved.append(canvas_rel)
        else:
            self.canvas('JARVIS Second Brain',json.dumps(['JARVIS Brain','[[Knowledge Index]]','[[Research Index]]',
                '[[Video Tutorial Index]]','[[Project Index]]','[[Development Index]]','[[Lessons Learned]]','Daily journal']),
                json.dumps([[0,i] for i in range(1,8)] + [[1,2],[2,3],[4,5],[1,6]]))
            created.append(canvas_rel)
        # Check actual files, not only returned success values.
        for item in created:
            if not self.settings.in_workspace(item).is_file():
                raise PolicyError('Second-brain file did not appear on disk: '+item)
        return {'status':'created_or_verified','vault':result['path'], 'dashboard':dashboard,
                'canvas':canvas_rel,'created':created,'preserved_existing':preserved,
                'next':'Open the vault folder in Obsidian. Continue adding source-linked knowledge; the model can call the usual Obsidian tools.'}

    def daily(self,text):
        self.settings.require('files');self.settings.require_not_stopped()
        if not isinstance(text,str) or not text.strip() or len(text)>8000:
            raise PolicyError('Daily entry must be 1-8000 characters.')
        self.init()
        now=datetime.now().astimezone();filename=f'JARVIS_Brain/Daily/{now:%Y-%m-%d}.md'
        old=''
        if self.settings.in_workspace(filename).exists():old=self.files.read_text(filename)
        addition=f'\n## {now:%H:%M:%S}\n{text.strip()}\n'
        content=(old or f'# JARVIS daily journal — {now:%Y-%m-%d}\n')+addition
        return self.files.write_text(filename,content,overwrite=bool(old))
    def search(self,query:str):
        self.settings.require('files')
        if not isinstance(query,str) or not query.strip() or len(query)>100:
            raise PolicyError('Search requires a short query.')
        root=self.settings.in_workspace('JARVIS_Brain')
        if not root.exists():return []
        words=[w for w in re.split(r'\s+',query.casefold()) if w]
        phrase=query.casefold().strip()
        found=[]
        for file in root.rglob('*.md'):
            rel=str(file.relative_to(self.settings.workspace)).replace('\\','/')
            self.settings.in_workspace(rel)
            if file.stat().st_size>256*1024:continue
            text=file.read_text('utf-8',errors='replace')
            hay=(file.stem+'\n'+text).casefold()
            if not all(w in hay for w in words):continue      # every word somewhere in the note
            score=(10 if phrase in hay else 0)+(5 if phrase in file.stem.casefold() else 0)+sum(hay.count(w) for w in words)
            low=text.casefold()
            if phrase in low:
                at=low.find(phrase)
            else:   # the spot where most of the words appear close together
                spots=[m.start() for w in words for m in re.finditer(re.escape(w),low)][:200]
                at=max(spots,key=lambda pos:(sum(w in low[max(0,pos-150):pos+150] for w in words),-pos),default=0)
            start=max(0,at-120)
            snippet=('…' if start else '')+text[start:start+350].replace('\n',' ')
            found.append({'file':rel,'title':file.stem,'snippet':snippet,'score':score})
        found.sort(key=lambda f:-f['score'])
        return found[:20]
    def canvas(self,title,nodes_json,edges_json='[]',overwrite=False):
        self.settings.require('files');self.settings.require_not_stopped()
        title=self.title_ok(title)
        try:nodes=json.loads(nodes_json);edges=json.loads(edges_json)
        except (ValueError,TypeError) as e:raise PolicyError('Canvas nodes/edges must be valid JSON arrays.') from e
        if isinstance(nodes,list):
            # Small models often send [{"text":"..."}]; accept that shape too.
            nodes=[x.get('text') or x.get('label') if isinstance(x,dict) else x for x in nodes]
        if not isinstance(nodes,list) or not 1<=len(nodes)<=24 or not all(isinstance(x,str) and 1<=len(x)<=140 for x in nodes):
            raise PolicyError('Canvas must contain 1-24 short text nodes, e.g. nodes_json=["Goal","Step 1"] and edges_json=[[0,1]].')
        if not isinstance(edges,list) or len(edges)>80:
            raise PolicyError('Canvas edges must be an array with <=80 pairs.')
        links=[]
        for i,pair in enumerate(edges):
            if not isinstance(pair,list) or len(pair)!=2 or not all(type(x)==int and 0<=x<len(nodes) for x in pair):
                raise PolicyError('Canvas edges must be index pairs, e.g. [[0,1]].')
            a,b=pair
            links.append({'id':f'e{i}','fromNode':f'n{a}','fromSide':'right','toNode':f'n{b}','toSide':'left'})
        payload={'nodes':[{'id':f'n{i}','type':'text','text':text,'x':(i%4)*340,'y':(i//4)*200,
                           'width':300,'height':145} for i,text in enumerate(nodes)],'edges':links}
        self.init()
        rel=f'JARVIS_Brain/Canvas/{title}.canvas'
        self.files.write_text(rel,json.dumps(payload,indent=2,ensure_ascii=False),overwrite)
        return {'canvas':rel,'nodes':len(nodes),'edges':len(links)}
