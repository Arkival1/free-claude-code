"""Background jobs for slow work (downloads, transcription) - v3.2.

A tool starts a job and returns at once with a job id, so LM Studio never times out
waiting. Status lives in small JSON files under data_dir/jobs, so the Workstation app
and the MCP server (separate processes) can both see progress and ask to cancel.
Jobs run only inside the process that started them; a job whose process died is
reported as 'stale' instead of pretending it is still running.
"""
from __future__ import annotations

import json
import os
import secrets
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from .policy import PolicyError

FINISHED = ('done', 'failed', 'cancelled')
STALE_AFTER_SECONDS = 180
MAX_RUNNING = 2


def _now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


class JobCancelled(Exception):
    """Raised inside a job when the owner cancelled it or the STOP file appeared."""


class JobContext:
    """Handed to the job function: report stages, check for cancel/STOP, store data."""

    def __init__(self, jobs: 'Jobs', job_id: str):
        self._jobs = jobs
        self.id = job_id

    def stage(self, name: str, detail: str = '', **extra):
        self.check()
        self._jobs._update(self.id, stage=name, detail=str(detail)[:600], **extra)
        self._jobs._log(self.id, f'{name}: {detail}'[:600])

    def log(self, text: str):
        self._jobs._log(self.id, str(text)[:600])
        self._jobs._update(self.id)

    def set(self, **values):
        self._jobs._update(self.id, **values)

    def check(self):
        if self._jobs.settings.kill_switch_path().exists():
            raise JobCancelled('Owner STOP file exists.')
        if self._jobs._cancel_path(self.id).exists():
            raise JobCancelled('Cancelled by owner.')

    def sleep(self, seconds: float):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self.check()
            time.sleep(min(0.5, max(0.0, end - time.monotonic())))
            self._jobs._update(self.id)  # heartbeat


class Jobs:
    def __init__(self, settings, reporter=None):
        self.settings = settings
        self._lock = threading.Lock()
        self.reporter = reporter      # e.g. FCC's activity panel; told about every change, best effort

    def _report(self, data: dict):
        if self.reporter is not None:
            try:
                self.reporter(dict(data))
            except Exception:  # a progress display must never break a job
                pass

    @property
    def dir(self) -> Path:
        path = self.settings.data_dir / 'jobs'
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _path(self, job_id: str) -> Path:
        if not isinstance(job_id, str) or not job_id.replace('-', '').isalnum() or len(job_id) > 40:
            raise PolicyError('Unknown job id.')
        return self.dir / f'{job_id}.json'

    def _cancel_path(self, job_id: str) -> Path:
        return self.dir / f'{job_id}.cancel'

    def _read(self, job_id: str) -> dict:
        path = self._path(job_id)
        for attempt in range(8):  # Windows: another process may be replacing the file
            try:
                return json.loads(path.read_text(encoding='utf-8'))
            except FileNotFoundError:
                raise PolicyError('Unknown job id.') from None
            except (PermissionError, ValueError):
                if attempt == 7:
                    raise PolicyError('Job file is busy or unreadable; try again.') from None
                time.sleep(0.05)

    def _write(self, data: dict):
        path = self._path(data['id'])
        tmp = path.with_name(f'{path.stem}.{os.getpid()}.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
        for attempt in range(8):
            try:
                os.replace(tmp, path)
                return
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(0.05)

    def _update(self, job_id: str, **values):
        with self._lock:
            data = self._read(job_id)
            data.update(values)
            data['heartbeat'] = time.time()
            data['updated'] = _now()
            self._write(data)
        self._report(data)

    def _log(self, job_id: str, text: str):
        with self._lock:
            data = self._read(job_id)
            log = data.setdefault('log', [])
            log.append(f"{datetime.now().strftime('%H:%M:%S')} {text}")
            data['log'] = log[-60:]
            self._write(data)
        self._report(data)

    def running(self) -> list[dict]:
        return [j for j in self.list(30) if j['status'] in ('running', 'waiting')]

    def start(self, kind: str, title: str, fn, **params) -> dict:
        """Run fn(ctx, **params) in a background thread. fn returns a JSON-able result."""
        self.settings.require_not_stopped()
        if len(self.running()) >= MAX_RUNNING:
            raise PolicyError(f'{MAX_RUNNING} jobs are already running. Wait or cancel one (job_list / job_cancel).')
        job_id = datetime.now().strftime('%Y%m%d-%H%M%S-') + secrets.token_hex(3)
        data = {'id': job_id, 'kind': kind, 'title': str(title)[:200], 'status': 'running',
                'stage': 'starting', 'detail': '', 'params': params, 'result': None, 'error': '',
                'created': _now(), 'updated': _now(), 'heartbeat': time.time(), 'pid': os.getpid(), 'log': []}
        with self._lock:
            self._write(data)
        self._report(data)
        ctx = JobContext(self, job_id)

        def finish(**values):
            try:
                self._update(job_id, **values)
                self._log(job_id, values.get('stage') if values.get('status') == 'done' else
                          f"{values['status'].upper()}: {values.get('error', '')}")
            except (PolicyError, OSError):
                pass  # job file removed (owner cleaned up); nothing left to report to

        def runner():
            try:
                result = fn(ctx, **params)
                finish(status='done', stage='done', result=result, detail='Finished.')
            except JobCancelled as exc:
                finish(status='cancelled', stage='cancelled', error=str(exc))
            except Exception as exc:  # report every failure honestly, never crash the server
                finish(status='failed', error=f'{type(exc).__name__}: {exc}'[:700])

        threading.Thread(target=runner, name=f'jarvis-job-{job_id}', daemon=True).start()
        return self.public(self._read(job_id))

    @staticmethod
    def public(data: dict) -> dict:
        out = {k: data.get(k) for k in ('id', 'kind', 'title', 'status', 'stage', 'detail',
                                       'result', 'error', 'created', 'updated')}
        for key in ('approval', 'progress', 'needs_owner'):
            if key in data:
                out[key] = data[key]
        out['log_tail'] = (data.get('log') or [])[-8:]
        if data.get('status') in ('running', 'waiting') and time.time() - float(data.get('heartbeat') or 0) > STALE_AFTER_SECONDS:
            out['status'] = 'stale'
            out['detail'] = 'No progress for 3 minutes; the program running this job was probably closed. Start it again.'
        return out

    def get(self, job_id: str, wait_seconds: float = 0) -> dict:
        # Small models often send "45" or 120: accept numbers as text and cap at 50 s.
        try:
            wait_seconds = float(wait_seconds or 0)
        except (TypeError, ValueError):
            raise PolicyError('wait_seconds must be a number of seconds (0-50).') from None
        wait_seconds = min(max(wait_seconds, 0.0), 50.0)
        if isinstance(job_id, str):
            job_id = job_id.strip()
        end = time.monotonic() + wait_seconds
        first = self._read(job_id)
        while True:
            data = self._read(job_id)
            changed = (data.get('stage'), data.get('status')) != (first.get('stage'), first.get('status'))
            if data['status'] in FINISHED or changed or time.monotonic() >= end:
                return self.public(data)
            time.sleep(0.5)

    def list(self, limit: int = 10) -> list[dict]:
        files = sorted(self.dir.glob('*.json'), reverse=True)[:max(1, min(int(limit), 50))]
        out = []
        for f in files:
            try:
                out.append(self.public(json.loads(f.read_text(encoding='utf-8'))))
            except (OSError, ValueError):
                continue
        return out

    def cancel(self, job_id: str) -> dict:
        data = self._read(job_id)
        if data['status'] in FINISHED:
            return {'id': job_id, 'status': data['status'], 'note': 'Job already finished.'}
        self._cancel_path(job_id).write_text('cancel', encoding='utf-8')
        return {'id': job_id, 'cancel_requested': True,
                'note': 'The job stops at its next safe point. A transfer already in progress may finish first.'}
