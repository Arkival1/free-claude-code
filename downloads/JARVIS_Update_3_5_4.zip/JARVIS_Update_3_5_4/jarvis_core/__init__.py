"""JARVIS v2 local MCP core. No cloud inference or listener."""
__version__ = '2.0.0'
