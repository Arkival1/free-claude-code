"""Optional evidence-based browser control for PUBLIC transcript/converter websites.

Uses Playwright CDP connected to a dedicated throwaway Opera/Edge user profile.
No arbitrary JS evaluation, hidden account access, or downloads through this bridge.
Requires owner-installed playwright, plus an installed Opera or Edge binary.
This interface is not a download-permission security boundary.
"""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import urlsplit

from .policy import PolicyError
from .youtube import canonical_video

PROVIDERS = {'ytmp3.zone', 'youtubetotranscript.com', 'tactiq.io', 'clipsdk.com'}
CDP_PORT=9341
CDP_URL=f'http://127.0.0.1:{CDP_PORT}'
INPUT_SELECTOR='input:not([type=password]):not([type=file]):not([type=hidden]), textarea, [contenteditable="true"]'
ACTION_SELECTOR='button, input[type=submit], input[type=button], [role=button]'
DENY_LABELS = ('download','install','checkout','payment','purchase','subscribe','save file','get file','buy now','pay now','upload')

def _allowed_url(url):
    parts=urlsplit(url)
    host=(parts.hostname or '').casefold().removeprefix('www.')
    if parts.scheme!='https' or parts.port not in (None,443) or parts.username or parts.password or host not in PROVIDERS:
        raise PolicyError('Browser DOM tools are restricted to explicitly allowed public transcription/converter sites.')
    return host

def _safe_action(label):
    clean=str(label or '').strip().casefold()
    if not clean or any(term in clean for term in DENY_LABELS):
        raise PolicyError('Cannot click ambiguous, download, installation or payment controls. Owner review required.')
    if len(clean)>100:raise PolicyError('Button label too long.')
    return clean

def _browser_executable():
    env=os.environ
    possible=[
        Path(env.get('LOCALAPPDATA','C:/'))/'Programs'/'Opera'/'launcher.exe',
        Path(env.get('LOCALAPPDATA','C:/'))/'Programs'/'Opera'/'opera.exe',
        Path(env.get('LOCALAPPDATA','C:/'))/'Programs'/'Opera GX'/'launcher.exe',
        Path(env.get('PROGRAMFILES','C:/Program Files'))/'Opera'/'launcher.exe',
        Path(env.get('PROGRAMFILES','C:/Program Files'))/'Opera'/'opera.exe',
        Path(env.get('PROGRAMFILES(X86)','C:/Program Files (x86)'))/'Opera'/'launcher.exe',
        Path(env.get('PROGRAMFILES(X86)','C:/Program Files (x86)'))/'Microsoft'/'Edge'/'Application'/'msedge.exe',
        Path(env.get('PROGRAMFILES','C:/Program Files'))/'Microsoft'/'Edge'/'Application'/'msedge.exe',
    ]
    for name in ('opera','msedge'):
        found=shutil.which(name)
        if found:possible.append(Path(found))
    for path in possible:
        if path.is_file():return str(path)
    raise PolicyError('Opera or Microsoft Edge executable not found for automation profile.')

class BrowserDOM:
    def __init__(self,settings):
        self.settings=settings
        self._proc=None
        self._last_inspected=None

    def _perm(self):
        if sys.platform!='win32':raise PolicyError('Browser DOM bridge operates on Windows only.')
        self.settings.require_not_stopped()
        for permission in ('web_research','desktop_control','app_launch'):
            self.settings.require(permission)

    def _playwright(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise PolicyError('Playwright is not installed. Run START_JARVIS.bat and choose Setup/Repair; Playwright is missing in this JARVIS environment.') from exc
        return sync_playwright

    def _context(self):
        self._perm()
        pl=self._playwright()().start()
        try:
            browser=pl.chromium.connect_over_cdp(CDP_URL,timeout=4500)
            if not browser.contexts:raise PolicyError('Automation browser has no active context. Restart the JARVIS Browser DOM window.')
            context=browser.contexts[0]
            # Block Chromium-native downloads in this dedicated profile. This is
            # best effort, not a sandbox or guarantee for arbitrary JS/file writes.
            try:
                pages=context.pages
                if pages:
                    session=context.new_cdp_session(pages[-1])
                    session.send('Browser.setDownloadBehavior',{'behavior':'deny'})
                    session.detach()
            except Exception:pass
            valid=[]
            for page in context.pages:
                try:
                    _allowed_url(page.url)
                    valid.append(page)
                except (PolicyError,ValueError):continue
            if not valid:raise PolicyError('No authorized transcript/converter webpage open in JARVIS automation browser. Use browser_dom_open first.')
            return pl,browser,valid[-1]
        except Exception:
            pl.stop()
            raise

    def open(self,url):
        self._perm()
        _allowed_url(url)
        self._playwright() # Clear missing dependency before launching browser.
        exe=_browser_executable()
        profile=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))/'JARVIS_Clean_v3'/'BrowserAutomation'
        # os.path.expandvars on Windows supports %VAR% (not on Linux).
        profile.mkdir(parents=True,exist_ok=True)
        args=[exe,'--remote-debugging-address=127.0.0.1',f'--remote-debugging-port={CDP_PORT}',
              '--user-data-dir='+str(profile),'--no-first-run','--no-default-browser-check',url]
        try:
            self._proc=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True)
        except OSError as exc:
            raise PolicyError('Could not start dedicated Opera/Edge automation browser: '+str(exc)[:160]) from exc
        self._last_inspected=None
        return {'requested':url,'browser_executable':Path(exe).name,
                'automation_profile':'isolated local-only profile, not your normal logged-in Opera session',
                'next':'Wait for page, then call browser_dom_inspect to get actual input/button labels. Do not guess screen coordinates.',
                'downloads':'Browser DOM bridge does not download files; download approval remains separate.'}

    def inspect(self):
        pl,browser,page=self._context()
        try:
            _allowed_url(page.url)
            fields=[]
            loc=page.locator(INPUT_SELECTOR)
            for i in range(min(loc.count(),40)):
                item=loc.nth(i)
                if not item.is_visible():continue
                label=item.get_attribute('aria-label') or item.get_attribute('placeholder') or item.get_attribute('title') or ''
                typ=item.get_attribute('type') or 'text'
                if typ.casefold() in ('password','file','email','tel','number'):
                    continue
                fields.append({'index':i,'label':str(label)[:100],'type':str(typ)[:30],'tag':item.evaluate('(e) => e.tagName.toLowerCase()')})
            actions=[]
            buttons=page.locator(ACTION_SELECTOR)
            for i in range(min(buttons.count(),60)):
                item=buttons.nth(i)
                if not item.is_visible():continue
                label=(item.inner_text(timeout=1000) or item.get_attribute('aria-label') or item.get_attribute('value') or '').strip()
                if label:
                    actions.append({'index':i,'label':label[:100],'requires_owner_review':any(term in label.casefold() for term in DENY_LABELS)})
            self._last_inspected={'url':page.url,'fields':fields,'actions':actions,'at':time.monotonic()}
            return {'url':page.url,'fields':fields,'actions':actions,
                    'verification':'These are actual DOM elements, not inferred screenshot positions.',
                    'next':'Fill a confirmed input with browser_dom_fill_youtube, then inspect again. Stop if no matching input.'}
        finally:
            browser.close();pl.stop()

    def fill_youtube(self,index,url):
        self._perm()
        canonical,vid=canonical_video(url)
        if type(index) is not int:raise PolicyError('Field index must be an integer returned by browser_dom_inspect.')
        if not self._last_inspected or time.monotonic()-self._last_inspected['at']>90:
            raise PolicyError('No recent browser DOM inspection. Call browser_dom_inspect first.')
        pl,browser,page=self._context()
        try:
            if page.url!=self._last_inspected['url']:
                raise PolicyError('Page changed since inspection. Inspect again.')
            matching=[f for f in self._last_inspected['fields'] if f['index']==index]
            if not matching:raise PolicyError('Field index was not an inspected, visible safe text field.')
            locator=page.locator(INPUT_SELECTOR).nth(index)
            if not locator.is_visible():raise PolicyError('Input field is no longer visible. Inspect again.')
            locator.fill(canonical,timeout=5000)
            actual=locator.input_value(timeout=4000)
            if actual!=canonical:raise PolicyError('YouTube URL NOT verified in field; stop and inspect again.')
            return {'ok':True,'field_index':index,'field_label':matching[0]['label'],
                    'verified_text':canonical,'page':page.url,
                    'next':'Input VERIFIED. Inspect page for Convert button; never click Download without owner approval.'}
        finally:
            browser.close();pl.stop()

    def click_action(self,index):
        self._perm()
        if type(index) is not int:raise PolicyError('Action index must be an integer returned by browser_dom_inspect.')
        snap=self._last_inspected
        if not snap or time.monotonic()-snap['at']>90:raise PolicyError('Inspect the page again before clicking.')
        pl,browser,page=self._context()
        try:
            if page.url!=snap['url']:raise PolicyError('Page navigated; inspect again.')
            matches=[a for a in snap['actions'] if a['index']==index]
            if not matches:raise PolicyError('Button index not found in prior DOM inspection.')
            action=matches[0]
            _safe_action(action['label'])
            if _allowed_url(page.url)=='ytmp3.zone':
                raise PolicyError('This converter can start downloads from its buttons. JARVIS DOM bridge does not click converter buttons; request owner-approved audio via youtube_audio_download_request instead.')
            item=page.locator(ACTION_SELECTOR).nth(index)
            if not item.is_visible() or not item.is_enabled():raise PolicyError('Button no longer enabled/visible. Inspect again.')
            item.click(timeout=5000,no_wait_after=True)
            self._last_inspected=None
            return {'clicked_label':action['label'],'action_sent':True,'verified_result':False,
                    'next':'Call browser_dom_inspect to verify page contents changed. Clicking Convert may not select format or produce an audio file.',
                    'download':'Never click download through browser; use owner-approved download tool.'}
        finally:
            browser.close();pl.stop()

    def read_page(self):
        pl,browser,page=self._context()
        try:
            _allowed_url(page.url)
            text=page.locator('body').inner_text(timeout=6000)
            links=[]
            for loc in page.locator('a[href]').all()[:50]:
                try:
                    href=loc.get_attribute('href') or ''
                    label=(loc.inner_text(timeout=800) or '')[:100]
                    if label and href.startswith('https://'):
                        links.append({'label':label,'url':href[:400]})
                except Exception:continue
            return {'url':page.url,'visible_text':text[:9000],
                    'links':links[:25],'truncated':len(text)>9000,
                    'status':'Read from live DOM, not an invented interpretation of a screenshot.'}
        finally:
            browser.close();pl.stop()

# Playwright raises its own exception types. Translate these to bounded errors so
# Qwen receives an actionable tool result instead of a missing-tool illusion.
from functools import wraps

def _tool_safe(method):
    @wraps(method)
    def wrapper(self,*args,**kwargs):
        try:return method(self,*args,**kwargs)
        except (PolicyError,OSError,ValueError,RuntimeError):raise
        except Exception as exc:
            raise PolicyError('Browser DOM automation failed ('+type(exc).__name__+'). The site may block browser automation, the CDP browser may be closed, or the page changed. Stop guessing; inspect and verify.') from exc
    return wrapper

for _name in ('open','inspect','fill_youtube','click_action','read_page'):
    setattr(BrowserDOM,_name,_tool_safe(getattr(BrowserDOM,_name)))
