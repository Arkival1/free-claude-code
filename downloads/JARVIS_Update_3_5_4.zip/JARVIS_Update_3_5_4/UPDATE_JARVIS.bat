@echo off
setlocal
cd /d "%~dp0"
title JARVIS UPDATE
where py >nul 2>nul
if not errorlevel 1 (
    py -3 update_jarvis.py %*
    goto :done
)
where python >nul 2>nul
if not errorlevel 1 (
    python update_jarvis.py %*
    goto :done
)
echo ERROR: Python 3.11 or newer was not found. Install it from https://www.python.org/downloads/windows/
:done
echo.
pause
