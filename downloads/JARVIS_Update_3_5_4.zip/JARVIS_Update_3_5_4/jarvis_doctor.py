"""Owner-run no-download doctor for local tool calling and YouTube dependencies.

No install, no subprocess commands, no media download. The test sends one
read-only *proposed* function call to the local LM Studio server. It does not
actually execute that suggested function.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

ROOT=Path(__file__).resolve().parent

def check(base=ROOT):
    print('\n=== JARVIS TOOL & TRANSCRIPTION DIAGNOSTIC ===\n')
    cfg_path=base/'config.json'
    if not cfg_path.exists():
        print('FAIL: config.json missing in installation folder');return 2
    cfg=json.loads(cfg_path.read_text('utf-8'))
    permissions=cfg.get('permissions',{})
    print('Config permissions:',', '.join(f'{k}={v}' for k,v in sorted(permissions.items())))
    print('Broad Mode:',cfg.get('desktop_mode'))
    for dependency in ('mcp','yt_dlp','faster_whisper'):
        found=importlib.util.find_spec(dependency) is not None
        print(f'{dependency}:', 'installed' if found else 'MISSING')
    print('FFmpeg executable:',shutil.which('ffmpeg') or 'MISSING (needed only for local video frames)')
    try:
        # expand Windows variable paths for a local diagnostic only
        from jarvis_core.policy import Settings
        conf=Settings(cfg_path)
        model_dir=conf.data_dir/'models'/'faster-whisper-base'
        model_files=['model.bin','config.json','tokenizer.json']
        missing=[f for f in model_files if not (model_dir/f).is_file()]
        print('Offline speech model:',str(model_dir))
        print('Speech model files:', 'available' if not missing else 'MISSING '+', '.join(missing))
    except Exception as exc:
        print('Speech model path check failed:',type(exc).__name__,str(exc)[:160])
    url='http://127.0.0.1:1234/v1/models'
    try:
        with urlopen(Request(url,headers={'Accept':'application/json'}),timeout=5) as res:
            models=json.load(res).get('data',[])
        ids=[x.get('id','') for x in models if isinstance(x,dict) and x.get('id')]
        if not ids:
            print('LM Studio server reachable, but no model IDs were returned.')
            return 1
        print('LM Studio server: CONNECTED')
        print('Available model IDs:',', '.join(ids[:5]))
    except (URLError, HTTPError, ValueError,TimeoutError) as exc:
        print('LM Studio server: NOT REACHABLE:',str(exc)[:180])
        print('Start LM Studio Local Server on port 1234 and load a model.')
        return 1
    # Deliberately ask the model for one read-only sample tool call.
    payload={
        'model':ids[0],
        'messages':[{'role':'system','content':'Use the provided function to answer. Do not write a chat answer.'},
                    {'role':'user','content':'Call the skills_list function with query "obsidian".'}],
        'tools':[{'type':'function','function':{'name':'skills_list',
                'description':'List a local skill by keyword',
                'parameters':{'type':'object','properties':{'query':{'type':'string'}},
                              'required':['query'],'additionalProperties':False}}}],
        'tool_choice':'required','max_tokens':220,'temperature':0
    }
    try:
        request=Request('http://127.0.0.1:1234/v1/chat/completions',
            data=json.dumps(payload).encode('utf8'),
            headers={'Content-Type':'application/json'},method='POST')
        with urlopen(request,timeout=70) as res:
            body=json.load(res)
        msg=body['choices'][0]['message']
        calls=msg.get('tool_calls') or []
        if calls and calls[0].get('function',{}).get('name')=='skills_list':
            print('Local model tool-call format: PASS (suggested skills_list, NOT executed)')
        else:
            print('Local model tool-call format: FAIL (the model answered without a tool call)')
            print('Response excerpt:',str(msg.get('content') or '')[:200])
    except HTTPError as exc:
        detail=exc.read(1500).decode('utf8','replace')
        print('Tool-call test rejected by LM Studio:',exc.code,detail[:300])
        print('If tool_choice=required unsupported, update LM Studio. Try a tool-capable model.')
    except (URLError,TimeoutError,KeyError,IndexError,ValueError) as exc:
        print('Tool-call test failed:',str(exc)[:240])
    print('\nReminder: ordinary LM Studio chat can still choose prose rather than MCP tools.')
    print('Use START_JARVIS.bat option 6 for a full agent task. No files or downloads were modified by this doctor.')
    return 0

if __name__=='__main__':
    try:sys.exit(check())
    except KeyboardInterrupt:print('Cancelled by owner.');sys.exit(130)
