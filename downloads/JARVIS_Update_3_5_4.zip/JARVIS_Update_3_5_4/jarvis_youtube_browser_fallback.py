"""Owner-launchable fallback wizard that needs no LM Studio tool-calling reliability.

Windows CLI -> visible external transcript website -> owner/agent clicks Copy ->
clipboard text safely saved into bounded local JARVIS brain. No file downloads.
"""
from pathlib import Path
import sys
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.files import FileTools
from jarvis_core.network import WebTools
from jarvis_core.transcript_fallback import TranscriptFallback


def run(input_fn=input, output_fn=print, instance=None):
    if instance is None:
        config=Path(__file__).resolve().parent/'config.json'
        settings=Settings(config)
        instance=TranscriptFallback(settings,WebTools(settings),FileTools(settings))
    output_fn('=== JARVIS YOUTUBE TRANSCRIPT BROWSER FALLBACK ===')
    output_fn('Only submit PUBLIC YouTube URLs. External websites may process video links/audio.')
    url=input_fn('Paste public YouTube video link: ').strip()
    provider=input_fn('Provider [companion / tactiq / audio_cloud] (Enter=companion): ').strip() or 'companion'
    try:
        result=instance.open_website(url,provider)
        output_fn('Website opened: '+result['website'])
        output_fn('Video URL copied to Windows clipboard: '+str(result['youtube_url_on_clipboard']))
        output_fn('Paste URL into site form, generate transcript, choose COPY transcript text (NOT Download).')
        output_fn('Do not paste private links. For cloud audio mode, site processes audio on its servers.')
        confirmation=input_fn('After clicking COPY TRANSCRIPT in browser, type IMPORT and Enter (otherwise quit): ').strip()
        if confirmation!='IMPORT':
            output_fn('Cancelled. No transcript imported.')
            return False
        saved=instance.import_clipboard(url,provider)
        if not saved.get('saved'):
            output_fn('Existing saved transcript was left intact: '+saved['file'])
            return False
        output_fn('Transcript imported into local JARVIS workspace: '+saved['file'])
        output_fn('JARVIS may now read it with youtube_transcript_section.')
        return True
    except (PolicyError,OSError,ValueError) as exc:
        output_fn('Cannot complete browser fallback: '+str(exc))
        return False

if __name__=='__main__':
    try:sys.exit(0 if run() else 1)
    except KeyboardInterrupt:print('Cancelled by owner.');sys.exit(1)
