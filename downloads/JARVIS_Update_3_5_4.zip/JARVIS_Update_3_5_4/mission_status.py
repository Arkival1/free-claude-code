"""Read the current local mission checkpoint without executing model or tools."""
from pathlib import Path
from jarvis_core.policy import Settings
from jarvis_core.mission import MissionStore
import json

if __name__ == '__main__':
    settings=Settings(Path(__file__).resolve().parent/'config.json')
    try:
        state=MissionStore(settings).load()
    except ValueError as err:
        print('No resumable mission:',err)
    else:
        print(json.dumps({k:state.get(k) for k in ('goal','model','turns','status','reason','updated')},indent=2,ensure_ascii=False))
