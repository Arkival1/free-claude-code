@echo off
setlocal
cd /d "%~dp0"
title JARVIS CLEAN v3.4
where py >nul 2>nul
if not errorlevel 1 (
    py -3 jarvis_setup.py
    goto :done
)
where python >nul 2>nul
if not errorlevel 1 (
    python jarvis_setup.py
    goto :done
)
echo ERROR: Python 3.11 or newer was not detected.
echo Install Python from https://www.python.org/downloads/windows/
echo then run START_JARVIS.bat again.
:done
echo.
if errorlevel 1 echo JARVIS ended with an error.
pause
