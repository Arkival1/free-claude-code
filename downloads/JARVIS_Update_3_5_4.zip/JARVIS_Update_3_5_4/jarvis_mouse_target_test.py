"""Owner-run visual calibration test; opens a local Tkinter window, no downloads.

Use JARVIS's desktop_screenshot_guided and desktop_click_image, verify that
this app advances through three targets. The test does not move the cursor.
"""
from __future__ import annotations
import sys
import tkinter as tk

if sys.platform == 'win32':
    import ctypes
    if ctypes.windll.shell32.IsUserAnAdmin():
        raise SystemExit('Run this test as a normal Windows user, not Administrator.')

root=tk.Tk()
root.title('JARVIS Mouse Coordination Test — Local only')
root.geometry('850x580')
root.configure(bg='#171a25')
root.resizable(False,False)
# No topmost, allows normal focus and Windows window activation tools.
progress=tk.StringVar(value='Step 1 of 3')
message=tk.StringVar(value='Ask JARVIS to take a guided screenshot and click the highlighted target.')
targets=[(70,100),(350,230),(630,370)]
regions=[]

def step(i):
    if i==len(targets):
        progress.set('PASS — all three targets clicked correctly')
        message.set('Mouse coordinate mapping worked on the three visible targets.')
        for btn in regions:btn.destroy()
        return
    progress.set(f'Step {i+1} of {len(targets)}')
    message.set('Click ONLY the highlighted green target, then take another screenshot.')
    for btn in regions:btn.destroy()
    regions.clear()
    x,y=targets[i]
    btn=tk.Button(root,text=f'CLICK TARGET {i+1}',bg='#1fbb83',fg='#071c17',
                  activebackground='#9bfbc3',font=('Segoe UI',16,'bold'),bd=0,
                  command=lambda:step(i+1))
    btn.place(x=x,y=y,width=180,height=64)
    regions.append(btn)

header=tk.Label(root,text='JARVIS · MOUSE COORDINATION TEST',bg='#171a25',fg='#ecf0ff',font=('Segoe UI',19,'bold'))
header.pack(pady=(15,5))
tk.Label(root,textvariable=progress,bg='#171a25',fg='#91b4ff',font=('Segoe UI',15,'bold')).pack(pady=5)
tk.Label(root,textvariable=message,bg='#171a25',fg='#f0f0f5',font=('Segoe UI',11),wraplength=760).pack(pady=6)
tk.Label(root,text='No admin access or internet required. Close this window when done.',bg='#171a25',fg='#b0adbd',font=('Segoe UI',10)).place(x=150,y=520)
step(0)
root.mainloop()
