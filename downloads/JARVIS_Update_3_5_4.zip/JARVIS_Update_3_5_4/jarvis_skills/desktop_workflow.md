# Screenshot-aware mouse workflow — v2.8.7

For an approved, ordinary Windows application:
1. Identify/activate the correct window using `desktop_list_windows` + `desktop_activate_window`.
2. Capture `desktop_screenshot_guided`. Read `desktop_screen_info` to obtain JPEG image geometry.
3. Identify the actual intended control from the IMAGE itself (not generic UI guesses).
4. If optional Windows UIA is installed and control has an unambiguous visible label, use `desktop_click_named(name="Exact visible button")`.
5. Otherwise use `desktop_click_image(x,y)` where x/y are PIXELS OF THE JPEG screenshot, NOT your Windows desktop's full-resolution coordinates. `desktop_move_image` and `desktop_drag_image` work similarly.
6. Always obtain a NEW screenshot after clicks/drags and compare the real UI state. The input tool says only that it sent inputs.
7. If the target cannot be confidently identified, do not randomly click. Ask for a clearer screenshot, UIA labels or report a blocker. The screenshot must be recent (120s maximum) and the window focus unchanged.
8. Never click Download, Install, or Pay to bypass the human's approval requirement. Never attempt protected apps/admin prompts. Owner emergency stop takes precedence.

# Desktop App Operation — Open Real Apps
When you work on an Obsidian brain/wiki task, call `desktop_open_obsidian(view="dashboard")` (or `canvas`) so the owner sees the actual desktop app. Obsidian URI links require an installed/registered Obsidian and a vault added once from its Open folder as vault screen. Creating Markdown files alone does not prove the GUI is open.
For coding tasks, launch `desktop_launch_app(app_name="vscode")` if installed. Chrome/Edge/Firefox may be launched by alias, but never click downloads without owner review. Use desktop_list_windows, desktop_activate_window, desktop_ui_controls and screenshots to verify real UI state. Non-admin only. If an app is absent, keep working in approved workspace and report the missing app rather than pretending success.

## Precision mouse actions (v2.8.7)
1. `desktop_screenshot_guided` + `desktop_screen_info` to see image geometry.
2. `desktop_screenshot_zoom` to inspect small controls; it changes the last screenshot coordinate origin.
3. `desktop_click_box_image(left,top,right,bottom)` for a measured button rectangle (clicks center).
4. `desktop_hover_image(x,y)` to show tooltips; capture fresh screenshot before deciding.
5. `desktop_scroll_image(x,y,clicks)` to scroll only the target pane.
6. `desktop_drag_path_image(points)` for slow precise Canvas/slider/selection movements.
7. `desktop_pointer_info` for feedback.
8. After click/scroll/drag/hover, ALWAYS take a new screenshot; the action result is NOT proof a button worked.
Do not click guessed coordinates. Do not try multi-monitor coordinates with primary-screen-only screenshot tools.
