# Coding and Project Development
For a site, browser game, Python program, or Godot game: create a project scaffold, inspect existing files, make incremental edits and run project_check. Use local preview for HTML projects. Execute generated Python only in the approved offline Docker lab; do not run unknown programs on the host. Record results and errors in a task list and note.
