# Obsidian second brain — v3.4
JARVIS's notes live in the vault `JARVIS_Brain` (Markdown files the owner opens in Obsidian).

**Before writing**
1. `obsidian_memory_search` first (every word must appear; best matches first). If a note on the topic exists, read it with `workspace_read` and ADD to it instead of making a duplicate.
2. Pick the folder: Knowledge (facts), Research (sources, videos), Projects, Coding_Lab, Reflections (lessons), Daily (journal) — or a folder that already exists in the owner's vault, e.g. `06 Research`. Never invent new top-level folders.

**Writing a good note** (`obsidian_note`)
- Title: short and specific ("Godot tilemap collisions", not "Notes").
- Body: what was learned, where it came from (link, video, file, date), what is verified vs. still a guess.
- `links`: a LIST of related note titles, e.g. ["Research Index", "Godot"]. They become [[wikilinks]]. Prefer titles that already exist (search for them).
- Never overwrite (overwrite=true) unless the owner asked; overwrites are backed up in `_backups`.

**Journal and memory**
- `obsidian_daily_memory`: one paragraph per finished piece of work: what was done, results, files, errors, next step.
- `chat_memory_save`: owner preferences and important facts from conversations (no passwords or private numbers).
- `obsidian_canvas`: mind maps; nodes_json is a list of short texts, edges_json pairs like [[0,1]].

**Showing it**
- `desktop_open_obsidian(note="Title")` opens that note in the Obsidian app; it reports whether the window appeared.
- To check what Obsidian shows: `desktop_focus_app("Obsidian")`, `desktop_ui_controls`, `desktop_read_text`.

**Check your work**: read the saved note back (`workspace_read`) before saying it is saved.
