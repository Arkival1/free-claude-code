# Research and Verification
When unfamiliar, start with research_search. Prefer official docs, source-linked information, and distinguish tentative leads from independently read pages. Use website_read for source details. Save verified results to Obsidian with references and create follow-up tasks. Never include private files, secrets or personal details in web queries.
