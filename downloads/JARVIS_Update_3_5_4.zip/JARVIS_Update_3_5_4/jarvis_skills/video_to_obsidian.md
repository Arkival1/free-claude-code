# YouTube video to Obsidian notes — v3.2 (USE THIS FIRST)
For any request like "get notes / a transcript / a summary from this YouTube link":

1. Call `video_to_notes(url)` ONCE. It does every step in tested code: gets the audio (ytmp3.zone website in the JARVIS browser, or direct from YouTube), waits for the OWNER's approval, downloads and checks the file, transcribes locally (OpenWhispr or built-in Whisper), saves the full transcript and study notes in `JARVIS_Brain/Research/YouTube`, and writes a daily-journal line.
2. Call `job_status(job_id, wait_seconds=45)` again and again until `status` is `done` or `failed`.
3. If `status` is `waiting`, tell the owner exactly what `needs_owner` says. Usually: "Approve the download in JARVIS Workstation". Or: "Click the website's human check in the JARVIS browser window". Then keep calling `job_status`. Never try to approve or solve it yourself.
4. When `done`: report `title`, `transcript_engine`, `transcript_files`, `notes_file`. Read the notes with `workspace_read` if the owner wants a summary in chat.
5. When `failed`: report the exact `error`. Do not retry more than once with the same settings. `source="direct"` or `engine="whisper"` are the alternatives.

Do NOT use browser_dom_*, desktop mouse tools, youtube_audio_download or transcript websites for this job: `video_to_notes` already does them safely and checks each result.
