"""Owner-operated GUI for JARVIS MCP permissions. Not exposed as an MCP tool.

Uses only tkinter and the Python standard library. Never runs downloads or apps.
"""
from __future__ import annotations
import json
import os
import re
import webbrowser
from urllib.parse import urlsplit
from jarvis_core.policy import Settings
from jarvis_core.download_approvals import DownloadApprovals
import tempfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
STOP = BASE / "STOP_JARVIS.txt"
APPROVALS = DownloadApprovals(Settings(CONFIG))

PERMISSIONS = [
    ("files", "Workspace file read/write"),
    ("notes_and_tasks", "Local notes and tasks"),
    ("web_research", "Web research (internet)"),
    ("screen", "Windows screenshots (potentially sensitive)"),
    ("desktop_control", "Mouse and keyboard (desktop mode controls eligible apps)"),
    ("app_launch", "Launch installed desktop applications"),
    ("downloads", "Download requests (every exact link needs your approval)"),
    ("coding_lab", "Coding Lab Python runner (requires preinstalled Docker image)"),
    ("preview_local", "Allow localhost browser preview of JARVIS-generated HTML/JS (review first)"),
]


def load_config():
    with CONFIG.open('r', encoding='utf-8') as f:
        return json.load(f)


def atomic_config_write(data):
    """Write a validated JSON config atomically to prevent partial reloads."""
    if not isinstance(data, dict) or not isinstance(data.get('permissions'), dict):
        raise ValueError('Invalid config format.')
    fd, name = tempfile.mkstemp(prefix='.jarvis-config-', suffix='.tmp', dir=BASE)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, indent=2, ensure_ascii=False)
            out.write('\n')
        os.replace(name, CONFIG)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class Panel(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('JARVIS Local MCP v2.6 — Owner Control Panel')
        self.geometry('850x760')
        self.minsize(640, 560)
        self.data = load_config()
        self.flags = {}
        self._build()
        self.refresh()

    def _build(self):
        outer = ttk.Frame(self, padding=16)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='JARVIS · Local MCP Control Panel', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        ttk.Label(outer, text='Settings are stored locally. No cloud API. Keep LM Studio tool confirmations ON.', wraplength=730).pack(anchor='w', pady=(3, 10))
        self.status = ttk.Label(outer, text='')
        self.status.pack(anchor='w', pady=(0, 8))
        buttons = ttk.Frame(outer)
        buttons.pack(fill='x', pady=(0, 10))
        ttk.Button(buttons, text='EMERGENCY STOP', command=self.stop).pack(side='left', padx=(0, 8))
        ttk.Button(buttons, text='Resume tools', command=self.resume).pack(side='left', padx=(0, 8))
        ttk.Button(buttons, text='Reload settings', command=self.refresh).pack(side='left')
        tabs = ttk.Notebook(outer)
        tabs.pack(fill='both', expand=True)
        permissions = ttk.Frame(tabs, padding=12)
        tabs.add(permissions, text='Permissions')
        for key, label in PERMISSIONS:
            flag = tk.BooleanVar()
            self.flags[key] = flag
            ttk.Checkbutton(permissions, text=label, variable=flag).pack(anchor='w', pady=4)
        self.broad_mode=tk.BooleanVar()
        ttk.Separator(permissions,orient='horizontal').pack(fill='x',pady=10)
        ttk.Checkbutton(permissions,text='Broad mode: interact with non-admin apps + launch Windows-registered apps (RISKY)',variable=self.broad_mode).pack(anchor='w',pady=4)
        ttk.Label(permissions, text='Broad mode is enabled by default on v2.8.3 installs and upgrades; the owner may turn it off. It blocks some system/credential executables, but GUI access is NOT a security sandbox. Never leave JARVIS unattended with browser accounts or private documents open.', wraplength=690).pack(anchor='w', pady=(8, 6))
        ttk.Button(permissions, text='Save permission settings', command=self.save_flags).pack(anchor='w', pady=8)
        apps = ttk.Frame(tabs, padding=12)
        tabs.add(apps, text='Approved Apps')
        ttk.Label(apps, text='These are manually registered apps. In Broad Mode JARVIS can also discover and launch Windows App Paths registered applications without adding them here.', wraplength=680).pack(anchor='w')
        self.app_list = tk.Listbox(apps, height=10)
        self.app_list.pack(fill='both', expand=True, pady=(8, 4))
        fr = ttk.Frame(apps)
        fr.pack(fill='x')
        ttk.Button(fr, text='Add installed .exe', command=self.add_app).pack(side='left', padx=(0, 8))
        ttk.Button(fr, text='Remove selected app', command=self.remove_app).pack(side='left')
        ttk.Label(apps, text='Only select programs you trust. Do NOT approve terminal/PowerShell/admin tools for initial testing.', wraplength=680).pack(anchor='w', pady=9)
        web = ttk.Frame(tabs, padding=12)
        tabs.add(web, text='Download Domains')
        ttk.Label(web, text='Every download needs separate approval of its EXACT URL in Download Requests. The domains below are additional TRUSTED REDIRECT hosts (CDNs). Do not enter unknown hosts.', wraplength=680).pack(anchor='w')
        self.domain_list = tk.Listbox(web, height=11)
        self.domain_list.pack(fill='both', expand=True, pady=(8, 4))
        fb = ttk.Frame(web)
        fb.pack(fill='x')
        ttk.Button(fb, text='Add publisher domain', command=self.add_domain).pack(side='left', padx=(0,8))
        ttk.Button(fb, text='Remove selected domain', command=self.remove_domain).pack(side='left')
        downloads=ttk.Frame(tabs,padding=12)
        tabs.add(downloads,text='Download Requests')
        ttk.Label(downloads,text='JARVIS cannot download until YOU approve each exact URL and filename. Approval expires after 24 hours and is single use.',wraplength=700).pack(anchor='w')
        self.req_list=tk.Listbox(downloads,height=9,exportselection=False)
        self.req_list.pack(fill='both',expand=True,pady=(8,4))
        self.req_list.bind('<<ListboxSelect>>',self.request_selected)
        self.request_detail=tk.Text(downloads,height=5,wrap='word')
        self.request_detail.pack(fill='x',pady=6)
        self.request_detail.configure(state='disabled')
        df=ttk.Frame(downloads);df.pack(fill='x')
        ttk.Button(df,text='Refresh requests',command=self.refresh_requests).pack(side='left',padx=(0,8))
        ttk.Button(df,text='Open link in browser',command=self.open_request_url).pack(side='left',padx=(0,8))
        ttk.Button(df,text='APPROVE selected',command=lambda:self.decide_request(True)).pack(side='left',padx=(0,8))
        ttk.Button(df,text='DENY selected',command=lambda:self.decide_request(False)).pack(side='left')
        storage = ttk.Frame(tabs, padding=12)
        tabs.add(storage, text='Local Paths')
        self.paths = tk.Text(storage, height=11, wrap='word')
        self.paths.pack(fill='both', expand=True)
        self.paths.configure(state='disabled')
        ttk.Button(storage, text='Open MCP installation folder', command=lambda: os.startfile(BASE)).pack(anchor='w', pady=8)
        ttk.Button(storage, text='Open JARVIS workspace', command=self.open_workspace).pack(anchor='w')
        ttk.Label(outer, text='Note: Changes are used on the next tool call. Tool availability may require reconnecting the MCP in LM Studio.', wraplength=740).pack(anchor='w', pady=(12, 0))

    def refresh(self):
        try:
            self.data = load_config()
            self.broad_mode.set(self.data.get('desktop_mode','approved_apps')=='all_user_apps')
            self.refresh_requests()
            for key, flag in self.flags.items(): flag.set(bool(self.data.get('permissions',{}).get(key,False)))
            self.app_list.delete(0,'end')
            for name, app in sorted(self.data.get('apps',{}).items()):
                exe = Path(str(app.get('path',''))).name.lower()
                mark = ' [enabled]' if exe in [s.lower() for s in self.data.get('approved_desktop_exes',[])] else ' [not approved]'
                self.app_list.insert('end', f'{name} | {exe} | {app.get("path","")}{mark}')
            self.domain_list.delete(0,'end')
            for domain in sorted(self.data.get('approved_download_domains',[])): self.domain_list.insert('end',domain)
            txt = f'MCP server: {BASE}\nConfiguration: {CONFIG}\nWorkspace: {os.path.expandvars(self.data["workspace"])}\nLocal notes/tasks: {os.path.expandvars(self.data["data_dir"])}\nLM Studio configuration: {BASE / "LM_STUDIO_SNIPPET.json"}\n\nNo internet listener is created by this MCP server.'
            self.paths.configure(state='normal')
            self.paths.delete('1.0','end')
            self.paths.insert('1.0',txt)
            self.paths.configure(state='disabled')
            self.status.configure(text='Status: PAUSED (STOP file exists)' if STOP.exists() else 'Status: available (tool permissions still apply)')
        except Exception as exc:
            messagebox.showerror('Could not load settings',str(exc))

    def save_flags(self):
        if self.broad_mode.get():
            if not messagebox.askyesno('BROAD WINDOWS CONTROL — RISK',
               'The AI can interact with most visible non-admin applications and launch Windows App Paths registered apps without adding each one.\n\nBrowser clicks can bypass download approval. This is NOT a sandbox. Close sensitive apps, use a non-admin account and keep emergency STOP ready.\n\nEnable broad mode?'):
                return
        if self.flags['desktop_control'].get() or self.flags['downloads'].get():
            if not messagebox.askyesno('Sensitive permission', 'Enable the selected powerful tool permissions?\n\nKeep LM Studio tool approvals ON. Do not run JARVIS as administrator.'):
                return
        try:
            data=load_config()
            for key, flag in self.flags.items(): data['permissions'][key] = bool(flag.get())
            data['desktop_mode']='all_user_apps' if self.broad_mode.get() else 'approved_apps'
            atomic_config_write(data)
            self.refresh()
            messagebox.showinfo('Saved','Permissions updated locally.')
        except Exception as exc: messagebox.showerror('Save failed',str(exc))

    def stop(self):
        STOP.touch(exist_ok=True)
        self.refresh()
        messagebox.showinfo('Emergency stop','Future write/control/download calls will be blocked. For immediate termination also disconnect MCP in LM Studio.')

    def resume(self):
        if messagebox.askyesno('Resume JARVIS','Remove the emergency STOP file?'):
            STOP.unlink(missing_ok=True)
            self.refresh()

    def add_app(self):
        path = filedialog.askopenfilename(title='Choose trusted installed application', filetypes=[('Windows programs','*.exe')])
        if not path: return
        p=Path(path)
        if p.suffix.lower() != '.exe' or not p.is_file():
            messagebox.showerror('Invalid application','Select an existing .exe file.')
            return
        if p.name.lower() in ('cmd.exe','powershell.exe','pwsh.exe','wscript.exe','cscript.exe','mshta.exe'):
            messagebox.showwarning('Powerful program blocked','Do not approve general shells or script hosts in this initial control panel.')
            return
        name = simpledialog.askstring('Short application name',f'Enter a short name for {p.name} (e.g. vscode):',parent=self)
        if name is None: return
        name=name.strip().lower()
        if not re.fullmatch('[a-z][a-z0-9_-]{0,35}', name):
            messagebox.showerror('Invalid name','Use letters, numbers, underscores and hyphens; start with a letter.')
            return
        if not messagebox.askyesno('Approve app',f'Allow JARVIS to launch and interact with {p}?\n\nThis can affect documents open in that program.'):
            return
        try:
            data=load_config()
            data.setdefault('apps',{})[name]={'path':str(p),'args':[]}
            allowed={e.lower() for e in data.setdefault('approved_desktop_exes',[])}
            allowed.add(p.name.lower())
            data['approved_desktop_exes']=sorted(allowed)
            atomic_config_write(data)
            self.refresh()
        except Exception as exc: messagebox.showerror('Save failed',str(exc))

    def remove_app(self):
        selected=self.app_list.curselection()
        if not selected: return
        key=self.app_list.get(selected[0]).split(' | ',1)[0]
        if not messagebox.askyesno('Remove app',f'Remove approval for {key}?'):
            return
        try:
            data=load_config()
            data['apps'].pop(key,None)
            exes={Path(str(app.get('path',''))).name.lower() for app in data['apps'].values()}
            data['approved_desktop_exes']=[e for e in data.get('approved_desktop_exes',[]) if e.lower() in exes]
            atomic_config_write(data)
            self.refresh()
        except Exception as exc: messagebox.showerror('Save failed',str(exc))

    def add_domain(self):
        domain=simpledialog.askstring('Publisher domain','Enter verified publisher domain only (example: godotengine.org):',parent=self)
        if domain is None: return
        domain=domain.strip().lower().strip('.')
        if not re.fullmatch(r'[a-z0-9-]+(?:\.[a-z0-9-]+)+',domain):
            messagebox.showerror('Invalid domain','Enter a domain without protocol or paths.')
            return
        if not messagebox.askyesno('Approve domain',f'Allow downloading files from {domain} and its subdomains?\nConfirm this is the real publisher.'):
            return
        try:
            data=load_config()
            data['approved_download_domains']=sorted(set(data.get('approved_download_domains',[]))|{domain})
            atomic_config_write(data)
            self.refresh()
        except Exception as exc: messagebox.showerror('Save failed',str(exc))

    def remove_domain(self):
        selected=self.domain_list.curselection()
        if not selected:return
        domain=self.domain_list.get(selected[0])
        try:
            data=load_config()
            data['approved_download_domains']=[d for d in data.get('approved_download_domains',[]) if d != domain]
            atomic_config_write(data)
            self.refresh()
        except Exception as exc: messagebox.showerror('Save failed',str(exc))

    def refresh_requests(self):
        self.requests=APPROVALS.list_requests()
        if not hasattr(self,'req_list'): return
        self.req_list.delete(0,'end')
        for r in self.requests:
            host=urlsplit(r['url']).hostname or '(unknown)'
            self.req_list.insert('end',f"#{r['id']}  [{r['status']}]  {r['filename']}  ({host})")
        self.request_selected()

    def selected_request(self):
        selected=self.req_list.curselection()
        if not selected or selected[0]>=len(self.requests): return None
        return self.requests[selected[0]]

    def request_selected(self,event=None):
        if not hasattr(self,'request_detail'): return
        r=self.selected_request()
        body=(f"Filename: {r['filename']}\nStatus: {r['status']}\nExact link: {r['url']}\nExpires: {r['expires_at']}" if r else 'Select a request to inspect its exact URL.')
        self.request_detail.configure(state='normal')
        self.request_detail.delete('1.0','end')
        self.request_detail.insert('1.0',body)
        self.request_detail.configure(state='disabled')

    def open_request_url(self):
        r=self.selected_request()
        if r: webbrowser.open(r['url'],new=2)

    def decide_request(self,approved):
        r=self.selected_request()
        if not r or r['status']!='pending':
            messagebox.showinfo('Select pending request','Choose a pending request first.')
            return
        if not messagebox.askyesno('Confirm download authorization',
            f"{'APPROVE' if approved else 'DENY'} downloading this exact URL?\n\n{r['url']}\n\nSave as: {r['filename']}\n\nOnly approve if publisher and exact link are legitimate. This does NOT run the file."):
            return
        try:
            APPROVALS.owner_decide(r['id'],approved)
            self.refresh_requests()
            messagebox.showinfo('Saved','The owner decision was saved locally. Ask JARVIS to retry if approved.')
        except Exception as exc:
            messagebox.showerror('Cannot decide request',str(exc))

    def open_workspace(self):
        try:
            path=Path(os.path.expandvars(load_config()['workspace']))
            path.mkdir(parents=True,exist_ok=True)
            os.startfile(path)
        except Exception as exc:
            messagebox.showerror('Could not open workspace',str(exc))

if __name__ == '__main__':
    Panel().mainloop()
