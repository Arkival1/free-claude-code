# JARVIS Workstation: the big plan (26 Nov 2026)

## The goal
A JARVIS you can hand a job to, from one desktop app on your laptop. It does the work like a careful person: you can watch it, it checks every step, it asks you before anything risky, and everything it learns lands in your Obsidian brain. It's local first: your Qwen model, your OpenWhispr, your files.

## Why it was failing before
1. **Too much for a 4B model to juggle.** It had to chain about 15 tool calls (open site, inspect, type, click, wait, download, transcribe, save...) and remember them all. One slip and it guessed. *Fix in 3.2: the procedure lives in tested code (`video_to_notes`); the model makes one call and checks progress.*
2. **Its prompt was overloaded.** Every message described 78 tools (~10K tokens) in a ~7K context. *Fixed in 3.1 (tool groups); you now run 50K.*
3. **The converter's buttons were invisible to it.** ytmp3.zone puts its format table inside an embedded page from another site (`embed.dlsrv.online`), so the old browser tool only saw the outer page. *Fix in 3.2: the converter module reads that inner page.*
4. **Long steps timed out.** LM Studio gives up on slow tools, so a download that had already started looked like a failure, and the one-use approval was gone. *Fix in 3.2: background jobs + `job_status`.*
5. **OpenWhispr was driven by guessing clicks.** *Fix in 3.2: OpenWhispr has its own local API (`/v1/transcribe`), so JARVIS hands it the file path directly.*

## How JARVIS should "use a PC like a human"
A person looks, acts, then checks it worked. JARVIS does the same, with the most reliable "eyes" for each kind of app:

| What it's using | How JARVIS sees it | How it acts | How it checks |
|---|---|---|---|
| Websites | The page's real structure (DOM), incl. embedded frames | Real mouse clicks and key presses on the exact element | Reads the value back, looks for the expected next page |
| Apps with an API (OpenWhispr, Obsidian files, LM Studio) | The app's own local API | API calls | The API's answer + reading the saved file back |
| Normal Windows apps | Windows accessibility tree (UIA: button names, positions) | Click by exact name | Reads the control state again |
| Anything else | Screenshot (only if the model can actually see images) | Click inside a box it identified | New screenshot compared with the expected state |

Rule: **a click is not success; only a checked result is.** Humans stay in charge of approvals, logins, payments and "verify you are human" checks.

## Architecture

```text
JARVIS Workstation (desktop app, owner side)      LM Studio (Qwen) + jarvis-clean-v3 MCP
  Video→Notes | Jobs | Approvals | Check | STOP          "make notes from <link>" -> video_to_notes
                \                                        /
                 jarvis_core: pipeline (one tested procedure per job)
                   |- jobs        background work, progress, cancel, STOP
                   |- converter   website via JARVIS browser (DOM + real clicks)
                   |- youtube     direct audio (yt-dlp), built-in Whisper
                   |- openwhispr  local API of your OpenWhispr app
                   |- approvals   one-use owner approvals (SQLite)
                   |- vault/files Obsidian notes, read-back checks
```
New abilities get added as **modules + one Workstation tab + one high-level tool** each, never as a long prompt.

## Phases

### Phase 1: Video → Notes on your laptop (3.2, built now)
Done in code and tested here: Workstation app, website route, OpenWhispr bridge, built-in Whisper fallback, approvals in the app, background jobs, transcript + AI notes saved and read back, 228 automated tests (incl. a real-browser run through a copy of the converter's layout).
**Your test on the Legion:**
1. Update OpenWhispr to 1.10.0 or newer and keep it open, with a local model downloaded (Settings → Speech to Text).
2. In LM Studio turn on the local server (Developer → Start server).
3. Add `"context_tokens": 50000` to `config.json`.
4. `START_WORKSTATION.bat` → System check: all ✓ except optional FFmpeg.
5. Video → Notes: paste the link, Start, approve, wait for ✓ on all six steps.

**Done when:** a real transcript and notes from your video are in Obsidian, the steps match what happened, and nothing downloaded without your click.

### Phase 2: Make it sturdy (next)
- Real-site check on the Legion; adjust if ytmp3.zone shows a human check or changes its layout. Optional site profiles so a second converter can be added without new code.
- Timestamps from OpenWhispr (if its API offers them) or chunked built-in Whisper with progress percentage.
- Resume a job after a restart (stage checkpoints are already saved).
- A "Proof" panel per job: what was clicked, what was read back, file checks.

### Phase 3: App pilot, so JARVIS can work in normal apps
- Install UIA (menu 9 → 1). Add an "app recipe" layer: open app → find control by name → act → verify, with screenshots saved as proof.
- Test whether your Qwen model really sees screenshots; if not, use UIA/DOM only and say so. Consider a small vision model only if needed.
- First recipes: Obsidian (open note, search), File Explorer (find/copy), VS Code (open project, run task).

### Phase 4: Memory desk
- A Workstation tab to search everything JARVIS saved (notes, transcripts, journal), with source links.
- Automatic "what happened today" journal; lessons learned after each failed job.
- Keyword search now; add local semantic search (small embedding model in LM Studio) once the basics are solid.

### Phase 5: Research desk and Project builder
- Research: web search → read sources → notes with citations → open questions. Clearly marks unverified claims.
- Projects: website/game scaffolds → live preview → automatic checks (page loads, buttons work) → fix → journal.

### Phase 6: Autonomy you can trust
- Task queue in the Workstation: give JARVIS several jobs; it runs them one by one, each with checkpoints, max 3 repair attempts, then stops and reports.
- Per-task permissions ("this task may download", "this task may only read").
- Daily brief: done / waiting for you / failed and why.

## Security model (kept in every phase)
- **You approve; JARVIS never can.** Downloads need a one-use approval of the exact item. Approvals happen only in owner apps (Workstation, Control Panel).
- **No bypassing human checks.** CAPTCHAs, logins and payments are yours.
- **Least access:** fixed hosts for website routes, loopback-only local APIs, workspace-only files, no admin, no shell.
- **Untrusted downloads are quarantined**, checked by signature and size, and never opened or run.
- **EMERGENCY STOP** in the Workstation (and `START_JARVIS.bat` S) stops new actions and running jobs at their next safe point.
- **Secrets stay out of the model:** e.g. OpenWhispr's key is read only when needed and never shown or logged.
- Everything is tested twice: automated tests for every module, and the owner's real-laptop check for every phase.

## Known risks
- ytmp3.zone and its converter partner can change their pages or block automation at any time; the direct YouTube route is the backup.
- YouTube's terms limit downloading; only use videos you're allowed to.
- OpenWhispr's local API is new (Sep 2026); older versions don't have it, and JARVIS falls back to built-in Whisper.
- A 4B model is still small: keep jobs as high-level tools, not long chains.
