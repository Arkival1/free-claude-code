"""Optional owner-run test for JARVIS precision hover, scroll, drag and clicks.

No network/files/admin. The model must actually use a screenshot to find targets.
"""
from __future__ import annotations
import sys
import tkinter as tk

if sys.platform=='win32':
    import ctypes
    if ctypes.windll.shell32.IsUserAnAdmin():
        raise SystemExit('Run as a normal Windows user, not administrator.')

root=tk.Tk();root.title('JARVIS Advanced Mouse Test — Local Only')
root.geometry('860x590');root.resizable(False,False);root.configure(bg='#161b29')
step=tk.IntVar(value=0)
status=tk.StringVar(value='STEP 1: Click the green rectangular button at the left.')
tk.Label(root,text='JARVIS · ADVANCED MOUSE TEST',font=('Segoe UI',18,'bold'),
         bg='#161b29',fg='white').place(x=170,y=15)
tk.Label(root,textvariable=status,font=('Segoe UI',12),bg='#161b29',fg='#e9eef8',
         wraplength=820,justify='center').place(x=20,y=60,width=820,height=55)

def advance(expected):
    if step.get()!=expected:return
    step.set(expected+1)
    messages={1:'STEP 2: Hover over the BLUE box for its tooltip. Do not click.',
              2:'STEP 3: Put cursor inside YELLOW scroll area and scroll DOWN.',
              3:'STEP 4: DRAG the purple square to the green destination on the right.',
              4:'PASS — click, hover, scroll and drag were actually received by Windows.'}
    status.set(messages.get(expected+1,'PASS'))

# Click: real Tkinter callback, cannot pass through guesswork.
tk.Button(root,text='CLICK CENTER',bg='#19bd85',fg='black',
          font=('Segoe UI',14,'bold'),command=lambda:advance(0)).place(x=65,y=160,width=200,height=70)

hover=tk.Label(root,text='HOVER HERE',bg='#3987dc',fg='white',font=('Segoe UI',14,'bold'))
hover.place(x=330,y=160,width=210,height=70)
hover.bind('<Enter>',lambda event:advance(1))

scroll=tk.Label(root,text='SCROLL DOWN HERE',bg='#e6bc45',fg='black',font=('Segoe UI',14,'bold'))
scroll.place(x=560,y=280,width=255,height=100)
def do_wheel(event):
    if getattr(event,'delta',0)<0:advance(2)
scroll.bind('<MouseWheel>',do_wheel)
scroll.bind('<Button-5>',lambda e:advance(2))

source=tk.Label(root,text='DRAG ME',bg='#7d53cf',fg='white',font=('Segoe UI',12,'bold'))
source.place(x=75,y=425,width=110,height=75)
dest=tk.Label(root,text='DROP HERE',bg='#1fa970',fg='black',font=('Segoe UI',12,'bold'))
dest.place(x=625,y=425,width=150,height=75)
state={'pressed':False}
source.bind('<ButtonPress-1>',lambda event:state.__setitem__('pressed',True))
def released(event):
    # Screen event x_root/y_root: actual pointer location, not just button bounds.
    if not state['pressed']:return
    state['pressed']=False
    x0,y0=dest.winfo_rootx(),dest.winfo_rooty()
    if x0<=event.x_root<x0+dest.winfo_width() and y0<=event.y_root<y0+dest.winfo_height():
        advance(3)
source.bind('<ButtonRelease-1>',released)

footer='Follow the steps in order. Test receives real Windows mouse events. No files, admin or downloads required.'
tk.Label(root,text=footer,bg='#161b29',fg='#b2bed5',font=('Segoe UI',10)).place(x=38,y=547)
root.mainloop()
