"""Owner-only local settings command. Never made available as MCP tool."""
import json
from pathlib import Path
import sys
from jarvis_core.policy import Settings
from jarvis_core.memory import Memory

ROOT=Path(__file__).resolve().parent
settings=Settings(ROOT/'config.json')
if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1]=='status':
        print(json.dumps({'config':str(settings.path),'permissions':settings.data['permissions'],
              'workspace':str(settings.workspace),'data':str(settings.data_dir),
              'stop_file':str(settings.kill_switch_path()),
              'approved_projects':Memory(settings).projects()},indent=2))
    elif len(sys.argv)==3 and sys.argv[1]=='approve':
        name=Memory(settings).approve_project_by_owner(sys.argv[2])
        print('Project approved for JARVIS notes and tasks:',name)
    else:
        print('Usage:\n  py manage.py status\n  py manage.py approve "My Project"')
