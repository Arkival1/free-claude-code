"""Owner-run, no-model, no-download Obsidian app-open check."""
from __future__ import annotations
import json
from pathlib import Path
import sys
from jarvis_core.policy import PolicyError,Settings
from jarvis_core.files import FileTools
from jarvis_core.vault import Vault
from jarvis_core.desktop import Desktop


def run():
    if sys.platform!='win32':
        print('This test requires the Windows 10/11 desktop.')
        return 2
    config=Path(__file__).resolve().parent/'config.json'
    settings=Settings(config)
    vault=Vault(settings,FileTools(settings))
    desktop=Desktop(settings)
    try:
        created=vault.build_second_brain()  # idempotent: preserve previous notes
        out=desktop.open_obsidian('dashboard')
    except (PolicyError,ValueError,RuntimeError,OSError) as exc:
        print('OBSIDIAN OPEN FAILED:',exc)
        print('If Obsidian is installed, open it manually once and register')
        print('this folder with Open folder as vault:',settings.workspace/'JARVIS_Brain')
        return 1
    print('Vault:',created['vault'])
    print('Desktop app open request:',json.dumps(out,ensure_ascii=False,indent=2))
    if out['window_observed']:
        print('Obsidian window observed. CHECK VISUALLY that the correct vault is displayed.')
        return 0
    print('Window not confirmed. CHECK Obsidian yourself; for a new vault use Open folder as vault once.')
    return 3


if __name__=='__main__':
    raise SystemExit(run())
