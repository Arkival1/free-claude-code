"""Explicit OWNER-APPROVED download of a verified offline transcription model.

Never called by JARVIS MCP/agent. Only invoked from owner-run BAT. Does not run
installer code or auto-install packages, and warns about the exact repository.
"""
from pathlib import Path
import sys
from jarvis_core.policy import Settings

REPO='Systran/faster-whisper-base'
PUBLIC='https://huggingface.co/Systran/faster-whisper-base'

def main(input_fn=input):
    settings=Settings(Path(__file__).resolve().parent/'config.json')
    root=settings.data_dir/'models'/'faster-whisper-base'
    print('\n=== OWNER-ONLY OFFLINE SPEECH MODEL DOWNLOAD ===')
    print('Model:',PUBLIC)
    print('Destination:',root)
    print('This downloads model files from Hugging Face over HTTPS. No model software is executed.')
    print('It may be hundreds of MB. Only approve if you recognize and trust this exact source.')
    print('JARVIS agents cannot call this script through MCP tools.')
    if input_fn('Do YOU approve downloading this model? Type YES to continue: ').strip()!='YES':
        print('Download NOT approved. No network request made.')
        return False
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        print('Missing huggingface_hub. Use START_JARVIS.bat menu 9 > option 3 (faster-whisper) first.')
        return False
    root.mkdir(parents=True,exist_ok=True)
    snapshot_download(repo_id=REPO,local_dir=str(root),
                      allow_patterns=['model.bin','config.json','tokenizer.json','vocabulary.json','preprocessor_config.json'])
    if not all((root/f).is_file() for f in ('model.bin','config.json','tokenizer.json')):
        print('Model download incomplete. Run diagnostic for missing files.')
        return False
    print('Offline Whisper model installed. Speech inference will remain local.')
    return True

if __name__=='__main__':
    try:sys.exit(0 if main() else 1)
    except KeyboardInterrupt:sys.exit('Cancelled by owner')
