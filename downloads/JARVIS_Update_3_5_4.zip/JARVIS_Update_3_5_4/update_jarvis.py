"""Owner-run updater for JARVIS Clean v3.x: copy this version's program files into your
EXISTING JARVIS folder, keeping config.json, .venv, your notes and the LM Studio connection.

Run UPDATE_JARVIS.bat from the EXTRACTED update folder (anywhere, e.g. Downloads).
- finds your JARVIS install(s) by itself, or asks for the folder
- backs up every file it replaces into <install>\\_update_backups\\<time>\\
- moves obsolete leftovers into that backup (never deletes them)
- "UPDATE_JARVIS.bat undo" puts the last backup back
Nothing here needs administrator rights or the internet.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SRC = Path(__file__).resolve().parent
KEEP = {'config.json', '.venv', 'LM_STUDIO_SNIPPET.json', 'STOP_JARVIS.txt', '_update_backups', '_backups',
        'SIMULATION_REPORT.md', 'simulation_screenshots', '__pycache__', '.git'}
OBSOLETE = ['jarvis_sim', 'tests/test_v33_simulator.py', 'INSTALL_EVERYTHING.bat']   # the orb now has its own update package   # older builds' files that no longer belong
SKIP_DIRS = {'.venv', 'node_modules', '_update_backups', '_backups', '.git', 'AppData', 'JARVIS_Brain',
             'site-packages', '__pycache__', 'Downloads_YouTube'}


def version_of(folder: Path) -> str:
    try:
        m = re.search(r"'version':'([0-9.]+)'", (folder / 'server.py').read_text(encoding='utf-8', errors='replace'))
        return m.group(1) if m else 'unknown'
    except OSError:
        return 'unknown'


def is_install(folder: Path) -> bool:
    try:
        return ((folder / 'server.py').is_file() and (folder / 'config.json').is_file()
                and 'jarvis-clean-v3' in (folder / 'server.py').read_text(encoding='utf-8', errors='replace'))
    except OSError:
        return False


def whats_new(lines=12) -> str:
    try:
        text = (SRC / 'CHANGELOG.md').read_text(encoding='utf-8')
    except OSError:
        return ''
    parts = text.split('\n## ')
    return ('## ' + parts[1]).strip().splitlines()[:lines] if len(parts) > 1 else []


def find_installs() -> list[Path]:
    """Look in the usual places (up to 4 folders deep) for JARVIS Clean v3 installs."""
    home = Path.home()
    roots = [home, home / 'Desktop', home / 'OneDrive' / 'Desktop', home / 'Documents', home / 'Downloads',
             SRC.parent, SRC.parent.parent]
    found = []
    for root in roots:
        if not root.is_dir():
            continue
        stack = [(root, 0)]
        while stack:
            d, depth = stack.pop()
            try:
                if d.resolve() == SRC or d.name in SKIP_DIRS:
                    continue
            except OSError:
                continue
            if is_install(d):
                found.append(d.resolve())
                continue
            if depth < 4:
                try:
                    stack += [(c, depth + 1) for c in d.iterdir() if c.is_dir() and not c.name.startswith('.')]
                except OSError:
                    pass
    return sorted(set(found), key=lambda p: -(p / 'config.json').stat().st_mtime)


def program_files() -> list[Path]:
    out = []
    for p in SRC.rglob('*'):
        rel = p.relative_to(SRC)
        if p.is_file() and not (set(rel.parts) & KEEP) and p.suffix not in ('.pyc',):
            out.append(rel)
    return sorted(out)


def update(target: Path, log=print) -> Path:
    target = target.resolve()
    if target == SRC:
        raise ValueError('That is the update folder itself. Choose your EXISTING JARVIS folder.')
    if not is_install(target):
        raise ValueError(f'{target} is not a JARVIS Clean v3 folder (needs server.py and config.json). Nothing changed.')
    json.loads((target / 'config.json').read_text(encoding='utf-8'))          # refuse a broken config before touching anything
    backup = target / '_update_backups' / datetime.now().strftime('%Y%m%d_%H%M%S')
    backup.mkdir(parents=True)
    (backup / 'FROM_VERSION.txt').write_text(version_of(target), encoding='utf-8')
    files = program_files()
    replaced = added = 0
    for rel in files:                                   # 1) back up everything that will be replaced
        dest = target / rel
        if dest.is_file():
            (backup / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, backup / rel)
    for rel in files:                                   # 2) copy the new program files
        dest = target / rel
        existed = dest.exists()
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SRC / rel, dest)
        replaced += existed
        added += not existed
    moved = []
    for rel in OBSOLETE:                                # 3) move leftovers aside, never delete
        old = target / rel
        if old.exists():
            (backup / 'obsolete' / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(old), str(backup / 'obsolete' / rel))
            moved.append(rel)
    (backup / 'FILES.json').write_text(json.dumps({'added': [str(r) for r in files if not (backup / r).exists()],
                                                   'moved_aside': moved}, indent=1), encoding='utf-8')
    log(f'Updated {replaced} files, added {added}, moved aside {len(moved)} old item(s).')
    log(f'Backup of the old files: {backup}')
    return backup


def undo(target: Path, log=print) -> Path:
    target = target.resolve()
    folder = target / '_update_backups'
    backups = sorted(b for b in folder.glob('*') if b.is_dir() and not b.name.endswith('_undone')) if folder.is_dir() else []
    if not backups:
        raise ValueError('No update backup found in this folder.')
    last = backups[-1]
    info = json.loads((last / 'FILES.json').read_text(encoding='utf-8')) if (last / 'FILES.json').is_file() else {}
    for f in last.rglob('*'):
        rel = f.relative_to(last)
        if f.is_file() and rel.parts[0] not in ('obsolete',) and rel.name not in ('FILES.json', 'FROM_VERSION.txt'):
            (target / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, target / rel)
    for rel in info.get('added', []):                  # files the update added are removed again
        (target / rel).unlink(missing_ok=True)
    for rel in info.get('moved_aside', []):
        if (last / 'obsolete' / rel).exists() and not (target / rel).exists():
            shutil.move(str(last / 'obsolete' / rel), str(target / rel))
    shutil.move(str(last), str(last.with_name(last.name + '_undone')))
    log(f'Restored version {version_of(target)} from {last.name}.')
    return last


def venv_python(target: Path) -> Path:
    return target / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def check(target: Path, log=print) -> bool:
    py = venv_python(target)
    if not py.is_file():
        log('WARNING: this install has no .venv yet. Run START_JARVIS.bat and choose 1.')
        return False
    code = ('import importlib.util as u, sys; sys.path.insert(0, "."); import jarvis_core.app_control, jarvis_core.desktop_backend; '
            'print("UIA", "yes" if u.find_spec("pywinauto") else "no")')
    p = subprocess.run([str(py), '-c', code], cwd=str(target), capture_output=True, text=True, timeout=120)
    if p.returncode:
        log('PROBLEM: the updated files do not load: ' + (p.stderr.strip().splitlines() or ['?'])[-1])
        return False
    log(f'Check OK: JARVIS {version_of(target)} loads with its own Python.')
    if 'UIA no' in p.stdout:
        log('Windows UI Automation (needed for clicking apps by name) is not installed.')
        if ask('Install it now? (downloads pywinauto into JARVIS\'s own Python)'):
            subprocess.run([str(py), '-m', 'pip', 'install', 'pywinauto>=0.6.9,<1'], cwd=str(target), check=False)
    return True


def ask(q: str) -> bool:
    return input(q + ' [y/N]: ').strip().casefold() in ('y', 'yes')


def choose(installs: list[Path]) -> Path | None:
    if installs:
        print('\nJARVIS installs found:')
        for i, p in enumerate(installs, 1):
            print(f'  {i}. {p}   (version {version_of(p)})')
        pick = input(f'Number to update [1], or paste a different folder path: ').strip().strip('"')
        if not pick:
            return installs[0]
        if pick.isdigit() and 1 <= int(pick) <= len(installs):
            return installs[int(pick) - 1]
        return Path(pick)
    pick = input('No JARVIS install found automatically. Paste your JARVIS folder path (the one with START_JARVIS.bat): ').strip().strip('"')
    return Path(pick) if pick else None


def main():
    new = version_of(SRC)
    print(f'=== JARVIS UPDATE to version {new} ===')
    print('Your settings, notes, .venv and LM Studio connection are kept. Old files are backed up first.')
    for line in whats_new():
        print('   ' + line)
    undo_mode = len(sys.argv) > 1 and sys.argv[1].casefold() == 'undo'
    target = choose(find_installs())
    if target is None:
        print('Nothing chosen; nothing changed.'); return 1
    try:
        if undo_mode:
            if ask(f'Undo the last update in {target}?'):
                undo(target)
            return 0
        print(f'\nUpdate {target}\n  from version {version_of(target)}  to version {new}')
        if not ask('Close LM Studio first. Continue?'):
            print('Cancelled; nothing changed.'); return 1
        update(target)
        check(target)
        print('\nDONE. Next: open LM Studio, reconnect jarvis-clean-v3, and ask JARVIS to call jarvis_status '
              f'(should say {new}). To undo: run UPDATE_JARVIS.bat undo')
        return 0
    except (ValueError, OSError) as exc:
        print('NO UPDATE DONE: ' + str(exc))
        return 1


if __name__ == '__main__':
    sys.exit(main())
