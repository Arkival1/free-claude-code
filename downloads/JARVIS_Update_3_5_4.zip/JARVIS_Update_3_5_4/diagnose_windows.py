"""One-shot offline preflight for the local MCP environment. Never starts MCP."""
from __future__ import annotations
from pathlib import Path
import sys, json, platform, importlib.util

base = Path(__file__).resolve().parent
print('JARVIS Local MCP v2.1 preflight')
print('Python:', sys.executable, sys.version.split()[0])
print('Platform:', platform.platform())
for name in ('mcp', 'pyautogui', 'PIL', 'requests', 'bs4', 'tkinter'):
    print(f'{name}:', 'FOUND' if importlib.util.find_spec(name) else 'MISSING')
print('Server script:', 'FOUND' if (base / 'server.py').is_file() else 'MISSING')
print('LM Studio snippet:', 'FOUND' if (base / 'LM_STUDIO_SNIPPET.json').is_file() else 'MISSING')
try:
    cfg=json.loads((base/'config.json').read_text(encoding='utf-8'))
    print('Workspace:', Path(__import__('os').path.expandvars(cfg['workspace'])))
    print('Permissions:', cfg['permissions'])
    print('Owner STOP file:', 'PRESENT' if (base/'STOP_JARVIS.txt').exists() else 'absent')
except Exception as exc:
    print('Config problem:', exc)
try:
    from mcp.server.fastmcp import FastMCP
    print('Official MCP FastMCP import: OK')
except Exception as exc:
    print('MCP import failed:', repr(exc))
