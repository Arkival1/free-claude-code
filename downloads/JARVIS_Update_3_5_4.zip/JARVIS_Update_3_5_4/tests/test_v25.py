"""Offline tests: fake search-provider HTML; no external HTTP calls."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jarvis_core.files import FileTools
from jarvis_core.memory import Memory
from jarvis_core.network import WebTools
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.research import ResearchTools
from jarvis_core.vault import Vault

DDG_HTML = b'''<html><div class="result"><a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fdocs.python.org%2F3%2Ftutorial%2F">Python tutorial</a><div class="result__snippet">Official tutorial for Python.</div></div><div class="result"><a class="result__a" href="javascript:alert(1)">Bad link</a></div><div class="result"><a class="result__a" href="http://127.0.0.1/private">Private link</a></div></html>'''

class FakeResponse:
    headers={'Content-Type':'text/html; charset=utf-8'}
    encoding='utf-8'
    def __init__(self, data=DDG_HTML):self.data=data
    def iter_content(self,size):yield self.data
    def close(self):pass
class FakeSession:
    def close(self):pass

class ResearchFeatureTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        root=Path(t.name)
        self.cfg=root/'config.json'
        self.cfg.write_text(json.dumps({'workspace':str(root/'workspace'),'data_dir':str(root/'data'),
                           'permissions':{'files':True,'notes_and_tasks':True,'web_research':True}}))
        self.settings=Settings(self.cfg)
        self.files=FileTools(self.settings)
        self.memory=Memory(self.settings)
        self.memory.approve_project_by_owner('JARVIS_Demo')
        self.web=WebTools(self.settings)
        self.vault=Vault(self.settings,self.files)
        self.research=ResearchTools(self.settings,self.web,self.memory,self.vault)

    def fake_get(self,url):return FakeResponse(),url,FakeSession()

    def test_search_returns_valid_source_and_rejects_unsafe_links(self):
        with patch.object(self.web,'_get',side_effect=self.fake_get):
            output=self.research.search('python beginner tutorial','official')
        self.assertEqual(output['results'][0]['url'],'https://docs.python.org/3/tutorial/')
        self.assertEqual(len(output['results']),1)
        self.assertIn('unverified',output['verification'].lower())

    def test_reject_private_search_topics(self):
        for topic in ('My API_KEY=supersecretvalue','find C:\\Users\\Spawn\\Documents','Bearer aaa.bbb.ccc'):
            with self.subTest(topic=topic),self.assertRaises(PolicyError):
                self.research.search(topic)

    def test_research_disabled(self):
        cfg=json.loads(self.cfg.read_text());cfg['permissions']['web_research']=False
        self.cfg.write_text(json.dumps(cfg))
        with patch.object(self.web,'_get',side_effect=AssertionError('Network must not be called')):
            with self.assertRaises(PolicyError):self.research.search('python tutorial')

    def test_stop_blocks_research(self):
        (self.cfg.parent/'STOP_JARVIS.txt').touch()
        with patch.object(self.web,'_get',side_effect=AssertionError('Network must not be called')):
            with self.assertRaises(PolicyError):self.research.search('python tutorial')

    def test_save_leads_and_verify_task_to_approved_project_and_vault(self):
        with patch.object(self.web,'_get',side_effect=self.fake_get):
            saved=self.research.learn('JARVIS_Demo','python beginner tutorial','official')
        self.assertEqual(saved['project'],'JARVIS_Demo')
        self.assertTrue(self.memory.search_notes('JARVIS_Demo','Research leads'))
        self.assertEqual(len(self.memory.tasks('JARVIS_Demo')),1)
        self.assertTrue(self.vault.search('docs.python.org'))
        self.assertIn('unverified',saved['status'].lower())

    def test_unapproved_project_cannot_store_or_search(self):
        with patch.object(self.web,'_get',side_effect=AssertionError('Network must not be called')):
            with self.assertRaises(PolicyError):self.research.learn('Unknown','python beginner tutorial')

    def test_bing_fallback_when_duckduckgo_unavailable(self):
        bing=b'<li class="b_algo"><h2><a href="https://docs.godotengine.org/en/stable/">Godot docs</a></h2><div class="b_caption"><p>Manual</p></div></li>'
        def f(url):
            return FakeResponse(bing if 'bing.com' in url else b''),url,FakeSession()
        with patch.object(self.web,'_get',side_effect=f):
            result=self.research.search('Godot tutorial')
        self.assertEqual(result['engine'],'bing')
        self.assertEqual(result['results'][0]['title'],'Godot docs')

    def test_results_empty_does_not_create_fake_memories(self):
        def f(url):return FakeResponse(b''),url,FakeSession()
        with patch.object(self.web,'_get',side_effect=f):
            result=self.research.learn('JARVIS_Demo','python beginner tutorial')
        self.assertFalse(result['saved'])
        self.assertEqual(self.memory.tasks('JARVIS_Demo'),[])

if __name__ == '__main__':unittest.main()

class AgentResearchFollowupTests(unittest.TestCase):
    def test_model_uncertainty_gets_one_research_opportunity(self):
        import agent_runner as a
        calls = []
        class Resp:
            def __init__(self, text, tool_calls=None):self.text=text;self.calls=tool_calls or []
            def raise_for_status(self):pass
            def json(self):return {'choices':[{'message':{'content':self.text,'tool_calls':self.calls}}]}
        class Session:
            def __init__(self):self.i=0
            def post(self,*_,**kwargs):
                self.i += 1
                calls.append(list(kwargs['json']['messages']))
                if self.i == 1: return Resp("I don't know how to make that application yet.")
                if self.i == 2:return Resp('I should look up the documentation.',[
                    {'id':'tool_1','type':'function','function':{'name':'research_search',
                       'arguments':'{"topic":"Obsidian Canvas instructions","focus":"official"}'}}])
                return Resp('TASK_COMPLETE: Research links found; here are my next steps.')
        with patch.object(a.requests,'Session',Session), patch.dict(a.ACTIONS,{
            'research_search':lambda topic,focus='official':{'results':[{'url':'https://help.obsidian.md/','title':'Obsidian Docs'}]}}),patch.object(a,'log',lambda _:None):
            self.assertTrue(a.run_agent('Learn how Obsidian Canvas works','local-model',max_steps=4))
        self.assertEqual(len(calls),3)
        self.assertIn('knowledge gap',calls[1][-1]['content'])
        self.assertTrue(any(t['function']['name']=='research_search' for t in a.TOOLS))

    def test_permission_denial_does_not_prompt_bypass_research(self):
        import agent_runner as a
        class Resp:
            def raise_for_status(self):pass
            def json(self):return {'choices':[{'message':{'content':'TASK_BLOCKED: I cannot proceed because download permission is required.','tool_calls':[]}}]}
        class Session:
            def post(self,*_,**kwargs):return Resp()
        with patch.object(a.requests,'Session',Session),patch.object(a,'log',lambda _:None):
            self.assertFalse(a.run_agent('Install this app','local-model',max_steps=1))
