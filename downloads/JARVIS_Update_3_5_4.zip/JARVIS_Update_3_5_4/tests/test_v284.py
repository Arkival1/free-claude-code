"""YouTube transcript browser fallback: offline mocked UI, URL validation, local ingest, routing."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.files import FileTools
from jarvis_core.youtube import YouTubeTools
from jarvis_core.transcript_fallback import TranscriptFallback, SITES, EXTENSION
import agent_runner as agent

PUBLIC_URL='https://youtu.be/dQw4w9WgXcQ'
CANONICAL='https://www.youtube.com/watch?v=dQw4w9WgXcQ'
TRANSCRIPT='[00:00] Welcome to this tutorial on using Obsidian as a second brain.\n[00:15] The first step is creating a vault and connecting research notes to each other.\n[00:45] Next we open the mind map and arrange topics with edges. '

class Clipboard:
    def __init__(self, value=''):self.value=value
    def put(self,value):self.value=value
    def get(self):return self.value

class FallbackTests(unittest.TestCase):
    def setUp(self):
        d=tempfile.TemporaryDirectory();self.addCleanup(d.cleanup)
        root=Path(d.name)
        config=root/'config.json'
        config.write_text(json.dumps({'workspace':str(root/'workspace'), 'data_dir':str(root/'data'),
            'permissions':{'files':True,'desktop_control':True,'web_research':True},
            'desktop_mode':'all_user_apps','max_file_kb':256}),encoding='utf8')
        self.settings=Settings(config)
        self.files=FileTools(self.settings)
        self.web=Mock()
        self.web.browse.side_effect=lambda url:'Opened '+url
        self.clipboard=Clipboard()
        self.fallback=TranscriptFallback(self.settings,self.web,self.files,self.clipboard)

    def test_websites_are_verified_literal_allowlist(self):
        self.assertEqual(SITES['companion']['url'],'https://youtubetotranscript.com/')
        self.assertEqual(SITES['audio_cloud']['url'],'https://clipsdk.com/tools/youtube-transcript-generator/')
        self.assertIn('bcmoplgjpddohaelhnnodojbamdobbhc',EXTENSION)

    def test_site_opens_with_canonical_url_pasted_to_clipboard(self):
        result=self.fallback.open_website(PUBLIC_URL)
        self.web.browse.assert_called_once_with(SITES['companion']['url'])
        self.assertEqual(self.clipboard.value,CANONICAL)
        self.assertTrue(result['youtube_url_on_clipboard'])
        self.assertIn('no',result['downloads'].lower())

    def test_rejects_private_and_unapproved_services(self):
        for url in ('http://youtu.be/dQw4w9WgXcQ','https://evil.example/watch?v=dQw4w9WgXcQ',
                    'https://127.0.0.1/private','https://youtu.be/invalid'):
            with self.subTest(url=url),self.assertRaises(PolicyError):self.fallback.open_website(url)
        with self.assertRaises(PolicyError):self.fallback.open_website(PUBLIC_URL,'example')
        self.web.browse.assert_not_called()

    def test_clipboard_import_and_read_in_sections(self):
        self.clipboard.put(TRANSCRIPT)
        result=self.fallback.import_clipboard(PUBLIC_URL)
        self.assertTrue(result['saved'])
        self.assertTrue(result['file'].endswith('dQw4w9WgXcQ-website.txt'))
        self.assertFalse(result['source_verified'])
        part=YouTubeTools(self.settings,files=self.files).transcript_section(result['file'],0,150)
        self.assertIn('Unverified',part['content'])
        self.assertTrue(self.settings.in_workspace(result['file']).exists())
        self.assertTrue(self.settings.in_workspace(result['obsidian_index']).exists())
        self.assertFalse(self.fallback.import_clipboard(PUBLIC_URL)['saved'])
        self.assertIn(TRANSCRIPT.strip(),self.files.read_text(result['file']))

    def test_doesnt_consume_clipboard_link_or_short_text(self):
        self.clipboard.put(CANONICAL)
        with self.assertRaises(PolicyError):self.fallback.import_clipboard(PUBLIC_URL)
        self.clipboard.put('Hello')
        with self.assertRaises(PolicyError):self.fallback.import_clipboard(PUBLIC_URL)
        self.assertFalse(self.settings.in_workspace('JARVIS_Brain/Research/YouTube/dQw4w9WgXcQ-website.txt').exists())

    def test_owner_extension_listing_only_no_install(self):
        result=self.fallback.open_extension_listing()
        self.assertFalse(result['installed'])
        self.web.browse.assert_called_once_with(EXTENSION)
        self.assertIn('Owner',result['next'])

    def test_permission_required_for_clipboard_or_website(self):
        self.settings.data['permissions']['desktop_control']=False
        self.settings.path.write_text(json.dumps(self.settings.data))
        res=self.fallback.open_website(PUBLIC_URL)
        self.assertFalse(res['youtube_url_on_clipboard'])
        with self.assertRaises(PolicyError):self.fallback.import_clipboard(PUBLIC_URL)

class ModelRoutingTests(unittest.TestCase):
    def test_relevant_tools_provided_to_4b_model(self):
        tools={t['function']['name'] for t in agent.focused_tools('Transcribe https://youtu.be/dQw4w9WgXcQ and use website',desktop=True)}
        for need in ('youtube_transcript','youtube_transcript_website_open','youtube_transcript_clipboard_import',
                     'youtube_transcript_extension_open','desktop_screenshot','desktop_click','desktop_type'):
            self.assertIn(need,tools)
        self.assertNotIn('official_download',tools)

    def test_auto_fallback_when_no_caption_track(self):
        calls=[]
        def fake(name,args):
            calls.append(name)
            if name=='youtube_transcript':return {'captions_available':False}
            return {'opened':True}
        name,args,value=agent.kickoff_goal('Transcribe '+PUBLIC_URL,call=fake)
        self.assertEqual(name,'youtube_transcript_website_open')
        self.assertEqual(calls,['youtube_transcript','youtube_transcript_website_open'])
        self.assertEqual(args['provider'],'companion')

    def test_auto_fallback_when_yt_dlp_missing(self):
        calls=[]
        def fake(name,args):
            calls.append(name)
            if name=='youtube_transcript':raise PolicyError('yt-dlp missing')
            return {'opened':True}
        name,args,value=agent.kickoff_goal('Transcribe '+PUBLIC_URL,call=fake)
        self.assertEqual(name,'youtube_transcript_website_open')
        self.assertIn('yt-dlp missing',value['caption_attempt_error'])
        self.assertEqual(len(calls),2)

if __name__=='__main__':unittest.main()

class BrowserWizardTests(unittest.TestCase):
    def test_wizard_does_not_import_without_exact_import_confirmation(self):
        import jarvis_youtube_browser_fallback as wizard
        mock=Mock()
        mock.open_website.return_value={'website':'https://youtubetotranscript.com/','youtube_url_on_clipboard':True}
        prompts=iter([PUBLIC_URL,'','quit'])
        self.assertFalse(wizard.run(input_fn=lambda _:next(prompts),output_fn=lambda _:None,instance=mock))
        mock.import_clipboard.assert_not_called()

    def test_wizard_imports_only_after_user_copy_confirmation(self):
        import jarvis_youtube_browser_fallback as wizard
        mock=Mock()
        mock.open_website.return_value={'website':'https://youtubetotranscript.com/','youtube_url_on_clipboard':True}
        mock.import_clipboard.return_value={'saved':True,'file':'JARVIS_Brain/Research/YouTube/example-website.txt'}
        prompts=iter([PUBLIC_URL,'','IMPORT'])
        self.assertTrue(wizard.run(input_fn=lambda _:next(prompts),output_fn=lambda _:None,instance=mock))
        mock.import_clipboard.assert_called_once_with(PUBLIC_URL,'companion')
