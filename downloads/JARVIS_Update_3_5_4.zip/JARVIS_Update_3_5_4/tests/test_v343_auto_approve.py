"""v3.4.3: owner's auto-approve switch for YouTube audio only."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import jarvis_setup  # noqa: E402
from jarvis_core import pipeline as pl  # noqa: E402
import test_v32_pipeline as base  # noqa: E402
URL, wait_for = base.URL, base.wait_for


class AutoApprove(base.PipelineTests):
    test_full_run_waits_for_owner_then_saves_transcript_and_notes = None
    test_denied_means_nothing_downloaded = None
    test_openwhispr_closed_falls_back_to_builtin_whisper = None
    test_reuses_audio_already_downloaded = None
    test_bad_inputs_and_permissions = None
    def _set(self, on):
        data = json.loads(self.settings.path.read_text())
        data.setdefault('video_pipeline', {})['auto_approve_audio'] = on
        self.settings.path.write_text(json.dumps(data)); self.settings.reload()

    def test_on_means_no_click_needed(self):
        self.build(); self._set(True)
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'):
            job = self.p.start(URL, write_notes=False)
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)
        self.assertEqual(self.approvals.latest(URL, 'WftF2zJkvHY.ytmp3.opus')['status'], 'used')
        full_log = json.loads(self.jobs._path(job['id']).read_text())['log']
        self.assertTrue(any('Auto-approved' in l for l in full_log), full_log)

    def test_off_still_waits_for_owner(self):
        self.build(); self._set(False)
        job = self.p.start(URL, write_notes=False)
        w = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] == 'waiting' and j, 20)
        self.assertEqual(w['stage'], 'awaiting_approval')
        self.jobs.cancel(job['id'])

    def test_never_auto_approves_other_files(self):
        self.assertTrue(pl.AUTO_OK.fullmatch('WftF2zJkvHY.ytmp3.opus'))
        self.assertTrue(pl.AUTO_OK.fullmatch('WftF2zJkvHY.m4a'))
        for bad in ('setup.exe', 'WftF2zJkvHY.exe', 'WftF2zJkvHY.opus.exe', 'notes.zip', '../WftF2zJkvHY.mp3', 'abc.mp3'):
            self.assertFalse(pl.AUTO_OK.fullmatch(bad), bad)

    def test_setting_value_must_be_true_exactly(self):
        self.build()
        data = json.loads(self.settings.path.read_text()); data['video_pipeline'] = {'auto_approve_audio': 'yes'}
        self.settings.path.write_text(json.dumps(data)); self.settings.reload()
        job = self.p.start(URL, write_notes=False)
        w = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] == 'waiting' and j, 20)
        self.assertEqual(w['stage'], 'awaiting_approval')
        self.jobs.cancel(job['id'])


class MenuSwitch(unittest.TestCase):
    def test_owner_menu_toggles_and_keeps_other_settings(self):
        d = Path(tempfile.mkdtemp()); cfg = d / 'config.json'
        cfg.write_text(json.dumps({'workspace': 'W', 'permissions': {'files': True}, 'video_pipeline': {'source': 'direct'}}))
        with patch.object(jarvis_setup, 'CONFIG', cfg), patch.object(jarvis_setup, 'log', lambda *a: None):
            self.assertTrue(jarvis_setup.auto_approve_audio(True))
            data = json.loads(cfg.read_text())
            self.assertEqual(data['video_pipeline'], {'source': 'direct', 'auto_approve_audio': True})
            self.assertEqual(data['permissions'], {'files': True})
            with patch.object(jarvis_setup, 'yes', return_value=True):
                self.assertFalse(jarvis_setup.auto_approve_audio())
        self.assertFalse(json.loads(cfg.read_text())['video_pipeline']['auto_approve_audio'])


if __name__ == '__main__':
    unittest.main()
