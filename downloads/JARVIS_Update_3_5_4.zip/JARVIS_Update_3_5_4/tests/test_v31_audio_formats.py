"""v3.1: owner audio preference Opus > M4A > MP3 320, still behind one-use human approval."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jarvis_core.download_approvals import DownloadApprovals
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.youtube import MEDIA_EXTS, YouTubeTools, choose_audio_format

URL = 'https://www.youtube.com/watch?v=WftF2zJkvHY'
VID = 'WftF2zJkvHY'
OPUS = {'format_id': '251', 'ext': 'webm', 'vcodec': 'none', 'acodec': 'opus', 'abr': 135, 'filesize': 4_000_000}
OPUS_LOW = {'format_id': '250', 'ext': 'webm', 'vcodec': 'none', 'acodec': 'opus', 'abr': 70}
M4A = {'format_id': '140', 'ext': 'm4a', 'vcodec': 'none', 'acodec': 'mp4a.40.2', 'abr': 129}
MP3_320 = {'format_id': 'mp3-320', 'ext': 'mp3', 'vcodec': 'none', 'acodec': 'mp3', 'abr': 320}
MP3_128 = {'format_id': 'mp3-128', 'ext': 'mp3', 'vcodec': 'none', 'acodec': 'mp3', 'abr': 128}
VIDEO_WITH_AUDIO = {'format_id': '18', 'ext': 'mp4', 'vcodec': 'avc1', 'acodec': 'mp4a.40.2', 'abr': 96}
VIDEO_ONLY = {'format_id': '137', 'ext': 'mp4', 'vcodec': 'avc1', 'acodec': 'none'}


class ChooseFormat(unittest.TestCase):
    def test_opus_preferred_and_best_bitrate(self):
        c = choose_audio_format([M4A, OPUS_LOW, OPUS, MP3_320], have_ffmpeg=True)
        self.assertEqual((c['kind'], c['final_ext'], c['format_id']), ('opus', 'opus', '251'))
        self.assertEqual(c['estimated_bytes'], 4_000_000)

    def test_opus_without_ffmpeg_keeps_webm_container(self):
        c = choose_audio_format([OPUS, M4A], have_ffmpeg=False)
        self.assertEqual((c['kind'], c['final_ext']), ('opus', 'webm'))

    def test_m4a_when_no_opus(self):
        self.assertEqual(choose_audio_format([M4A, MP3_320], True)['kind'], 'm4a')

    def test_mp3_only_when_native_320(self):
        self.assertEqual(choose_audio_format([MP3_320], True)['final_ext'], 'mp3')
        self.assertIsNone(choose_audio_format([MP3_128], True))

    def test_nothing_acceptable(self):
        self.assertIsNone(choose_audio_format([], True))
        self.assertIsNone(choose_audio_format(None, True))
        # Muxed video+audio and video-only streams are never picked as "audio".
        self.assertIsNone(choose_audio_format([VIDEO_WITH_AUDIO, VIDEO_ONLY, 'junk', {}], True))

    def test_opus_is_local_media(self):
        self.assertIn('.opus', MEDIA_EXTS)


def make_ydl(formats, log, create_ext=None, root=None):
    class YDL:
        def __init__(self, opts):
            self.opts = opts
            log.append(('init', opts))
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def extract_info(self, url, download):
            assert not download
            log.append(('probe', url))
            return {'title': 'Test video', 'formats': formats}
        def download(self, urls):
            log.append(('download', urls, self.opts.get('format')))
            if create_ext:
                Path(root, 'Downloads', 'YouTube', VID + '.' + create_ext).write_bytes(b'x' * 2048)
    return YDL


class FakeWeb:
    def __init__(self, settings): self.approvals = DownloadApprovals(settings)


class RequestAndDownload(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup)
        root = Path(t.name); self.ws = root / 'workspace'
        cfg = root / 'config.json'
        cfg.write_text(json.dumps({'workspace': str(self.ws), 'data_dir': str(root / 'data'),
                                   'permissions': {'files': True, 'web_research': True, 'downloads': True}}))
        self.settings = Settings(cfg)
        self.web = FakeWeb(self.settings)
        self.y = YouTubeTools(self.settings, web=self.web)
        self.log = []

    def use(self, formats, ffmpeg='/usr/bin/ffmpeg', create_ext=None):
        self.y._get_ydl = lambda: make_ydl(formats, self.log, create_ext, self.ws)
        self.y._ffmpeg = lambda: ffmpeg

    def approve_latest(self, approved=True):
        rid = self.web.approvals.list_requests()[0]['id']
        self.web.approvals.owner_decide(rid, approved)

    def test_request_queues_preferred_format_without_downloading(self):
        self.use([M4A, OPUS])
        r = self.y.audio_download_request('https://youtu.be/' + VID)
        self.assertEqual((r['status'], r['filename'], r['url']), ('pending', VID + '.opus', URL))
        self.assertEqual(r['destination'], 'Downloads/YouTube/' + VID + '.opus')
        self.assertFalse(r['fallback_used'])
        self.assertFalse(any(e[0] == 'download' for e in self.log))

    def test_request_reports_fallback_and_unsupported(self):
        self.use([M4A])
        r = self.y.audio_download_request(URL)
        self.assertEqual(r['filename'], VID + '.m4a'); self.assertTrue(r['fallback_used'])
        self.use([MP3_128, VIDEO_WITH_AUDIO])
        r = self.y.audio_download_request(URL)
        self.assertEqual(r['status'], 'unsupported')
        self.assertEqual(len(self.web.approvals.list_requests()), 1)  # nothing new queued

    def test_request_refuses_oversize(self):
        self.use([dict(OPUS, filesize=900 * 1024 * 1024)])
        with self.assertRaises(PolicyError): self.y.audio_download_request(URL)
        self.assertEqual(self.web.approvals.list_requests(), [])

    def test_download_needs_approval_and_makes_no_network_call(self):
        self.use([OPUS], create_ext='opus')
        self.y.audio_download_request(URL)
        self.log.clear()
        with self.assertRaises(PolicyError): self.y.audio_download(URL)   # pending
        self.approve_latest(approved=False)
        with self.assertRaises(PolicyError): self.y.audio_download(URL)   # denied
        self.assertEqual(self.log, [])  # yt-dlp never constructed

    def test_approved_opus_download_uses_matching_selector_once(self):
        self.use([OPUS, M4A], create_ext='opus')
        self.y.audio_download_request(URL); self.approve_latest()
        with patch.object(YouTubeTools, '_probe', staticmethod(lambda p, e: {'codec_verified': True})):
            out = self.y.audio_download(URL)
        self.assertEqual((out['format'], out['local_file']), ('opus', 'Downloads/YouTube/' + VID + '.opus'))
        init = [e[1] for e in self.log if e[0] == 'init'][-1]
        self.assertEqual(init['format'], 'bestaudio[acodec=opus]')
        self.assertEqual(init['postprocessors'][0]['preferredcodec'], 'opus')
        # One-use: a second download needs a fresh approval.
        (self.ws / 'Downloads/YouTube' / (VID + '.opus')).unlink()
        with self.assertRaises(PolicyError): self.y.audio_download(URL)

    def test_webm_and_m4a_paths(self):
        self.use([OPUS], ffmpeg=None, create_ext='webm')
        r = self.y.audio_download_request(URL); self.assertEqual(r['filename'], VID + '.webm')
        self.approve_latest()
        with patch.object(YouTubeTools, '_probe', staticmethod(lambda p, e: {})):
            self.assertEqual(self.y.audio_download(URL)['format'], 'webm')
        init = [e[1] for e in self.log if e[0] == 'init'][-1]
        self.assertEqual(init['format'], 'bestaudio[acodec=opus][ext=webm]')
        self.assertNotIn('postprocessors', init)

    def test_opus_approved_but_ffmpeg_missing_keeps_approval(self):
        self.use([OPUS], create_ext='opus')
        self.y.audio_download_request(URL); self.approve_latest()
        self.y._ffmpeg = lambda: None
        with self.assertRaises(PolicyError): self.y.audio_download(URL)
        statuses = [r['status'] for r in self.web.approvals.list_requests()]
        self.assertEqual(statuses, ['approved'])  # not spent

    def test_no_silent_substitution_when_file_missing(self):
        self.use([M4A], create_ext='webm')  # downloader produces the wrong thing
        self.y.audio_download_request(URL); self.approve_latest()
        with self.assertRaises(PolicyError) as ctx: self.y.audio_download(URL)
        self.assertIn('no other format', str(ctx.exception))

    def test_existing_file_never_overwritten(self):
        self.use([M4A], create_ext='m4a')
        self.y.audio_download_request(URL); self.approve_latest()
        target = self.ws / 'Downloads/YouTube' / (VID + '.m4a')
        target.parent.mkdir(parents=True); target.write_bytes(b'owner data')
        with self.assertRaises(PolicyError): self.y.audio_download(URL)
        self.assertEqual(target.read_bytes(), b'owner data')


import shutil
import subprocess


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'needs local FFmpeg')
class RealProbe(unittest.TestCase):
    """Real files, real ffprobe: the postcondition check must accept true audio and reject fakes."""
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup); self.d = Path(t.name)

    def make(self, name, *codec):
        out = self.d / name
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2',
                        *codec, str(out)], check=True, timeout=60)
        return out

    def test_real_codecs_verified(self):
        webm = self.make('a.webm', '-c:a', 'libopus')
        for path, ext in [(webm, 'webm'), (self.make('a.m4a', '-c:a', 'aac'), 'm4a'),
                          (self.make('a.mp3', '-c:a', 'libmp3lame', '-b:a', '320k'), 'mp3')]:
            r = YouTubeTools._probe(path, ext)
            self.assertTrue(r['codec_verified'], (ext, r)); self.assertGreater(r['duration_seconds'], 1.5)
        # Lossless remux webm->opus, as yt-dlp does for same-codec FFmpegExtractAudio.
        opus = self.d / 'a.opus'
        subprocess.run(['ffmpeg', '-v', 'error', '-i', str(webm), '-vn', '-c:a', 'copy', str(opus)], check=True, timeout=60)
        self.assertTrue(YouTubeTools._probe(opus, 'opus')['codec_verified'])

    def test_wrong_codec_or_garbage_rejected(self):
        m4a = self.make('b.m4a', '-c:a', 'aac')
        self.assertFalse(YouTubeTools._probe(m4a, 'opus')['codec_verified'])
        junk = self.d / 'c.opus'; junk.write_bytes(b'not audio' * 100)
        self.assertFalse(YouTubeTools._probe(junk, 'opus')['codec_verified'])


if __name__ == '__main__':
    unittest.main()
