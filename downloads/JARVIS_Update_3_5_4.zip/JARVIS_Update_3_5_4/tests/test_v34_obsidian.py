"""v3.4: Obsidian folders (incl. the owner's numbered folders), smarter search, opening one note."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jarvis_core.desktop import Desktop
from jarvis_core.files import FileTools
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.vault import Vault


def make(**extra):
    d = Path(tempfile.mkdtemp())
    cfg = {'workspace': str(d / 'ws'), 'data_dir': str(d / 'data'), 'desktop_mode': 'all_user_apps',
           'permissions': {'files': True, 'app_launch': True, 'desktop_control': True, 'screen': True}}
    cfg.update(extra)
    (d / 'c.json').write_text(json.dumps(cfg))
    s = Settings(d / 'c.json')
    return s, Vault(s, FileTools(s))


class Folders(unittest.TestCase):
    def test_existing_numbered_folder_and_mapping(self):
        s, v = make(obsidian_folders={'Research': '06 Research'})
        v.init()
        (s.workspace / 'JARVIS_Brain' / '06 Research').mkdir()
        v.note('Research', 'Mapped', 'x')                 # mapped standard category
        v.note('06 Research', 'Direct', 'y')              # existing folder by its own name
        self.assertTrue((s.workspace / 'JARVIS_Brain/06 Research/Mapped.md').is_file())
        self.assertTrue((s.workspace / 'JARVIS_Brain/06 Research/Direct.md').is_file())

    def test_unknown_folder_lists_choices_and_never_creates(self):
        s, v = make()
        v.init()
        with self.assertRaises(PolicyError) as cm:
            v.note('07 Mind Maps', 'X', 'y')
        self.assertIn('Research', str(cm.exception)); self.assertIn('existing vault folder', str(cm.exception))
        self.assertFalse((s.workspace / 'JARVIS_Brain/07 Mind Maps').exists())
        for bad in ('../escape', 'Research/sub', '_backups'):
            with self.assertRaises(PolicyError):
                v.note(bad, 'X', 'y')


class Search(unittest.TestCase):
    def test_words_anywhere_ranked_with_context(self):
        s, v = make()
        v.note('Research', 'Fox Notes', 'Intro text. ' * 30 + 'The silver fox carries a blue lantern at night.')
        v.note('Knowledge', 'Lantern Facts', 'Lanterns give light. A lantern, another lantern.')
        v.note('Knowledge', 'Unrelated', 'Nothing here about that.')
        hits = v.search('fox lantern')
        self.assertEqual([h['title'] for h in hits], ['Fox Notes'])
        self.assertIn('silver fox', hits[0]['snippet'])             # text around the match, not the intro
        self.assertEqual(v.search('lantern')[0]['title'], 'Lantern Facts')   # more mentions rank first


class OpenNote(unittest.TestCase):
    def test_open_specific_note_by_title_or_path(self):
        s, v = make()
        v.note('Research', 'Lantern Research', 'body')
        d = Desktop(s)
        sent = []
        with patch.object(d, '_windows_only'), patch('jarvis_core.desktop.os.startfile', sent.append, create=True), \
                patch.object(d, 'list_windows', return_value=[{'exe': 'obsidian.exe'}]):
            r = d.open_obsidian('home', 'lantern research')
            self.assertTrue(r['window_observed'])
            self.assertIn('Lantern%20Research.md', sent[-1])
            d.open_obsidian('home', 'Research/Lantern Research.md')
            with self.assertRaises(PolicyError):
                d.open_obsidian('home', 'No Such Note')
            with self.assertRaises(PolicyError):
                d.open_obsidian('home', '../../secrets.md')


if __name__ == '__main__':
    unittest.main()
