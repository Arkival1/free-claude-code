"""v3.2: background jobs, OpenWhispr loopback bridge, and the one-call video -> notes pipeline."""
import json
import secrets
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from jarvis_core import pipeline as pl
from jarvis_core.download_approvals import DownloadApprovals
from jarvis_core.files import FileTools
from jarvis_core.jobs import Jobs
from jarvis_core.openwhispr import OpenWhispr
from jarvis_core.pipeline import VideoPipeline
from jarvis_core.policy import PolicyError, Settings
from jarvis_core.vault import Vault

URL = 'https://www.youtube.com/watch?v=WftF2zJkvHY'


def make_settings(root: Path, **extra):
    cfg = root / 'config.json'
    data = {'workspace': str(root / 'ws'), 'data_dir': str(root / 'data'),
            'permissions': {'files': True, 'downloads': True, 'web_research': True, 'notes_and_tasks': True}}
    data.update(extra)
    cfg.write_text(json.dumps(data))
    return Settings(cfg)


def wait_for(fn, timeout=20):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = fn()
        if v:
            return v
        time.sleep(0.1)
    raise AssertionError('timed out')


# ---------------- fake OpenWhispr bridge (routes + auth copied from OpenWhispr's cliBridge.js) ----------------
def fake_openwhispr(home: Path, text='Hello from the video. This is step one. Then step two.', models=None):
    token = secrets.token_hex(32)
    seen = []
    models = models if models is not None else [{'model': 'base', 'provider': 'whisper', 'default': True, 'downloaded': True}]

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass

        def _json(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code); self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)

        def _auth(self):
            if self.headers.get('Authorization') != f'Bearer {token}':
                self._json(401, {'error': {'code': 'unauthorized', 'message': 'Unauthorized'}}); return False
            return True

        def do_GET(self):
            if not self._auth(): return
            if self.path == '/v1/health': self._json(200, {'data': {'ok': True, 'version': 1}})
            elif self.path == '/v1/transcribe/models': self._json(200, {'data': models})
            else: self._json(404, {'error': {'code': 'not_found', 'message': 'Not found'}})

        def do_POST(self):
            if not self._auth(): return
            body = json.loads(self.rfile.read(int(self.headers['Content-Length'])) or b'{}')
            seen.append(body)
            if self.path != '/v1/transcribe': return self._json(404, {'error': {'code': 'not_found', 'message': 'Not found'}})
            if not Path(body.get('path', '')).is_file(): return self._json(404, {'error': {'code': 'NOT_FOUND', 'message': 'No file'}})
            self._json(200, {'data': {'text': text, 'provider': 'whisper', 'model': 'base'}})

    srv = None
    for port in range(8200, 8220):
        try:
            srv = ThreadingHTTPServer(('127.0.0.1', port), H); break
        except OSError:
            continue
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    bridge = home / '.openwhispr' / 'cli-bridge.json'
    bridge.parent.mkdir(parents=True, exist_ok=True)
    bridge.write_text(json.dumps({'version': 1, 'port': srv.server_address[1], 'token': token}))
    return srv, bridge, token, seen


class JobsTests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup)
        self.settings = make_settings(Path(t.name)); self.jobs = Jobs(self.settings)

    def test_done_failed_cancel_stop(self):
        ok = self.jobs.start('t', 'ok', lambda ctx, x: {'x': x * 2}, x=21)
        self.assertEqual(self.jobs.get(ok['id'], wait_seconds=5)['result'], {'x': 42})
        bad = self.jobs.start('t', 'bad', lambda ctx: 1 / 0)
        out = wait_for(lambda: (j := self.jobs.get(bad['id'])) and j['status'] == 'failed' and j)
        self.assertIn('ZeroDivisionError', out['error'])

        def slow(ctx):
            ctx.stage('working', 'long')
            ctx.sleep(30)
        c = self.jobs.start('t', 'slow', slow)
        wait_for(lambda: self.jobs.get(c['id'])['stage'] == 'working')
        self.jobs.cancel(c['id'])
        self.assertEqual(wait_for(lambda: (j := self.jobs.get(c['id']))['status'] == 'cancelled' and j)['status'], 'cancelled')
        s = self.jobs.start('t', 'stop', slow)
        wait_for(lambda: self.jobs.get(s['id'])['stage'] == 'working')
        self.settings.kill_switch_path().write_text('stop')
        self.assertIn('STOP', wait_for(lambda: (j := self.jobs.get(s['id']))['status'] == 'cancelled' and j)['error'])
        with self.assertRaises(PolicyError): self.jobs.start('t', 'blocked', slow)
        self.settings.kill_switch_path().unlink()

    def test_stale_and_bad_ids(self):
        j = self.jobs.start('t', 'x', lambda ctx: ctx.sleep(1))
        data = json.loads(self.jobs._path(j['id']).read_text()); data['heartbeat'] = 0; data['status'] = 'running'
        with patch.object(self.jobs, '_read', return_value=data):
            self.assertEqual(self.jobs.get(j['id'])['status'], 'stale')
        for bad in ('../x', 'a' * 60, ''):
            with self.assertRaises(PolicyError): self.jobs.get(bad)
        wait_for(lambda: self.jobs.get(j['id'])['status'] == 'done')
        self.assertEqual(self.jobs.get(j['id'], wait_seconds='999')['status'], 'done')   # text + too big: capped, not an error
        with self.assertRaises(PolicyError): self.jobs.get(j['id'], wait_seconds='soon')


class OpenWhisprTests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup); self.root = Path(t.name)
        self.srv, self.bridge, self.token, self.seen = fake_openwhispr(self.root)
        self.addCleanup(self.srv.shutdown)
        self.ow = OpenWhispr(self.bridge)

    def test_status_never_leaks_key(self):
        st = self.ow.status()
        self.assertTrue(st['can_transcribe_files']); self.assertEqual(st['default_model']['model'], 'base')
        self.assertNotIn(self.token, json.dumps(st))

    def test_transcribe_sends_path_only(self):
        audio = self.root / 'a.opus'; audio.write_bytes(b'OggS....')
        out = self.ow.transcribe(audio)
        self.assertIn('step one', out['text']); self.assertEqual(self.seen[-1], {'path': str(audio)})
        with self.assertRaises(PolicyError): self.ow.transcribe(Path('relative.opus'))

    def test_refuses_odd_bridge_files_and_reports_closed_app(self):
        good = json.loads(self.bridge.read_text())
        for bad in ({**good, 'port': 80}, {**good, 'port': '8200'}, {**good, 'token': 'x'}):
            self.bridge.write_text(json.dumps(bad))
            with self.assertRaises(PolicyError): self.ow._bridge()
        self.bridge.write_text(json.dumps({**good, 'token': 'ab' * 32}))   # stale key after app restart
        with self.assertRaises(PolicyError) as cm: self.ow._call('GET', '/v1/health')
        self.assertIn('refused the key', str(cm.exception))
        self.bridge.unlink()
        self.assertFalse(self.ow.status()['available'])

    def test_no_default_model(self):
        srv, bridge, _, _ = fake_openwhispr(self.root / 'h2', models=[{'model': 'small', 'default': True, 'downloaded': False}])
        self.addCleanup(srv.shutdown)
        st = OpenWhispr(bridge).status()
        self.assertFalse(st['can_transcribe_files']); self.assertIn('Speech to Text', st['reason'])


class FakeConverter:
    def __init__(self, root):
        self.root, self.calls = root, []

    def find_formats(self, url, ctx=None):
        self.calls.append('find')
        return {'choice': {'kind': 'opus', 'text': 'OPUS opus'}, 'formats_on_site': ['320kbps mp3', 'OPUS opus']}

    def download(self, url, kind, dest_dir, filename, ctx=None, max_bytes=0, verify_wait=0, before_click=None):
        if before_click:
            before_click()          # the pipeline spends the approval here
        self.calls.append('download')
        Path(dest_dir).mkdir(parents=True, exist_ok=True)
        (Path(dest_dir) / filename).write_bytes(b'OggS' + b'0' * 100)
        return {'bytes': 104, 'container': 'ogg', 'verification': {'codec_checked': False}}


class FakeLMStudio:
    def __init__(self):
        self.requests = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, obj):
                b = json.dumps(obj).encode(); self.send_response(200)
                self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self): self._json({'data': [{'id': 'text-embedding-x'}, {'id': 'qwen3.5-4b'}]})

            def do_POST(self):
                req = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                outer.requests.append(req)
                self._json({'choices': [{'message': {'content': '<think>hmm</think>## Summary\nIt explains step one and step two.'}}]})
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f'http://127.0.0.1:{self.srv.server_address[1]}/v1'


class PipelineTests(unittest.TestCase):
    def build(self, **cfg):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup); root = Path(t.name)
        self.settings = make_settings(root, **cfg)
        files = FileTools(self.settings)
        self.approvals = DownloadApprovals(self.settings)
        self.srv, bridge, _, self.seen = fake_openwhispr(root / 'home')
        self.addCleanup(self.srv.shutdown)
        self.lm = FakeLMStudio(); self.addCleanup(self.lm.srv.shutdown)
        self.conv = FakeConverter(root)
        self.jobs = Jobs(self.settings)
        self.vault = Vault(self.settings, files)
        self.p = VideoPipeline(self.settings, files, self.vault, youtube=None, approvals=self.approvals,
                               openwhispr=OpenWhispr(bridge), converter=self.conv, jobs=self.jobs)
        self.p._title = lambda url: '5 Years Later | Episode 1'
        self.files, self.root = files, root

    def approve_when_asked(self, approve=True):
        def run():
            j = wait_for(lambda: next((x for x in self.jobs.list() if x.get('approval') and x['status'] == 'waiting'), None))
            self.approvals.owner_decide(j['approval']['request_id'], approve)
        threading.Thread(target=run, daemon=True).start()

    def test_full_run_waits_for_owner_then_saves_transcript_and_notes(self):
        self.build()
        with patch.object(pl, 'LMSTUDIO', self.lm.url):
            job = self.p.start(URL)
            waiting = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] == 'waiting' and j)
            self.assertEqual(waiting['approval']['filename'], 'WftF2zJkvHY.ytmp3.opus')
            self.assertEqual(self.conv.calls, ['find'])               # nothing downloaded before approval
            self.approve_when_asked()
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)
        r = done['result']
        self.assertEqual(self.conv.calls, ['find', 'download'])
        self.assertIn('OpenWhispr', r['transcript_engine'])
        transcript = self.files.read_text(r['transcript_files'][0])
        self.assertIn('This is step one.\nThen step two.', transcript)     # one sentence per line
        self.assertIn(URL, transcript)
        notes = self.files.read_text(r['notes_file'])
        self.assertIn('It explains step one', notes); self.assertNotIn('<think>', notes)
        self.assertEqual(r['notes_written_by'], 'qwen3.5-4b')            # skipped the embedding model
        self.assertIn('step one', self.lm.requests[0]['messages'][1]['content'])
        self.assertEqual(self.approvals.latest(URL, 'WftF2zJkvHY.ytmp3.opus')['status'], 'used')
        self.assertTrue(list((self.settings.workspace / 'JARVIS_Brain' / 'Daily').glob('*.md')))

    def test_denied_means_nothing_downloaded(self):
        self.build(video_pipeline={'fallback_source': 'ytmp3'})
        job = self.p.start(URL)
        self.approve_when_asked(approve=False)
        done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'failed'); self.assertIn('denied', done['error'])
        self.assertEqual(self.conv.calls, ['find'])

    def test_openwhispr_closed_falls_back_to_builtin_whisper(self):
        self.build()
        self.srv.shutdown()
        class YT:
            def transcribe_full(self, rel):
                return {'lines': ['[00:00:01] hello'], 'language': 'en', 'engine': 'built-in Whisper (faster-whisper base, CPU)'}
        self.p.youtube = YT()
        with patch.object(pl, 'LMSTUDIO', 'http://127.0.0.1:9/v1'):    # LM Studio off -> notes stub, not a failure
            job = self.p.start(URL, write_notes=True)
            self.approve_when_asked()
            done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done)
        self.assertIn('built-in Whisper', done['result']['transcript_engine'])
        self.assertEqual(done['result']['notes_written_by'], '')
        self.assertIn('not available', self.files.read_text(done['result']['notes_file']))

    def test_reuses_audio_already_downloaded(self):
        self.build()
        d = self.settings.workspace / 'Downloads' / 'YouTube'; d.mkdir(parents=True)
        (d / 'WftF2zJkvHY.ytmp3.opus').write_bytes(b'OggS' + b'1' * 50)
        job = self.p.start(URL, write_notes=False)
        done = wait_for(lambda: (j := self.jobs.get(job['id']))['status'] in ('done', 'failed') and j, 30)
        self.assertEqual(done['status'], 'done', done); self.assertEqual(self.conv.calls, [])

    def test_bad_inputs_and_permissions(self):
        self.build()
        for bad in ('https://evil.example/x', 'not a url'):
            with self.assertRaises(PolicyError): self.p.start(bad)
        with self.assertRaises(PolicyError): self.p.start(URL, source='torrent')
        data = json.loads(self.settings.path.read_text()); data['permissions']['downloads'] = False
        self.settings.path.write_text(json.dumps(data))
        with self.assertRaises(PolicyError): self.p.start(URL)


if __name__ == '__main__':
    unittest.main()
