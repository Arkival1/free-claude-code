"""v2.8.2 offline regression tests: execution routing, brain, download-approval gate."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
from jarvis_core.policy import Settings
from jarvis_core.files import FileTools
from jarvis_core.vault import Vault
import agent_runner as a

class BrainCreationTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        root=Path(t.name)
        conf=root/'config.json'
        conf.write_text(json.dumps({'workspace':str(root/'workspace'),
            'data_dir':str(root/'data'),'permissions':{'files':True}}),encoding='utf8')
        self.settings=Settings(conf)
        self.vault=Vault(self.settings,FileTools(self.settings))

    def test_build_real_wiki_and_canvas(self):
        outcome=self.vault.build_second_brain()
        self.assertEqual(outcome['status'],'created_or_verified')
        self.assertGreaterEqual(len(outcome['created']),8)
        for name in outcome['created']:
            self.assertTrue(self.settings.in_workspace(name).is_file())
        diagram=json.loads(self.settings.in_workspace(outcome['canvas']).read_text('utf8'))
        self.assertEqual(len(diagram['nodes']),8)
        self.assertGreaterEqual(len(diagram['edges']),7)
        self.assertIn('[[Knowledge Index]]',self.settings.in_workspace(outcome['dashboard']).read_text('utf8'))

    def test_preserves_existing_note_and_canvas(self):
        self.vault.init()
        existing='JARVIS_Brain/Knowledge/Knowledge Index.md'
        custom='DO NOT OVERWRITE MY KNOWLEDGE'
        self.settings.in_workspace(existing).write_text(custom,encoding='utf8')
        self.vault.build_second_brain();self.vault.build_second_brain()
        self.assertEqual(self.settings.in_workspace(existing).read_text('utf8'),custom)

    def test_respects_file_permission(self):
        doc=json.loads(self.settings.path.read_text('utf8'))
        doc['permissions']['files']=False
        self.settings.path.write_text(json.dumps(doc),encoding='utf8')
        with self.assertRaises(ValueError):self.vault.build_second_brain()

class TaskRoutingTests(unittest.TestCase):
    def test_obsidian_focus(self):
        names={t['function']['name'] for t in a.focused_tools('Create Obsidian mind map')}
        self.assertIn('obsidian_second_brain_build',names)
        self.assertNotIn('official_download',names)

    def test_combined_video_and_brain_tools(self):
        names={t['function']['name'] for t in a.focused_tools('Build Obsidian brain from YouTube captions')}
        self.assertIn('youtube_transcript',names)
        self.assertIn('obsidian_second_brain_build',names)

    def test_kickoff_calls_only_explicit_requested_actions(self):
        fake=Mock(return_value={'status':'created'})
        out=a.kickoff_goal('Create your Obsidian second brain',call=fake)
        self.assertEqual(out[0],'obsidian_second_brain_build')
        fake.assert_called_once_with('obsidian_second_brain_build',{})
        fake.reset_mock()
        self.assertIsNone(a.kickoff_goal('How does Obsidian work?',call=fake))
        fake.assert_not_called()
        out=a.kickoff_goal('Transcribe https://youtu.be/dQw4w9WgXcQ',call=fake)
        self.assertEqual(out[0],'youtube_transcript')
        self.assertEqual(fake.call_args.args[0],'youtube_transcript')
        self.assertIsNone(a.kickoff_goal('Please browse this random website',call=fake))

    def test_never_kickoff_download(self):
        fake=Mock()
        self.assertIsNone(a.kickoff_goal('Download https://example.org/model.bin',call=fake))
        fake.assert_not_called()

class SetupOwnerGate(unittest.TestCase):
    def test_whisper_model_does_not_download_without_yes(self):
        import install_whisper_model
        with tempfile.TemporaryDirectory() as root:
            cf=Path(root)/'config.json'
            cf.write_text(json.dumps({'workspace':str(Path(root)/'workspace'),
                'data_dir':str(Path(root)/'data'),'permissions':{'files':True}}),encoding='utf8')
            with patch.object(install_whisper_model,'Settings',side_effect=lambda _:Settings(cf)):
                self.assertFalse(install_whisper_model.main(input_fn=lambda _: 'NO'))

if __name__=='__main__':unittest.main()

class ModelToolFormatTests(unittest.TestCase):
    def test_backend_fallback_from_required_to_auto(self):
        from jarvis_core.mission import MissionStore
        with tempfile.TemporaryDirectory() as root:
            home=Path(root)
            cfg=home/'config.json'
            cfg.write_text(json.dumps({'workspace':str(home/'work'),'data_dir':str(home/'data'),
                 'permissions':{'files':True}}),encoding='utf8')
            settings=Settings(cfg)
            store=MissionStore(settings)
            class Resp:
                def __init__(self,status,text,msg):
                    self.status_code=status;self.text=text;self.msg=msg
                def raise_for_status(self):
                    if self.status_code>=400:raise ValueError('bad request')
                def json(self):return {'choices':[{'message':self.msg}]}
            class Session:
                seen=[]
                def __init__(self):self.trust_env=False
                def post(self,endpoint,json,timeout):
                    self.seen.append(json['tool_choice'])
                    if len(self.seen)==1:
                        return Resp(400,'tool_choice required unsupported',{})
                    return Resp(200,'',{'content':'TASK_COMPLETE: Test done.'})
            with patch.object(a,'SETTINGS',settings), patch.object(a,'MISSIONS',store), \
                patch.object(a,'memory_hints',lambda _:'') , patch.object(a,'log',lambda _:None), \
                patch.object(a.requests,'Session',Session):
                self.assertTrue(a.run_agent('test completion','local'))
            self.assertEqual(Session.seen,['required','auto'])
