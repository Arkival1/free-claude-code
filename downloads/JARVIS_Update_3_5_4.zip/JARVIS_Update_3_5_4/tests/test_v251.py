"""v2.8 migration tests: old forty-turn cap must no longer apply."""
import inspect
import unittest
from unittest.mock import patch
import agent_runner as a

class TestContinuousBudget(unittest.TestCase):
    def test_default_is_unlimited(self):
        self.assertIsNone(a.DEFAULT_MAX_TURNS)
        self.assertIsNone(inspect.signature(a.run_agent).parameters['max_steps'].default)
    def test_explicit_owner_budget_can_exceed_forty(self):
        class Resp:
            def raise_for_status(self):pass
            def json(self):return {'choices':[{'message':{'content':'Still working','tool_calls':[
                {'id':'1','type':'function','function':{'name':'workspace_list','arguments':'{"folder":"."}'}}
            ]}}]}
        class Session:
            count=0
            def __init__(self):self.trust_env=True
            def post(self,*args,**kwargs):
                type(self).count+=1
                return Resp()
        with patch.object(a.requests,'Session',Session), patch.dict(a.ACTIONS,{'workspace_list':lambda folder:[]}), patch.object(a,'log',lambda _:None):
            # Should pause for lack of progress, not due to 40 turn cap.
            self.assertFalse(a.run_agent('test','model',max_steps=41))
            self.assertLess(Session.count,41)

if __name__=='__main__':unittest.main()
