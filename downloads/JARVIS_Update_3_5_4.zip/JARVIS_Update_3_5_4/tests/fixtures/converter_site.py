"""A local stand-in for ytmp3.zone + its embedded converter, built from the real site's
observed structure (26 Nov 2026): link box + Start, then an iframe from another origin
with a format table of Download buttons, a 'Verification...' human check, a pop-up ad,
and a second Download link that appears after 'Converting...'."""
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

MAIN = """<!doctype html><html><body><h1>YTMP3</h1>
<form id=f><input type=text placeholder="Search or paste a YouTube link here..."><button type=submit>Start</button></form>
<script>
document.getElementById('f').onsubmit = (e) => { e.preventDefault();
  const v = new URL(document.querySelector('input').value).searchParams.get('v');
  location.href = '/en/download/?v=' + v; };
</script></body></html>"""

DOWNLOAD_PAGE = """<!doctype html><html><body><h1>Download</h1>
<iframe id=conv width=800 height=600></iframe>
<script>const v = new URLSearchParams(location.search).get('v');
document.getElementById('conv').src = 'http://localhost:%PORT%/v3/full?videoId=' + v + '%EXTRA%';</script>
</body></html>"""

FRAME = """<!doctype html><html><body>
<div id=verify>%VERIFY%</div>
<h2>5 Years Later | Episode 1</h2><button>Audio</button><button>Video</button>
<table>
<tr><td>320kbps</td><td>mp3</td><td><button type=submit data-f=mp3-320>Download</button></td></tr>
<tr><td>128kbps</td><td>mp3</td><td><button type=submit data-f=mp3-128>Download</button></td></tr>
<tr><td>M4A</td><td>m4a</td><td><button type=submit data-f=m4a>Download</button></td></tr>
<tr><td>OPUS</td><td>opus</td><td><button type=submit data-f=opus>Download</button></td></tr>
</table>
<script>
const mode = new URLSearchParams(location.search).get('serve') || 'opus';
if (%VERIFY_MS% > 0) setTimeout(() => { document.getElementById('verify').textContent = ''; }, %VERIFY_MS%);
let adClicks = %POPUNDER%, adNav = %ADNAV%;
document.querySelectorAll('button[data-f]').forEach(b => b.onclick = () => {
  if (adNav) { adNav = false; window.top.location = 'http://127.0.0.2:%PORT%/ad?nav=1'; return; }  // ad hijacks the whole tab
  window.open('http://127.0.0.2:%PORT%/ad', '_blank');           // pop-up ad, like real converters
  if (adClicks > 0) { adClicks -= 1; return; }                    // pop-under: this click ONLY opened the ad
  const cell = b.parentElement; b.textContent = 'Converting...';
  setTimeout(() => { cell.innerHTML = '<a href="http://127.0.0.1:%PORT%/file/' + mode + '?f=' + b.dataset.f + '">Download</a>'; }, 1500);
});
</script></body></html>"""


def serve(audio_bytes: bytes, verify_ms: int = 0, popunder: int = 0, ad_navigates: bool = False):
    """Start the fixture on a free port. Returns (server, port, hits)."""
    hits = []

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, body, ctype='text/html', extra=None):
            data = body.encode() if isinstance(body, str) else body
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            u = urlsplit(self.path)
            hits.append(u.path + ('?' + u.query if u.query else ''))
            port = str(self.server.server_address[1])
            q = parse_qs(u.query)
            if u.path == '/en/':
                self._send(MAIN)
            elif u.path == '/en/download/':
                self._send(DOWNLOAD_PAGE.replace('%PORT%', port).replace('%EXTRA%', '&serve=' + self.server.serve_mode))
            elif u.path == '/v3/full':
                self._send(FRAME.replace('%PORT%', port).replace('%VERIFY_MS%', str(verify_ms))
                           .replace('%VERIFY%', 'Verification is taking longer than expected.' if verify_ms else '')
                           .replace('%POPUNDER%', str(self.server.popunder)).replace('%ADNAV%', 'true' if self.server.ad_navigates else 'false'))
                self.server.ad_navigates = False      # like real ad networks: hijack once per visit
            elif u.path == '/ad':
                self._send('<h1>BUY NOW</h1>')
            elif u.path.startswith('/file/'):
                kind = u.path.rsplit('/', 1)[1]
                body = audio_bytes if kind == 'opus' else b'<html>not audio</html>' if kind == 'html' else b'MZ\x90\x00fake exe'
                self._send(body, 'application/octet-stream',
                           {'Content-Disposition': f'attachment; filename="video-{q.get("f", ["x"])[0]}.opus"'})
            else:
                self.send_response(404); self.end_headers()

    srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
    srv.serve_mode = 'opus'
    srv.popunder, srv.ad_navigates = popunder, ad_navigates
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1], hits
