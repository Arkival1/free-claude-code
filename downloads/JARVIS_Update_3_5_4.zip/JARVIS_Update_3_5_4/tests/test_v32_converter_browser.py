"""v3.2: drive a REAL Chromium over CDP through a local copy of the converter site's structure."""
import glob
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fixtures.converter_site import serve  # noqa: E402
from jarvis_core.converter import Converter, Site  # noqa: E402
from jarvis_core.policy import PolicyError, Settings  # noqa: E402

CHROME = os.environ.get('JARVIS_TEST_CHROME') or next(iter(sorted(glob.glob('/opt/pw-browsers/chromium-*/chrome-linux64/chrome'))), '')
VIDEO = 'https://www.youtube.com/watch?v=WftF2zJkvHY'


def free_port():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p


class Ctx:
    def __init__(self): self.stages, self.logs, self.values = [], [], {}
    def stage(self, n, d='', **k): self.stages.append(n)
    def log(self, t): self.logs.append(t)
    def set(self, **v): self.values.update(v)
    def check(self): pass
    def sleep(self, s): time.sleep(s)


@unittest.skipUnless(CHROME and shutil.which('ffmpeg'), 'needs a local Chromium and FFmpeg')
class ConverterInRealBrowser(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        audio = root / 'a.opus'
        subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-c:a', 'libopus', str(audio)], check=True)
        cls.srv, cls.port, cls.hits = serve(audio.read_bytes(), verify_ms=2500)
        cls.cdp_port = free_port()
        cls.chrome = subprocess.Popen([CHROME, '--headless=new', f'--remote-debugging-port={cls.cdp_port}', '--no-sandbox',
                                       f'--user-data-dir={root / "profile"}', '--no-first-run', 'about:blank'],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        cfg = root / 'config.json'
        cfg.write_text(json.dumps({'workspace': str(root / 'ws'), 'data_dir': str(root / 'data'), 'permissions': {'files': True}}))
        cls.settings = Settings(cfg)
        site = Site(f'http://127.0.0.1:{cls.port}/en/', frozenset({'127.0.0.1'}), frozenset({'localhost'}), https_only=False)
        cls.conv = Converter(cls.settings, None, site=site, cdp_url=f'http://127.0.0.1:{cls.cdp_port}')
        cls.dest = root / 'ws' / 'Downloads' / 'YouTube'

    def setUp(self):
        # Fresh page per test, so each test sees the site behaviour it configured.
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.connect_over_cdp(f'http://127.0.0.1:{self.cdp_port}')
            ctx = b.contexts[0]
            fresh = ctx.new_page()
            for p in list(ctx.pages):
                if p is not fresh:
                    p.close()
            fresh.goto('about:blank')
            b.close()

    @classmethod
    def tearDownClass(cls):
        cls.chrome.terminate(); cls.chrome.wait(10); cls.srv.shutdown(); cls.tmp.cleanup()

    def test_1_find_formats_reads_real_table(self):
        out = self.conv.find_formats(VIDEO, Ctx())
        self.assertEqual(out['choice']['kind'], 'opus')
        self.assertIn('320kbps mp3', ' '.join(out['formats_on_site']))
        self.assertIn('/en/download/?v=WftF2zJkvHY', self.hits)   # typed link really submitted

    def test_2_download_waits_for_human_check_then_catches_verified_file(self):
        self.srv.serve_mode = 'opus'
        ctx = Ctx()
        out = self.conv.download(VIDEO, 'opus', self.dest, 'WftF2zJkvHY.ytmp3.opus', ctx, verify_wait=30)
        p = Path(out['local_path'])
        self.assertTrue(p.is_file()); self.assertEqual(p.read_bytes()[:4], b'OggS')
        self.assertEqual(out['container'], 'ogg')
        self.assertEqual(out['clicks'], 2)                          # one click per button, second after "Converting..."
        self.assertIn('human_check', ctx.stages)                   # waited for the owner's human check
        self.assertTrue(any('pop-up' in l for l in ctx.logs), ctx.logs)
        self.assertTrue(any('f=opus' in h for h in self.hits), self.hits)   # clicked the OPUS row, not mp3
        self.assertEqual(list((self.settings.data_dir / 'quarantine').iterdir()), [])
        with self.assertRaises(PolicyError):                        # never overwrites
            self.conv.download(VIDEO, 'opus', self.dest, 'WftF2zJkvHY.ytmp3.opus', Ctx(), verify_wait=30)

    def test_4_popunder_ads_closed_and_download_clicked_again(self):
        # Real ytmp3.zone behaviour seen by the owner: the first clicks only open ad tabs.
        self.srv.serve_mode = 'opus'; self.srv.popunder = 2
        ctx = Ctx()
        dest = Path(self.tmp.name) / 'ws2'
        out = self.conv.download('https://youtu.be/WftF2zJkvHY', 'opus', dest, 'pop.opus', ctx, verify_wait=30, retry_wait=2)
        self.assertEqual(Path(out['local_path']).read_bytes()[:4], b'OggS')
        self.assertGreaterEqual(out['clicks'], 3)
        self.assertTrue(any('clicked Download again' in l for l in ctx.logs), ctx.logs)
        self.assertTrue(any('Closed pop-up' in l for l in ctx.logs), ctx.logs)
        self.srv.popunder = 0

    def test_5_ad_that_hijacks_the_tab_is_undone(self):
        self.srv.serve_mode = 'opus'; self.srv.ad_navigates = True
        ctx = Ctx()
        dest = Path(self.tmp.name) / 'ws3'
        out = self.conv.download('https://youtu.be/WftF2zJkvHY', 'opus', dest, 'nav.opus', ctx, verify_wait=30, retry_wait=2)
        self.assertTrue(Path(out['local_path']).is_file())
        self.assertTrue(any('went back to the converter' in l for l in ctx.logs), ctx.logs)
        self.srv.ad_navigates = False

    def test_6_gives_up_cleanly_when_no_download_ever_starts(self):
        self.srv.serve_mode = 'opus'; self.srv.popunder = 99
        with self.assertRaises(PolicyError) as cm:
            self.conv.download('https://youtu.be/WftF2zJkvHY', 'opus', Path(self.tmp.name) / 'ws4', 'never.opus', Ctx(),
                               verify_wait=30, retry_wait=1, max_tries=3)
        self.assertIn('Clicked Download 3 times', str(cm.exception))
        self.assertFalse((Path(self.tmp.name) / 'ws4' / 'never.opus').exists())
        self.srv.popunder = 0

    def test_3_non_audio_is_deleted_never_kept(self):
        for mode in ('html', 'exe'):
            with self.subTest(mode=mode):
                self.srv.serve_mode = mode
                # fresh page so the frame is re-created with the new serve mode
                with self.assertRaises(PolicyError) as cm:
                    self.conv.download('https://youtu.be/WftF2zJkvHY', 'opus', self.dest, f'bad-{mode}.opus', Ctx(), verify_wait=30)
                self.assertIn('not audio', str(cm.exception))
                self.assertFalse((self.dest / f'bad-{mode}.opus').exists())
                self.assertEqual(list((self.settings.data_dir / 'quarantine').iterdir()), [])


if __name__ == '__main__':
    unittest.main()
