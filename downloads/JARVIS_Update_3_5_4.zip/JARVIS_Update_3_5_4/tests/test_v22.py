import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jarvis_core.policy import Settings, PolicyError
from jarvis_core.download_approvals import DownloadApprovals
from jarvis_core.coding_lab import CodingLab
from jarvis_core.desktop import Desktop


def fixture(tmp):
    config=Path(tmp)/'config.json'
    workspace=Path(tmp)/'workspace'
    datadir=Path(tmp)/'data'
    config.write_text(json.dumps({
        'workspace':str(workspace), 'data_dir':str(datadir),
        'permissions':{'files':True,'downloads':True,'coding_lab':False,'desktop_control':True},
        'desktop_mode':'approved_apps','approved_desktop_exes':['notepad.exe'],
        'apps':{},'max_file_kb':256
    }),encoding='utf8')
    return Settings(config)

class TestDownloadOwnerApproval(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.settings=fixture(self.temp.name)
        self.ap=DownloadApprovals(self.settings)
    def tearDown(self):self.temp.cleanup()

    def test_exact_owner_approval_once(self):
        url='https://example.com/obsidian-installer.exe'
        r=self.ap.request(url,'setup.exe')
        self.assertEqual(r['status'],'pending')
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'setup.exe')
        self.ap.owner_decide(r['request_id'],True)
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'different.exe')
        with self.assertRaises(PolicyError):self.ap.consume_once('https://example.com/other.exe','setup.exe')
        self.ap.consume_once(url,'setup.exe')
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'setup.exe')

    def test_denial_is_final(self):
        url='https://example.org/a.zip'
        r=self.ap.request(url,'a.zip')
        self.ap.owner_decide(r['request_id'],False)
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'a.zip')
        self.assertEqual(self.ap.list_requests()[0]['status'],'denied')

    def test_invalid_urls_rejected(self):
        for link in ('http://example.com/file','https://127.0.0.1/malware','file:///C:/tmp/x','https://localhost/f'):
            with self.subTest(link=link):
                with self.assertRaises(PolicyError):self.ap.request(link,'x.txt')

    def test_privilege_revocation_blocks_approved_link(self):
        url='https://example.net/data.zip'
        request=self.ap.request(url,'data.zip')
        self.ap.owner_decide(request['request_id'],True)
        config=self.settings.path
        data=json.loads(config.read_text())
        data['permissions']['downloads']=False
        config.write_text(json.dumps(data))
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'data.zip')

    def test_stop_file_blocks_request_and_download(self):
        url='https://example.net/data.zip'
        request=self.ap.request(url,'data.zip')
        self.ap.owner_decide(request['request_id'],True)
        self.settings.kill_switch_path().touch()
        with self.assertRaises(PolicyError):self.ap.consume_once(url,'data.zip')

class TestBroadMode(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.settings=fixture(self.temp.name)
        self.desktop=Desktop(self.settings)
    def tearDown(self):self.temp.cleanup()

    def test_allowed_app_only_by_default(self):
        self.assertTrue(self.desktop._allowed_process({'exe':'notepad.exe'}))
        self.assertFalse(self.desktop._allowed_process({'exe':'code.exe'}))

    def test_broad_mode_blocks_credentials_and_elevation(self):
        data=json.loads(self.settings.path.read_text())
        data['desktop_mode']='all_user_apps'
        self.settings.path.write_text(json.dumps(data))
        self.assertTrue(self.desktop._allowed_process({'exe':'code.exe','elevated':False}))
        self.assertTrue(self.desktop._allowed_process({'exe':'game.exe','elevated':False}))
        self.assertFalse(self.desktop._allowed_process({'exe':'code.exe','elevated':True}))
        self.assertFalse(self.desktop._allowed_process({'exe':'code.exe'}))
        self.assertFalse(self.desktop._allowed_process({'exe':'cmd.exe','elevated':False}))
        self.assertFalse(self.desktop._allowed_process({'exe':'bitwarden.exe','elevated':False}))

class TestCodingLab(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.settings=fixture(self.temp.name)
        self.lab=CodingLab(self.settings)
    def tearDown(self):self.temp.cleanup()

    def test_cannot_run_directly_on_host_or_without_permission(self):
        self.settings.workspace.mkdir()
        (self.settings.workspace/'hello.py').write_text('print(1)')
        with self.assertRaises(PolicyError):self.lab.python_run('hello.py')
        cfg=json.loads(self.settings.path.read_text())
        cfg['permissions']['coding_lab']=True
        self.settings.path.write_text(json.dumps(cfg))
        with patch('shutil.which',return_value=None):
            with self.assertRaisesRegex(PolicyError,'Docker is not installed'):
                self.lab.python_run('hello.py')

if __name__=='__main__': unittest.main()
