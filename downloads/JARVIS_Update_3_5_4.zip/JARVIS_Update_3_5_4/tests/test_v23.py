import json
from pathlib import Path
import tempfile
import unittest
from urllib.request import urlopen
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.files import FileTools
from jarvis_core.memory import Memory
from jarvis_core.projects import ProjectTools
from jarvis_core.vault import Vault
from jarvis_core.activity import Activity

class V23(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        root=Path(self.tmp.name)
        self.conf=root/'config.json'
        self.conf.write_text(json.dumps({'workspace':str(root/'workspace'),'data_dir':str(root/'data'),
           'permissions':{'files':True,'notes_and_tasks':True,'preview_local':False}}),encoding='utf8')
        self.settings=Settings(self.conf)
        self.files=FileTools(self.settings)
        self.memory=Memory(self.settings)
        self.memory.approve_project_by_owner('JARVIS_Demo')
        self.projects=ProjectTools(self.settings,self.files,self.memory)
        self.vault=Vault(self.settings,self.files)
    def enable_preview(self):
        d=json.loads(self.conf.read_text());d['permissions']['preview_local']=True
        self.conf.write_text(json.dumps(d))
    def test_approved_scaffold_and_no_overwrite(self):
        r=self.projects.create('JARVIS_Demo','First_Website','website')
        self.assertEqual(len(r['files_created']),3)
        self.assertIn('JARVIS',self.files.read_text('JARVIS_Demo/Projects/First_Website/index.html'))
        with self.assertRaises(PolicyError):self.projects.create('JARVIS_Demo','First_Website','website')
    def test_scaffold_unauthorized_project(self):
        with self.assertRaises(PolicyError):self.projects.create('Other','App','python')
    def test_scaffold_rejects_escape(self):
        for name in ('../escape','C:\\bad','a/../../', 'con','x\\y'):
            with self.assertRaises(PolicyError):self.projects.create('JARVIS_Demo',name,'website')
    def test_scaffold_families_and_python_syntax(self):
        self.projects.create('JARVIS_Demo','P','python')
        r=self.projects.check('JARVIS_Demo','P')
        self.assertEqual(r['python_syntax'][0]['syntax'],'ok')
        self.projects.create('JARVIS_Demo','G','godot')
        r=self.projects.check('JARVIS_Demo','G')
        self.assertIn('main.gd',r['files'])
        self.projects.create('JARVIS_Demo','Game','browser_game')
        r=self.projects.check('JARVIS_Demo','Game')
        self.assertEqual(r['missing_local_assets'],[])
    def test_project_check_detects_missing_asset(self):
        self.projects.create('JARVIS_Demo','Website','website')
        self.files.write_text('JARVIS_Demo/Projects/Website/index.html','<script src="not_found.js"></script>',overwrite=True)
        self.assertEqual(len(self.projects.check('JARVIS_Demo','Website')['missing_local_assets']),1)
    def test_preview_disabled_and_loopback_optin(self):
        self.projects.create('JARVIS_Demo','Game','browser_game')
        with self.assertRaises(PolicyError):self.projects.preview_start('JARVIS_Demo','Game')
        self.enable_preview()
        info=self.projects.preview_start('JARVIS_Demo','Game')
        try:
            self.assertTrue(info['url'].startswith('http://127.0.0.1:'))
            with urlopen(info['url'],timeout=2) as response:
                self.assertIn(b'Star Collector',response.read())
        finally:self.projects.preview_stop()
    def test_obsidian_vault_notes_and_search(self):
        self.vault.init()
        self.vault.note('Research','Physics','Conservation of momentum','Newton')
        r=self.vault.search('momentum')
        self.assertEqual(len(r),1)
        self.assertIn('[[Newton]]',self.files.read_text('JARVIS_Brain/Research/Physics.md'))
    def test_obsidian_daily_append_not_replace(self):
        self.vault.daily('Created a project.')
        self.vault.daily('Reviewed the project.')
        import datetime
        today=datetime.date.today().isoformat()
        text=self.files.read_text(f'JARVIS_Brain/Daily/{today}.md')
        self.assertIn('Created a project.',text)
        self.assertIn('Reviewed the project.',text)
    def test_obsidian_canvas_validation(self):
        self.vault.canvas('BrainMap',json.dumps(['JARVIS','Coding Lab']),json.dumps([[0,1]]))
        canvas=json.loads(self.files.read_text('JARVIS_Brain/Canvas/BrainMap.canvas'))
        self.assertEqual(len(canvas['edges']),1)
        with self.assertRaises(PolicyError):
            self.vault.canvas('Bad','["OnlyOne"]','[[0,3]]')
    def test_stop_blocks_writes(self):
        (self.conf.parent/'STOP_JARVIS.txt').touch()
        with self.assertRaises(PolicyError):self.projects.create('JARVIS_Demo','P','python')
        with self.assertRaises(PolicyError):self.vault.daily('test')
    def test_activity_log_does_not_log_sensitive_args(self):
        a=Activity(self.settings)
        a.record('workspace_write',True)
        text=(self.settings.data_dir/'activity.jsonl').read_text()
        self.assertIn('workspace_write',text)
        self.assertNotIn('password',text)

if __name__=='__main__':unittest.main()
