"""v3.4: app control by name, verified clicks, Unicode typing, protected-app screenshot guard."""
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from PIL import Image

from jarvis_core.app_control import AppControl, match_score, norm
from jarvis_core.desktop import Desktop
from jarvis_core.desktop_backend import WindowsBackend
from jarvis_core.policy import PolicyError, Settings


class FakeGui:
    def __init__(self): self.calls = []
    def size(self): return (1000, 800)
    def position(self): return (0, 0)
    def click(self, **kw): self.calls.append(('click', kw))
    def hotkey(self, *k): self.calls.append(('hotkey', k))
    def write(self, t, interval=0): self.calls.append(('write', t))


class FakeBackend:
    """A tiny in-memory 'Windows': one or more windows with named controls."""

    def __init__(self):
        self.gui_obj, self.typed, self.invoked = FakeGui(), [], []
        self.front = 1
        self.wins = {1: {'hwnd': 1, 'pid': 5, 'exe': 'notepad.exe', 'title': 'Notes', 'rect': [0, 0, 600, 500], 'elevated': False},
                     2: {'hwnd': 2, 'pid': 6, 'exe': 'keepass.exe', 'title': 'Passwords', 'rect': [0, 0, 300, 300], 'elevated': False},
                     3: {'hwnd': 3, 'pid': 7, 'exe': 'obsidian.exe', 'title': 'JARVIS Brain - Obsidian', 'rect': [0, 0, 800, 600], 'elevated': False}}
        self.values = {'Name': '', 'Password': ''}
        self.tree = [
            {'name': 'Name', 'role': 'edit', 'rect': [10, 10, 200, 30], 'enabled': True, 'visible': True, 'password': False},
            {'name': 'Password', 'role': 'edit', 'rect': [10, 40, 200, 60], 'enabled': True, 'visible': True, 'password': True},
            {'name': 'Save As...', 'role': 'button', 'rect': [10, 70, 100, 90], 'enabled': True, 'visible': True, 'password': False},
            {'name': 'OK', 'role': 'button', 'rect': [10, 100, 60, 120], 'enabled': True, 'visible': True, 'password': False},
            {'name': 'OK', 'role': 'button', 'rect': [300, 100, 350, 120], 'enabled': True, 'visible': True, 'password': False},
            {'name': 'Submit', 'role': 'button', 'rect': [10, 130, 80, 150], 'enabled': False, 'visible': True, 'password': False},
            {'name': 'File', 'role': 'menuitem', 'rect': [0, 0, 40, 9], 'enabled': True, 'visible': True, 'password': False},
            {'name': 'Hidden thing', 'role': 'button', 'rect': [0, 0, 5, 5], 'enabled': True, 'visible': False, 'password': False},
        ]
        self.menu_open = False

    def gui(self): return self.gui_obj
    def foreground(self): return self.front
    def window_info(self, h): return dict(self.wins[h]) if h in self.wins else None
    def windows(self): return [dict(w) for w in self.wins.values()]
    def activate(self, h): self.front = h; return True
    def grab(self): return Image.new('RGB', (1000, 800), (len(self.invoked) * 40 % 255, 0, 0))
    def type_text(self, t): self.typed.append(t)

    def ui_tree(self, h, limit=300):
        t = [dict(e, ref=e['name']) for e in self.tree]
        if self.menu_open:
            t.append({'name': 'Save As...', 'role': 'menuitem', 'rect': [0, 12, 80, 22], 'enabled': True, 'visible': True, 'password': False, 'ref': 'menu:Save As'})
        return t

    def ui_invoke(self, el):
        self.invoked.append(el['ref'])
        if el['ref'] == 'File':
            self.menu_open = True
        return True

    def ui_set_text(self, el, text):
        self.values[el['ref']] = text; return True

    def ui_get_text(self, el): return self.values.get(el['ref'], '')


def make(perms=None):
    d = Path(tempfile.mkdtemp())
    (d / 'c.json').write_text(json.dumps({'workspace': str(d / 'w'), 'data_dir': str(d / 'd'), 'desktop_mode': 'all_user_apps',
                                          'permissions': perms or {'screen': True, 'desktop_control': True}}))
    s = Settings(d / 'c.json')
    b = FakeBackend()
    desk = Desktop(s, backend=b)
    return desk, AppControl(desk, s), b


class Matching(unittest.TestCase):
    def test_forgiving_names(self):
        self.assertEqual(norm('&Save As...'), 'save as')
        self.assertEqual(match_score('save as', 'Save As...'), 3)
        self.assertEqual(match_score('next', 'Next >'), 3)
        self.assertEqual(match_score('save', 'Save As...'), 2)
        self.assertEqual(match_score('as', 'Save As...'), 1)
        self.assertEqual(match_score('ave', 'Save'), 0)          # no half-word guesses


class AppControlTests(unittest.TestCase):
    def setUp(self):
        self.desk, self.ac, self.b = make()

    def test_controls_hide_passwords_and_invisible(self):
        out = self.ac.controls()
        names = [c['name'] for c in out['controls']]
        self.assertIn('[password box]', names); self.assertNotIn('Hidden thing', names)
        self.assertTrue(any(c.get('disabled') for c in out['controls']))

    def test_click_named_forgiving_and_reports_change(self):
        r = self.ac.click_named('save as')
        self.assertEqual(r['clicked'], 'Save As...'); self.assertEqual(r['method'], 'ui_automation')
        self.assertIn('ui_changed', r); self.assertIn('front_window_after', r)

    def test_ambiguous_lists_then_index(self):
        with self.assertRaises(PolicyError) as cm:
            self.ac.click_named('OK')
        self.assertIn('index', str(cm.exception)); self.assertIn('2 controls', str(cm.exception))
        self.ac.click_named('OK', index=2)
        self.assertEqual(self.b.invoked[-1], 'OK')
        with self.assertRaises(PolicyError):
            self.ac.click_named('OK', index=5)

    def test_disabled_and_missing(self):
        with self.assertRaises(PolicyError) as cm:
            self.ac.click_named('Submit')
        self.assertIn('greyed out', str(cm.exception))
        with self.assertRaises(PolicyError) as cm:
            self.ac.click_named('Launch rockets')
        self.assertIn('Visible names include', str(cm.exception))

    def test_type_into_reads_back_and_refuses_passwords(self):
        r = self.ac.type_into('Name', 'Zoë 日本')
        self.assertTrue(r['verified']); self.assertEqual(self.b.values['Name'], 'Zoë 日本')
        with self.assertRaises(PolicyError):
            self.ac.type_into('Password', 'hunter2')
        with self.assertRaises(PolicyError):
            self.ac.read_text('Password')
        self.assertEqual(self.ac.read_text('Name')['text'], 'Zoë 日本')

    def test_menu_path(self):
        r = self.ac.menu('File > Save As...')
        self.assertEqual(r['menu_path'], ['File', 'Save As...'])
        self.assertEqual(self.b.invoked[-2:], ['File', 'menu:Save As'])

    def test_wait_for(self):
        self.assertTrue(self.ac.wait_for('Name', 1)['found'])
        self.assertFalse(self.ac.wait_for('Never appears', 0.6)['found'])

    def test_focus_app_allowed_only(self):
        r = self.ac.focus_app('obsidian')
        self.assertTrue(r['confirmed']); self.assertEqual(r['app'], 'obsidian.exe')
        with self.assertRaises(PolicyError):
            self.ac.focus_app('passwords')            # KeePass is never offered

    def test_protected_front_app_blocks_everything(self):
        self.b.front = 2   # KeePass in front
        for action in (self.ac.controls, lambda: self.ac.click_named('OK', index=1), self.desk.screenshot):
            with self.assertRaises(PolicyError):
                action()

    def test_needs_permission(self):
        desk, ac, b = make({'screen': True})
        with self.assertRaises(PolicyError):
            ac.click_named('save as')


class DesktopUpgrades(unittest.TestCase):
    def test_unicode_typing_goes_to_backend(self):
        desk, ac, b = make()
        desk.type_text('Café ñ 日本 ✓\nnext line')
        self.assertEqual(b.typed, ['Café ñ 日本 ✓\nnext line'])
        with self.assertRaises(PolicyError):
            desk.type_text('bell\x07')

    def test_click_image_reports_change_and_front_window(self):
        desk, ac, b = make()
        desk.screenshot_guided()
        r = desk.click_image(100, 100)
        for key in ('screen_changed', 'foreground_after', 'new_window_in_front', 'verified_visual_change'):
            self.assertIn(key, r)
        self.assertFalse(r['screen_changed'])                       # fake screen never changes
        self.assertIn('warning', r)


class WindowsBackendUIA(unittest.TestCase):
    """The real Windows layer's UI Automation mapping, with pretend pywinauto objects."""

    def _obj(self, name, ctype, rect=(1, 2, 30, 40), password=False, invoke_ok=True):
        o = MagicMock()
        o.element_info = SimpleNamespace(name=name, control_type=ctype, is_password=password)
        o.rectangle.return_value = SimpleNamespace(left=rect[0], top=rect[1], right=rect[2], bottom=rect[3])
        o.is_visible.return_value = True; o.is_enabled.return_value = True
        if not invoke_ok:
            o.invoke.side_effect = RuntimeError('no invoke'); o.toggle.side_effect = RuntimeError; o.select.side_effect = RuntimeError
        o.get_value.return_value = 'typed text'
        return o

    def test_tree_invoke_text(self):
        be = WindowsBackend.__new__(WindowsBackend)       # skip WinAPI setup: Windows-only
        win = MagicMock()
        win.descendants.return_value = [self._obj('Save', 'Button'), self._obj('Password', 'Edit', password=True),
                                        self._obj('Body', 'Document')]
        fake = MagicMock(); fake.window.return_value = win
        with patch.object(WindowsBackend, '_uia', staticmethod(lambda: fake)):
            tree = be.ui_tree(42)
        self.assertEqual([(e['name'], e['role'], e['password']) for e in tree],
                         [('Save', 'button', False), ('Password', 'edit', True), ('Body', 'document', False)])
        self.assertEqual(tree[0]['rect'], [1, 2, 30, 40])
        self.assertTrue(be.ui_invoke(tree[0]))
        self.assertFalse(be.ui_invoke({'ref': self._obj('x', 'Button', invoke_ok=False)}))
        self.assertEqual(be.ui_get_text(tree[2]), 'typed text')
        self.assertTrue(be.ui_set_text(tree[2], 'hi')); tree[2]['ref'].set_edit_text.assert_called_with('hi')


if __name__ == '__main__':
    unittest.main()
