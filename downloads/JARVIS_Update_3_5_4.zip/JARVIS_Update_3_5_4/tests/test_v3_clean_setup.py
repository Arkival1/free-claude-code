"""Installer and independence checks; do not install Python packages on test machine."""
import json
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import jarvis_setup as js


class CleanSetupTests(unittest.TestCase):
    def test_original_workspace_is_selected_if_brain_exists(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            old=home/'OneDrive'/'Desktop'/'CJARVIS_Workspace'/'JARVIS_Brain'
            old.mkdir(parents=True)
            self.assertEqual(js.suggest_workspace(home),old.parent)

    def test_fresh_config_separates_internal_runtime(self):
        work=Path('C:/Users/Spawn/OneDrive/Desktop/CJARVIS_Workspace')
        cfg=js.build_config(work)
        self.assertEqual(cfg['workspace'],str(work))
        self.assertEqual(cfg['data_dir'],r'%LOCALAPPDATA%\JARVIS_Clean_v3\data')
        self.assertEqual(cfg['desktop_mode'],'all_user_apps')
        self.assertNotIn('auto_approve_downloads',cfg)

    def test_never_overwrite_existing_config_or_vault(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            cfg=root/'config.json'
            vault=root/'workspace'/'JARVIS_Brain'/'Knowledge'/'Test Note.md'
            vault.parent.mkdir(parents=True)
            vault.write_text('The silver fox carries a blue lantern.')
            with patch.object(js,'CONFIG',cfg):
                self.assertTrue(js.write_config_if_missing(vault.parents[2]))
                first=cfg.read_bytes()
                self.assertFalse(js.write_config_if_missing(root/'other'))
            self.assertEqual(cfg.read_bytes(),first)
            self.assertEqual(vault.read_text(),'The silver fox carries a blue lantern.')

    def test_snippet_points_to_exact_new_venv(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            exe=root/'.venv'/'Scripts'/'python.exe'
            exe.parent.mkdir(parents=True)
            exe.write_bytes(b'pretend exe')
            server=root/'server.py'
            server.write_text('# MCP')
            with patch.object(js,'SNIPPET',root/'LM_STUDIO_SNIPPET.json'):
                js.write_snippet(exe,server)
                item=json.loads(js.SNIPPET.read_text())['mcpServers']['jarvis-clean-v3']
            self.assertEqual(Path(item['command']),exe.resolve())
            self.assertEqual(Path(item['args'][0]),server.resolve())
            self.assertNotIn('jarvis-local-v2',item)

    def test_playwright_in_primary_install_flow(self):
        source=(js.ROOT/'jarvis_setup.py').read_text()
        self.assertIn("install_dependencies('requirements-browser-dom.txt')",source)
        self.assertIn("verify_python_dependencies()",source)
        self.assertIn('playwright', (js.ROOT/'requirements-browser-dom.txt').read_text())

    def test_no_stale_data_bundled(self):
        root=js.ROOT
        self.assertFalse((root/'STOP_JARVIS.txt').exists())
        self.assertFalse((root/'LM_STUDIO_SNIPPET.json').exists())
        self.assertFalse((root/'%LOCALAPPDATA%\\JARVIS\\data').exists())

    def test_no_old_upgrade_batch(self):
        self.assertFalse((js.ROOT/'JARVIS_Upgrade_Existing.bat').exists())
        self.assertFalse((js.ROOT/'INSTALL_BROWSER_DOM.bat').exists())
        self.assertTrue((js.ROOT/'START_JARVIS.bat').is_file())


if __name__ == '__main__':
    unittest.main()
