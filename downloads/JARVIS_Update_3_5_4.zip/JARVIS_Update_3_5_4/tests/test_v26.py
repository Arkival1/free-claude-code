"""v2.6: fully offline unit tests for YouTube validation, captions, media safety and agent wiring."""
import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.youtube import (YouTubeTools, canonical_video, caption_segments)

class VideoURLs(unittest.TestCase):
    def test_canonicalization(self):
        for raw in [
            'https://youtu.be/dQw4w9WgXcQ',
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=15',
            'https://m.youtube.com/shorts/dQw4w9WgXcQ',
        ]:
            self.assertEqual(canonical_video(raw)[0], 'https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    def test_reject_non_youtube(self):
        for url in ['http://youtube.com/watch?v=dQw4w9WgXcQ',
                    'https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ',
                    'https://www.youtube.com/watch?v=../../etc/passwd',
                    'https://youtu.be/not-an-id',
                    'https://www.youtube.com/playlist?list=PL123']:
            with self.assertRaises(PolicyError):canonical_video(url)
    def test_captions(self):
        obj={'events':[{'tStartMs':3000,'segs':[{'utf8':'hello '},{'utf8':'world'}]}]}
        self.assertEqual(caption_segments(json.dumps(obj),'json3'),[{'t':3.0,'text':'hello world'}])
        vtt='WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nWelcome!\n\n00:00:04.200 --> 00:00:06.000\n<b>Step</b> two'
        self.assertEqual([s['text'] for s in caption_segments(vtt,'vtt')],['Welcome!','Step two'])

class YouTubeLiveMock(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        config=root/'config.json'
        config.write_text(json.dumps({'workspace':str(root/'workspace'),'data_dir':str(root/'data'),
                          'permissions':{'files':True,'web_research':True,'notes_and_tasks':True,'downloads':False}}))
        self.settings=Settings(config)
        self.youtube=YouTubeTools(self.settings)

    def test_no_captions(self):
        class YDL:
            def __init__(self,opts):self.opts=opts
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def extract_info(self,url,download):
                assert not download
                return {'title':'test video','subtitles':{},'automatic_captions':{}}
        with patch.object(YouTubeTools,'_get_ydl',return_value=YDL):
            x=self.youtube.transcript('https://youtu.be/dQw4w9WgXcQ')
        self.assertFalse(x['captions_available'])
        self.assertFalse(x['transcribed'])

    def test_get_caption_without_media(self):
        class YDL:
            def __init__(self,opts):self.opts=opts
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def extract_info(self,url,download):
                assert not download
                assert self.opts['skip_download'] is True
                return {'title':'Sample video','subtitles':{'en':[{'ext':'json3','url':'https://www.youtube.com/api/timedtext?x=1'}]}}
        class Resp:
            status_code=200;headers={}
            def raise_for_status(self):pass
            def iter_content(self,n):
                yield json.dumps({'events':[{'tStartMs':5000,'segs':[{'utf8':'A demo.'}]}]}).encode()
            def close(self):pass
        class Session:
            trust_env=True
            def get(self,url,**kw):
                assert kw['allow_redirects'] is False
                return Resp()
            def close(self):pass
        with patch.object(YouTubeTools,'_get_ydl',return_value=YDL), \
             patch('jarvis_core.youtube.requests.Session',return_value=Session()), \
             patch('jarvis_core.youtube.public_https_url',side_effect=lambda s:s):
            response=self.youtube.transcript('https://youtu.be/dQw4w9WgXcQ')
        self.assertEqual(response['caption_source'],'manual')
        self.assertIn('[00:05] A demo.',response['transcript_excerpt'])
        self.assertFalse(response['visual_analysis'])

    def test_transcript_section_stays_in_vault(self):
        from jarvis_core.files import FileTools
        files=FileTools(self.settings)
        self.youtube.files=files
        rel='JARVIS_Brain/Research/YouTube/dQw4w9WgXcQ-captions.txt'
        files.write_text(rel,'A'*8000)
        x=self.youtube.transcript_section(rel,offset=4000,max_chars=200)
        self.assertEqual(len(x['content']),200)
        self.assertEqual(x['next_offset'],4200)
        with self.assertRaises(PolicyError): self.youtube.transcript_section('private.txt')
        with self.assertRaises(PolicyError): self.youtube.transcript_section(rel,offset=-1)

    def test_missing_media_and_local_restriction(self):
        with self.assertRaises(PolicyError):self.youtube.local_frame('../private.mp4',2)
        with self.assertRaises(PolicyError):self.youtube.local_frame('none.mp4',2)
        with self.assertRaises(PolicyError):self.youtube.local_transcribe('../private.mp4')


    def test_youtube_audio_requires_approval(self):
        from jarvis_core.download_approvals import DownloadApprovals
        class FakeWeb:
            def __init__(self, settings):self.approvals=DownloadApprovals(settings)
        y=YouTubeTools(self.settings,web=FakeWeb(self.settings))
        with self.assertRaises(PolicyError):y.audio_download('https://youtu.be/dQw4w9WgXcQ')
        config=json.loads(self.settings.path.read_text())
        config['permissions']['downloads']=True
        self.settings.path.write_text(json.dumps(config))
        with self.assertRaises(PolicyError):y.audio_download('https://youtu.be/dQw4w9WgXcQ')
        # The model can request; it cannot authorize its own download.
        class YDL:
            def __init__(self,opts):pass
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def extract_info(self,url,download):
                assert not download
                return {'title':'t','formats':[{'format_id':'140','ext':'m4a','vcodec':'none','acodec':'mp4a.40.2','abr':129}]}
        y._get_ydl=lambda:YDL
        req=y.audio_download_request('https://youtu.be/dQw4w9WgXcQ')
        self.assertEqual(req['status'],'pending')
        with self.assertRaises(PolicyError):y.audio_download('https://youtu.be/dQw4w9WgXcQ')

    def test_permission_denial(self):
        data=json.loads(self.settings.path.read_text())
        data['permissions']['web_research']=False
        self.settings.path.write_text(json.dumps(data))
        with self.assertRaises(PolicyError):self.youtube.transcript('https://youtu.be/dQw4w9WgXcQ')

class AgentWiring(unittest.TestCase):
    def test_autonomous_tools_are_exposed(self):
        import agent_runner
        names={x['function']['name'] for x in agent_runner.TOOLS}
        for t in ['youtube_transcript','youtube_transcript_section','youtube_open_video','youtube_video_frame','youtube_transcribe_local','youtube_audio_download_request','youtube_audio_download']:
            self.assertIn(t,names)
        self.assertIsNone(agent_runner.DEFAULT_MAX_TURNS)
        self.assertIn('desktop_find_installed_apps',{x['function']['name'] for x in agent_runner.DESKTOP_TOOLS})

if __name__=='__main__': unittest.main()
