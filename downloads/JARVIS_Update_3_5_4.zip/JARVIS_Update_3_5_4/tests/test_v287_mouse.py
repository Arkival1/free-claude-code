"""V2.8.7 screenshot-relative mouse/vision regression tests. No Windows needed."""
import json
from pathlib import Path
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from PIL import Image

from jarvis_core.desktop import Desktop
from jarvis_core.policy import Settings, PolicyError
import agent_runner
import chat_runner


class MouseGeometryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root=Path(self.tmp.name)
        config=root/'config.json'
        config.write_text(json.dumps({'workspace':str(root/'work'),'data_dir':str(root/'data'),
                'desktop_mode':'all_user_apps',
                'permissions':{'desktop_control':True,'screen':True,'app_launch':True}}))
        self.desktop=Desktop(Settings(config))
        self.gui=Mock()
        self.gui.size.return_value=(1920,1080)
        self.win={'hwnd':7,'exe':'notepad.exe','rect':[0,0,1920,1080],
                  'elevated':False}
        self.foreground=7
        self.patches=[
            patch.object(self.desktop,'_windows_only'),
            patch.object(self.desktop,'_gui',return_value=self.gui),
            patch.object(self.desktop,'_active_allowed',side_effect=lambda:self.win),
            patch.object(self.desktop,'_window_info',side_effect=lambda hwnd:self.win if hwnd==7 else None),
            patch.object(self.desktop,'_foreground',side_effect=lambda:self.foreground),
            patch.object(self.desktop,'_grab',return_value=Image.new('RGB',(1920,1080),(80,80,80)))
        ]
        for p in self.patches:p.start();self.addCleanup(p.stop)

    def test_thumbnail_geometry_maps_to_real_screen(self):
        jpg=self.desktop.screenshot_guided()
        self.assertTrue(jpg.startswith(b'\xff\xd8'))
        info=self.desktop.screen_info()
        self.assertEqual((info['image_width'],info['image_height']),(1280,720))
        self.assertEqual((info['desktop_width'],info['desktop_height']),(1920,1080))
        result=self.desktop.click_image(640,360)
        self.assertEqual(result['desktop_point'],[960,540])
        self.gui.click.assert_called_once_with(x=960,y=540,button='left',clicks=1,interval=0.12)
        self.assertFalse(result['verified_visual_change'])
        self.assertFalse(self.desktop.screen_info()['screenshot_available'])

    def test_proportional_mapping_handles_native_vs_gui_dpi(self):
        self.patches[-1].stop()
        with patch.object(self.desktop,'_grab',return_value=Image.new('RGB',(2560,1440))):
            self.desktop.screenshot_guided()
        self.assertEqual(self.desktop.screen_info()['capture_width'],2560)
        # Cursor coords in GUI's logical 1920x1080 even though grab pixels 2560x1440.
        self.assertEqual(self.desktop.click_image(320,180)['desktop_point'],[480,270])

    def test_reject_stale_or_changed_window(self):
        self.desktop.screenshot()
        self.foreground=12
        with self.assertRaisesRegex(PolicyError,'Foreground window changed'):
            self.desktop.click_image(100,100)
        self.foreground=7
        self.desktop._last_frame['captured_monotonic']-=150
        with self.assertRaisesRegex(PolicyError,'older than 120'):
            self.desktop.click_image(100,100)
        self.gui.click.assert_not_called()

    def test_rejects_unapproved_coordinates_and_changed_resolution(self):
        self.desktop.screenshot()
        for x,y in [(-1,0),(1280,0),(0,720),(1.5,2),(True,3)]:
            with self.subTest(pt=(x,y)),self.assertRaises(PolicyError):
                self.desktop.click_image(x,y)
        self.gui.size.return_value=(1366,768)
        with self.assertRaisesRegex(PolicyError,'resolution changed'):
            self.desktop.click_image(100,100)
        self.gui.click.assert_not_called()

    def test_rejects_click_outside_actual_active_app_even_if_in_screenshot(self):
        self.desktop.screenshot()
        self.win['rect']=[800,500,1600,900]
        self.desktop._last_frame['foreground_rect']=[800,500,1600,900]
        with self.assertRaisesRegex(PolicyError,'outside'):
            self.desktop.click_image(100,100)
        self.gui.click.assert_not_called()

    def test_move_and_drag_use_view_coordinates(self):
        self.desktop.screenshot()
        self.desktop.move_image(400,200)
        self.gui.moveTo.assert_called_with(600,300,duration=.25)
        self.desktop.drag_image(200,200,1000,600)
        self.gui.dragTo.assert_called_once_with(1500,900,duration=.4,button='left')
        with self.assertRaisesRegex(PolicyError,'No screenshot reference'):
            self.desktop.drag_image(200,200,300,300)

    def test_disable_or_stop_blocks(self):
        self.desktop.screenshot()
        self.desktop.settings.kill_switch_path().write_text('STOP')
        with self.assertRaises(PolicyError):self.desktop.click_image(200,200)

    def test_screen_info_without_capture(self):
        self.assertFalse(self.desktop.screen_info()['screenshot_available'])
        self.assertIn('screenshot',self.desktop.screen_info()['next_step'])


class MouseWiringTests(unittest.TestCase):
    def test_tools_in_autonomous_and_memory_chat(self):
        wanted={'desktop_screenshot_guided','desktop_screen_info','desktop_click_image',
                'desktop_move_image','desktop_drag_image','desktop_click_named'}
        actual={x['function']['name'] for x in agent_runner.DESKTOP_TOOLS}
        self.assertTrue(wanted.issubset(actual))
        for name in wanted-{'desktop_screenshot_guided'}:
            self.assertIn(name,agent_runner.ACTIONS)
        self.assertTrue(wanted.issubset({x['function']['name'] for x in chat_runner.choose_tools('Open Opera and click')}))
        # v3.1: desktop groups are loaded on demand with jarvis_load_tools.
        self.assertTrue(wanted.issubset({x['function']['name'] for x in agent_runner.focused_tools('Transcribe this YouTube video',desktop=True,extra_groups=('desktop','desktop_precise'))}))

    def test_guided_image_in_autonomous_runner_includes_geometry(self):
        with patch.object(agent_runner.DESKTOP,'screenshot_guided',return_value=b'img'), \
             patch.object(agent_runner.DESKTOP,'screen_info',return_value={'image_width':1280,'image_height':720}):
            result=agent_runner.invoke('desktop_screenshot_guided',{})
        self.assertEqual(result['image_meta']['image_width'],1280)
        self.assertEqual(result['image_data'],'aW1n')

    def test_mcp_wiring_source(self):
        source=(Path(__file__).resolve().parents[1]/'server.py').read_text()
        for name in ('desktop_screen_info','desktop_screenshot_guided','desktop_click_image',
                     'desktop_move_image','desktop_drag_image','desktop_click_named'):
            self.assertIn('def '+name+'(',source)

if __name__=='__main__':unittest.main()
