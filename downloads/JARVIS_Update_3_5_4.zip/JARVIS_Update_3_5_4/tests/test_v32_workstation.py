"""v3.2: the Workstation window opens, shows all tabs, runs its system check, and closes."""
import os
import unittest

try:
    import tkinter
    tkinter.Tk().destroy()
    HAVE_DISPLAY = True
except Exception:
    HAVE_DISPLAY = False


@unittest.skipUnless(HAVE_DISPLAY, 'needs a screen')
class WorkstationOpens(unittest.TestCase):
    def test_window_tabs_and_check(self):
        import workstation
        app = workstation.Workstation()
        try:
            app.update()
            nb = next(w for w in app.winfo_children() if w.winfo_class() == 'TNotebook')
            names = [nb.tab(t, 'text').strip() for t in nb.tabs()]
            self.assertEqual(names, ['Video → Notes', 'Jobs', 'Approvals', 'System check', 'Coming next'])
            rows = app.checks()
            self.assertTrue(any('OpenWhispr' in r[1] for r in rows))
            self.assertTrue(all(r[0] in ('✓', '✗') for r in rows))
            app._run_check(); app.update()
        finally:
            app.destroy()
            del app
            import gc
            gc.collect()   # free Tk variables on the main thread, not later in another test's thread


if __name__ == '__main__':
    unittest.main()
