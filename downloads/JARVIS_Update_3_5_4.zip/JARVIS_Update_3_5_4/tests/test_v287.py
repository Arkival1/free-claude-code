"""v2.8.7 rolling memory and standalone local memory chat safety checks."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.context_memory import ChatMemory
import chat_runner
import agent_runner


def settings_at(root):
    path=root/'config.json'
    path.write_text(json.dumps({'workspace':str(root/'workspace'),'data_dir':str(root/'local_data'),
        'permissions':{'files':True,'notes_and_tasks':True},'desktop_mode':'all_user_apps'}))
    return Settings(path)


class RollingMemoryTests(unittest.TestCase):
    def test_append_complete_turn_and_resume_without_duplicate_archive(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            m.record('How do I use Obsidian?','Open JARVIS_Brain.')
            m.record('What was the vault?','JARVIS_Brain folder.')
            archive=list((st.workspace/'JARVIS_Brain'/'Chat Memory').glob('JARVIS Long Chat 20*.md'))
            self.assertEqual(len(archive),1)
            content=archive[0].read_text()
            self.assertIn('How do I use Obsidian?',content)
            self.assertIn('What was the vault?',content)
            resume=ChatMemory(st)
            self.assertEqual(resume.state['turn_count'],2)
            self.assertEqual(len(resume.state['recent']),4)

    def test_offload_preserves_full_archive_and_summary(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            for i in range(6):
                m.record('Task '+str(i), 'Verified '+str(i))
            self.assertTrue(m.should_compact())
            seen=[]
            def summarize(old,source):
                seen.append(source)
                return 'Important project: JARVIS second brain, verified steps and unresolved tasks.'
            self.assertTrue(m.compact(summarize))
            self.assertEqual(m.state['offloads'],1)
            self.assertEqual(len(m.state['recent']),4)
            self.assertIn('JARVIS second brain',m.memory_context())
            archived=' '.join(p.read_text() for p in (st.workspace/'JARVIS_Brain'/'Chat Memory').glob('JARVIS Long Chat 20*.md'))
            self.assertIn('Task 0',archived)
            self.assertIn('Task 5',archived)
            self.assertTrue(seen)
            resume=ChatMemory(st)
            self.assertIn('JARVIS second brain',resume.state['summary'])

    def test_gui_history_uses_full_archived_messages(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            for i in range(5):m.record('Older user detail '+str(i),'Older assistant result '+str(i))
            m.compact(lambda *_:'Verified task summary from local model.')
            history=ChatMemory(st).render_history()
            self.assertIn('Older user detail 0',history)
            self.assertIn('Older assistant result 4',history)

    def test_failed_local_summary_falls_back_verbatim(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            for i in range(6):m.record('Issue '+str(i),'Result '+str(i))
            def bad(a,b):raise ConnectionError('local model unavailable')
            self.assertTrue(m.compact(bad))
            self.assertIn('Verbatim recent older exchanges',m.state['summary'])

    def test_memory_search_finds_prior_archive(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            m.record('The silver fox carries a blue lantern','Confirmed as memory test.')
            self.assertIn('silver fox',m.memory_context('silver fox').lower())

    def test_only_explicit_text_saved_by_manual_tool(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            result=m.manual_save('Summary from LM Studio','The user approved a browser test.')
            self.assertTrue(result['saved'])
            self.assertIn('NOT compacted',result['note'])
            with self.assertRaises(PolicyError):m.manual_save('../outside','text')

    def test_stop_blocks_writes(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));m=ChatMemory(st)
            st.kill_switch_path().write_text('STOP')
            with self.assertRaises(PolicyError):m.record('a','b')

    def test_chat_tool_call_then_archives_verified_output(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp));brain=ChatMemory(st)
            toolcall={'id':'call1','type':'function','function':{
                  'name':'obsidian_memory_search','arguments':'{"query":"silver fox"}'}}
            responses=[{'role':'assistant','content':'','tool_calls':[toolcall]},
                       {'role':'assistant','content':'I found the lantern memory.','tool_calls':[]}]
            with patch.object(chat_runner.ar,'SETTINGS',st), \
                 patch.object(chat_runner.ar,'memory_hints',return_value=''), \
                 patch.object(chat_runner.ar,'invoke',return_value=[{'snippet':'silver fox blue lantern'}]), \
                 patch.object(chat_runner,'local_complete',side_effect=responses):
                output=chat_runner.ask(object(),'test-model',brain,'Search silver fox')
            self.assertIn('lantern',output)
            self.assertEqual(brain.state['turn_count'],1)
            self.assertIn('lantern',brain.render_history())

    def test_chat_runner_no_remote_endpoint(self):
        self.assertEqual(chat_runner.BASE_URL,'http://127.0.0.1:1234/v1')
        names={t['function']['name'] for t in chat_runner.choose_tools('Use Obsidian notes')}
        self.assertIn('obsidian_memory_search',names)
        self.assertNotIn('official_download',names)

    def test_compact_old_autonomous_messages_archived(self):
        with tempfile.TemporaryDirectory() as temp:
            st=settings_at(Path(temp))
            msgs=[{'role':'system','content':'Owner rules'}, {'role':'user','content':'Do task'}]
            for i in range(18):
                msgs.extend([{'role':'assistant','content':'','tool_calls':[{'function':{'name':'workspace_list'}}]},
                             {'role':'tool','content':f'check {i}'}])
            with patch.object(agent_runner,'SETTINGS',st):
                result=agent_runner.compact_context(msgs)
            self.assertLessEqual(len(result),26)
            self.assertIn('ARCHIVED TOOL CONTEXT LEAD',result[0]['content'])
            archive=(st.workspace/'JARVIS_Brain'/'Chat Memory'/'Manually Saved Conversation Notes.md').read_text()
            self.assertIn('workspace_list',archive)

    def test_clean_install_ships_chat_files_and_does_not_mutate_vault(self):
        import jarvis_setup as js
        src=Path(__file__).resolve().parents[1]
        self.assertTrue((src/'chat_runner.py').is_file())
        self.assertTrue((src/'memory_chat_gui.py').is_file())
        self.assertTrue((src/'jarvis_core/context_memory.py').is_file())
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            work=root/'workspace'
            vault=work/'JARVIS_Brain'/'00 Dashboard'
            vault.mkdir(parents=True)
            old=vault/'JARVIS Home.md'
            old.write_text('Original owner memory')
            cfg=root/'config.json'
            with patch.object(js,'CONFIG',cfg):
                self.assertTrue(js.write_config_if_missing(work))
                self.assertFalse(js.write_config_if_missing(root/'other'))
            self.assertEqual(old.read_text(),'Original owner memory')
            self.assertEqual(json.loads(cfg.read_text())['workspace'],str(work))


if __name__=='__main__':unittest.main()
