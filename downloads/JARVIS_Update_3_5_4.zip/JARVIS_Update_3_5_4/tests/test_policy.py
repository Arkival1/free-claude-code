import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from jarvis_core.policy import Settings, PolicyError, public_https_url, is_allowed_domain
from jarvis_core.files import FileTools
from jarvis_core.memory import Memory
from jarvis_core.network import WebTools

class BasicFixture(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory()
        root=Path(self.d.name)
        self.root=root
        self.config=root/'config.json'
        self.config.write_text(json.dumps({
            'workspace':str(root/'workspace'), 'data_dir':str(root/'data'),
            'permissions':{'files':True,'notes_and_tasks':True,'web_research':False,'screen':False,
                           'downloads':False,'desktop_control':False,'app_launch':False},
            'approved_desktop_exes':['notepad.exe'],'approved_download_domains':['godotengine.org'],
            'max_file_kb':256,'max_download_mb':1,
            'apps':{'notepad':{'path':'C:\\Windows\\System32\\notepad.exe','args':[]}}
        }),encoding='utf-8')
        self.settings=Settings(self.config)
        self.files=FileTools(self.settings)
        self.memory=Memory(self.settings)
        self.web=WebTools(self.settings)
    def tearDown(self): self.d.cleanup()

class TestSecurity(BasicFixture):
    def test_normal_write_read_list(self):
        self.files.create_folder('project')
        self.files.write_text('project/test.py','print(1)')
        self.assertEqual(self.files.read_text('project/test.py'),'print(1)')
        self.assertIn('test.py',self.files.list_files('project'))
    def test_no_absolute_drive_or_traversal(self):
        for bad in ['../outside','folder/../../outside','C:\\Windows\\file.txt',
                    '/etc/passwd',r'\\server\share\hello.txt','folder//file.txt','a:b']:
            with self.subTest(path=bad), self.assertRaises(PolicyError):
                self.files.write_text(bad,'hack')
    def test_no_symlinks(self):
        outside=self.root/'outside'
        outside.mkdir()
        (self.settings.workspace).mkdir(exist_ok=True)
        link=self.settings.workspace/'outlink'
        try: link.symlink_to(outside,target_is_directory=True)
        except (PermissionError,NotImplementedError,OSError): self.skipTest('Cannot create test link')
        with self.assertRaises(PolicyError): self.files.write_text('outlink/escape.txt','no')
    def test_backup_overwrite_and_no_delete(self):
        self.files.write_text('t.txt','first')
        with self.assertRaises(PolicyError): self.files.write_text('t.txt','second')
        self.files.write_text('t.txt','second',overwrite=True)
        self.assertEqual(self.files.read_text('t.txt'),'second')
        self.assertTrue(list((self.settings.workspace/'_backups').glob('*.bak')))
    def test_file_size_cap(self):
        with self.assertRaises(PolicyError): self.files.write_text('test.txt','X'*300000)
    def test_disabled_write(self):
        cfg=json.loads(self.config.read_text())
        cfg['permissions']['files']=False
        self.config.write_text(json.dumps(cfg))
        with self.assertRaises(PolicyError): self.files.write_text('test.txt','x')
    def test_stop_file_blocks_writes(self):
        self.settings.kill_switch_path().touch()
        with self.assertRaises(PolicyError): self.files.write_text('test.txt','x')
        self.assertEqual(self.files.list_files('.'),'[empty folder]')
    def test_owner_only_project(self):
        with self.assertRaises(PolicyError): self.memory.add_task('No','bad')
        self.memory.approve_project_by_owner('Approved')
        task_id=self.memory.add_task('Approved','Make prototype','test')
        self.assertTrue(task_id)
        self.assertEqual(self.memory.tasks('Approved')[0]['state'],'todo')
        self.memory.update_task('Approved',task_id,'done')
        self.assertEqual(self.memory.tasks('Approved')[0]['state'],'done')
        with self.assertRaises(PolicyError): self.memory.update_task('Approved',task_id,'invalid')
    def test_notes(self):
        self.memory.approve_project_by_owner('P')
        self.memory.add_note('P','Research','I found a local library.','https://example.org/')
        self.assertEqual(len(self.memory.search_notes('P','library')),1)
        with self.assertRaises(PolicyError): self.memory.add_note('Bad','a','b')
    def test_https_url_rejections(self):
        for url in ['http://google.com','https://127.0.0.1','https://localhost',
                    'https://10.0.0.4','https://user:pw@example.com','file:///tmp/test',
                    'https://example.com:444/','https://foo.local/', 'https://[::1]/']:
            with self.subTest(url=url), self.assertRaises(PolicyError):
                public_https_url(url,resolve_dns=False)
        self.assertEqual(public_https_url('https://www.youtube.com/watch?v=ABC',resolve_dns=False),
            'https://www.youtube.com/watch?v=ABC')
    def test_domain_allowlist(self):
        self.assertTrue(is_allowed_domain('download.godotengine.org',['godotengine.org']))
        self.assertFalse(is_allowed_domain('godotengine.org.bad.com',['godotengine.org']))
        self.assertFalse(is_allowed_domain('badgodotengine.org',['godotengine.org']))
    def test_web_requires_permission(self):
        with self.assertRaises(PolicyError): self.web.search('test')
        with self.assertRaises(PolicyError): self.web.download('https://godotengine.org/','test.bin')
    def test_download_no_unapproved_domain(self):
        cfg=json.loads(self.config.read_text()); cfg['permissions']['downloads']=True
        self.config.write_text(json.dumps(cfg))
        with patch('jarvis_core.network.public_https_url', return_value='https://evil.com/file'):
            with self.assertRaises(PolicyError): self.web.download('https://evil.com/file','file.exe')
    def test_download_bad_filename(self):
        cfg=json.loads(self.config.read_text()); cfg['permissions']['downloads']=True
        self.config.write_text(json.dumps(cfg))
        with patch('jarvis_core.network.public_https_url', return_value='https://godotengine.org/file'):
            for name in ['../evil','C:\\test.exe','bad/name.exe','']:
                with self.subTest(name=name),self.assertRaises(PolicyError):
                    self.web.download('https://godotengine.org/file',name)
    def test_no_unauthorized_run(self):
        import inspect
        from jarvis_core.desktop import Desktop
        from jarvis_core.files import FileTools
        self.assertFalse(hasattr(Desktop,'run_shell'))
        self.assertFalse(hasattr(FileTools,'delete'))
    def test_config_revocation_live(self):
        self.assertFalse(self.settings.enabled('screen'))
        cfg=json.loads(self.config.read_text());cfg['permissions']['screen']=True
        self.config.write_text(json.dumps(cfg))
        self.assertTrue(self.settings.enabled('screen'))
        cfg['permissions']['screen']=False
        self.config.write_text(json.dumps(cfg))
        self.assertFalse(self.settings.enabled('screen'))
    def test_python_ast_not_execution(self):
        import ast
        tree=ast.parse('import os\nprint("no code actually run")')
        self.assertTrue(tree)
