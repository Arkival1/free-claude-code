import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import control_panel

class TestControlPanel(unittest.TestCase):
    def test_atomic_save_valid_json(self):
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)/'config.json'
            dest.write_text('{"permissions":{"files":true}}',encoding='utf-8')
            with patch.object(control_panel, 'CONFIG', dest), patch.object(control_panel, 'BASE', Path(td)):
                control_panel.atomic_config_write({'permissions':{'files':False,'screen':True}})
            new=json.loads(dest.read_text(encoding='utf-8'))
            self.assertFalse(new['permissions']['files'])
            self.assertTrue(new['permissions']['screen'])
            self.assertEqual(list(Path(td).glob('.jarvis-config-*')), [])
    def test_bad_format_rejected(self):
        with self.assertRaises(ValueError):
            control_panel.atomic_config_write({'permissions':None})
