"""v3.4.2: one-click updater keeps settings/.venv, backs up, moves leftovers aside, and can undo."""
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import update_jarvis as up

CONFIG = {'workspace': 'C:/Users/Spawn/OneDrive/Desktop/CJARVIS_Workspace', 'data_dir': 'x', 'permissions': {'files': True}}


def fake_install(root: Path, version='3.1.0') -> Path:
    inst = root / 'CUsersSpawnJARVIS_Clean_v3' / 'JARVIS_Clean_v3_1' / 'JARVIS_Clean_v3_1'   # the owner's real nesting
    (inst / 'jarvis_core').mkdir(parents=True)
    (inst / 'server.py').write_text(f"mcp=FastMCP('jarvis-clean-v3')\nX={{'version':'{version}'}}\n")
    (inst / 'jarvis_core' / 'desktop.py').write_text('# old desktop\n')
    (inst / 'config.json').write_text(json.dumps(CONFIG))
    (inst / '.venv' / 'Scripts').mkdir(parents=True)
    (inst / '.venv' / 'marker.txt').write_text('installed packages')
    (inst / 'LM_STUDIO_SNIPPET.json').write_text('{"mcpServers": {}}')
    (inst / 'jarvis_sim').mkdir(); (inst / 'jarvis_sim' / 'services.py').write_text('old sim')
    (inst / 'JARVIS_Clean_v3_4_1.zip').write_bytes(b'PK stray zip')
    return inst


class Updater(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup)
        self.root = Path(t.name)
        self.inst = fake_install(self.root)
        self.quiet = io.StringIO()

    def test_update_keeps_settings_and_backs_up(self):
        before_cfg = (self.inst / 'config.json').read_bytes()
        with redirect_stdout(self.quiet):
            backup = up.update(self.inst)
        self.assertEqual((self.inst / 'config.json').read_bytes(), before_cfg)
        self.assertEqual((self.inst / '.venv' / 'marker.txt').read_text(), 'installed packages')
        self.assertEqual((self.inst / 'LM_STUDIO_SNIPPET.json').read_text(), '{"mcpServers": {}}')
        self.assertEqual(up.version_of(self.inst), up.version_of(up.SRC))
        self.assertTrue((self.inst / 'jarvis_core' / 'app_control.py').is_file())
        self.assertTrue((self.inst / 'UPDATE_JARVIS.bat').is_file())            # next updates work the same way
        self.assertEqual((backup / 'jarvis_core' / 'desktop.py').read_text(), '# old desktop\n')
        self.assertEqual((backup / 'FROM_VERSION.txt').read_text(), '3.1.0')
        self.assertFalse((self.inst / 'jarvis_sim').exists())
        self.assertTrue((backup / 'obsolete' / 'jarvis_sim' / 'services.py').is_file())   # moved, not deleted
        self.assertTrue((self.inst / 'JARVIS_Clean_v3_4_1.zip').is_file())               # owner files untouched

    def test_undo_restores_previous_version(self):
        with redirect_stdout(self.quiet):
            up.update(self.inst)
            up.undo(self.inst)
        self.assertEqual(up.version_of(self.inst), '3.1.0')
        self.assertEqual((self.inst / 'jarvis_core' / 'desktop.py').read_text(), '# old desktop\n')
        self.assertFalse((self.inst / 'jarvis_core' / 'app_control.py').exists())      # added file removed again
        self.assertEqual((self.inst / 'jarvis_sim' / 'services.py').read_text(), 'old sim')
        with self.assertRaises(ValueError):
            up.undo(self.inst)                                                           # nothing left to undo

    def test_refuses_wrong_folders(self):
        with self.assertRaises(ValueError):
            up.update(up.SRC)
        with self.assertRaises(ValueError):
            up.update(self.root)
        (self.inst / 'config.json').write_text('{broken')
        with self.assertRaises(ValueError):
            up.update(self.inst)
        self.assertFalse((self.inst / '_update_backups').exists())                       # nothing touched

    def test_finds_the_nested_install(self):
        with patch.object(up.Path, 'home', classmethod(lambda cls: self.root)):
            found = up.find_installs()
        self.assertIn(self.inst.resolve(), found)
        self.assertEqual(found[0], self.inst.resolve())          # most recently used install first

    def test_check_uses_installs_own_python(self):
        with redirect_stdout(self.quiet):
            up.update(self.inst)
        py = up.venv_python(self.inst)
        py.parent.mkdir(parents=True, exist_ok=True)
        if py.exists():
            py.unlink()
        os.symlink(sys.executable, py)
        out = io.StringIO()
        with redirect_stdout(out), patch.object(up, 'ask', return_value=False):
            self.assertTrue(up.check(self.inst, log=print))
        self.assertIn('Check OK', out.getvalue())

    def test_main_end_to_end_with_typed_answers(self):
        answers = iter(['', 'y'])                       # Enter = first install found, then yes
        out = io.StringIO()
        with patch.object(up.Path, 'home', classmethod(lambda cls: self.root)), \
                patch('builtins.input', lambda *_: next(answers)), patch.object(up, 'check', return_value=True), redirect_stdout(out):
            code = up.main()
        self.assertEqual(code, 0, out.getvalue())
        self.assertIn('DONE', out.getvalue())
        self.assertEqual(up.version_of(self.inst), up.version_of(up.SRC))


if __name__ == '__main__':
    unittest.main()
