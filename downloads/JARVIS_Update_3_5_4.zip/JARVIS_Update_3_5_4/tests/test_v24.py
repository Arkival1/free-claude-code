import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jarvis_core.desktop import Desktop
from jarvis_core.installed_apps import _safe_executable, BLOCKED_LAUNCH_EXES
from jarvis_core.policy import Settings, PolicyError


class AppDiscoveryTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.workspace=self.root/'workspace'
        self.workspace.mkdir()
        self.cfg=self.root/'config.json'
        self.cfg.write_text(json.dumps({
            'workspace':str(self.workspace), 'data_dir':str(self.root/'data'),
            'permissions':{'desktop_control':True,'app_launch':True,'screen':True},
            'desktop_mode':'approved_apps',
            'approved_desktop_exes':['notepad.exe'],'apps':{}
        }))
        self.desktop=Desktop(Settings(self.cfg))

    def broad(self):
        x=json.loads(self.cfg.read_text());x['desktop_mode']='all_user_apps'
        self.cfg.write_text(json.dumps(x))

    def test_app_discovery_requires_broad_mode(self):
        with patch.object(Desktop,'_windows_only',return_value=None):
            with self.assertRaises(PolicyError):self.desktop.installed_apps('code')

    def test_only_matching_ids_returned(self):
        self.broad()
        with patch.object(Desktop,'_windows_only',return_value=None), patch('jarvis_core.desktop.registered_apps',return_value={'code.exe':'C:/code.exe','godot.exe':'C:/godot.exe'}):
            res=self.desktop.installed_apps('godot')
        self.assertEqual([x['app_id'] for x in res['apps']],['godot.exe'])

    def test_launch_registered_without_per_app_approval(self):
        self.broad(); fake=self.root/'obsidian.exe';fake.write_bytes(b'placeholder')
        with patch.object(Desktop,'_windows_only',return_value=None), patch('jarvis_core.desktop.registered_apps',return_value={'obsidian.exe':str(fake)}), patch('jarvis_core.desktop.subprocess.Popen') as popen:
            self.assertIn('Launched',self.desktop.launch('obsidian.exe'))
            popen.assert_called_once_with([str(fake)],cwd=str(self.workspace),shell=False)

    def test_not_any_path_or_shell(self):
        self.broad()
        fake=self.root/'obsidian.exe';fake.write_bytes(b'placeholder')
        with patch.object(Desktop,'_windows_only',return_value=None), patch('jarvis_core.desktop.registered_apps',return_value={'obsidian.exe':str(fake)}), patch('jarvis_core.desktop.subprocess.Popen') as popen:
            for app in ('C:/Users/Spawn/Downloads/app.exe','powershell.exe','obsidian.exe --evil','other.exe'):
                with self.subTest(app=app),self.assertRaises(PolicyError):self.desktop.launch(app)
            popen.assert_not_called()

    def test_stop_blocks_launch(self):
        self.broad();(self.root/'STOP_JARVIS.txt').touch()
        with patch.object(Desktop,'_windows_only',return_value=None),self.assertRaises(PolicyError):self.desktop.launch('obsidian.exe')

    def test_non_admin_broad_window_and_protected_apps(self):
        self.broad()
        self.assertTrue(self.desktop._allowed_process({'exe':'obsidian.exe','elevated':False}))
        self.assertFalse(self.desktop._allowed_process({'exe':'obsidian.exe','elevated':True}))
        self.assertFalse(self.desktop._allowed_process({'exe':'python.exe','elevated':False}))

    def test_literal_executable_validation(self):
        app=self.root/'obsidian.exe';app.write_bytes(b'test')
        self.assertEqual(_safe_executable(str(app),workspace=self.workspace),app.resolve())
        self.assertIsNone(_safe_executable(str(app)+' --option'))
        self.assertIsNone(_safe_executable('https://example.com/app.exe'))
        bad=self.workspace/'program.exe';bad.write_bytes(b'test')
        self.assertIsNone(_safe_executable(str(bad),workspace=self.workspace))
        self.assertIn('cmd.exe',BLOCKED_LAUNCH_EXES)

if __name__=='__main__':unittest.main()
