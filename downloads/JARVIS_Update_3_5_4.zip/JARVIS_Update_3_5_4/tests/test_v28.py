"""Continuous local autonomy, checkpoints, and non-host coding tests."""
import json
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from jarvis_core.policy import Settings,PolicyError
from jarvis_core.mission import MissionStore
from jarvis_core.dev_lab import DevLab

class NewFeatures(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.home=Path(tmp.name)
        cfg={'workspace':str(self.home/'work'),'data_dir':str(self.home/'data'),
             'permissions':{'files':True,'notes_and_tasks':True,'coding_lab':True,'web_research':True},
}
        path=self.home/'config.json';path.write_text(json.dumps(cfg),encoding='utf8')
        self.settings=Settings(path)
        self.store=MissionStore(self.settings)

    def test_checkpoint_roundtrip_and_images_not_saved(self):
        huge='data:image/jpeg;base64,'+('a'*12000)
        state=self.store.save('build a game','local-ai',[
            {'role':'system','content':'rules'},{'role':'user','content':'build a game'},
            {'role':'user','content':[{'type':'image_url','image_url':{'url':huge}}]}],
            92,'paused','interrupted')
        self.assertEqual(self.store.load()['turns'],92)
        self.assertNotIn('aaaaaaa',self.store.path.read_text(encoding='utf8'))
        self.assertIn('image omitted',str(state['messages']))

    def test_resume_recovers_interrupted_multi_tool_call(self):
        calls=[{'id':'one','type':'function','function':{'name':'workspace_list','arguments':'{}'}},
               {'id':'two','type':'function','function':{'name':'workspace_read','arguments':'{}'}}]
        self.store.save('goal','model',[
            {'role':'system','content':'x'}, {'role':'user','content':'goal'},
            {'role':'assistant','content':'','tool_calls':calls},
            {'role':'tool','tool_call_id':'one','content':'done'}],3,'paused')
        recovered=self.store.load()['messages']
        self.assertEqual(len([x for x in recovered if x.get('role')=='tool']),2)
        self.assertIn('interrupted',recovered[-1]['content'])

    def test_completed_task_cannot_resume(self):
        self.store.save('goal','model',[],4,'completed')
        with self.assertRaises(PolicyError): self.store.load()

    def test_dev_lab_requires_offline_docker_image(self):
        root=self.settings.workspace;root.mkdir(parents=True,exist_ok=True)
        (root/'hello.js').write_text('console.log("safe")',encoding='utf8')
        lab=DevLab(self.settings)
        with patch('jarvis_core.dev_lab.shutil.which',return_value=None):
            with self.assertRaises(PolicyError):lab.run('hello.js','javascript')
        with patch('jarvis_core.dev_lab.shutil.which',return_value='docker'), patch('jarvis_core.dev_lab.subprocess.run') as run:
            run.return_value.returncode=1
            with self.assertRaises(PolicyError):lab.run('hello.js','javascript')
            self.assertEqual(run.call_args.args[0][1:4],['image','inspect','node:22-alpine'])

    def test_dev_lab_does_not_execute_on_host(self):
        root=self.settings.workspace;root.mkdir(parents=True,exist_ok=True)
        (root/'hello.cpp').write_text('int main(){return 0;}',encoding='utf8')
        lab=DevLab(self.settings)
        class Completed:
            returncode=0;stdout='ok';stderr=''
        seen=[]
        def fake_run(cmd,*a,**kw):
            seen.append(cmd)
            return Completed()
        with patch('jarvis_core.dev_lab.shutil.which',return_value='docker'),patch('jarvis_core.dev_lab.subprocess.run',side_effect=fake_run):
            result=lab.run('hello.cpp','cpp')
        self.assertEqual(result['exit_code'],0)
        self.assertIn('--network',seen[1]);self.assertIn('none',seen[1])
        self.assertIn('--read-only',seen[1])
        self.assertIn('--cap-drop',seen[1])
        self.assertEqual(seen[1][0],'docker')

class ContinuousLoop(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.path=Path(tmp.name)
        cfg={'workspace':str(self.path/'work'),'data_dir':str(self.path/'data'),
             'permissions':{'files':True,'notes_and_tasks':True,'web_research':False}}
        conf=self.path/'config.json';conf.write_text(json.dumps(cfg))
        self.settings=Settings(conf)

    def test_beyond_forty_turns_then_finish(self):
        import agent_runner as a
        class Resp:
            def __init__(self, msg):self.msg=msg
            def raise_for_status(self):pass
            def json(self):return {'choices':[{'message':self.msg}]}
        class Session:
            count=0
            def __init__(self):self.trust_env=True
            def post(self,*args,**kwargs):
                type(self).count+=1
                n=self.count
                if n>45:return Resp({'content':'TASK_COMPLETE: Checked forty-five unique records.'})
                return Resp({'content':'working', 'tool_calls':[{'id':str(n),'type':'function',
                    'function':{'name':'workspace_list','arguments':json.dumps({'folder':str(n)})}}]})
        with patch.object(a,'MISSIONS',MissionStore(self.settings)),patch.object(a,'SETTINGS',self.settings), \
             patch.object(a,'log',lambda _:None),patch.object(a,'memory_hints',lambda goal:''), \
             patch.object(a.requests,'Session',Session), patch.dict(a.ACTIONS,{'workspace_list':lambda folder:'unique-'+folder}):
            self.assertTrue(a.run_agent('test more than forty','local-model'))
        self.assertEqual(Session.count,46)
        self.assertEqual(MissionStore(self.settings).path.exists(),True)

    def test_owner_pause_and_resume(self):
        import agent_runner as a
        class Resp:
            def __init__(self,t):self.t=t
            def raise_for_status(self):pass
            def json(self):return {'choices':[{'message':{'content':self.t}}]}
        class Session:
            count=0
            def __init__(self):self.trust_env=True
            def post(self,*_,**__):
                type(self).count+=1
                return Resp('TASK_COMPLETE: resumed successfully.')
        store=MissionStore(self.settings)
        store.save('resume task','local-model',[{'role':'system','content':'rules'},{'role':'user','content':'resume task'}],4,'paused')
        with patch.object(a,'MISSIONS',store),patch.object(a,'SETTINGS',self.settings), \
             patch.object(a,'log',lambda _:None),patch.object(a.requests,'Session',Session):
            self.assertTrue(a.run_agent('ignored','ignored',resume=True))
        data=json.loads(store.path.read_text())
        self.assertEqual(data['status'],'completed')
        self.assertEqual(data['turns'],5)

if __name__=='__main__': unittest.main()
