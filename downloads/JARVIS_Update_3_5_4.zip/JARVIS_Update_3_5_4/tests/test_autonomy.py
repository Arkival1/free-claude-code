import unittest
from unittest.mock import patch
from jarvis_core.policy import PolicyError


class TestAutonomy(unittest.TestCase):
    def test_remote_inference_fails_closed(self):
        import agent_runner
        with self.assertRaises(PolicyError):
            agent_runner.run_agent('hi','test',base_url='https://cloud.example.com/v1',max_steps=1)
        with self.assertRaises(PolicyError):
            agent_runner.run_agent('hi','test',base_url='http://192.168.0.1:1234/v1',max_steps=1)

    def test_two_step_local_tool_use(self):
        import agent_runner as a
        class Resp:
            def __init__(self,data):self.data=data
            def raise_for_status(self):pass
            def json(self):return self.data
        class Fake:
            def __init__(self):
                self.i=0
            def post(self,*_,**kwargs):
                self.i+=1
                if self.i==1:
                    return Resp({'choices':[{'message':{'content':'Checking files','tool_calls':[
                         {'id':'call_1','type':'function','function':{'name':'workspace_list','arguments':'{"folder":"."}'}}
                         ]}}]})
                return Resp({'choices':[{'message':{'content':'TASK_COMPLETE: I read the workspace listing; finished.'}}]})
        with patch.object(a.requests,'Session',Fake), patch.dict(a.ACTIONS,{'workspace_list':lambda folder:'safe-list'}), patch.object(a,'log',lambda data:None):
            self.assertTrue(a.run_agent('List workspace','local-model',max_steps=3))

if __name__=='__main__':unittest.main()
