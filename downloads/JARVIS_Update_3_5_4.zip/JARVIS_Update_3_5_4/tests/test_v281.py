"""Adviser retirement / future-safe memory preservation."""
import json
import ast
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jarvis_core.vault import CATEGORIES

class AdviserRemovalTests(unittest.TestCase):
    def test_no_adviser_callable_in_agent(self):
        import agent_runner as a
        self.assertNotIn('local_adviser_consult',a.ACTIONS)
        self.assertNotIn('local_adviser_consult',[t['function']['name'] for t in a.TOOLS])
    def test_no_adviser_mcp_exported(self):
        source=(Path(__file__).resolve().parent.parent/'server.py').read_text(encoding='utf8')
        exports={x.name for x in ast.parse(source).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
        self.assertNotIn('local_adviser_consult', exports)
        self.assertNotIn('Advisers', CATEGORIES)
    @unittest.skip("Legacy upgrade helper intentionally excluded from fresh-install package")
    def test_upgrade_keeps_memory_and_removes_old_code(self):
        import apply_upgrade
        with tempfile.TemporaryDirectory() as t:
            target=Path(t)/'install';target.mkdir()
            (target/'jarvis_core').mkdir()
            (target/'jarvis_core'/'advisers.py').write_text('legacy adviser',encoding='utf8')
            (target/'server.py').write_text('# legacy',encoding='utf8')
            old={'workspace':str(target/'workspace'),'data_dir':str(target/'data'),
                 'permissions':{'files':True},'local_advisers':{'coder':'local-model'}}
            (target/'config.json').write_text(json.dumps(old),encoding='utf8')
            data=target/'data';data.mkdir()
            (data/'adviser_memory.sqlite3').write_bytes(b'keep original contents')
            backup=apply_upgrade.upgrade(target)
            cfg=json.loads((target/'config.json').read_text(encoding='utf8'))
            self.assertNotIn('local_advisers',cfg)
            self.assertFalse((target/'jarvis_core/advisers.py').exists())
            self.assertEqual((data/'adviser_memory.sqlite3').read_bytes(),b'keep original contents')
            self.assertEqual((backup/'jarvis_core/advisers.py').read_text(), 'legacy adviser')
            self.assertEqual(json.loads((backup/'config.json').read_text())['local_advisers'],{'coder':'local-model'})

if __name__=='__main__': unittest.main()
