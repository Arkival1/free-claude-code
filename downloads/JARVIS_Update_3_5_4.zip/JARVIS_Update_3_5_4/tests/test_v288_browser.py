import unittest
import time
from unittest.mock import MagicMock, patch
from jarvis_core.browser_dom import BrowserDOM,_allowed_url,_safe_action
from jarvis_core.policy import PolicyError

class DOMTests(unittest.TestCase):
    def test_allowed_sites_only(self):
        self.assertEqual(_allowed_url('https://ytmp3.zone/en/'),'ytmp3.zone')
        self.assertEqual(_allowed_url('https://www.youtubetotranscript.com/'),'youtubetotranscript.com')
        for bad in ['http://ytmp3.zone/','https://evil.example/','https://ytmp3.zone.evil.example/',
                    'https://127.0.0.1/','https://u:p@ytmp3.zone/','https://ytmp3.zone:4433/']:
            with self.subTest(url=bad),self.assertRaises(PolicyError):_allowed_url(bad)

    def test_disallow_download_and_checkout(self):
        for bad in ['Download MP3','Install','Get File','Pay Now','']:
            with self.subTest(label=bad),self.assertRaises(PolicyError):_safe_action(bad)
        self.assertEqual(_safe_action('Search'),'search')

    def _obj(self,host='https://ytmp3.zone/en/'):
        b=BrowserDOM(MagicMock())
        b._perm=lambda:None
        pl=MagicMock();browser=MagicMock();page=MagicMock()
        page.url=host
        b._context=lambda:(pl,browser,page)
        return b,pl,browser,page

    def test_verified_fill_only_after_inspection(self):
        b,pl,browser,page=self._obj()
        url='https://www.youtube.com/watch?v=WftF2zJkvHY'
        with self.assertRaises(PolicyError):b.fill_youtube(0,url)
        b._last_inspected={'url':page.url,'fields':[{'index':0,'label':'Video URL'}],
                           'actions':[],'at':time.monotonic()}
        locator=page.locator.return_value.nth.return_value
        locator.is_visible.return_value=True
        locator.input_value.return_value=url
        value=b.fill_youtube(0,url)
        self.assertTrue(value['ok'])
        self.assertEqual(value['verified_text'],url)
        locator.fill.assert_called_once_with(url,timeout=5000)
        browser.close.assert_called()

    def test_no_success_if_form_did_not_accept_input(self):
        b,pl,browser,page=self._obj()
        b._last_inspected={'url':page.url,'fields':[{'index':0,'label':'Video URL'}],
                           'actions':[],'at':time.monotonic()}
        locator=page.locator.return_value.nth.return_value
        locator.is_visible.return_value=True
        locator.input_value.return_value=''
        with self.assertRaisesRegex(PolicyError,'NOT verified'):
            b.fill_youtube(0,'https://www.youtube.com/watch?v=WftF2zJkvHY')

    def test_no_converter_click(self):
        b,pl,browser,page=self._obj()
        b._last_inspected={'url':page.url,'fields':[],
                           'actions':[{'index':3,'label':'Convert','requires_owner_review':False}],
                           'at':time.monotonic()}
        with self.assertRaisesRegex(PolicyError,'converter'):
            b.click_action(3)
        page.locator.assert_not_called()

    def test_no_download_click(self):
        b,pl,browser,page=self._obj()
        b._last_inspected={'url':page.url,'fields':[],
                           'actions':[{'index':3,'label':'Download audio','requires_owner_review':True}],
                           'at':time.monotonic()}
        with self.assertRaises(PolicyError):b.click_action(3)
        page.locator.assert_not_called()

    def test_page_change_invalidates_input(self):
        b,pl,browser,page=self._obj()
        b._last_inspected={'url':'https://ytmp3.zone/other','fields':[{'index':0,'label':'Video'}],
                           'actions':[],'at':time.monotonic()}
        with self.assertRaisesRegex(PolicyError,'Page changed'):
            b.fill_youtube(0,'https://www.youtube.com/watch?v=WftF2zJkvHY')

if __name__=='__main__':unittest.main()
