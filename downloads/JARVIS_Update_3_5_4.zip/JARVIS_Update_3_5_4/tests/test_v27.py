import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from jarvis_core.policy import Settings, PolicyError
from jarvis_core.skills import Skills
from jarvis_core.file_ops import FileOps
from jarvis_core.windows_uia import UIInspector


def cfg(root):
    return {'workspace':str(root/'workspace'),'data_dir':str(root/'data'),
            'permissions':{'files':True,'notes_and_tasks':True,'web_research':True,'screen':False,'desktop_control':False,
                           'app_launch':False,'downloads':False,'coding_lab':False,'preview_local':False},
            'desktop_mode':'approved_apps','approved_desktop_exes':['notepad.exe']}

class V27(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.path=self.base/'config.json'
        self.path.write_text(json.dumps(cfg(self.base)),encoding='utf8')
        self.settings=Settings(self.path)

    def test_builtin_skill_catalog_and_read(self):
        skills=Skills(self.settings)
        all_=skills.catalog()['skills']
        self.assertEqual(len(all_),9)
        self.assertIn('video_to_obsidian',{s['skill_id'] for s in all_})
        self.assertTrue(any(s['skill_id']=='obsidian_brain' for s in skills.catalog('Obsidian')['skills']))
        self.assertIn('Obsidian',skills.read('obsidian_brain')['content'])

    def test_skill_traversal_rejected(self):
        with self.assertRaises(PolicyError): Skills(self.settings).read('../config')

    def test_skills_read_only_does_not_require_file_permission(self):
        c=cfg(self.base);c['permissions']['files']=False
        self.path.write_text(json.dumps(c),encoding='utf8')
        self.assertIn('skills',Skills(self.settings).catalog())

    def test_copy_move_search(self):
        files=FileOps(self.settings)
        w=self.settings.workspace;w.mkdir()
        (w/'one.txt').write_text('hello',encoding='utf8')
        files.copy('one.txt','sub/two.txt')
        self.assertEqual((w/'sub'/'two.txt').read_text(),'hello')
        self.assertTrue((w/'one.txt').is_file())
        files.move('sub/two.txt','three.txt')
        self.assertFalse((w/'sub'/'two.txt').exists())
        self.assertIn('three.txt',files.find('three')['matches'])

    def test_cannot_overwrite_or_escape(self):
        files=FileOps(self.settings)
        w=self.settings.workspace;w.mkdir()
        (w/'one.txt').write_text('safe',encoding='utf8')
        with self.assertRaises(PolicyError):files.move('one.txt','one.txt')
        with self.assertRaises(PolicyError):files.copy('one.txt','../evil.txt')
        with self.assertRaises(PolicyError):files.copy('one.txt','one.txt')

    def test_stop_blocks_file_operations(self):
        w=self.settings.workspace;w.mkdir()
        (w/'one.txt').write_text('safe',encoding='utf8')
        self.settings.kill_switch_path().touch()
        with self.assertRaises(PolicyError):FileOps(self.settings).copy('one.txt','two.txt')

    @unittest.skip("Legacy upgrade helper intentionally excluded from fresh-install package")
    def test_owner_mode_makes_backup_and_keeps_download_review(self):
        import enable_owner_autonomy
        with patch.object(enable_owner_autonomy,'CFG',self.path):
            backup=enable_owner_autonomy.enable()
        updated=json.loads(self.path.read_text())
        old=json.loads(backup.read_text())
        self.assertEqual(old['desktop_mode'],'approved_apps')
        self.assertEqual(updated['desktop_mode'],'all_user_apps')
        self.assertTrue(all(updated['permissions'][x] for x in ('screen','desktop_control','app_launch','downloads','coding_lab','preview_local')))
        # Download approvals are implemented in a separate owner-controlled queue, not in this script.
        self.assertNotIn('auto_approve_downloads', updated)

    def test_uia_fails_closed_on_non_windows(self):
        class Desk:pass
        with self.assertRaises(PolicyError):UIInspector(Desk(),self.settings).controls()

    def test_runner_tools_available(self):
        import agent_runner
        for t in ('skills_list','skills_read','workspace_copy','workspace_move','workspace_find','desktop_ui_controls'):
            self.assertIn(t,agent_runner.ACTIONS)
        self.assertIsNone(agent_runner.DEFAULT_MAX_TURNS)

if __name__=='__main__':unittest.main()
