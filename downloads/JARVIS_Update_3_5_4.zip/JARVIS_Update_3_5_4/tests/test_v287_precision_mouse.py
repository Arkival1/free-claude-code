"""Extra mouse coordination tests: owner safety, geometry and model wiring."""
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from PIL import Image

from jarvis_core.desktop import Desktop
from jarvis_core.policy import Settings, PolicyError
import agent_runner, chat_runner

class PreciseMouseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        base=Path(self.tmp.name)
        c=base/'config.json'
        c.write_text(json.dumps({'workspace':str(base/'work'),'data_dir':str(base/'data'),
           'desktop_mode':'all_user_apps','permissions':{'screen':True,'desktop_control':True,'app_launch':True}}))
        self.desktop=Desktop(Settings(c));self.gui=Mock();self.gui.size.return_value=(1920,1080)
        self.gui.position.return_value=(960,540)
        self.win={'hwnd':7,'exe':'notepad.exe','rect':[0,0,1920,1080],'elevated':False}
        self.foreground=7
        parts=[patch.object(self.desktop,'_windows_only'),patch.object(self.desktop,'_gui',return_value=self.gui),
           patch.object(self.desktop,'_active_allowed',side_effect=lambda:self.win),
           patch.object(self.desktop,'_window_info',side_effect=lambda hwnd:self.win if hwnd==7 else None),
           patch.object(self.desktop,'_foreground',side_effect=lambda:self.foreground),
           patch.object(self.desktop,'_grab',return_value=Image.new('RGB',(1920,1080)))]
        for p in parts:p.start();self.addCleanup(p.stop)
        self.desktop.screenshot_guided()

    def test_click_center_of_button_box(self):
        result=self.desktop.click_box_image(600,300,700,400)
        self.assertEqual(result['image_box'],[600,300,700,400])
        self.gui.click.assert_called_once()
        actual=self.gui.click.call_args.kwargs
        self.assertTrue(970<=actual['x']<=975)
        self.assertTrue(520<=actual['y']<=525)
        self.assertIs(result['verified_target'],False)
        self.assertIsNone(self.desktop._last_frame)

    def test_rejects_ambiguous_boxes(self):
        for bounds in [(10,10,1000,500),(10,10,12,12),(-10,10,50,50),(100,100,99,110)]:
            with self.subTest(bounds=bounds),self.assertRaises(PolicyError):
                self.desktop.click_box_image(*bounds)
        self.gui.click.assert_not_called()

    def test_hover_moves_then_forces_screenshot(self):
        with patch('jarvis_core.desktop.time.sleep'):
            report=self.desktop.hover_image(200,200,0.6)
        self.assertEqual(report['desktop_point'],[300,300])
        self.assertIsNone(self.desktop._last_frame)
        self.gui.moveTo.assert_called_once_with(300,300,duration=0.2)

    def test_hover_rejects_unreasonable_duration(self):
        with self.assertRaises(PolicyError):self.desktop.hover_image(200,200,7)

    def test_scroll_moves_into_target_pane(self):
        report=self.desktop.scroll_image(400,300,-4)
        self.assertEqual(report['desktop_point'],[600,450])
        self.gui.scroll.assert_called_once_with(-4)
        self.assertIsNone(self.desktop._last_frame)

    def test_scroll_blocks_invalid_direction_and_changed_window(self):
        with self.assertRaises(PolicyError):self.desktop.scroll_image(400,300,0)
        self.foreground=8
        with self.assertRaises(PolicyError):self.desktop.scroll_image(400,300,-3)
        self.gui.scroll.assert_not_called()

    def test_mouse_pointer_coordinates(self):
        report=self.desktop.pointer_info()
        self.assertEqual(report['last_image_point'],[640,360])
        self.assertEqual(report['desktop_point'],[960,540])

    def test_drag_path_releases_left_button(self):
        points=[[50,50],[400,300],[800,500]]
        result=self.desktop.drag_path_image(points,0.8)
        self.assertEqual(len(result['desktop_waypoints']),3)
        self.gui.mouseDown.assert_called_once_with(button='left')
        self.gui.mouseUp.assert_called_once_with(button='left')
        self.assertIsNone(self.desktop._last_frame)

    def test_drag_path_releases_on_failure(self):
        # Fail halfway through via mouse move, must still release button.
        self.gui.moveTo.side_effect=[None,RuntimeError('mouse transport issue')]
        with self.assertRaisesRegex(RuntimeError,'mouse transport'):
            self.desktop.drag_path_image([[50,50],[400,300]],0.6)
        self.gui.mouseUp.assert_called_once_with(button='left')

    def test_drag_path_invalid_points_do_not_click(self):
        for points in [[],[[50,50]],[[50,50],[1900,400]],[[0.2,50],[40,40]],[[50,50],[100,100]]*7]:
            with self.subTest(points=points),self.assertRaises(PolicyError):
                self.desktop.drag_path_image(points)
        self.gui.mouseDown.assert_not_called()

    def test_stop_blocks_click(self):
        self.desktop.settings.kill_switch_path().write_text('STOP')
        with self.assertRaises(PolicyError):self.desktop.click_box_image(200,200,300,300)
        self.gui.click.assert_not_called()

class PrecisionWiringTests(unittest.TestCase):
    def test_all_interfaces_have_new_tools(self):
        names={'desktop_pointer_info','desktop_click_box_image','desktop_hover_image','desktop_scroll_image','desktop_drag_path_image'}
        declared={t['function']['name'] for t in agent_runner.DESKTOP_TOOLS}
        self.assertTrue(names<=declared)
        self.assertTrue(names<=set(agent_runner.ACTIONS))
        self.assertTrue(names<={t['function']['name'] for t in chat_runner.choose_tools('click Opera browser')})
        code=(Path(__file__).resolve().parents[1]/'server.py').read_text()
        for n in names:self.assertIn('def '+n+'(',code)

if __name__=='__main__':unittest.main()
