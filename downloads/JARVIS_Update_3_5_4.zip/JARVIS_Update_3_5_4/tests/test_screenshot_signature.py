"""Regression test: union with MCP Image causes Pydantic schema-generation crash.
This test uses stdlib AST, so it runs even when MCP dependencies are absent.
"""
import ast
from pathlib import Path
import unittest


class TestScreenshotSignature(unittest.TestCase):
    def test_screenshot_does_not_annotate_image_union(self):
        source = Path(__file__).resolve().parents[1] / "server.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        target = next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "desktop_screenshot"), None)
        self.assertIsNotNone(target)
        self.assertIsNone(target.returns, "Do not annotate desktop_screenshot with Image | str; MCP Pydantic registration crashes.")
