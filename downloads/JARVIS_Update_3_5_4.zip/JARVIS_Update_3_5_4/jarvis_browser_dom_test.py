"""Owner-operated visual/browser input check. NO conversion, NO download."""
from __future__ import annotations
import sys
import time
from pathlib import Path
from jarvis_core.policy import Settings, PolicyError
from jarvis_core.browser_dom import BrowserDOM
from jarvis_core.youtube import canonical_video


def run():
    config=Path(__file__).resolve().parent/'config.json'
    settings=Settings(config)
    bridge=BrowserDOM(settings)
    print('=== JARVIS Browser Input Test (no download, no payment) ===')
    url=input('Paste a public YouTube URL: ').strip()
    try: url,_=canonical_video(url)
    except PolicyError as exc:
        print('INVALID VIDEO:',exc);return 1
    try:
        print('Launching dedicated Opera/Edge profile...')
        print(bridge.open('https://ytmp3.zone/en/'))
        time.sleep(2)
        snapshot=None
        for attempt in range(4):
            try:
                snapshot=bridge.inspect();break
            except Exception as exc:
                if attempt==3:raise
                time.sleep(2)
        print('Actual visible text fields:')
        for fld in snapshot['fields']:
            print(' ',fld['index'],fld['label'],fld['type'])
        if not snapshot['fields']:
            print('NO VISIBLE INPUT. The site may block browser automation. Nothing was typed.');return 2
        fields=snapshot['fields']
        words=('youtube','video','paste','link','url')
        matches=[f for f in fields if any(w in f['label'].casefold() for w in words)]
        if len(matches)==1:
            index=matches[0]['index']
            print('Selected matching field:',index)
        else:
            print('Could not uniquely identify the URL input from its actual label.')
            print('No automatic action was taken. If the correct field is listed above, enter its exact index.')
            raw=input('Input field index or blank to cancel: ').strip()
            if not raw.isdigit():return 3
            index=int(raw)
        result=bridge.fill_youtube(index,url)
        if result.get('verified_text') != url:
            print('FAILED: input was not verified.');return 4
        print('SUCCESS: YouTube URL VERIFIED in actual webpage input:')
        print('  ',result['verified_text'])
        print('No conversion or download was attempted. Close the dedicated browser when finished.')
        return 0
    except (PolicyError,OSError,RuntimeError,ValueError) as exc:
        print('FAILED:',str(exc));return 5

if __name__=='__main__':sys.exit(run())
