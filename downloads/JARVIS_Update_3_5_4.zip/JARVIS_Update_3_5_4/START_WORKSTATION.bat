@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo JARVIS is not set up yet. Run START_JARVIS.bat and choose 1 first.
    pause
    exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" workstation.py
