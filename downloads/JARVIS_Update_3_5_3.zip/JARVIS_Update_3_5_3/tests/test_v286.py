"""v2.8.6 hotkey alias, transcript copy and source packaging regression tests."""
from pathlib import Path
import tempfile
import json
import unittest
from unittest.mock import Mock,patch
from jarvis_core.desktop import Desktop
from jarvis_core.policy import Settings,PolicyError
from jarvis_core.transcript_fallback import TranscriptFallback
import agent_runner

class HotkeyFix(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        base=Path(tmp.name)
        cfg=base/'config.json'
        cfg.write_text(json.dumps({'workspace':str(base/'work'),'data_dir':str(base/'data'),
            'desktop_mode':'all_user_apps','permissions':{'desktop_control':True,'files':True,'screen':True},
            'approved_desktop_exes':[],'apps':{}}))
        self.settings=Settings(cfg)
        self.desktop=Desktop(self.settings)

    def test_ctrl_c_and_copy_are_equivalent(self):
        for arg in ['copy','Ctrl+C','CTRL + C','control+c','^c']:
            with self.subTest(arg=arg):
                gui=Mock()
                with patch.object(self.desktop,'_active_allowed',return_value={'exe':'opera.exe'}),patch.object(self.desktop,'_gui',return_value=gui):
                    result=self.desktop.hotkey(arg)
                gui.hotkey.assert_called_once_with('ctrl','c')
                self.assertIn('copy',result)

    def test_other_shortcuts_and_address_bar(self):
        cases={'Ctrl+V':('ctrl','v'),'Ctrl+A':('ctrl','a'),'CTRL+L':('ctrl','l'),
               'escape':('esc',),'Ctrl+S':('ctrl','s'),'undo':('ctrl','z')}
        for name,keys in cases.items():
            with self.subTest(name=name):
                gui=Mock()
                with patch.object(self.desktop,'_active_allowed',return_value={'exe':'opera.exe'}),patch.object(self.desktop,'_gui',return_value=gui):
                    self.desktop.hotkey(name)
                gui.hotkey.assert_called_once_with(*keys)

    def test_dangerous_shortcuts_are_still_blocked(self):
        for name in ('Ctrl+Alt+Del','Win+R','Alt+F4','PowerShell','',None,'Ctrl+Shift+Esc'):
            with self.subTest(name=name),self.assertRaises(PolicyError):
                Desktop.normalize_hotkey(name)

    def test_copy_import_uses_the_safe_browser_and_verifies_saved_text(self):
        fallback=TranscriptFallback(self.settings,Mock(),Mock())
        fake_desktop=Mock()
        fake_desktop._active_allowed.return_value={'exe':'opera.exe'}
        with patch.object(fallback,'import_clipboard',return_value={'saved':True,'file':'JARVIS_Brain/Research/YouTube/abc-website.txt'}) as imported:
            result=fallback.copy_selection_and_import('https://www.youtube.com/watch?v=dQw4w9WgXcQ','companion',fake_desktop)
        fake_desktop.hotkey.assert_called_once_with('copy')
        imported.assert_called_once()
        self.assertTrue(result['saved'])

    def test_copy_import_refuses_unrelated_app(self):
        fallback=TranscriptFallback(self.settings,Mock(),Mock())
        fake_desktop=Mock();fake_desktop._active_allowed.return_value={'exe':'notepad.exe'}
        with self.assertRaises(PolicyError):
            fallback.copy_selection_and_import('https://www.youtube.com/watch?v=dQw4w9WgXcQ','companion',fake_desktop)
        fake_desktop.hotkey.assert_not_called()

    def test_failed_copy_gives_specific_next_step_and_stops(self):
        fallback=TranscriptFallback(self.settings,Mock(),Mock())
        fake_desktop=Mock();fake_desktop._active_allowed.return_value={'exe':'opera.exe'}
        with patch.object(fallback,'import_clipboard',side_effect=PolicyError('Clipboard has only the URL')):
            with self.assertRaisesRegex(PolicyError,'Select the actual transcript text'):
                fallback.copy_selection_and_import('https://www.youtube.com/watch?v=dQw4w9WgXcQ','companion',fake_desktop)

    def test_runner_registers_new_tool_and_does_not_restore_turn_cap_or_advisers(self):
        funcs={t['function']['name'] for t in agent_runner.focused_tools('transcribe YouTube',desktop=True)}
        self.assertIn('youtube_transcript_copy_import',funcs)
        self.assertIn('desktop_hotkey',funcs)
        self.assertIsNone(agent_runner.DEFAULT_MAX_TURNS)
        self.assertFalse(any('adviser' in name for name in agent_runner.ACTIONS))

    def test_mcp_and_installer_include_fix(self):
        base=Path(__file__).resolve().parents[1]
        server=(base/'server.py').read_text()
        self.assertIn('def youtube_transcript_copy_import',server)
        self.assertIn("'version':'3.5.3'",server)
        self.assertTrue((base/'START_JARVIS.bat').is_file())
        self.assertIn('verify_python_dependencies',(base/'jarvis_setup.py').read_text())

if __name__=='__main__':unittest.main()
